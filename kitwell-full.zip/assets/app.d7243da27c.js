//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

}();


(function(factory){if(typeof exports==="object"){module.exports=factory()}else if(typeof define==="function"&&define.amd){define(factory)}else{var glob;try{glob=window}catch(e){glob=self}glob.SparkMD5=factory()}})(function(undefined){"use strict";var add32=function(a,b){return a+b&4294967295},hex_chr=["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"];function cmn(q,a,b,x,s,t){a=add32(add32(a,q),add32(x,t));return add32(a<<s|a>>>32-s,b)}function md5cycle(x,k){var a=x[0],b=x[1],c=x[2],d=x[3];a+=(b&c|~b&d)+k[0]-680876936|0;a=(a<<7|a>>>25)+b|0;d+=(a&b|~a&c)+k[1]-389564586|0;d=(d<<12|d>>>20)+a|0;c+=(d&a|~d&b)+k[2]+606105819|0;c=(c<<17|c>>>15)+d|0;b+=(c&d|~c&a)+k[3]-1044525330|0;b=(b<<22|b>>>10)+c|0;a+=(b&c|~b&d)+k[4]-176418897|0;a=(a<<7|a>>>25)+b|0;d+=(a&b|~a&c)+k[5]+1200080426|0;d=(d<<12|d>>>20)+a|0;c+=(d&a|~d&b)+k[6]-1473231341|0;c=(c<<17|c>>>15)+d|0;b+=(c&d|~c&a)+k[7]-45705983|0;b=(b<<22|b>>>10)+c|0;a+=(b&c|~b&d)+k[8]+1770035416|0;a=(a<<7|a>>>25)+b|0;d+=(a&b|~a&c)+k[9]-1958414417|0;d=(d<<12|d>>>20)+a|0;c+=(d&a|~d&b)+k[10]-42063|0;c=(c<<17|c>>>15)+d|0;b+=(c&d|~c&a)+k[11]-1990404162|0;b=(b<<22|b>>>10)+c|0;a+=(b&c|~b&d)+k[12]+1804603682|0;a=(a<<7|a>>>25)+b|0;d+=(a&b|~a&c)+k[13]-40341101|0;d=(d<<12|d>>>20)+a|0;c+=(d&a|~d&b)+k[14]-1502002290|0;c=(c<<17|c>>>15)+d|0;b+=(c&d|~c&a)+k[15]+1236535329|0;b=(b<<22|b>>>10)+c|0;a+=(b&d|c&~d)+k[1]-165796510|0;a=(a<<5|a>>>27)+b|0;d+=(a&c|b&~c)+k[6]-1069501632|0;d=(d<<9|d>>>23)+a|0;c+=(d&b|a&~b)+k[11]+643717713|0;c=(c<<14|c>>>18)+d|0;b+=(c&a|d&~a)+k[0]-373897302|0;b=(b<<20|b>>>12)+c|0;a+=(b&d|c&~d)+k[5]-701558691|0;a=(a<<5|a>>>27)+b|0;d+=(a&c|b&~c)+k[10]+38016083|0;d=(d<<9|d>>>23)+a|0;c+=(d&b|a&~b)+k[15]-660478335|0;c=(c<<14|c>>>18)+d|0;b+=(c&a|d&~a)+k[4]-405537848|0;b=(b<<20|b>>>12)+c|0;a+=(b&d|c&~d)+k[9]+568446438|0;a=(a<<5|a>>>27)+b|0;d+=(a&c|b&~c)+k[14]-1019803690|0;d=(d<<9|d>>>23)+a|0;c+=(d&b|a&~b)+k[3]-187363961|0;c=(c<<14|c>>>18)+d|0;b+=(c&a|d&~a)+k[8]+1163531501|0;b=(b<<20|b>>>12)+c|0;a+=(b&d|c&~d)+k[13]-1444681467|0;a=(a<<5|a>>>27)+b|0;d+=(a&c|b&~c)+k[2]-51403784|0;d=(d<<9|d>>>23)+a|0;c+=(d&b|a&~b)+k[7]+1735328473|0;c=(c<<14|c>>>18)+d|0;b+=(c&a|d&~a)+k[12]-1926607734|0;b=(b<<20|b>>>12)+c|0;a+=(b^c^d)+k[5]-378558|0;a=(a<<4|a>>>28)+b|0;d+=(a^b^c)+k[8]-2022574463|0;d=(d<<11|d>>>21)+a|0;c+=(d^a^b)+k[11]+1839030562|0;c=(c<<16|c>>>16)+d|0;b+=(c^d^a)+k[14]-35309556|0;b=(b<<23|b>>>9)+c|0;a+=(b^c^d)+k[1]-1530992060|0;a=(a<<4|a>>>28)+b|0;d+=(a^b^c)+k[4]+1272893353|0;d=(d<<11|d>>>21)+a|0;c+=(d^a^b)+k[7]-155497632|0;c=(c<<16|c>>>16)+d|0;b+=(c^d^a)+k[10]-1094730640|0;b=(b<<23|b>>>9)+c|0;a+=(b^c^d)+k[13]+681279174|0;a=(a<<4|a>>>28)+b|0;d+=(a^b^c)+k[0]-358537222|0;d=(d<<11|d>>>21)+a|0;c+=(d^a^b)+k[3]-722521979|0;c=(c<<16|c>>>16)+d|0;b+=(c^d^a)+k[6]+76029189|0;b=(b<<23|b>>>9)+c|0;a+=(b^c^d)+k[9]-640364487|0;a=(a<<4|a>>>28)+b|0;d+=(a^b^c)+k[12]-421815835|0;d=(d<<11|d>>>21)+a|0;c+=(d^a^b)+k[15]+530742520|0;c=(c<<16|c>>>16)+d|0;b+=(c^d^a)+k[2]-995338651|0;b=(b<<23|b>>>9)+c|0;a+=(c^(b|~d))+k[0]-198630844|0;a=(a<<6|a>>>26)+b|0;d+=(b^(a|~c))+k[7]+1126891415|0;d=(d<<10|d>>>22)+a|0;c+=(a^(d|~b))+k[14]-1416354905|0;c=(c<<15|c>>>17)+d|0;b+=(d^(c|~a))+k[5]-57434055|0;b=(b<<21|b>>>11)+c|0;a+=(c^(b|~d))+k[12]+1700485571|0;a=(a<<6|a>>>26)+b|0;d+=(b^(a|~c))+k[3]-1894986606|0;d=(d<<10|d>>>22)+a|0;c+=(a^(d|~b))+k[10]-1051523|0;c=(c<<15|c>>>17)+d|0;b+=(d^(c|~a))+k[1]-2054922799|0;b=(b<<21|b>>>11)+c|0;a+=(c^(b|~d))+k[8]+1873313359|0;a=(a<<6|a>>>26)+b|0;d+=(b^(a|~c))+k[15]-30611744|0;d=(d<<10|d>>>22)+a|0;c+=(a^(d|~b))+k[6]-1560198380|0;c=(c<<15|c>>>17)+d|0;b+=(d^(c|~a))+k[13]+1309151649|0;b=(b<<21|b>>>11)+c|0;a+=(c^(b|~d))+k[4]-145523070|0;a=(a<<6|a>>>26)+b|0;d+=(b^(a|~c))+k[11]-1120210379|0;d=(d<<10|d>>>22)+a|0;c+=(a^(d|~b))+k[2]+718787259|0;c=(c<<15|c>>>17)+d|0;b+=(d^(c|~a))+k[9]-343485551|0;b=(b<<21|b>>>11)+c|0;x[0]=a+x[0]|0;x[1]=b+x[1]|0;x[2]=c+x[2]|0;x[3]=d+x[3]|0}function md5blk(s){var md5blks=[],i;for(i=0;i<64;i+=4){md5blks[i>>2]=s.charCodeAt(i)+(s.charCodeAt(i+1)<<8)+(s.charCodeAt(i+2)<<16)+(s.charCodeAt(i+3)<<24)}return md5blks}function md5blk_array(a){var md5blks=[],i;for(i=0;i<64;i+=4){md5blks[i>>2]=a[i]+(a[i+1]<<8)+(a[i+2]<<16)+(a[i+3]<<24)}return md5blks}function md51(s){var n=s.length,state=[1732584193,-271733879,-1732584194,271733878],i,length,tail,tmp,lo,hi;for(i=64;i<=n;i+=64){md5cycle(state,md5blk(s.substring(i-64,i)))}s=s.substring(i-64);length=s.length;tail=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(i=0;i<length;i+=1){tail[i>>2]|=s.charCodeAt(i)<<(i%4<<3)}tail[i>>2]|=128<<(i%4<<3);if(i>55){md5cycle(state,tail);for(i=0;i<16;i+=1){tail[i]=0}}tmp=n*8;tmp=tmp.toString(16).match(/(.*?)(.{0,8})$/);lo=parseInt(tmp[2],16);hi=parseInt(tmp[1],16)||0;tail[14]=lo;tail[15]=hi;md5cycle(state,tail);return state}function md51_array(a){var n=a.length,state=[1732584193,-271733879,-1732584194,271733878],i,length,tail,tmp,lo,hi;for(i=64;i<=n;i+=64){md5cycle(state,md5blk_array(a.subarray(i-64,i)))}a=i-64<n?a.subarray(i-64):new Uint8Array(0);length=a.length;tail=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(i=0;i<length;i+=1){tail[i>>2]|=a[i]<<(i%4<<3)}tail[i>>2]|=128<<(i%4<<3);if(i>55){md5cycle(state,tail);for(i=0;i<16;i+=1){tail[i]=0}}tmp=n*8;tmp=tmp.toString(16).match(/(.*?)(.{0,8})$/);lo=parseInt(tmp[2],16);hi=parseInt(tmp[1],16)||0;tail[14]=lo;tail[15]=hi;md5cycle(state,tail);return state}function rhex(n){var s="",j;for(j=0;j<4;j+=1){s+=hex_chr[n>>j*8+4&15]+hex_chr[n>>j*8&15]}return s}function hex(x){var i;for(i=0;i<x.length;i+=1){x[i]=rhex(x[i])}return x.join("")}if(hex(md51("hello"))!=="5d41402abc4b2a76b9719d911017c592"){add32=function(x,y){var lsw=(x&65535)+(y&65535),msw=(x>>16)+(y>>16)+(lsw>>16);return msw<<16|lsw&65535}}if(typeof ArrayBuffer!=="undefined"&&!ArrayBuffer.prototype.slice){(function(){function clamp(val,length){val=val|0||0;if(val<0){return Math.max(val+length,0)}return Math.min(val,length)}ArrayBuffer.prototype.slice=function(from,to){var length=this.byteLength,begin=clamp(from,length),end=length,num,target,targetArray,sourceArray;if(to!==undefined){end=clamp(to,length)}if(begin>end){return new ArrayBuffer(0)}num=end-begin;target=new ArrayBuffer(num);targetArray=new Uint8Array(target);sourceArray=new Uint8Array(this,begin,num);targetArray.set(sourceArray);return target}})()}function toUtf8(str){if(/[\u0080-\uFFFF]/.test(str)){str=unescape(encodeURIComponent(str))}return str}function utf8Str2ArrayBuffer(str,returnUInt8Array){var length=str.length,buff=new ArrayBuffer(length),arr=new Uint8Array(buff),i;for(i=0;i<length;i+=1){arr[i]=str.charCodeAt(i)}return returnUInt8Array?arr:buff}function arrayBuffer2Utf8Str(buff){return String.fromCharCode.apply(null,new Uint8Array(buff))}function concatenateArrayBuffers(first,second,returnUInt8Array){var result=new Uint8Array(first.byteLength+second.byteLength);result.set(new Uint8Array(first));result.set(new Uint8Array(second),first.byteLength);return returnUInt8Array?result:result.buffer}function hexToBinaryString(hex){var bytes=[],length=hex.length,x;for(x=0;x<length-1;x+=2){bytes.push(parseInt(hex.substr(x,2),16))}return String.fromCharCode.apply(String,bytes)}function SparkMD5(){this.reset()}SparkMD5.prototype.append=function(str){this.appendBinary(toUtf8(str));return this};SparkMD5.prototype.appendBinary=function(contents){this._buff+=contents;this._length+=contents.length;var length=this._buff.length,i;for(i=64;i<=length;i+=64){md5cycle(this._hash,md5blk(this._buff.substring(i-64,i)))}this._buff=this._buff.substring(i-64);return this};SparkMD5.prototype.end=function(raw){var buff=this._buff,length=buff.length,i,tail=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],ret;for(i=0;i<length;i+=1){tail[i>>2]|=buff.charCodeAt(i)<<(i%4<<3)}this._finish(tail,length);ret=hex(this._hash);if(raw){ret=hexToBinaryString(ret)}this.reset();return ret};SparkMD5.prototype.reset=function(){this._buff="";this._length=0;this._hash=[1732584193,-271733879,-1732584194,271733878];return this};SparkMD5.prototype.getState=function(){return{buff:this._buff,length:this._length,hash:this._hash.slice()}};SparkMD5.prototype.setState=function(state){this._buff=state.buff;this._length=state.length;this._hash=state.hash;return this};SparkMD5.prototype.destroy=function(){delete this._hash;delete this._buff;delete this._length};SparkMD5.prototype._finish=function(tail,length){var i=length,tmp,lo,hi;tail[i>>2]|=128<<(i%4<<3);if(i>55){md5cycle(this._hash,tail);for(i=0;i<16;i+=1){tail[i]=0}}tmp=this._length*8;tmp=tmp.toString(16).match(/(.*?)(.{0,8})$/);lo=parseInt(tmp[2],16);hi=parseInt(tmp[1],16)||0;tail[14]=lo;tail[15]=hi;md5cycle(this._hash,tail)};SparkMD5.hash=function(str,raw){return SparkMD5.hashBinary(toUtf8(str),raw)};SparkMD5.hashBinary=function(content,raw){var hash=md51(content),ret=hex(hash);return raw?hexToBinaryString(ret):ret};SparkMD5.ArrayBuffer=function(){this.reset()};SparkMD5.ArrayBuffer.prototype.append=function(arr){var buff=concatenateArrayBuffers(this._buff.buffer,arr,true),length=buff.length,i;this._length+=arr.byteLength;for(i=64;i<=length;i+=64){md5cycle(this._hash,md5blk_array(buff.subarray(i-64,i)))}this._buff=i-64<length?new Uint8Array(buff.buffer.slice(i-64)):new Uint8Array(0);return this};SparkMD5.ArrayBuffer.prototype.end=function(raw){var buff=this._buff,length=buff.length,tail=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],i,ret;for(i=0;i<length;i+=1){tail[i>>2]|=buff[i]<<(i%4<<3)}this._finish(tail,length);ret=hex(this._hash);if(raw){ret=hexToBinaryString(ret)}this.reset();return ret};SparkMD5.ArrayBuffer.prototype.reset=function(){this._buff=new Uint8Array(0);this._length=0;this._hash=[1732584193,-271733879,-1732584194,271733878];return this};SparkMD5.ArrayBuffer.prototype.getState=function(){var state=SparkMD5.prototype.getState.call(this);state.buff=arrayBuffer2Utf8Str(state.buff);return state};SparkMD5.ArrayBuffer.prototype.setState=function(state){state.buff=utf8Str2ArrayBuffer(state.buff,true);return SparkMD5.prototype.setState.call(this,state)};SparkMD5.ArrayBuffer.prototype.destroy=SparkMD5.prototype.destroy;SparkMD5.ArrayBuffer.prototype._finish=SparkMD5.prototype._finish;SparkMD5.ArrayBuffer.hash=function(arr,raw){var hash=md51_array(new Uint8Array(arr)),ret=hex(hash);return raw?hexToBinaryString(ret):ret};return SparkMD5});

;
const WORDLIST = ["abacus","abroad","aching","active","afford","agenda","aground","alfalfa","aloe","amaze","amiss","amulet","android","angling","another","anybody","appear","apron","armful","aroma","arson","askew","atom","attire","avenge","award","babied","badass","bagged","balcony","banner","barley","basil","battery","blame","blemish","blitz","bluish","bobbed","bogus","boney","bootie","botany","boxer","brewery","brim","broiler","brunch","budding","bulb","bunch","busily","cache","cahoots","camera","candy","canopy","capsize","carded","carpool","carving","catcall","cattail","cavalry","chafe","chaos","charter","cheese","chevy","chirpy","chowder","chute","citric","clamp","clatter","clench","clique","clover","coaster","coexist","collie","comma","compile","concise","conjure","contour","copious","corny","cosmos","courier","cramp","crazed","creme","cried","crispy","crouton","crummy","crystal","cupid","curled","curtly","customs","dagger","danger","dating","deacon","debug","decibel","deed","defiant","defy","demise","denture","depth","despite","device","dictate","dimple","dioxide","discuss","disown","ditto","dodgy","donated","dork","doze","dreamt","drift","drool","drum","dugout","durable","dwarf","earache","earshot","easing","ebook","edgy","either","elf","elusive","embody","empower","encrust","engine","enslave","entree","equal","errant","etching","even","excess","exile","explain","extrude","factual","fame","fantasy","fedora","fender","fetch","figment","finale","fit","flap","fleshed","flirt","flyer","follow","footman","frail","freedom","fretted","fritter","fruit","galley","gangway","garnet","gazing","gentile","getup","gilled","glacial","glazing","glitzy","glue","golf","google","gotten","grandly","grapple","gray","grimace","groom","growing","guide","gummy","guy","haiku","hamster","handset","hardhat","hash","hatred","heading","hedging","henna","hertz","human","hungry","hurried","hyphen","idiom","impale","imprint","ipod","item","jam","jawless","jester","job","jovial","jujitsu","junkie","karaoke","kept","kinetic","kitten","kosher","ladybug","lanky","lark","launch","legal","lemon","lettuce","lifter","limeade","lint","litter","lucid","lung","lying","magnify","manager","manhunt","mantis","margin","marshy","matcher","maybe","modify","mongrel","mop","motive","move","mulch","mundane","musky","mutt","nail","narrow","neatly","nervous","nibble","nucleus","nursing","oak","obtuse","ogle","omit","onto","operate","ought","outgrow","output","overact","overtly","paced","paging","pang","papyrus","parkway","partly","pastel","patriot","payee","pelican","penny","perky","petty","phrase","plated","plaza","ploy","poem","poking","polymer","popular","possum","pouch","prance","preface","preppy","pretzel","primer","prize","profile","prorate","proxy","pueblo","punch","purify","pushing","quack","quarry","quintet","rack","ragged","raking","ranging","rash","ream","rebound","recess","recount","refined","refund","region","rejoin","relieve","remarry","removed","reopen","replica","require","reshape","retake","retract","reunion","reverse","rewash","ribcage","rifling","rinse","risk","robbing","roman","roundup","rubble","rummage","rural","sadly","said","salsa","sandbox","sappy","sauna","scabby","scarce","scion","scoring","scribe","scuttle","segment","send","serve","seventy","shakily","shanty","shed","shifter","ship","shorts","showoff","shrubs","siamese","silicon","sincere","sister","sizably","skewer","skimmer","slacked","slather","slicer","sliver","slum","smile","smoky","snaking","sniff","snout","species","sphere","spindle","splurge","spooky","spousal","spring","sputter","squirt","stamina","stark","state","steed","sternum","stingy","stomp","storage","stream","strike","stubbed","stuffed","sturdy","subpar","subway","sugar","sullen","surgery","suspect","sweep","swirl","swung","tablet","tadpole","tamer","tapping","tassel","that","thesis","thirsty","thrive","tibia","tile","tingly","tipping","trading","traps","tremble","trickle","tripod","trowel","tubby","turban","tutu","twiddle","twitter","unawake","uncheck","uncouth","undoing","uneven","unheard","unison","unlined","unnerve","unrest","unseen","untaxed","untwist","unwind","upfront","upriver","uptake","urgent","usual","vacate","vanity","vastly","venue","very","video","viper","visitor","void","voyage","wake","wanted","wasp","wheat","wick","wildcat","wincing","wiry","wok","work","wrath","writing","yanking","yen","yoyo","zipping","zoom"];
const PASSPHRASE_WORDS = WORDLIST;

;
// Custom SVG glyph set (24x24 grid, stroked). No emoji, no icon fonts.
const G = {
  text:'<path d="M5 6h14M12 6v12M9 18h6"/>',
  count:'<path d="M5 8h14M5 12h14M5 16h8"/><path d="M17 15v4M15 17h4"/>',
  case:'<path d="M3 17l4-10 4 10M4.5 13.5h5"/><path d="M14 17v-6a2.5 2.5 0 0 1 5 0v6M14 14.5h5"/>',
  space:'<path d="M4 9v6h16V9"/><path d="M8 4l-2 2 2 2M16 4l2 2-2 2"/>',
  sort:'<path d="M7 5v14M4 16l3 3 3-3M17 19V5M14 8l3-3 3 3"/>',
  dup:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/>',
  random:'<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="15" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="9" cy="15" r="1"/>',
  link:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  reverse:'<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
  lines:'<path d="M4 6h16M4 10h16M4 14h10M4 18h7"/>',
  find:'<circle cx="10" cy="10" r="5"/><path d="M14 14l5 5M8 10h4"/>',
  compare:'<path d="M9 4v16M15 4v16"/><path d="M4 8h3M4 12h3M17 12h3M17 16h3"/>',
  repeat:'<path d="M5 11V9a3 3 0 0 1 3-3h11l-3-3M19 13v2a3 3 0 0 1-3 3H5l3 3"/>',
  code:'<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
  tag:'<path d="M3 12V4h8l9 9-8 8z"/><circle cx="7.5" cy="8.5" r="1"/>',
  chart:'<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
  cipher:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  wave:'<path d="M3 12h2l2-6 3 12 3-9 2 3h6"/>',
  binary:'<path d="M7 5v6M5 7l2-2M14 5h3v6h-3zM7 14h0M5 19h4M14 14h3v5h-3z"/>',
  sound:'<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  mirror:'<path d="M12 3v18" stroke-dasharray="2 3"/><path d="M9 7L3 12l6 5zM15 7l6 5-6 5z"/>',
  swap:'<path d="M5 9h14l-4-4M19 15H5l4 4"/>',
  ruler:'<rect x="3" y="8" width="18" height="8" rx="1.5"/><path d="M7 8v3M11 8v4M15 8v3M19 8v2"/>',
  calendar:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  percent:'<path d="M18 6L6 18"/><circle cx="7.5" cy="7.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/>',
  money:'<circle cx="12" cy="12" r="8"/><path d="M14.5 9.5c-.5-1-1.4-1.5-2.5-1.5-1.4 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1.1 2-2.5 2c-1.1 0-2-.5-2.5-1.5M12 6.5V8M12 16v1.5"/>',
  bank:'<path d="M3 10l9-6 9 6zM5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>',
  tax:'<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 14l5-4M9.5 10h.01M13.5 14h.01"/>',
  tip:'<path d="M5 8h14l-1.5 11h-11z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  fuel:'<path d="M5 20V5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v15M4 20h11"/><path d="M14 9h2.5a1.5 1.5 0 0 1 1.5 1.5V16a1.5 1.5 0 0 0 3 0V9l-3-3"/><path d="M7 8h5"/>',
  cap:'<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c3 2.5 9 2.5 12 0v-4.5"/>',
  avg:'<path d="M4 12h16"/><circle cx="12" cy="6.5" r="1.5"/><circle cx="12" cy="17.5" r="1.5"/>',
  person:'<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>',
  scale:'<path d="M12 4v16M6 20h12M5 8h14"/><path d="M5 8l-2.5 6a3 3 0 0 0 5 0zM19 8l-2.5 6a3 3 0 0 0 5 0z"/>',
  calc:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
  trend:'<path d="M3 17l6-6 4 4 8-8M15 7h6v6"/>',
  target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".5"/>',
  ratio:'<circle cx="7" cy="7" r="2"/><circle cx="17" cy="17" r="2"/><path d="M19 5L5 19"/>',
  image:'<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
  resize:'<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>',
  compress:'<path d="M4 14h6v6M20 10h-6V4M10 14l-7 7M14 10l7-7"/>',
  crop:'<path d="M7 3v14h14M3 7h14v14"/>',
  picker:'<path d="M14 5l5 5-9 9H5v-5z"/><path d="M13 6l-1.5-1.5a2 2 0 0 1 2.8-2.8L20 7.4"/>',
  rotate:'<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
  star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  braces:'<path d="M8 4c-2 0-3 1-3 3v2c0 1.5-1 2.5-2 3 1 .5 2 1.5 2 3v2c0 2 1 3 3 3M16 4c2 0 3 1 3 3v2c0 1.5 1 2.5 2 3-1 .5-2 1.5-2 3v2c0 2-1 3-3 3"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
  id:'<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="9" cy="12" r="2"/><path d="M14 10h4M14 14h3M6 16c.5-1.2 1.6-2 3-2s2.5.8 3 2"/>',
  hash:'<path d="M5 9h15M4 15h15M10 4L8 20M16 4l-2 16"/>',
  regex:'<path d="M12 4v8M8.5 6l7 4M15.5 6l-7 4"/><circle cx="7" cy="18" r="1.2"/><path d="M12 15v5"/>',
  palette:'<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 2-2 0-1.5-1-1.5-1-3s1-2 2.500-2H18a3 3 0 0 0 3-3c0-4.500-4-8-9-8z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.500" r="1"/><circle cx="16" cy="11" r="1"/>',
  token:'<path d="M3 12a4 4 0 0 1 4-4h2M21 12a4 4 0 0 1-4 4h-2M8 12h8"/>',
  doc:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
  min:'<path d="M4 6l7 6-7 6M13 18h7"/>',
  clock:'<circle cx="12" cy="12" r="8.500"/><path d="M12 7v5l3 2"/>',
  stopwatch:'<circle cx="12" cy="13" r="7"/><path d="M12 13V9M9.500 3h5M18 6l1.500-1.500"/>',
  hourglass:'<path d="M7 3h10M7 21h10M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9"/>',
  globe:'<circle cx="12" cy="12" r="8.500"/><path d="M3.500 12h17M12 3.500c3 3 3 14 0 17M12 3.500c-3 3-3 14 0 17"/>',
  qr:'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h3v3M20 14v.01M14 20h.01M17 20h3v-3"/>',
  pin:'<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.500"/>',
  coin:'<circle cx="12" cy="12" r="8.500"/><path d="M12 7v10M9 9.500h4.500a2 2 0 0 1 0 4H9.500"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  heart:'<path d="M12 20s-8-5-8-11a4.500 4.500 0 0 1 8-2.500A4.500 4.500 0 0 1 20 9c0 6-8 11-8 11z"/>',
  drop:'<path d="M12 3s6 6.500 6 11a6 6 0 0 1-12 0c0-4.500 6-11 6-11z"/>',
  run:'<circle cx="14" cy="5" r="2"/><path d="M6 21l4-6 3 2 2-6-4-2-3 3M13 11l4 3 3-1"/>',
  bolt:'<path d="M13 3L5 13h6l-1 8 8-10h-6z"/>',
  shield:'<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  card:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18M7 15h4"/>',
  sqrt:'<path d="M4 13l3 5 4-14h9"/><path d="M13 9l5 6M18 9l-5 6"/>',
  prime:'<circle cx="7" cy="7" r="2"/><circle cx="17" cy="7" r="2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><circle cx="12" cy="12" r="2"/>',
  fib:'<path d="M4 20V10h6v6H4M10 10V4h10v12H10"/><path d="M10 16c4 0 6-3 6-6"/>',
  fact:'<path d="M9 4v12M9 19.500v.01M15 4v12"/>',
  roman:'<path d="M5 5v14M11 5v14M17 5l4 14M21 5l-4 14"/>',
  triangle:'<path d="M12 4l9 16H3z"/><path d="M12 4v16"/>',
  sigma:'<path d="M18 5H6l6 7-6 7h12"/>',
  log:'<path d="M4 20V4M4 20h16"/><path d="M6 17c2-8 6-9 12-10"/>',
  perm:'<path d="M5 7h10M5 12h14M5 17h10"/><circle cx="19" cy="7" r="1.200"/><circle cx="19" cy="17" r="1.200"/>',
  temp:'<path d="M10 14V5a2 2 0 0 1 4 0v9a4 4 0 1 1-4 0z"/><path d="M12 8v8"/>',
  box:'<path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
  area:'<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M4 12h16M12 4v16"/>',
  angle:'<path d="M4 19h16M4 19L16 7"/><path d="M11 19a7 7 0 0 0-2-5"/>',
  freq:'<path d="M3 12c2-6 3-6 4.500 0s2.500 6 4.500 0 2.500-6 4.500 0 2.500 6 4.500 0"/>',
  shoe:'<path d="M3 16V9l5 2 3-3 3 3 7 3v2z"/><path d="M3 19h18"/>',
  cook:'<path d="M5 11h14v5a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4z"/><path d="M8 7c0-1 1-1.500 1-3M12 7c0-1 1-1.500 1-3M16 7c0-1 1-1.500 1-3"/>',
  data:'<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.700 3 3 7 3s7-1.300 7-3V6M5 12v6c0 1.700 3 3 7 3s7-1.300 7-3v-6"/>',
  power:'<path d="M12 3v8M6.500 6.500a8 8 0 1 0 11 0"/>',
  force:'<path d="M4 12h14M13 7l5 5-5 5"/><path d="M4 7v10"/>',
  pressure:'<circle cx="12" cy="13" r="8"/><path d="M12 13l4-4M12 5v1.500M5 13h1.500M19 13h-1.500"/>',
  meta:'<path d="M4 6h16M4 10h10M4 14h16M4 18h7"/><circle cx="18" cy="17" r="3"/><path d="M20 19l2 2"/>',
  share:'<circle cx="6" cy="12" r="2.500"/><circle cx="17" cy="6" r="2.500"/><circle cx="17" cy="18" r="2.500"/><path d="M8.200 11l6.600-3.800M8.200 13l6.600 3.800"/>',
  robot:'<rect x="5" y="8" width="14" height="11" rx="2"/><path d="M12 4v4M9 13h.01M15 13h.01M9 16.500h6"/>',
  map:'<path d="M4 6l5-2 6 2 5-2v14l-5 2-6-2-5 2zM9 4v14M15 6v14"/>',
  utm:'<path d="M10 14l-2 2a3 3 0 0 1-4-4l3-3a3 3 0 0 1 4 0M14 10l2-2a3 3 0 0 1 4 4l-3 3a3 3 0 0 1-4 0"/><path d="M9 15l6-6"/>',
  tool:'<path d="M14.500 6.500a4 4 0 0 0 5 5L10 21a2.100 2.100 0 0 1-3-3z"/><path d="M14.500 6.500L17 4l3 3-2.500 2.500"/>',
  wheel:'<circle cx="12" cy="12" r="8.500"/><path d="M12 3.500v17M3.500 12h17M6 6l12 12M18 6L6 18"/>',
  users:'<circle cx="9" cy="8" r="3.500"/><path d="M2.500 20c.5-3.500 3-5.500 6.500-5.500s6 2 6.500 5.500M16 4.800a3.500 3.500 0 0 1 0 6.400M18 14.800c2 .6 3.200 2.300 3.500 5.200"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  yaml:'<path d="M5 5l4 5v5M13 5l-4 5M14 15h6M14 19h6"/>',
  xml:'<path d="M8 6L3 12l5 6M16 6l5 6-5 6M13.500 5l-3 14"/>',
  server:'<rect x="4" y="4" width="16" height="6" rx="1.500"/><rect x="4" y="14" width="16" height="6" rx="1.500"/><path d="M8 7h.01M8 17h.01"/>',
  speed:'<path d="M4 18a9 9 0 1 1 16 0"/><path d="M12 18l4-6"/>',
  grid:'<rect x="4" y="4" width="7" height="7" rx="1.500"/><rect x="13" y="4" width="7" height="7" rx="1.500"/><rect x="4" y="13" width="7" height="7" rx="1.500"/><rect x="13" y="13" width="7" height="7" rx="1.500"/>',
  // UI glyphs
  ui_arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  ui_back:'<path d="M19 12H5M11 6l-6 6 6 6"/>',
  ui_search:'<circle cx="11" cy="11" r="6.500"/><path d="M16 16l4.500 4.500"/>',
  ui_close:'<path d="M6 6l12 12M18 6L6 18"/>',
  ui_swap:'<path d="M6 9h13l-3.500-3.500M18 15H5l3.500 3.500"/>',
  ui_check:'<path d="M5 12.500l4.500 4.500L19 7.500"/>',
  ui_back_del:'<path d="M9 5h11v14H9l-6-7z"/><path d="M12.500 9.500l5 5M17.500 9.500l-5 5"/>',
  ui_up:'<path d="M12 20V5M6 11l6-6 6 6"/>',
  ui_down:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  ui_sun:'<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.600 5.600L7 7M17 17l1.400 1.400M5.600 18.400L7 17M17 7l1.400-1.400"/>',
  ui_moon:'<path d="M20 14.500A8 8 0 0 1 9.500 4 8 8 0 1 0 20 14.500z"/>',
  ui_zap:'<path d="M13 3L5 13h6l-1 8 8-10h-6z"/>',
  ui_lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
};

Object.assign(G,{
  lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  chars:'<path d="M4 17l4-10 4 10M5.500 13h5M15 8h5M15 12h5M15 16h5"/>',
  linecount:'<path d="M4 6h10M4 12h16M4 18h12"/><path d="M19 4v4M17 6h4"/>',
  strlen:'<path d="M4 8v8M20 8v8M4 12h16M8 9l-4 3 4 3M16 9l4 3-4 3"/>',
  syll:'<path d="M4 8v8M10 8v8M16 8v8M4 12h2M10 12h2M16 12h4"/>',
  br:'<path d="M4 7h16M4 12h10M4 17h16"/><path d="M17 10l3 2-3 2"/>',
  textq:'<path d="M5 6h14M5 11h14M5 16h9"/><circle cx="19" cy="17" r="1.500"/>',
  checklink:'<path d="M10 14a4 4 0 0 0 5.700 0l3-3a4 4 0 0 0-5.700-5.700l-1 1"/><path d="M4 18l2.500 2.500L11 16"/>',
  amp:'<path d="M17 20L8 11a3 3 0 1 1 3-3c0 3-6 4-6 8a4 4 0 0 0 7 2.500M17 14l3 3"/>',
  term:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10l3 2-3 2M12 15h5"/>',
  md:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 15V9l2.500 3L12 9v6M17 9v6M15 13l2 2 2-2"/>',
  density:'<circle cx="8" cy="9" r="2"/><circle cx="15" cy="7" r="1.500"/><circle cx="12" cy="14" r="2.500"/><circle cx="18" cy="16" r="1.500"/><circle cx="6" cy="17" r="1.500"/>',
  shuffle:'<path d="M4 7h4l8 10h4M4 17h4l2-2.500M14 9l2-2h4M18 5l2 2-2 2M18 15l2 2-2 2"/>',
  abc:'<path d="M4 17l3-9 3 9M5 14h4M13 8v9M13 8h3a2.500 2.500 0 0 1 0 5h-3"/>',
  numword:'<path d="M5 7v10M5 7L3 9M13 8h6M13 12h6M13 16h4"/>',
  hex:'<path d="M12 3l8 4.500v9L12 21l-8-4.500v-9z"/>',
  calday:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4M12 13v4"/>',
  cash:'<rect x="3" y="7" width="18" height="11" rx="2"/><circle cx="12" cy="12.500" r="2.500"/><path d="M6 10v.01M18 15v.01"/>',
  receipt:'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  layers:'<path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/>',
  markup:'<path d="M5 19L19 5M14 5h5v5"/><path d="M5 12v7h7"/>',
  weight:'<path d="M6 9h12l2 11H4z"/><circle cx="12" cy="5.500" r="2.500"/>',
  steps:'<path d="M4 20h4v-4h4v-4h4V8h4"/>',
  goal:'<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  flip:'<circle cx="12" cy="12" r="8.500"/><path d="M8 12a4 4 0 0 1 8 0M14 10l2 2 2-2"/>',
  imgswapA:'<rect x="3" y="4" width="10" height="8" rx="1.500"/><rect x="11" y="12" width="10" height="8" rx="1.500"/><path d="M14 8h3v3M10 16H7v-3"/>',
  imgswapB:'<rect x="11" y="4" width="10" height="8" rx="1.500"/><rect x="3" y="12" width="10" height="8" rx="1.500"/><path d="M10 8H7v3M14 16h3v-3"/>',
  imgcode:'<rect x="3" y="4" width="18" height="11" rx="2"/><path d="M9 20l-2-2 2-2M15 16l2 2-2 2"/>',
  codeimg:'<path d="M8 7L4 11l4 4M16 7l4 4-4 4"/><rect x="9" y="17" width="6" height="4" rx="1"/>',
  urlenc:'<circle cx="12" cy="12" r="8.500"/><path d="M8 12h8M14 9l3 3-3 3"/>',
  table:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M9 10v9M15 10v9"/>',
  sparkle:'<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
  schema:'<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/><path d="M12 8v4M6 16v-4h12v4"/>',
  phrase:'<path d="M4 7h16M4 12h10M4 17h8"/><circle cx="18" cy="16" r="3"/>',
  tokgen:'<circle cx="12" cy="12" r="8.500"/><path d="M12 8v8M8 12h8"/>',
  finger:'<path d="M6 11a6 6 0 0 1 12 0v3M9 20c1-2 1-4 1-6a2 2 0 0 1 4 0c0 3 0 5-1 7M5 15c0 2 0 3-1 5M18 17c0 1 0 2-1 3"/>',
  cron:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h4M15 15l2 2 3-3"/>',
  unixts:'<circle cx="12" cy="13" r="7"/><path d="M12 9v4l2 2M9 3h6"/>',
  book:'<path d="M4 5h6a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H4zM20 5h-6a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h6z"/>',
  countdown:'<circle cx="12" cy="13" r="7"/><path d="M12 13l3-3M9 3h6M12 3v3"/>',
  tomato:'<circle cx="12" cy="14" r="7"/><path d="M12 7V4M9 5l3 2 3-2"/>',
  flame:'<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',
  plug:'<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0zM12 17v4"/>',
  datediff:'<rect x="3" y="5" width="7" height="14" rx="1.500"/><rect x="14" y="5" width="7" height="14" rx="1.500"/><path d="M10 12h4"/>',
  weeknum:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4M8 14h8"/>',
  datefmt:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4M8 14h2M12 14h4M8 17h5"/>',
  brief:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M3 13h18"/>',
  leap:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4M12 18v-5M10 15l2-2 2 2"/>',
  worldclock:'<circle cx="10" cy="10" r="6.500"/><path d="M3.500 10h13M10 3.500c2.500 3 2.500 10 0 13"/><circle cx="17" cy="17" r="3.500"/><path d="M17 15.500V17l1 .8"/>',
  dice:'<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="15" cy="15" r="1"/>',
  rng:'<path d="M5 8h4M5 12h2M5 16h4M13 8h6v8h-6zM16 10v4"/>',
  titlea:'<path d="M4 6h16M12 6v8"/><circle cx="16" cy="17" r="3"/><path d="M18 19l2 2"/>',
  metadesc:'<path d="M4 6h16M4 10h16M4 14h9"/><path d="M16 17l2 2 3-3"/>',
  alt:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 14l2-4 2 4M8 13h2M14 10h4M14 14h3"/>',
  ssl:'<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M10 12v-1a2 2 0 0 1 4 0v1M9.500 12h5v3.500h-5z"/>',
  ssn:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h4M7 14h6M16 10h2"/>',
  parab:'<path d="M4 4c3 18 13 18 16 0"/>',
  pdf:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 17v-4h1.500a1.500 1.500 0 0 1 0 3H9M14 17v-4M14 13h2M14 15h1.500"/>',
  merge:'<path d="M5 4v4a4 4 0 0 0 4 4h6a4 4 0 0 1 4 4v4M19 4v4a4 4 0 0 1-4 4"/>',
  split:'<path d="M12 3v6M12 9l-6 6v6M12 9l6 6v6"/>',
  imgpdf:'<rect x="3" y="4" width="12" height="10" rx="1.500"/><path d="M4 13l3-3 2 2 2-2 3 3M13 17h8v4h-8z"/>',
  rotpage:'<rect x="7" y="7" width="10" height="13" rx="1.500"/><path d="M4 9a8 8 0 0 1 8-6M12 3l-2-1.500M12 3l-1.500 2.500"/>',
  sip:'<path d="M4 20h16M6 16v4M10 12v8M14 9v11M18 5v15"/>',
  pig:'<circle cx="12" cy="12" r="8.500"/><path d="M9 15l6-6M9.500 9.500h.01M14.500 14.500h.01"/>',
});
const ID_ICON = {
  'nps-calculator':'shield','epf-calculator':'pig','home-loan-eligibility':'target','ssy-calculator':'heart','inflation-calculator':'hourglass',
  'hra-calculator':'bank','gratuity-calculator':'cash','swp-calculator':'trend','stepup-sip-calculator':'steps','loan-prepayment-calculator':'markup','rd-calculator':'goal','webp-converter':'imgswapA','pdf-to-jpg':'imgpdf','pdf-delete-pages':'split','pdf-page-numbers':'abc',
  'pdf-merge':'merge','pdf-split':'split','images-to-pdf':'imgpdf','pdf-rotate':'rotpage','sip-calculator':'sip','fd-calculator':'bank','ppf-calculator':'goal','cagr-calculator':'trend','income-tax-india':'tax',
  'word-counter':'count','character-counter':'chars','line-counter':'linecount','string-length':'strlen','syllable-counter':'syll','content-length-checker':'chart',
  'remove-line-breaks':'br','random-word-generator':'textq','lorem-ipsum':'doc','url-structure-checker':'checklink','text-to-html':'code','html-encode':'amp','leetspeak':'term',
  'markdown-html':'md','html-formatter':'code','word-frequency':'chart','keyword-density':'density','anagram-checker':'shuffle','acronym-generator':'abc','number-to-words':'numword',
  'palindrome-checker':'mirror','pig-latin':'text','caesar-cipher':'rotate','number-base':'hex','binary-converter':'binary','binary-text':'binary',
  'age-calculator':'person','age-in-days':'calday','percentage-calculator':'percent','mean-median-mode-calculator':'avg','loan-calculator':'cash','emi-calculator':'bank',
  'vat-calculator':'receipt','simple-tax-estimator':'layers','gst-calculator':'tax','markup-calculator':'markup','discount-calculator':'tag','weight-converter':'weight','bmi-calculator':'scale',
  'compound-interest':'steps','simple-interest':'trend','savings-goal':'goal','hourly-to-annual-salary':'money','coin-flip':'flip','currency-converter':'coin',
  'jpg-to-png':'imgswapA','png-to-jpg':'imgswapB','image-to-base64':'imgcode','base64-to-image':'codeimg','base64-encoder':'swap','url-encoder':'urlenc','csv-json':'table',
  'image-color-picker':'picker','color-converter':'palette','random-color':'sparkle','json-formatter':'braces','json-validator':'yaml','schema-generator':'schema',
  'password-generator':'key','password-passphrase':'phrase','uuid-generator':'id','token-generator':'tokgen','jwt-decoder':'token','md5-hash':'hash','hash-generator':'finger',
  'css-minifier':'min','js-minifier':'compress','cron-explainer':'cron','timestamp-converter':'clock','unix-timestamp':'unixts','reading-time':'book',
  'length-converter':'ruler','speed-converter':'speed','time-unit-converter':'hourglass','countdown-timer':'countdown','pomodoro-timer':'tomato','energy-converter':'bolt','bmr-calculator':'flame','electricity-cost':'plug',
  'angle-converter':'angle','triangle-calculator':'triangle','date-difference':'datediff','days-until':'calendar','week-number':'weeknum','date-formatter':'datefmt','business-days':'brief','leap-year':'leap',
  'timezone-converter':'globe','world-clock':'worldclock','random-number':'rng','dice-roller':'dice','robots-txt-generator':'robot','title-analyzer':'titlea','meta-description-checker':'metadesc','alt-text-checker':'alt',
  'meta-tag-generator':'meta','password-strength':'shield','password-entropy':'ssl','fake-data-generator':'ssn','credit-card-check':'card','quadratic-solver':'parab','log-calculator':'log','fuel-economy':'speed','fuel-cost':'fuel',
  'htpasswd':'lock','time-converter ':'hourglass','spin-wheel':'wheel','name-picker':'users','qr-generator':'qr','ip-lookup':'pin','text-to-speech':'mic','water-intake':'drop','pace-calculator':'run',
};
// category -> default glyph
const CAT_GLYPH = {'Text Tools':'text','Calculator Tools':'calc','Image Tools':'image','Developer Tools':'code','Unit Converters':'ruler','Date & Time Tools':'calendar','Utility Tools':'tool','SEO Tools':'meta','Security Tools':'shield','Math Tools':'sigma','PDF Tools':'pdf'};
// ordered id rules -> glyph
const ICON_RULES = [
  [/^(word-counter|character-counter|line-counter|string-length|word-count-seo|syllable)/,'count'],
  [/case-converter/,'case'],[/remove-spaces|remove-line/,'space'],[/sorter/,'sort'],[/duplicates/,'dup'],[/random-text|lorem/,'doc'],
  [/slug/,'link'],[/reverser|reverse/,'reverse'],[/line-numbers/,'lines'],[/find-replace/,'find'],[/text-compare/,'compare'],[/repeater/,'repeat'],
  [/html|markdown/,'code'],[/frequency$|word-frequency|keyword-density/,'chart'],[/pig-latin|palindrome|anagram|acronym/,'text'],[/rot13|caesar/,'cipher'],
  [/morse/,'wave'],[/binary-text/,'binary'],[/nato/,'sound'],[/leetspeak/,'code'],
  [/age-calculator|age-in-days/,'person'],[/percentage|percent-error/,'percent'],[/emi|loan/,'bank'],[/gst|vat|tax/,'tax'],[/discount|markup/,'tag'],
  [/bmi/,'scale'],[/scientific/,'calc'],[/interest/,'trend'],[/tip-/,'tip'],[/fuel-cost|fuel-economy/,'fuel'],[/cgpa/,'cap'],[/average/,'avg'],
  [/salary|savings/,'money'],[/break-even/,'target'],[/currency/,'coin'],[/ratio/,'ratio'],
  [/image-resizer/,'resize'],[/compressor/,'compress'],[/jpg-to-png|png-to-jpg|image-to-base64|base64-to-image/,'swap'],[/image-crop/,'crop'],
  [/color-picker|color-converter|random-color/,'palette'],[/rotator/,'rotate'],[/favicon/,'star'],
  [/json-formatter|json-to-yaml/,'braces'],[/password-generator|password-passphrase/,'key'],[/password-strength/,'shield'],[/base64-encoder|url-encoder/,'swap'],
  [/uuid|token/,'id'],[/md5|hash/,'hash'],[/regex/,'regex'],[/jwt/,'token'],[/csv-json/,'swap'],[/minifier/,'min'],[/cron/,'clock'],[/number-base|binary-converter/,'binary'],
  [/timestamp|unix/,'clock'],[/xml-formatter/,'xml'],
  [/length-converter|unit-converter|speed/,'ruler'],[/weight/,'scale'],[/temperature/,'temp'],[/area/,'area'],[/volume/,'box'],[/time-converter/,'hourglass'],
  [/data-storage/,'data'],[/energy/,'bolt'],[/pressure/,'pressure'],[/power-converter/,'power'],[/force/,'force'],[/angle/,'angle'],[/frequency-converter/,'freq'],
  [/shoe/,'shoe'],[/cooking/,'cook'],
  [/date-|days-until|week-number|business-days|leap-year|date-formatter/,'calendar'],[/timezone|world-clock/,'globe'],[/stopwatch/,'stopwatch'],
  [/countdown|pomodoro/,'hourglass'],
  [/qr/,'qr'],[/ip-lookup/,'pin'],[/random-number|dice/,'random'],[/coin-flip/,'coin'],[/reading-time/,'clock'],[/number-to-words/,'text'],[/text-to-speech/,'mic'],
  [/name-picker/,'users'],[/spin-wheel/,'wheel'],[/bmr/,'bolt'],[/water/,'drop'],[/pace/,'run'],[/electricity/,'bolt'],
  [/meta-tag|robots|meta-description|title-analyzer|alt-text/,'meta'],[/og-generator/,'share'],[/schema/,'braces'],[/utm/,'utm'],[/sitemap/,'map'],
  [/htpasswd/,'lock'],[/ssn|credit-card/,'card'],[/ssl/,'shield'],
  [/square-root/,'sqrt'],[/prime/,'prime'],[/fibonacci/,'fib'],[/hcf|lcm/,'sigma'],[/factorial/,'fact'],[/roman/,'roman'],[/quadratic/,'log'],[/permutation/,'perm'],
  [/log-calculator/,'log'],[/triangle/,'triangle'],
];
function glyphFor(tool){
  if (ID_ICON[tool.id]) return ID_ICON[tool.id];
  for (const [re,g] of ICON_RULES) if (re.test(tool.id)) return g;
  return CAT_GLYPH[tool.cat] || 'grid';
}
function svgIcon(name, size, extra){
  return `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${extra||''}>${G[name]||G.grid}</svg>`;
}
function toolIconSvg(tool, size){ return svgIcon(glyphFor(tool), size||20); }
function catIconSvg(cat, size){ return svgIcon(CAT_GLYPH[cat]||'grid', size||20); }

// Hindi strings for the home page, category pages and tool cards. Tool pages themselves stay in English.
const HI_TOOLS_RAW = `
word-counter|वर्ड काउंटर|शब्द, अक्षर, वाक्य और पढ़ने का समय गिनें
character-counter|कैरेक्टर काउंटर|स्पेस के साथ और बिना अक्षर गिनें
case-converter|केस कन्वर्टर|टेक्स्ट को अपरकेस, लोअरकेस या टाइटल केस में बदलें
remove-spaces|एक्स्ट्रा स्पेस हटाएं|टेक्स्ट से फालतू स्पेस साफ करें
text-sorter|टेक्स्ट सॉर्टर|लाइनों को A से Z या उल्टे क्रम में सजाएं
remove-duplicates|डुप्लिकेट लाइन हटाएं|टेक्स्ट से दोहराई गई लाइनें तुरंत हटाएं
random-word-generator|रैंडम वर्ड जनरेटर|यादृच्छिक प्लेसहोल्डर शब्द बनाएं
slug-generator|स्लग जनरेटर|टेक्स्ट को URL के अनुकूल स्लग में बदलें
text-reverser|टेक्स्ट रिवर्सर|किसी भी टेक्स्ट को उल्टा करें
lorem-ipsum|लोरेम इप्सम जनरेटर|डिज़ाइन के लिए प्लेसहोल्डर टेक्स्ट बनाएं
find-replace|खोजें और बदलें|टेक्स्ट में एक साथ कई शब्द बदलें
line-counter|लाइन काउंटर|किसी भी टेक्स्ट की लाइनें गिनें
text-compare|टेक्स्ट कंपेयर|दो टेक्स्ट की तुलना करें
text-repeater|टेक्स्ट रिपीटर|टेक्स्ट को कई बार दोहराएं
text-to-html|टेक्स्ट से HTML|साधारण टेक्स्ट को HTML में बदलें
html-encode|HTML एंटिटी एन्कोडर/डिकोडर|HTML एंटिटी को एन्कोड या डिकोड करें
word-frequency|शब्द आवृत्ति काउंटर|हर शब्द कितनी बार आया, गिनें
remove-line-breaks|लाइन ब्रेक हटाएं|टूटी लाइनों को एक पैराग्राफ में जोड़ें
add-line-numbers|लाइन नंबर जोड़ें|हर लाइन के आगे उसका नंबर लगाएं
pig-latin|पिग लैटिन कन्वर्टर|अंग्रेज़ी टेक्स्ट को पिग लैटिन में बदलें
rot13|ROT13 एन्कोडर/डिकोडर|ROT13 सिफर टेक्स्ट को एन्कोड या डिकोड करें
caesar-cipher|सीज़र सिफर|अक्षरों को चुनी हुई संख्या से खिसकाएं
morse-code|मोर्स कोड ट्रांसलेटर|टेक्स्ट को मोर्स कोड में और वापस बदलें
binary-text|टेक्स्ट से बाइनरी|टेक्स्ट को बाइनरी में और वापस बदलें
nato-phonetic|नाटो फोनेटिक अल्फाबेट|नाटो अल्फाबेट से टेक्स्ट की स्पेलिंग बोलें
leetspeak|लीटस्पीक कन्वर्टर|टेक्स्ट को 1337 स्पीक में बदलें
palindrome-checker|पैलिंड्रोम चेकर|जांचें कि टेक्स्ट उल्टा भी वैसा ही पढ़ा जाता है
anagram-checker|एनाग्राम चेकर|जांचें कि दो शब्द एनाग्राम हैं या नहीं
acronym-generator|एक्रोनिम जनरेटर|वाक्यांश से संक्षिप्त रूप बनाएं
string-length|स्ट्रिंग लेंथ चेकर|सोशल मीडिया की सीमा के हिसाब से लंबाई जांचें
syllable-counter|सिलेबल काउंटर|टेक्स्ट में अक्षांश (सिलेबल) का अनुमान लगाएं
age-calculator|आयु कैलकुलेटर|जन्मतिथि से सटीक उम्र निकालें
percentage-calculator|प्रतिशत कैलकुलेटर|प्रतिशत आसानी से निकालें
emi-calculator|EMI कैलकुलेटर|लोन की मासिक EMI निकालें
loan-calculator|लोन कैलकुलेटर|लोन की कुल अदायगी निकालें
gst-calculator|GST कैलकुलेटर|किसी भी राशि में GST जोड़ें या हटाएं
discount-calculator|डिस्काउंट कैलकुलेटर|छूट और अंतिम कीमत निकालें
bmi-calculator|BMI कैलकुलेटर|बॉडी मास इंडेक्स (BMI) निकालें
scientific-calculator|साइंटिफिक कैलकुलेटर|पूरा साइंटिफिक कैलकुलेटर
simple-interest|साधारण ब्याज कैलकुलेटर|लोन पर साधारण ब्याज निकालें
compound-interest|चक्रवृद्धि ब्याज कैलकुलेटर|चक्रवृद्धि ब्याज निकालें
tip-calculator|टिप कैलकुलेटर|रेस्टोरेंट की टिप आसानी से निकालें
fuel-cost|ईंधन खर्च कैलकुलेटर|यात्रा का ईंधन खर्च निकालें
cgpa-calculator|CGPA / GPA कैलकुलेटर|ग्रेड और क्रेडिट से GPA निकालें
mean-median-mode-calculator|माध्य, माध्यिका और बहुलक कैलकुलेटर|माध्य, माध्यिका, बहुलक और मानक विचलन निकालें
hourly-to-annual-salary|घंटे से सालाना सैलरी कैलकुलेटर|घंटे, हफ्ते, महीने और साल की पगार बदलें
savings-goal|बचत लक्ष्य कैलकुलेटर|लक्ष्य के लिए हर महीने कितना बचाना है, जानें
markup-calculator|मार्कअप और मार्जिन कैलकुलेटर|मार्कअप प्रतिशत और लाभ मार्जिन निकालें
break-even|ब्रेक-ईवन पॉइंट कैलकुलेटर|ब्रेक-ईवन बिक्री मात्रा निकालें
vat-calculator|VAT कैलकुलेटर|कीमत में VAT जोड़ें या हटाएं
currency-converter|करेंसी कन्वर्टर|दुनिया की मुद्राओं के बीच बदलें
ratio-simplifier|अनुपात सरल करें|अनुपात को सबसे छोटे रूप में लिखें
image-resizer|इमेज रिसाइज़र|इमेज को किसी भी साइज़ में बदलें
image-compressor|इमेज कंप्रेसर|क्वालिटी ज़्यादा गिराए बिना इमेज छोटी करें
jpg-to-png|JPG से PNG कन्वर्टर|JPG इमेज को PNG में बदलें
png-to-jpg|PNG से JPG कन्वर्टर|PNG इमेज को JPG में बदलें
image-crop|इमेज क्रॉप टूल|इमेज को अपने साइज़ में काटें
image-color-picker|इमेज कलर पिकर|किसी भी इमेज से रंग चुनें
image-to-base64|इमेज से Base64|इमेज को Base64 स्ट्रिंग में बदलें
base64-to-image|Base64 से इमेज|Base64 स्ट्रिंग को वापस इमेज बनाएं
image-rotator|इमेज रोटेट और फ्लिप|इमेज को घुमाएं या पलटें
favicon-generator|फेविकॉन जनरेटर|किसी भी इमेज से फेविकॉन बनाएं
json-formatter|JSON फॉर्मैटर|JSON डेटा को फॉर्मैट और वैलिडेट करें
password-generator|पासवर्ड जनरेटर|मजबूत और सुरक्षित पासवर्ड बनाएं
base64-encoder|Base64 एन्कोडर और डिकोडर|टेक्स्ट या डेटा को Base64 में बदलें
url-encoder|URL एन्कोडर और डिकोडर|URL को सुरक्षित रूप में एन्कोड करें
uuid-generator|UUID जनरेटर|यूनिक UUID (v4) बनाएं
md5-hash|MD5 हैश जनरेटर|किसी भी टेक्स्ट का MD5 हैश बनाएं
hash-generator|हैश जनरेटर (SHA-1/256/384/512)|MD5, SHA1, SHA256 हैश बनाएं
regex-tester|रेगेक्स टेस्टर|रेगेक्स पैटर्न टेस्ट और डीबग करें
color-converter|कलर कन्वर्टर|HEX, RGB, HSL रंग बदलें
jwt-decoder|JWT डिकोडर|JWT टोकन को डिकोड करके देखें
markdown-html|Markdown से HTML|Markdown को HTML में बदलें
csv-json|CSV से JSON कन्वर्टर|CSV डेटा को JSON में बदलें
html-formatter|HTML फॉर्मैटर|HTML कोड को फॉर्मैट और इंडेंट करें
css-minifier|CSS मिनिफायर|खाली जगह हटाकर CSS छोटा करें
js-minifier|JS व्हाइटस्पेस मिनिफायर|JS से कमेंट और फालतू स्पेस हटाएं
cron-explainer|क्रॉन एक्सप्रेशन एक्सप्लेनर|क्रॉन एक्सप्रेशन का मतलब समझें
number-base|नंबर बेस कन्वर्टर|बाइनरी, डेसिमल, हेक्स, ऑक्टल बदलें
timestamp-converter|यूनिक्स टाइमस्टैम्प कन्वर्टर|यूनिक्स टाइमस्टैम्प को तारीख में बदलें
json-validator|JSON वैलिडेटर|JSON जांचें और उसकी संरचना के आंकड़े देखें
xml-formatter|XML फॉर्मैटर|XML को फॉर्मैट और इंडेंट करें
length-converter|लंबाई कन्वर्टर|मीटर, फीट, इंच, मील बदलें
weight-converter|वज़न कन्वर्टर|किलो, पाउंड, ग्राम, औंस बदलें
temperature-converter|तापमान कन्वर्टर|सेल्सियस, फारेनहाइट, केल्विन बदलें
speed-converter|गति कन्वर्टर|km/h, mph, m/s, नॉट बदलें
area-converter|क्षेत्रफल कन्वर्टर|वर्ग मीटर, एकड़, वर्ग फीट बदलें
volume-converter|आयतन कन्वर्टर|लीटर, गैलन, कप बदलें
time-unit-converter|समय इकाई कन्वर्टर|सेकंड, मिनट, घंटे, दिन बदलें
data-storage-converter|डेटा स्टोरेज कन्वर्टर|बाइट, KB, MB, GB, TB बदलें
energy-converter|ऊर्जा कन्वर्टर|जूल, कैलोरी, kWh बदलें
pressure-converter|दबाव कन्वर्टर|Pa, बार, psi, atm बदलें
power-converter|शक्ति कन्वर्टर|वाट, किलोवाट, हॉर्सपावर बदलें
force-converter|बल कन्वर्टर|न्यूटन, पाउंड-फोर्स, kgf बदलें
angle-converter|कोण कन्वर्टर|डिग्री, रेडियन, ग्रेडियन बदलें
frequency-converter|आवृत्ति कन्वर्टर|Hz, kHz, MHz, GHz बदलें
fuel-economy|ईंधन दक्षता कन्वर्टर|MPG, L/100km, km/L बदलें
shoe-size|जूते का साइज़ कन्वर्टर|अलग-अलग देशों के जूते के साइज़ बदलें
cooking-converter|कुकिंग माप कन्वर्टर|कप, चम्मच, ग्राम बदलें
date-difference|तारीख अंतर कैलकुलेटर|दो तारीखों के बीच के दिन निकालें
timezone-converter|टाइम ज़ोन कन्वर्टर|अलग टाइम ज़ोन में समय बदलें
days-until|तारीख तक कितने दिन|किसी भी इवेंट तक के दिन गिनें
week-number|सप्ताह संख्या कैलकुलेटर|किसी भी तारीख का सप्ताह नंबर जानें
unix-timestamp|अभी का यूनिक्स टाइमस्टैम्प|मौजूदा यूनिक्स टाइमस्टैम्प, लाइव
date-formatter|डेट फॉर्मैटर|तारीख को किसी भी फॉर्मैट में लिखें
business-days|कार्य दिवस कैलकुलेटर|दो तारीखों के बीच कार्य दिवस निकालें
stopwatch|स्टॉपवॉच|लैप टाइमर वाली ऑनलाइन स्टॉपवॉच
countdown-timer|काउंटडाउन टाइमर|किसी भी तारीख और समय तक की उलटी गिनती
pomodoro-timer|पोमोडोरो टाइमर|पोमोडोरो तकनीक वाला फोकस टाइमर
leap-year|लीप ईयर चेकर|जांचें कि कोई साल लीप ईयर है या नहीं
world-clock|वर्ल्ड क्लॉक|बड़े शहरों का मौजूदा समय देखें
age-in-days|दिनों में आयु कैलकुलेटर|अपनी उम्र कुल दिनों में जानें
qr-generator|QR कोड जनरेटर|तुरंत QR कोड बनाएं
ip-lookup|मेरा IP एड्रेस|अपना पब्लिक IP एड्रेस जानें
random-number|रैंडम नंबर जनरेटर|दिए दायरे में रैंडम नंबर बनाएं
coin-flip|सिक्का उछालें|वर्चुअल सिक्का उछालने का टूल
dice-roller|डाइस रोलर|ऑनलाइन पासा फेंकें
reading-time|पढ़ने का समय कैलकुलेटर|लेख पढ़ने का समय अनुमानित करें
number-to-words|संख्या से शब्द|संख्या को अंग्रेज़ी शब्दों में बदलें
text-to-speech|टेक्स्ट टू स्पीच|टेक्स्ट को आवाज़ में बदलें
password-passphrase|पासफ्रेज़ जनरेटर|याद रखने लायक शब्दों वाला पासफ्रेज़ बनाएं
random-color|रैंडम कलर जनरेटर|कोड के साथ रैंडम रंग बनाएं
name-picker|रैंडम नाम चुनें|सूची में से एक रैंडम नाम चुनें
spin-wheel|स्पिन द व्हील|पहिया घुमाकर रैंडम विकल्प चुनें
bmr-calculator|BMR कैलकुलेटर|बेसल मेटाबॉलिक रेट का अनुमान लगाएं
water-intake|पानी की मात्रा कैलकुलेटर|रोज़ पानी की ज़रूरत का अनुमान लगाएं
pace-calculator|रनिंग पेस कैलकुलेटर|दौड़ की रफ्तार, समय या दूरी निकालें
simple-tax-estimator|सिंपल टैक्स एस्टिमेटर|अपने ब्रैकेट दरों से टैक्स का अनुमान लगाएं
electricity-cost|बिजली खर्च कैलकुलेटर|उपकरण चलाने का खर्च निकालें
meta-tag-generator|मेटा टैग जनरेटर|किसी भी पेज के लिए SEO मेटा टैग बनाएं
keyword-density|कीवर्ड डेंसिटी चेकर|कंटेंट में कीवर्ड घनत्व जांचें
open-graph-generator|ओपन ग्राफ टैग जनरेटर|सोशल शेयरिंग के ओपन ग्राफ टैग बनाएं
robots-txt-generator|robots.txt जनरेटर|robots.txt फाइल बनाएं
schema-generator|स्कीमा मार्कअप जनरेटर|JSON-LD स्कीमा मार्कअप बनाएं
title-analyzer|टाइटल टैग एनालाइज़र|टाइटल टैग जांचें और बेहतर करें
meta-description-checker|मेटा डिस्क्रिप्शन चेकर|मेटा डिस्क्रिप्शन की लंबाई जांचें
utm-builder|UTM लिंक बिल्डर|UTM ट्रैकिंग URL बनाएं
sitemap-generator|साइटमैप जनरेटर|अपनी साइट के लिए XML साइटमैप बनाएं
url-structure-checker|URL संरचना चेकर|URL में आम SEO गलतियां जांचें
alt-text-checker|इमेज Alt टेक्स्ट चेकर|HTML में बिना alt वाली इमेज खोजें
content-length-checker|कंटेंट लंबाई चेकर|SEO मानकों के हिसाब से कंटेंट की लंबाई जांचें
password-strength|पासवर्ड स्ट्रेंथ चेकर|पासवर्ड की मजबूती का स्कोर देखें
token-generator|रैंडम टोकन जनरेटर|सुरक्षित रैंडम टोकन बनाएं
htpasswd|HTPASSWD जनरेटर|.htpasswd पासवर्ड हैश बनाएं
fake-data-generator|फेक डेटा जनरेटर|टेस्ट के लिए नकली डेटा (नाम, ईमेल) बनाएं
credit-card-check|क्रेडिट कार्ड नंबर वैलिडेटर|Luhn जांच से कार्ड नंबर परखें
password-entropy|पासवर्ड एंट्रॉपी कैलकुलेटर|पासवर्ड की एंट्रॉपी बिट्स में निकालें
square-root|वर्गमूल और घनमूल कैलकुलेटर|वर्गमूल और घनमूल निकालें
prime-checker|अभाज्य संख्या चेकर|जांचें कि संख्या अभाज्य है या नहीं
fibonacci|फिबोनाची अनुक्रम जनरेटर|फिबोनाची संख्याओं का अनुक्रम बनाएं
hcf-lcm|HCF और LCM कैलकुलेटर|संख्याओं का HCF और LCM निकालें
factorial|फैक्टोरियल कैलकुलेटर|किसी भी संख्या का फैक्टोरियल निकालें
binary-converter|बाइनरी और डेसिमल कन्वर्टर|बाइनरी, डेसिमल, हेक्स, ऑक्टल बदलें
roman-numerals|रोमन अंक कन्वर्टर|अरबी और रोमन अंकों के बीच बदलें
quadratic-solver|द्विघात समीकरण हल करें|ax² + bx + c = 0 हल करें
percent-error|प्रतिशत त्रुटि कैलकुलेटर|प्रतिशत त्रुटि निकालें
permutation-combination|क्रमचय और संचय कैलकुलेटर|nPr और nCr निकालें
log-calculator|लघुगणक कैलकुलेटर|किसी संख्या का log और एंटीलॉग निकालें
triangle-calculator|समकोण त्रिभुज कैलकुलेटर|समकोण त्रिभुज हल करें (पाइथागोरस)
sip-calculator|SIP कैलकुलेटर|मासिक SIP का भविष्य मूल्य निकालें
fd-calculator|FD / एकमुश्त निवेश कैलकुलेटर|FD या एकमुश्त निवेश की मैच्योरिटी राशि निकालें
ppf-calculator|PPF कैलकुलेटर|PPF की मैच्योरिटी का अनुमान लगाएं
cagr-calculator|CAGR कैलकुलेटर|निवेश की चक्रवृद्धि वार्षिक वृद्धि दर निकालें
income-tax-india|इनकम टैक्स कैलकुलेटर (भारत)|पुरानी और नई टैक्स व्यवस्था की तुलना करें, वित्त वर्ष 2026-27
pdf-merge|PDF मर्ज करें|कई PDF फाइलों को एक में जोड़ें
pdf-split|PDF पेज अलग करें|PDF से चुने हुए पेज निकालें
images-to-pdf|इमेज से PDF|JPG और PNG इमेज को एक PDF में बदलें
pdf-rotate|PDF घुमाएं|PDF के हर पेज को घुमाएं
hra-calculator|HRA छूट कैलकुलेटर|HRA का कर-मुक्त हिस्सा निकालें
gratuity-calculator|ग्रेच्युटी कैलकुलेटर|नौकरी छोड़ने पर मिलने वाली ग्रेच्युटी का अनुमान लगाएं
swp-calculator|SWP कैलकुलेटर|मासिक निकासी के साथ कोष कितने समय चलेगा, देखें
stepup-sip-calculator|स्टेप-अप SIP कैलकुलेटर|हर साल तय प्रतिशत बढ़ने वाली SIP
loan-prepayment-calculator|लोन प्रीपेमेंट कैलकुलेटर|लोन का हिस्सा पहले चुकाने पर बचा ब्याज देखें
rd-calculator|RD कैलकुलेटर|रेकरिंग डिपॉजिट की मैच्योरिटी राशि निकालें
nps-calculator|NPS कैलकुलेटर|NPS कोष, एकमुश्त राशि और मासिक पेंशन का अनुमान लगाएं
epf-calculator|EPF कैलकुलेटर|रिटायरमेंट पर EPF बैलेंस का अनुमान लगाएं
home-loan-eligibility|होम लोन पात्रता कैलकुलेटर|आपकी आय पर कितना होम लोन मिल सकता है, देखें
ssy-calculator|सुकन्या समृद्धि कैलकुलेटर|सुकन्या समृद्धि योजना की परिपक्वता राशि का अनुमान लगाएं
inflation-calculator|महंगाई कैलकुलेटर|देखें कि आज के पैसे से आगे कितना सामान मिलेगा
webp-converter|WebP कन्वर्टर|इमेज को WebP में या WebP से बदलें
pdf-to-jpg|PDF से JPG|PDF के हर पेज को इमेज में बदलें
pdf-delete-pages|PDF पेज हटाएं|PDF से गैर-ज़रूरी पेज हटाएं
pdf-page-numbers|PDF में पेज नंबर जोड़ें|हर पेज पर पेज नंबर लगाएं
`;
const HI_TOOLS = {};
HI_TOOLS_RAW.trim().split('\n').forEach(l => { const [id, n, d] = l.split('|'); HI_TOOLS[id] = {n, d}; });
const HI_CAT = {'Text Tools':'टेक्स्ट टूल्स','Calculator Tools':'कैलकुलेटर','Image Tools':'इमेज टूल्स','Developer Tools':'डेवलपर टूल्स','Unit Converters':'यूनिट कन्वर्टर','Date & Time Tools':'तारीख और समय','Utility Tools':'यूटिलिटी टूल्स','SEO Tools':'SEO टूल्स','Security Tools':'सिक्योरिटी टूल्स','Math Tools':'गणित टूल्स','PDF Tools':'PDF टूल्स'};
const HI_CAT_SHORT = {'Text Tools':'टेक्स्ट','Calculator Tools':'कैलकुलेटर','Image Tools':'इमेज','Developer Tools':'डेवलपर','Unit Converters':'कन्वर्टर','Date & Time Tools':'तारीख और समय','Utility Tools':'यूटिलिटी','SEO Tools':'SEO','Security Tools':'सिक्योरिटी','Math Tools':'गणित','PDF Tools':'PDF'};
const HI_UI = {
  topbar:'150+ मुफ्त टूल्स। लॉगिन नहीं। आपके ब्राउज़र में चलते हैं।', browse:'सभी टूल्स देखें',
  navHome:'होम', navTools:'टूल्स', navAbout:'हमारे बारे में', navContact:'संपर्क',
  badge:'मुफ्त। अकाउंट की ज़रूरत नहीं।', h1a:'आपका ऑल-इन-वन', h1b:'ऑनलाइन टूलबॉक्स',
  heroP:'टेक्स्ट, कैलकुलेशन, इमेज, PDF, डेवलपमेंट और SEO के 150+ मुफ्त टूल्स, सब आपके ब्राउज़र में चलते हैं।',
  search:'150+ टूल्स खोजें', all:'सभी टूल्स', popular:'लोकप्रिय टूल्स', reqH:'जो टूल चाहिए वह नहीं मिला?', reqP:'हमें बताइए क्या कमी है। नए टूल्स आपके सुझावों के आधार पर जोड़े जाते हैं।', reqBtn:'टूल सुझाएं',
  tools:'टूल्स', for:'के लिए', fTag:'टेक्स्ट, संख्या, इमेज, कोड और SEO के 150+ मुफ्त ऑनलाइन टूल्स। लॉगिन नहीं। ज़्यादातर टूल्स पूरी तरह आपके ब्राउज़र में चलते हैं।',
  fPop:'लोकप्रिय टूल्स', fCat:'श्रेणियां', fCo:'कंपनी', fAbout:'हमारे बारे में', fContact:'संपर्क', fPriv:'प्राइवेसी पॉलिसी', fTerms:'नियम और शर्तें', fDisc:'डिस्क्लेमर', fTop:'ऊपर जाएं', rights:'सर्वाधिकार सुरक्षित।'
};
const HI_CAT_USE = {'Text Tools':'लेखकों, छात्रों और डेवलपर्स के लिए जो टेक्स्ट जल्दी गिनना, साफ करना या बदलना चाहते हैं','Calculator Tools':'पैसे, सेहत, पढ़ाई और रोज़मर्रा की योजना के लिए तेज़ और सही हिसाब','Image Tools':'इमेज का साइज़ बदलने, कन्वर्ट करने और जांचने के लिए, बिना कहीं अपलोड किए','Developer Tools':'डेवलपर्स के लिए डेटा को फॉर्मैट, एन्कोड, डिकोड और जनरेट करना','Date & Time Tools':'तारीखों, डेडलाइन और टाइम ज़ोन की योजना बनाने के लिए','Unit Converters':'माप की इकाइयों को आसानी से बदलने के लिए','Utility Tools':'कोड बनाने, रैंडम चुनाव और रोज़ के छोटे कामों के लिए','SEO Tools':'साइट मालिकों और मार्केटर्स के लिए, पेज को सर्च के लिए तैयार करने में','Security Tools':'मजबूत पासवर्ड और सुरक्षित टेस्ट डेटा के लिए, बिना सर्वर पर भेजे','Math Tools':'छात्रों और शिक्षकों के लिए अंकगणित, संख्या सिद्धांत और बीजगणित','PDF Tools':'PDF जोड़ने, बांटने, घुमाने और बनाने के लिए, बिना सॉफ्टवेयर इंस्टॉल किए'};

// Guide metadata. Bodies live in guides.js (build time only). The first tool of each guide is its primary tool.
const GUIDES = [
  {slug:'how-emi-is-calculated', title:'How EMI Is Calculated, With a Worked Example', desc:'The EMI formula, a month-by-month breakdown of interest and principal, and how tenure changes what you pay.', tools:['emi-calculator','loan-prepayment-calculator','home-loan-eligibility']},
  {slug:'sip-vs-fd', title:'SIP vs FD: What Actually Differs', desc:'A SIP and a recurring deposit compared on the same monthly amount, with the risk that the headline numbers hide.', tools:['sip-calculator','rd-calculator','fd-calculator']},
  {slug:'old-vs-new-tax-regime', title:'Old vs New Tax Regime: How to Choose (FY 2026-27)', desc:'Slabs, deductions and the break-even point where the old regime starts to beat the new one.', tools:['income-tax-india','hra-calculator','ppf-calculator']},
  {slug:'sip-vs-lumpsum', title:'SIP vs Lumpsum: Same Money, Different Timing', desc:'What the maths says when you invest a sum all at once versus in monthly parts, and what it leaves out.', tools:['sip-calculator','fd-calculator','cagr-calculator']},
  {slug:'how-gst-is-calculated', title:'How GST Is Calculated: Adding and Removing It', desc:'The two formulas you need, with examples, and the mistake people make when removing GST from a total.', tools:['gst-calculator','percentage-calculator','discount-calculator']},
  {slug:'bmi-categories-explained', title:'BMI Categories Explained, and Where BMI Falls Short', desc:'How BMI is worked out, the WHO categories, why some guidelines use lower cut-offs for South Asians, and what BMI cannot tell you.', tools:['bmi-calculator','bmr-calculator','water-intake']},
  {slug:'how-compound-interest-works', title:'How Compound Interest Works', desc:'The formula, the difference from simple interest on real numbers, and the rule of 72.', tools:['compound-interest','simple-interest','inflation-calculator']},
  {slug:'ppf-vs-fd', title:'PPF vs FD: Tax, Lock-in and Real Returns', desc:'Why a lower headline rate can still win once tax is counted, and when a fixed deposit makes more sense.', tools:['ppf-calculator','fd-calculator','income-tax-india']},
  {slug:'strong-password-guide', title:'What Makes a Password Strong', desc:'Length versus complexity, how many bits of entropy you get from random characters or words, and what to do about reuse.', tools:['password-generator','password-passphrase','password-strength']},
  {slug:'merge-pdf-without-uploading', title:'How to Merge PDFs Without Uploading Them', desc:'How in-browser PDF tools work, what stays on your device, and where they hit their limits.', tools:['pdf-merge','pdf-split','pdf-delete-pages']}
];
const GUIDE_BY_TOOL = {};
GUIDES.forEach(g => g.tools.forEach(id => { if (!GUIDE_BY_TOOL[id]) GUIDE_BY_TOOL[id] = g; }));

// Hand-written content for the highest-traffic tools. Overrides the generic template in content.js.
const TOP_CONTENT = {
'word-counter': {
  intro:'Word count decides whether an essay meets a limit, whether a meta description fits, and how long a post takes to read. This counter updates as you type and shows words, characters with and without spaces, sentences, paragraphs, reading time and your most repeated keywords in one place.',
  steps:['Paste or type your text into the box. Counts update instantly.','Check the word and character totals against your limit, such as a 500-word assignment or a 160-character description.','Look at the reading time and the top keywords to judge length and repetition.','Edit your text and watch the numbers change until you hit your target.'],
  tips:['Counting rules differ. This tool treats any run of characters separated by spaces as a word, so "well-known" counts as one word.','University and journal limits often exclude references and headings. Paste only the part that counts.','Reading time assumes about 200 words per minute, a common average for adults reading on screen.'],
  faq:[['How does the counter decide what a word is?','It splits text on spaces and line breaks. A hyphenated word counts as one, and numbers count as words.'],['Why is my count different from Microsoft Word?','Word processors handle hyphens, dashes and symbols slightly differently, so a small gap is normal. Use the number your submission system uses.'],['Does it count characters with spaces?','Yes. Both totals are shown, with spaces and without.'],['Is the text stored anywhere?','No. The count runs in your browser and the text is never sent to a server.']]},
'character-counter': {
  intro:'Character limits are everywhere: SMS segments, tweets, meta titles, ad headlines and form fields. This counter shows the exact length of your text with and without spaces so you can stay inside a limit before you publish.',
  steps:['Paste your text into the box.','Read the total characters, and the figure without spaces.','Compare against the limit for where the text will be used.','Trim or extend the text until it fits.'],
  tips:['Search results usually cut titles near 60 characters and descriptions near 160, but pixel width matters too, so leave a little room.','A single SMS holds 160 characters in the GSM alphabet, but using emoji or non-Latin letters drops that to 70.','Line breaks count as a character in most systems.'],
  faq:[['Do spaces count as characters?','In most limits, yes. The tool shows both totals so you can use the right one.'],['Do emoji count as one character?','Visually yes, but many systems count an emoji as two or more. Test critical limits in the target system.'],['What is the limit for a tweet?','Platform limits change over time, so check the current rule on the platform before relying on a number.'],['Is my text uploaded?','No. Counting happens in your browser.']]},
'case-converter': {
  intro:'Retyping text just to change its capitalisation wastes time. Paste once, pick a style, and copy the result. The tool covers everyday cases such as UPPERCASE and Title Case, and developer styles such as camelCase, snake_case and kebab-case.',
  steps:['Paste your text into the input box.','Click the case you want: upper, lower, title, sentence, camel, Pascal, snake, kebab, alternating or inverse.','Review the output. It replaces nothing in your original text.','Press Copy to put the result on your clipboard.'],
  tips:['Title Case here capitalises the first letter of every word and lowercases the rest, so acronyms such as USA become Usa. Style guides leave short words like "of" and "the" lowercase, so check headings against your guide.','Use snake_case for Python and database columns, camelCase for JavaScript variables and kebab-case for URLs and CSS classes.','Sentence case capitalises the first letter after each full stop, so abbreviations may need a manual fix.'],
  faq:[['What is the difference between camelCase and PascalCase?','camelCase starts lowercase (userName). PascalCase starts uppercase (UserName).'],['Will it keep my line breaks?','Yes. Line breaks are kept for the plain case options.'],['Can I convert a whole document?','Yes, there is no length limit beyond what your browser can handle.'],['Does it handle non-English letters?','Accented Latin letters convert correctly. Some scripts have no upper and lower case, so they stay unchanged.']]},
'password-generator': {
  intro:'A strong password is long, random and unique to one account. This generator builds one in your browser using the browser\'s cryptographic random number source, so the result is never sent anywhere and never repeated.',
  steps:['Set the length. Use at least 16 characters for important accounts.','Choose which character types to include: uppercase, lowercase, numbers and symbols.','Click Generate and read the strength indicator.','Copy the password straight into your password manager.'],
  tips:['Length matters more than symbols. A random 20-character password is far harder to guess than a short one full of symbols.','Use a different password for every account, so one leak cannot unlock the rest.','Some sites reject certain symbols. If so, turn symbols off and add length instead.'],
  faq:[['Is this password generator safe to use?','It runs locally with the Web Crypto API. Nothing you generate is transmitted or stored by us.'],['How long should a password be?','Sixteen characters or more for anything important. Use a password manager so you do not need to remember it.'],['Why not make up my own?','People pick predictable patterns even when they try to be random. A generator does not.'],['Should I use a passphrase instead?','A passphrase of four or more random words is a good option when you must type it by hand. See the Passphrase Generator.']]},
'json-formatter': {
  intro:'Minified or messy JSON is hard to read and harder to debug. This tool validates your JSON, pretty-prints it with clean indentation, or minifies it for transport, and tells you where the syntax breaks.',
  steps:['Paste your JSON into the input box.','Press Format / Beautify to indent it, Minify to remove whitespace, or Validate Only to check syntax.','If the JSON is invalid, read the error message to find the problem.','Copy the formatted result.'],
  tips:['The most common errors are trailing commas, single quotes instead of double quotes and unquoted keys. JSON does not allow any of them.','Do not paste secrets or tokens from production systems into any online tool, even one that runs locally.','Validate JSON before sending it to an API to avoid vague 400 errors.'],
  faq:[['Does the formatter change my data?','No. It only changes whitespace. Keys and values stay as they are.'],['Why does it say my JSON is invalid?','Usually a missing comma, an extra comma at the end, or single quotes. The error message points near the problem.'],['Can it handle large files?','Yes, within your browser\'s memory. Very large files may take a moment.'],['Is my JSON uploaded?','No. Everything runs in your browser.']]},
'bmi-calculator': {
  intro:'Body Mass Index compares weight to height. It is a quick screening number, not a diagnosis. Enter your height and weight to see your BMI and the standard category it falls into.',
  steps:['Choose metric or imperial units.','Enter your height and weight.','Read your BMI and its category.','Use the result as one data point to discuss with a doctor if needed.'],
  tips:['BMI does not separate muscle from fat, so athletes and very muscular people can score as overweight while being healthy.','For Asian populations, health bodies often use lower cut-offs than the standard ones, so ask a doctor which range applies to you.','Waist size and overall health tell you more than BMI alone.'],
  faq:[['What is a healthy BMI?','The standard adult range for "normal" is 18.5 to 24.9. Ranges differ for children and some ethnic groups.'],['How is BMI calculated?','Weight in kilograms divided by height in metres squared.'],['Is BMI accurate?','It is a screening tool. It can mislead for muscular people, older adults and pregnancy.'],['Is this medical advice?','No. Speak to a qualified health professional about your weight and health.']]},
'age-calculator': {
  intro:'Work out your exact age in years, months and days from a date of birth, plus how many days until your next birthday. It is handy for forms, eligibility checks and simple curiosity.',
  steps:['Enter your date of birth.','Leave the "as of" date on today, or choose another date to check an age on a specific day.','Read your age in years, months and days.','See the countdown to your next birthday.'],
  tips:['Eligibility rules often use age on a specific cut-off date, so set the "as of" date to that day.','Someone born on 29 February celebrates on 28 February or 1 March in non-leap years, depending on local rules.','Dates use the calendar in your browser and your local time zone.'],
  faq:[['How is age calculated?','It counts complete years since the birth date, then the remaining whole months and days.'],['Can I check age on a past or future date?','Yes. Change the "as of" date.'],['Does it handle leap years?','Yes. Month lengths and leap years are handled correctly.'],['Is my date of birth stored?','No. The calculation runs in your browser.']]},
'emi-calculator': {
  intro:'EMI is the fixed amount you pay each month on a loan. Enter the loan amount, annual interest rate and tenure to see your monthly EMI, total interest and total repayment before you commit.',
  steps:['Enter the loan amount.','Enter the annual interest rate as a percentage.','Enter the tenure in months.','Read the EMI, the total interest and the total payment.'],
  tips:['A longer tenure lowers the EMI but raises total interest, often by a lot.','The rate on offer can be floating and change over time. Treat the EMI as an estimate.','Add processing fees and insurance to the true cost of the loan, as they are not included here.'],
  faq:[['What is the EMI formula?','EMI = P x r x (1+r)^n / ((1+r)^n - 1), where P is the loan, r the monthly rate and n the number of months.'],['Does it include processing fees?','No. Only principal and interest are included.'],['Can I reduce interest by prepaying?','Yes. Use the Loan Prepayment Calculator to see the saving.'],['Is the calculation exact?','The maths is exact for the numbers you enter. Your lender may round slightly differently.']]},
'sip-calculator': {
  intro:'A SIP invests a fixed amount every month. This calculator estimates what that habit could grow to at an assumed annual return, and shows how much of the final value is your money and how much is estimated growth.',
  steps:['Enter your monthly investment.','Enter the annual return you expect, as a percentage.','Enter the number of years.','Read the invested amount, estimated returns and total value.'],
  tips:['Returns are not guaranteed. Equity returns swing from year to year, so use a modest assumption.','Starting earlier matters more than starting bigger because of compounding.','Try the Step-up SIP Calculator if you plan to raise your investment each year.'],
  faq:[['How is SIP return calculated?','FV = P x ((1+i)^n - 1) / i x (1+i), where i is the monthly rate and n the number of months.'],['Is the result guaranteed?','No. It assumes a constant return, which real markets do not provide.'],['What return should I assume?','Use a cautious figure and compare a few scenarios. Past returns do not predict the future.'],['Are taxes included?','No. Capital gains tax and fund charges are not included.']]},
'income-tax-india': {
  intro:'Compare how much income tax you would pay under the new and old regime for FY 2026-27 and see which is lower for your income. It applies slabs, standard deduction, the Section 87A rebate and 4% cess.',
  steps:['Enter your annual gross income.','Say whether you are salaried, to apply the standard deduction.','Enter total deductions you would claim under the old regime, such as 80C, 80D and HRA.','Compare both tax figures and see which regime is better.'],
  tips:['The new regime allows very few deductions. If your deductions are large, the old regime can still win.','Under the new regime, taxable income up to 12 lakh pays no tax because of the rebate. For a salaried person that is about 12.75 lakh of gross income, and relief tapers just above it.','Surcharge, capital gains and special-rate income are not included, so use this as an estimate.'],
  faq:[['Which regime is better?','It depends on your deductions. The calculator shows both so you can compare.'],['Does it include cess?','Yes, 4% health and education cess.'],['Is this accurate for filing?','It is an estimate for individuals under 60. Confirm with the Income Tax Department or a chartered accountant before filing.'],['Which year does it cover?','FY 2026-27 (AY 2027-28), using the slabs in force at the time of building. Check for later changes.']]},
'percentage-calculator': {
  intro:'Percentages come up in discounts, marks, tax and growth. This calculator handles the three questions people ask most: what is X% of Y, X is what percent of Y, and what is the percentage change between two numbers.',
  steps:['Pick the type of percentage question.','Enter the two numbers.','Read the answer straight away.','Change the numbers to try another case.'],
  tips:['A 20% rise followed by a 20% fall does not return you to the start. You end up 4% lower.','Percentage points and percent are different. Going from 10% to 12% is 2 percentage points, or a 20% increase.','To find the original price before a discount, divide by (1 - discount rate).'],
  faq:[['How do I find X% of a number?','Multiply the number by X and divide by 100.'],['How is percentage change calculated?','(New - Old) / Old x 100.'],['Why is percentage change negative?','A negative result means the value went down.'],['Can I use decimals?','Yes. Decimal values are supported.']]},
'gst-calculator': {
  intro:'Add GST to a base price, or take it out of a GST-inclusive amount to find the original price and the tax portion. Choose the slab rate and the mode and read the three figures.',
  steps:['Enter the amount.','Select the GST rate.','Choose Add GST or Remove GST.','Read the base amount, GST and total.'],
  tips:['To remove GST, divide the total by (1 + rate). Subtracting the rate from the total gives the wrong answer.','CGST and SGST are each half of the total rate for sales inside a state. IGST is the full rate across states.','GST rates for specific goods change, so confirm the rate for your item on the official GST site.'],
  faq:[['How is GST calculated?','GST = base x rate / 100. Total = base + GST.'],['How do I find the price before GST?','Divide the GST-inclusive price by (1 + rate/100).'],['Which rate applies to my product?','It depends on the item. Check the GST rate schedule or ask your accountant.'],['Does it show CGST and SGST?','The total GST is shown. Halve it to get CGST and SGST for a same-state sale.']]},
'qr-generator': {
  intro:'Create a QR code for a link, text, Wi-Fi details or a phone number and download it as an image. The code is generated in your browser, so your data is not sent to any server.',
  steps:['Type or paste the text or URL.','Pick a size and error-correction level.','Check the preview, then scan it with your phone to test.','Download the image.'],
  tips:['Higher error correction survives smudges and small logos but makes the code denser.','Keep a quiet white border around the code and print it large enough to scan from the intended distance.','Always test a code on a real phone before printing thousands.'],
  faq:[['Do the QR codes expire?','No. A static QR code contains your data directly and works forever.'],['Is there a scan limit?','No.'],['Can I add a logo?','Not in this tool. Adding a logo can reduce scan reliability.'],['Is my link tracked?','No. Nothing is sent to us.']]},
'image-compressor': {
  intro:'Large images slow pages down. This tool re-encodes your image at the quality you choose, right in your browser, and shows how much space you saved before you download.',
  steps:['Choose an image.','Adjust the quality slider.','Compare the new size with the original.','Download the compressed image.'],
  tips:['For photos, quality around 70 to 80 usually looks the same as the original at a fraction of the size.','Photos compress far better than flat graphics. Screenshots with text may show artefacts at low quality.','Resize an image to the size it is displayed at before compressing, for the biggest saving.'],
  faq:[['Will quality drop?','Slightly, depending on the slider. Lossy compression discards detail you rarely notice.'],['Are my images uploaded?','No. Compression happens on your device.'],['Which format is smallest?','WebP is usually smaller than JPEG at the same quality. Try the WebP Converter.'],['Is there a size limit?','Only your device memory.']]},
'image-resizer': {
  intro:'Resize an image to exact pixel dimensions or a percentage, with the aspect ratio locked if you want. It runs in your browser, so your pictures stay private.',
  steps:['Choose an image.','Enter the new width or height in pixels.','Keep the aspect ratio locked to avoid stretching.','Download the resized image.'],
  tips:['Shrinking an image looks fine. Enlarging one makes it blurry because no new detail is created.','Resize to the display size of the image on your page, doubled for high-density screens.','Resize first, then compress, to get the smallest file.'],
  faq:[['Will resizing reduce quality?','Shrinking keeps quality well. Enlarging softens the image.'],['What does aspect ratio lock do?','It changes the other side automatically so the picture is not stretched.'],['Which formats work?','You can load JPG, PNG and WebP. The resized image downloads as a PNG.'],['Is anything uploaded?','No.']]},
'pdf-merge': {
  intro:'Combine several PDFs into one file in the order you choose. The merge happens on your device, so contracts, invoices and scans never leave your computer.',
  steps:['Add two or more PDF files.','Use the arrows to put them in the right order.','Press Merge and download.','Open the merged file to check page order.'],
  tips:['Remove password protection first. Protected files cannot be merged.','Very large PDFs depend on your device memory. Merge in smaller groups if the page slows.','Keep your originals in case you need to redo the order.'],
  faq:[['Is there a file size limit?','No fixed limit, only your device memory.'],['Are my PDFs uploaded?','No. Merging happens in your browser.'],['Can I reorder pages afterwards?','Use Split / Extract PDF Pages with a custom page order.'],['Why did the merge fail?','The file may be damaged or password protected.']]},
'pdf-split': {
  intro:'Pull out only the pages you need from a PDF. Type page numbers and ranges such as 1-3,5,8-10 and download a new PDF. You can also repeat or reorder pages.',
  steps:['Choose a PDF.','Enter the pages to keep, for example 1-3,5.','Press Extract and download.','Check the new file.'],
  tips:['Pages are counted from 1 in the order they appear, not by printed page numbers.','Write a range backwards, like 5-3, to reverse those pages.','To remove pages instead of keeping them, use Delete PDF Pages.'],
  faq:[['How do I write multiple ranges?','Separate them with commas: 1-3,5,8-10.'],['Does it change the original?','No. A new file is created.'],['Is it private?','Yes. Nothing is uploaded.'],['What if the PDF is protected?','Remove the password first.']]},
'weight-converter': {
  intro:'Convert between kilograms, grams, pounds, ounces, stones and tonnes. Enter a value, choose the units and read every equivalent at once.',
  steps:['Enter the weight.','Pick the starting unit and the target unit.','Read the converted value and the full table.','Use swap to go the other way.'],
  tips:['One kilogram is about 2.2046 pounds. For quick mental maths, double it and add 10%.','A stone is 14 pounds and is mainly used in the UK and Ireland for body weight.','Ounces here are avoirdupois ounces. Troy ounces for precious metals are different.'],
  faq:[['How many pounds in a kilogram?','About 2.2046.'],['How many grams in an ounce?','About 28.35.'],['Is the conversion exact?','Factors are standard. Display rounds to a few decimals.'],['What is a stone?','A British unit equal to 14 pounds or about 6.35 kg.']]},
'temperature-converter': {
  intro:'Convert between Celsius, Fahrenheit and Kelvin. Useful for recipes, weather, science homework and travel.',
  steps:['Enter a value.','Choose the scale it is in under From.','Read the equivalents in the other two scales.','Change the value or scale to try again.'],
  tips:['Fahrenheit = Celsius x 9/5 + 32.','Kelvin = Celsius + 273.15, and 0 K is absolute zero.','Water freezes at 0 C (32 F) and boils at 100 C (212 F) at sea level.'],
  faq:[['How do I convert Celsius to Fahrenheit?','Multiply by 9/5 and add 32.'],['What is 0 K in Celsius?','About -273.15 C, absolute zero.'],['At what point are C and F equal?','At -40 degrees.'],['Does it round?','Results show a few decimals.']]},
'currency-converter': {
  intro:'Convert between major currencies using recent reference rates from the European Central Bank. Rates are indicative, so use them to plan, not to settle a payment.',
  steps:['Enter the amount.','Choose the From and To currencies.','Read the converted amount and the rate date.','Swap currencies if needed.'],
  tips:['Banks and card networks add a margin, so the rate you actually get is slightly worse.','Reference rates update once per working day, not in real time.','Check the exact rate with your bank before a large transfer.'],
  faq:[['Where do the rates come from?','The Frankfurter API, which publishes European Central Bank reference rates.'],['Are they live?','They update once per working day. A bundled fallback table is used if the request fails.'],['Can I use it for trading?','No. These are reference rates, not tradable quotes.'],['Why is my bank rate different?','Banks add fees or a margin.']]},
'lorem-ipsum': {
  intro:'Generate placeholder text for designs, mock-ups and layouts. Choose paragraphs, sentences or words and copy the result in one click.',
  steps:['Enter how many you need, from 1 to 50.','Choose paragraphs, sentences or words. The text appears straight away.','Review the text.','Copy it into your design.'],
  tips:['Placeholder text hides real content problems. Replace it with real copy before launch.','Use realistic lengths. Very short or very long blocks change how a layout behaves.','Lorem ipsum is scrambled Latin and carries no meaning.'],
  faq:[['What is lorem ipsum?','Dummy text used since the 1500s to show how type looks without distracting with real words.'],['Does it start with "Lorem ipsum dolor sit amet"?','Yes, by default.'],['Is it free to use commercially?','Yes.'],['Can I generate long text?','Yes, up to 50 paragraphs at a time.']]},
'base64-encoder': {
  intro:'Encode text to Base64 or decode Base64 back to readable text. Base64 turns data into plain ASCII so it can travel safely inside URLs, JSON and email.',
  steps:['Paste text into the input box.','Click Encode or Decode.','Read the output.','Copy the result.'],
  tips:['Base64 is encoding, not encryption. Anyone can decode it, so never use it to protect secrets.','Encoded data is about 33% larger than the original.','If decoding fails, the input may be missing padding or contain characters that are not Base64.'],
  faq:[['Is Base64 secure?','No. It is a reversible format, not security.'],['Why does my string end with = signs?','They are padding to make the length a multiple of 4.'],['Can it handle Unicode?','Yes, text is encoded as UTF-8.'],['Does it upload my data?','No.']]},
'uuid-generator': {
  intro:'Generate random version 4 UUIDs for database keys, test data and identifiers. Create one or many and copy them in one go.',
  steps:['Enter how many UUIDs you need, from 1 to 100.','Choose lowercase or UPPERCASE. The list appears straight away.','Change the count or case to regenerate.','Copy the results.'],
  tips:['A v4 UUID has 122 random bits, so a clash is astronomically unlikely.','UUIDs are not secrets. Do not use them as passwords or access tokens.','Sequential IDs are faster for some databases. Random UUIDs can fragment indexes.'],
  faq:[['What is a UUID?','A 128-bit identifier written as 32 hex digits in five groups.'],['Are they unique?','Practically, yes. The chance of a duplicate is negligible.'],['Which version is this?','Version 4, random.'],['Are they generated locally?','Yes, in your browser.']]},
'text-compare': {
  intro:'Paste two versions of a text and see exactly what changed. It is useful for edits, contract revisions and code snippets.',
  steps:['Paste the original text on the left.','Paste the changed text on the right.','Read the highlighted differences.','Edit either side to re-compare.'],
  tips:['Trailing spaces and line endings can show as differences even when text looks the same.','Compare small sections at a time for long documents.','For code, use a proper version-control diff for large changes.'],
  faq:[['Does it compare by line or by word?','It compares line by line and highlights the changed lines.'],['Is there a size limit?','Only your device memory.'],['Is the text saved?','No.'],['Can it ignore case?','Not in this version.']]},
};
function topOf(t){ return (typeof TOP_CONTENT!=='undefined') ? TOP_CONTENT[t.id] : null; }

// Per-tool page content: how-to steps, details and FAQ. Pure functions (used at runtime and at build time).
const CAT_USE = {
  'Text Tools':'writers, students, editors and developers who need to clean, count or reshape text quickly',
  'Calculator Tools':'anyone who needs a fast, correct figure for money, health, study or everyday planning',
  'Image Tools':'designers, bloggers and developers who need to resize, convert or inspect images without uploading them anywhere',
  'Developer Tools':'developers who need to format, encode, decode or generate data while building and debugging',
  'Date & Time Tools':'people planning schedules, deadlines and events across dates and time zones',
  'Unit Converters':'students, engineers, cooks, travellers and anyone comparing measurements across systems',
  'Utility Tools':'everyday tasks such as generating codes, picking randomly or checking simple facts',
  'SEO Tools':'site owners, marketers and content teams who prepare pages for search and social sharing',
  'Security Tools':'people who want stronger passwords and safer test data without sending anything to a server',
  'Math Tools':'students, teachers and hobbyists working through arithmetic, number theory and algebra',
  'PDF Tools':'students, office workers and freelancers who need to merge, split, rotate or build PDF files without installing software',
};
const CAT_TIPS = {
  'Text Tools':['Work on a copy of important text so you can compare before and after.','Paste plain text for the cleanest results. Formatting from word processors can add hidden characters.','For long documents, process one section at a time to spot problems earlier.'],
  'Calculator Tools':['Double-check units and whether a rate is annual or monthly before you enter it.','Run the numbers with a cautious and an optimistic value to see the range of outcomes.','Results are estimates based on the inputs you give. Fees, taxes and rounding rules set by a provider can change the final figure.'],
  'Image Tools':['Images are processed on your device with your browser, so large files depend on your device memory.','Keep your original file. Converting or compressing can discard detail that cannot be restored.','Check the result at full size before using it on a website or in print.'],
  'Developer Tools':['Never paste live production secrets into any online tool, even one that runs locally. Use test values where you can.','Validate output in your own environment before shipping it.','Keep sample inputs handy so you can reproduce a result when debugging.'],
  'Date & Time Tools':['Check the time zone and whether daylight saving applies on the dates you care about.','Dates are calculated using the calendar in your browser, which follows the Gregorian system.','For legal or contractual deadlines, confirm the counting rules that apply to you.'],
  'Unit Converters':['Check whether a unit is metric, US customary or imperial. The names can look alike but the sizes differ.','Rounded display values are fine for everyday use. For engineering work keep more digits.','Use the swap button to sanity check a result by converting it back.'],
  'Utility Tools':['Random results come from your browser random number generator and are not suitable for gambling or security decisions.','Everything resets when you close the tab, so copy anything you want to keep.','Bookmark the tools you use often with the Save button.'],
  'SEO Tools':['Write for people first. Search engines reward pages that are clearly useful.','Keep titles under about 60 characters and descriptions under about 160 so they are not cut off in results.','Re-test pages after changes with the search engine tools you use.'],
  'Security Tools':['Use a different password for every account and store them in a reputable password manager.','Generated values are created in your browser and are not sent anywhere. Copy them into your manager straight away.','Strength meters are guidance. Length and randomness matter more than any single rule.'],
  'PDF Tools':['Keep a copy of your original files. These tools create a new PDF and do not change the originals.','Password protected or damaged PDFs cannot be processed. Remove the password first.','Very large PDFs depend on your device memory. If the page slows down, split the job into smaller parts.'],
  'Math Tools':['Work through a small example by hand to confirm you understand what the tool is doing.','Very large numbers may be shown in rounded or scientific form because of how browsers store numbers.','Check the input format, such as commas between values or one value per line.'],
};
const NETWORK_TOOLS = {'ip-lookup':'This tool contacts the public ipify service to find your public IP address. Nothing you type is sent.','currency-converter':'This tool requests current reference rates from the public Frankfurter API. Only the rate request is sent.'};
function ctSteps(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return tp.steps;
  const name = t.name;
  if (t.kind==='convert'){
    return [`Enter the amount you want to convert in the Amount field.`,`Pick the starting unit under From and the target unit under To. The converter covers ${Object.keys(tableOf(t).units).length} units.`,`Read the result instantly. The full conversions table below it shows the same value in every other unit.`,`Use the swap button to reverse the direction without retyping.`];
  }
  if (t.kind==='text'){
    const labels=(t.transforms||[]).map(x=>x.label);
    return [`Paste or type your text into the input box.`,labels.length?`Choose an action: ${labels.slice(0,8).join(', ')}${labels.length>8?' and more':''}.`:`Review the live analysis shown next to your text.`,`Read the output. It updates as soon as you click.`,`Use Copy to place the result on your clipboard, or Clear to start over.`];
  }
  if (t.kind==='calc'){
    const f=(t.fields||[]).map(x=>x.label);
    return [`Fill in the inputs: ${f.slice(0,8).join(', ')}.`,`The result appears immediately and updates as you change any value.`,`Adjust one input at a time to see how it changes the outcome.`,`Copy the figures you need into your notes or spreadsheet.`];
  }
  if (t.kind==='compare') return [`Paste the first text on the left and the second on the right.`,`Differences are highlighted as soon as both sides contain text.`,`Edit either side to re-check the comparison.`];
  if (t.kind==='base') return [`Type a number into the field for the base it is written in.`,`Every other base updates at the same time.`,`Copy any of the converted values.`];
  return [`Open the tool and fill in the input fields or drop in your file.`,`Press the main action button to run ${name}.`,`Review the result and copy or download it.`,`Change any input and run it again as often as you like.`];
}
function tableOf(t){ return (new Function('return '+t.table))(); }
function ctExample(t){
  try{
    if (t.kind==='convert'){
      const tb=tableOf(t), d=t.def||{amt:1,from:Object.keys(tb.units)[0],to:Object.keys(tb.units)[1]};
      const U=tb.units, f=U[d.from], to=U[d.to];
      if (f && to && typeof f.f==='number' && typeof to.f==='number'){
        const v=(d.amt*f.f/to.f); const r=Math.abs(v)>=1000?v.toLocaleString('en-US',{maximumFractionDigits:2}):String(+v.toPrecision(5));
        return `For example, ${d.amt} ${f.l.toLowerCase()} equals ${r} ${to.l.toLowerCase()}${/s$/.test(to.l)?'':''}.`;
      }
    }
  }catch(e){}
  return '';
}
function ctFaq(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return tp.faq;
  const priv = NETWORK_TOOLS[t.id] || 'Everything is calculated in your browser. What you type or upload is not sent to our servers.';
  const q=[
    [`What is ${t.name}?`, `${t.desc}. It is built for ${CAT_USE[t.cat]||'everyday use'}.`],
    [`Is ${t.name} free to use?`, `Yes. There is no login, no account and no usage limit.`],
    [`Is my data private?`, priv],
    [`Do I need to install anything?`, `No. ${t.name} runs in your browser tab. There is nothing to download, and it keeps working after the page has loaded, apart from the tools that clearly say they need a network request.`],
    [`Does ${t.name} work on my phone?`, `Yes. The layout adapts to phones and tablets, and the tool works in any modern browser.`],
  ];
  if (t.kind==='convert'){ const tb=tableOf(t); q.push([`How accurate are the results?`,`Conversions use standard factors against a base unit of ${tb.base}, and results are rounded for display only. Very large or very small values may be shown in rounded form.`]); }
  if (t.kind==='calc') q.push([`Can I rely on this for important decisions?`,`The arithmetic is exact for the numbers you enter, but real-world outcomes depend on terms, fees and rules the calculator cannot see. Treat the result as an estimate and confirm it with a qualified professional where money, health or legal matters are involved.`]);
  if (t.kind==='text') q.push([`Is there a limit on text length?`,`There is no fixed limit. Very large inputs depend on your device's memory and may feel slower.`]);
  return q;
}
function ctInfo(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return `<h2>${t.name}</h2><p>${tp.intro}</p>`;
  if (t.info) return t.info;
  return `<h2>About ${t.name}</h2><p>${t.desc}. ${t.name} is part of the ${t.cat} on Kitwell. It is built for ${CAT_USE[t.cat]||'everyday use'}. It opens instantly, needs no account and has no usage limits, so you can run it as many times as you need.</p>`;
}
function ctText(t){
  const steps=ctSteps(t), faq=ctFaq(t), ex=ctExample(t);
  const parts=[ctInfo(t).replace(/<[^>]+>/g,' '),ex,steps.join(' '),((topOf(t)&&topOf(t).tips)||CAT_TIPS[t.cat]||[]).join(' '),faq.map(x=>x.join(' ')).join(' ')];
  return parts.join(' ').replace(/\s+/g,' ').trim();
}
function ctHtml(t, esc){
  const steps=ctSteps(t), faq=ctFaq(t), ex=ctExample(t);
  return `${ctInfo(t)}${ex?`<p>${esc(ex)}</p>`:''}<h2>How to use ${esc(t.name)}</h2><ol>${steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol><h2>Tips for better results</h2><ul>${(((typeof topOf==='function'&&topOf(t))||{}).tips||CAT_TIPS[t.cat]||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h2>Frequently asked questions</h2>${faq.map(([q,a])=>`<h3>${esc(q)}</h3><p>${esc(a)}</p>`).join('')}`;
}

// Hand-picked related tools (fallback: same category)
const RELATED = {
  'nps-calculator':['epf-calculator','ppf-calculator','sip-calculator','income-tax-india','inflation-calculator'],
  'epf-calculator':['nps-calculator','ppf-calculator','gratuity-calculator','hra-calculator','income-tax-india'],
  'home-loan-eligibility':['emi-calculator','loan-prepayment-calculator','loan-calculator','income-tax-india'],
  'ssy-calculator':['ppf-calculator','fd-calculator','rd-calculator','sip-calculator','inflation-calculator'],
  'inflation-calculator':['compound-interest','cagr-calculator','sip-calculator','fd-calculator','percentage-calculator'],
  'emi-calculator':['loan-calculator','loan-prepayment-calculator','income-tax-india','sip-calculator','compound-interest','percentage-calculator'],
  'loan-calculator':['emi-calculator','loan-prepayment-calculator','compound-interest','simple-interest'],
  'loan-prepayment-calculator':['emi-calculator','loan-calculator','sip-calculator','fd-calculator'],
  'sip-calculator':['stepup-sip-calculator','swp-calculator','fd-calculator','ppf-calculator','cagr-calculator','compound-interest'],
  'stepup-sip-calculator':['sip-calculator','swp-calculator','cagr-calculator','rd-calculator'],
  'swp-calculator':['sip-calculator','fd-calculator','compound-interest','cagr-calculator'],
  'fd-calculator':['rd-calculator','ppf-calculator','compound-interest','simple-interest','sip-calculator'],
  'rd-calculator':['fd-calculator','ppf-calculator','sip-calculator','savings-goal'],
  'ppf-calculator':['fd-calculator','rd-calculator','sip-calculator','income-tax-india'],
  'cagr-calculator':['sip-calculator','compound-interest','percentage-calculator','percent-error'],
  'income-tax-india':['hra-calculator','gst-calculator','hourly-to-annual-salary','ppf-calculator','gratuity-calculator'],
  'hra-calculator':['income-tax-india','hourly-to-annual-salary','gratuity-calculator'],
  'gratuity-calculator':['hourly-to-annual-salary','income-tax-india','hra-calculator'],
  'hourly-to-annual-salary':['income-tax-india','hra-calculator','gratuity-calculator','percentage-calculator'],
  'gst-calculator':['vat-calculator','discount-calculator','percentage-calculator','markup-calculator'],
  'percentage-calculator':['percent-error','discount-calculator','gst-calculator','ratio-simplifier','mean-median-mode-calculator'],
  'bmi-calculator':['bmr-calculator','water-intake','age-calculator','weight-converter'],
  'age-calculator':['age-in-days','date-difference','days-until','bmi-calculator'],
  'word-counter':['character-counter','line-counter','reading-time','case-converter','text-compare'],
  'character-counter':['word-counter','string-length','line-counter','case-converter'],
  'case-converter':['word-counter','text-sorter','remove-spaces','slug-generator'],
  'password-generator':['password-strength','password-passphrase','token-generator','uuid-generator','hash-generator'],
  'json-formatter':['json-validator','csv-json','xml-formatter','base64-encoder','regex-tester'],
  'qr-generator':['url-encoder','base64-encoder','image-color-picker','image-compressor'],
  'image-compressor':['image-resizer','webp-converter','jpg-to-png','png-to-jpg','images-to-pdf'],
  'image-resizer':['image-compressor','image-crop','webp-converter','image-rotator'],
  'webp-converter':['image-compressor','jpg-to-png','png-to-jpg','image-resizer'],
  'images-to-pdf':['pdf-merge','pdf-to-jpg','image-compressor','pdf-split'],
  'pdf-merge':['pdf-split','pdf-delete-pages','pdf-rotate','images-to-pdf','pdf-page-numbers'],
  'pdf-split':['pdf-merge','pdf-delete-pages','pdf-rotate','pdf-to-jpg'],
  'pdf-delete-pages':['pdf-split','pdf-merge','pdf-rotate','pdf-page-numbers'],
  'pdf-to-jpg':['images-to-pdf','pdf-split','image-compressor','webp-converter'],
  'pdf-rotate':['pdf-merge','pdf-split','pdf-delete-pages'],
  'pdf-page-numbers':['pdf-merge','pdf-split','pdf-delete-pages'],
  'currency-converter':['percentage-calculator','gst-calculator','speed-converter','compound-interest'],
  'weight-converter':['length-converter','temperature-converter','bmi-calculator','speed-converter'],
  'temperature-converter':['weight-converter','length-converter','cooking-converter'],
  'length-converter':['weight-converter','area-converter','volume-converter','speed-converter'],
  'lorem-ipsum':['random-word-generator','word-counter','text-repeater','case-converter'],
  'base64-encoder':['url-encoder','json-formatter','hash-generator','image-to-base64'],
  'uuid-generator':['token-generator','password-generator','hash-generator','random-number'],
  'text-compare':['find-replace','word-counter','remove-duplicates','text-sorter'],
};

// ============================================================
// Shared helper functions used across tools
// ============================================================
function esc(s){ return String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function round4(n){ if(!isFinite(n)) return String(n); const r=Math.round(n*10000)/10000; return r.toLocaleString(undefined,{maximumFractionDigits:4}); }
function fmtMoney(n){ if(!isFinite(n)) return '-'; return n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
function fmtDuration(seconds){
  if(!isFinite(seconds)) return '-';
  const units=[['year',31536000],['day',86400],['hour',3600],['minute',60],['second',1]];
  if(seconds<1) return '< 1 second';
  for(const [name,secs] of units){ if(seconds>=secs){ const v=Math.round(seconds/secs); return v.toLocaleString()+' '+name+(v===1?'':'s'); } }
  return Math.round(seconds)+' seconds';
}
function statBlock(pairs){
  return '<div class="sgrid">'+pairs.map(([l,v])=>`<div class="sc"><span class="sn" style="font-size:18px">${esc(v)}</span><span class="sl">${esc(l)}</span></div>`).join('')+'</div>';
}
function parseNums(str){ return (str||'').split(/[,\s]+/).map(s=>parseFloat(s)).filter(n=>!isNaN(n)); }
function gcd(a,b){ a=Math.abs(a); b=Math.abs(b); while(b){ [a,b]=[b,a%b]; } return a||1; }

const LOREM_WORDS = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure reprehenderit voluptate velit esse cillum fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim est".split(" ");
function genLorem(num, type){
  const classic = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
  const rWord = () => LOREM_WORDS[Math.floor(Math.random()*LOREM_WORDS.length)];
  const rSent = () => { let w=[]; for(let i=0;i<Math.floor(Math.random()*10+8);i++) w.push(rWord()); return w[0].charAt(0).toUpperCase()+w.join(' ').slice(1)+'.'; };
  const rPara = () => { let s=[]; for(let i=0;i<Math.floor(Math.random()*4+3);i++) s.push(rSent()); return s.join(' '); };
  let result=[];
  if (type==='words'){ let w=[]; for(let i=0;i<num;i++) w.push(rWord()); result=[w.join(' ')]; }
  else if (type==='sentences'){ for(let i=0;i<num;i++) result.push(rSent()); }
  else { for(let i=0;i<num;i++) result.push(rPara()); result[0]=classic+' '+rPara(); }
  return result.join('\n\n');
}

function formatHTML(src){
  src = src.trim().replace(/>\s*</g,'><');
  let formatted='', pad=0;
  const tags = src.split(/(?=<)/);
  tags.forEach(tag=>{
    if(!tag) return;
    if(/^<\/\w/.test(tag)){ pad=Math.max(0,pad-1); formatted += '  '.repeat(pad)+tag+'\n'; }
    else if(/^<\w[^>]*[^\/]>$/.test(tag) && !/^<(br|hr|img|input|meta|link|area|base|col|embed|source|track|wbr)[\s>]/i.test(tag)){
      formatted += '  '.repeat(pad)+tag+'\n'; pad++;
    } else { formatted += '  '.repeat(pad)+tag+'\n'; }
  });
  return formatted.trim();
}

function parseCSV(str){
  const rows=[]; let row=[],field='',inQ=false;
  const s=str.replace(/\r\n/g,'\n');
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(inQ){
      if(c==='"'){ if(s[i+1]==='"'){ field+='"'; i++; } else inQ=false; }
      else field+=c;
    } else {
      if(c==='"') inQ=true;
      else if(c===','){ row.push(field); field=''; }
      else if(c==='\n'){ row.push(field); rows.push(row); row=[]; field=''; }
      else field+=c;
    }
  }
  if(field!=='' || row.length){ row.push(field); rows.push(row); }
  return rows.filter(r=>r.length>1 || r[0]!=='');
}

function explainCron(expr){
  const parts=expr.trim().split(/\s+/);
  if(parts.length!==5) throw new Error('Expected 5 fields: minute hour day-of-month month day-of-week');
  const [min,hour,dom,mon,dow]=parts;
  const names={dow:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],mon:['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']};
  const describe=(field,label,nameArr)=>{
    if(field==='*') return 'every '+label;
    if(field.includes('/')){ const [r,step]=field.split('/'); return `every ${step} ${label}(s)`+(r!=='*'?` starting at ${r}`:''); }
    if(field.includes('-')){ const [a,b]=field.split('-'); return `${label} ${nameArr?nameArr[a]:a} through ${nameArr?nameArr[b]:b}`; }
    if(field.includes(',')) return `${label}s ${field.split(',').map(x=>nameArr?nameArr[x]:x).join(', ')}`;
    return `${label} ${nameArr?nameArr[field]:field}`;
  };
  return `Runs at minute: ${describe(min,'minute')}; hour: ${describe(hour,'hour')}; day of month: ${describe(dom,'day')}; month: ${describe(mon,'month',names.mon)}; day of week: ${describe(dow,'weekday',names.dow)}.`;
}

function numberToWords(num){
  if(num===0) return 'zero';
  const neg = num<0; num=Math.abs(num);
  const ones=['','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen'];
  const tens=['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
  const scales=['','thousand','million','billion','trillion'];
  function chunk(n){
    let s='';
    if(n>=100){ s+=ones[Math.floor(n/100)]+' hundred '; n%=100; }
    if(n>=20){ s+=tens[Math.floor(n/10)]+' '; n%=10; }
    if(n>0) s+=ones[n]+' ';
    return s.trim();
  }
  let intPart=Math.floor(num);
  if(intPart===0) return 'zero';
  let parts=[];
  let scaleIdx=0;
  while(intPart>0){
    const c=intPart%1000;
    if(c>0) parts.unshift(chunk(c)+(scales[scaleIdx]?' '+scales[scaleIdx]:''));
    intPart=Math.floor(intPart/1000);
    scaleIdx++;
  }
  return (neg?'negative ':'')+parts.join(' ').trim();
}

function luhnCheck(digits){
  let sum=0, alt=false;
  for(let i=digits.length-1;i>=0;i--){
    let d=parseInt(digits[i],10);
    if(alt){ d*=2; if(d>9) d-=9; }
    sum+=d; alt=!alt;
  }
  return sum%10===0;
}
function detectCardBrand(digits){
  if(/^4/.test(digits)) return 'Visa';
  if(/^5[1-5]/.test(digits) || /^2(2[2-9]|[3-6]|7[01]|720)/.test(digits)) return 'Mastercard';
  if(/^3[47]/.test(digits)) return 'American Express';
  if(/^6(011|5)/.test(digits)) return 'Discover';
  if(/^3(0[0-5]|[68])/.test(digits)) return 'Diners Club';
  if(/^35/.test(digits)) return 'JCB';
  if(/^(60|65|81|82|508)/.test(digits)) return 'RuPay (possible)';
  return null;
}

function getISOWeek(d){
  d=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  const dayNum=(d.getUTCDay()+6)%7;
  d.setUTCDate(d.getUTCDate()-dayNum+3);
  const firstThursday=new Date(Date.UTC(d.getUTCFullYear(),0,4));
  return 1+Math.round(((d-firstThursday)/86400000-3+((firstThursday.getUTCDay()+6)%7))/7);
}
function getDayOfYear(d){
  const start=new Date(d.getFullYear(),0,0);
  return Math.floor((d-start)/86400000);
}

const NATO = {A:'Alfa',B:'Bravo',C:'Charlie',D:'Delta',E:'Echo',F:'Foxtrot',G:'Golf',H:'Hotel',I:'India',J:'Juliett',K:'Kilo',L:'Lima',M:'Mike',N:'November',O:'Oscar',P:'Papa',Q:'Quebec',R:'Romeo',S:'Sierra',T:'Tango',U:'Uniform',V:'Victor',W:'Whiskey',X:'Xray',Y:'Yankee',Z:'Zulu','0':'Zero','1':'One','2':'Two','3':'Three','4':'Four','5':'Five','6':'Six','7':'Seven','8':'Eight','9':'Nine'};

const MORSE = {A:'.-',B:'-...',C:'-.-.',D:'-..',E:'.',F:'..-.',G:'--.',H:'....',I:'..',J:'.---',K:'-.-',L:'.-..',M:'--',N:'-.',O:'---',P:'.--.',Q:'--.-',R:'.-.',S:'...',T:'-',U:'..-',V:'...-',W:'.--',X:'-..-',Y:'-.--',Z:'--..','0':'-----','1':'.----','2':'..---','3':'...--','4':'....-','5':'.....','6':'-....','7':'--...','8':'---..','9':'----.','.':'.-.-.-',',':'--..--','?':'..--..'};
const MORSE_REV = Object.fromEntries(Object.entries(MORSE).map(([k,v])=>[v,k]));

;
// ============================================================
// TOOLHUB PRO - Tool catalogue
// Every tool below is a real, working client-side tool. Nothing
// here is a placeholder: each entry either renders through one
// of the shared templates (convert / text / compare / calc / base)
// or supplies its own body()/init() for tools that need a custom UI.
// ============================================================

const CAT_CONFIG = {
  'Text Tools':        {id:'text', ab:'Tx', bg:'#9A3412'},
  'Calculator Tools':  {id:'calc', ab:'Cl', bg:'#0F766E'},
  'Image Tools':       {id:'img',  ab:'Im', bg:'#C2410C'},
  'Developer Tools':   {id:'dev',  ab:'Dv', bg:'#1D4ED8'},
  'Unit Converters':   {id:'unit', ab:'Un', bg:'#0369A1'},
  'Date & Time Tools': {id:'dt',   ab:'Dt', bg:'#A16207'},
  'Utility Tools':     {id:'util', ab:'Ut', bg:'#475569'},
  'SEO Tools':         {id:'seo',  ab:'SE', bg:'#0E7490'},
  'Security Tools':    {id:'sec',  ab:'Sc', bg:'#991B1B'},
  'Math Tools':        {id:'math', ab:'Mt', bg:'#BE123C'},
  'PDF Tools':         {id:'pdf',  ab:'Pd', bg:'#B91C1C'},
};

// ---- unit tables for convert-kind tools (value = multiplier to base unit) ----
const U_LENGTH = {base:'m', units:{
  mm:{l:'Millimeter',f:0.001}, cm:{l:'Centimeter',f:0.01}, m:{l:'Meter',f:1}, km:{l:'Kilometer',f:1000},
  in:{l:'Inch',f:0.0254}, ft:{l:'Foot',f:0.3048}, yd:{l:'Yard',f:0.9144}, mi:{l:'Mile',f:1609.344},
  nmi:{l:'Nautical Mile',f:1852},
}};
const U_WEIGHT = {base:'kg', units:{
  mg:{l:'Milligram',f:0.000001}, g:{l:'Gram',f:0.001}, kg:{l:'Kilogram',f:1}, t:{l:'Metric Ton',f:1000},
  oz:{l:'Ounce',f:0.0283495}, lb:{l:'Pound',f:0.453592}, st:{l:'Stone',f:6.35029},
}};
const U_SPEED = {base:'ms', units:{
  ms:{l:'Meters/sec',f:1}, kmh:{l:'Km/hour',f:0.277778}, mph:{l:'Miles/hour',f:0.44704},
  kn:{l:'Knots',f:0.514444}, fts:{l:'Feet/sec',f:0.3048},
}};
const U_AREA = {base:'m2', units:{
  mm2:{l:'mm²',f:0.000001}, cm2:{l:'cm²',f:0.0001}, m2:{l:'m²',f:1}, ha:{l:'Hectare',f:10000},
  km2:{l:'km²',f:1000000}, in2:{l:'in²',f:0.00064516}, ft2:{l:'ft²',f:0.092903},
  ac:{l:'Acre',f:4046.86}, mi2:{l:'mi²',f:2589988.11},
}};
const U_VOLUME = {base:'l', units:{
  ml:{l:'Milliliter',f:0.001}, l:{l:'Liter',f:1}, m3:{l:'Cubic meter',f:1000},
  tsp:{l:'Teaspoon (US)',f:0.00492892}, tbsp:{l:'Tablespoon (US)',f:0.0147868},
  cup:{l:'Cup (US)',f:0.236588}, pt:{l:'Pint (US)',f:0.473176}, qt:{l:'Quart (US)',f:0.946353},
  gal:{l:'Gallon (US)',f:3.78541}, galuk:{l:'Gallon (UK)',f:4.54609},
}};
const U_TIME = {base:'s', units:{
  ms:{l:'Millisecond',f:0.001}, s:{l:'Second',f:1}, min:{l:'Minute',f:60}, h:{l:'Hour',f:3600},
  d:{l:'Day',f:86400}, wk:{l:'Week',f:604800}, mo:{l:'Month (30d)',f:2592000}, yr:{l:'Year (365d)',f:31536000},
}};
const U_DATA = {base:'b', units:{
  b:{l:'Byte',f:1}, kb:{l:'Kilobyte',f:1024}, mb:{l:'Megabyte',f:1024**2}, gb:{l:'Gigabyte',f:1024**3},
  tb:{l:'Terabyte',f:1024**4}, bit:{l:'Bit',f:0.125}, kbit:{l:'Kilobit',f:128},
}};
const U_ENERGY = {base:'j', units:{
  j:{l:'Joule',f:1}, kj:{l:'Kilojoule',f:1000}, cal:{l:'Calorie',f:4.184}, kcal:{l:'Kilocalorie',f:4184},
  wh:{l:'Watt-hour',f:3600}, kwh:{l:'Kilowatt-hour',f:3600000}, btu:{l:'BTU',f:1055.06},
}};
const U_PRESSURE = {base:'pa', units:{
  pa:{l:'Pascal',f:1}, kpa:{l:'Kilopascal',f:1000}, bar:{l:'Bar',f:100000}, atm:{l:'Atmosphere',f:101325},
  psi:{l:'PSI',f:6894.76}, mmhg:{l:'mmHg',f:133.322},
}};
const U_POWER = {base:'w', units:{
  w:{l:'Watt',f:1}, kw:{l:'Kilowatt',f:1000}, mw:{l:'Megawatt',f:1000000},
  hp:{l:'Horsepower',f:745.7}, btuh:{l:'BTU/hour',f:0.293071},
}};
const U_FORCE = {base:'n', units:{
  n:{l:'Newton',f:1}, kn:{l:'Kilonewton',f:1000}, lbf:{l:'Pound-force',f:4.44822}, kgf:{l:'Kilogram-force',f:9.80665},
  dyn:{l:'Dyne',f:0.00001},
}};
const U_ANGLE = {base:'deg', units:{
  deg:{l:'Degree',f:1}, rad:{l:'Radian',f:57.29577951}, grad:{l:'Gradian',f:0.9}, rev:{l:'Revolution',f:360},
}};
const U_FREQ = {base:'hz', units:{
  hz:{l:'Hertz',f:1}, khz:{l:'Kilohertz',f:1000}, mhz:{l:'Megahertz',f:1000000}, ghz:{l:'Gigahertz',f:1000000000},
  rpm:{l:'RPM',f:1/60},
}};
const U_FUEL = {base:'l100km', units:{ // handled with custom fn below because mpg is inverse
}};

// === TOOLS ===================================================
// kind: 'custom' tools are implemented in src/custom-tools.js (TOOL_CUSTOM map)
const TOOLS = [
// ---------------- TEXT TOOLS ----------------
{id:'word-counter', name:'Word Counter', cat:'Text Tools', ab:'Wc', desc:'Count words, characters, sentences & reading time', badge:'pop', kind:'dedicated'},
{id:'character-counter', name:'Character Counter', cat:'Text Tools', ab:'Cc', desc:'Count characters with and without spaces', kind:'text',
  transforms:[{label:'Count', run:t=>t}], extra:'charcount', info:'<h2>Character Counter</h2><p>Counts total characters, characters excluding spaces, and bytes (UTF-8 size) of your text as you type.</p>'},
{id:'case-converter', name:'Case Converter', cat:'Text Tools', ab:'Cv', desc:'Convert text to uppercase, lowercase, title case', badge:'pop', kind:'text',
  transforms:[
    {label:'UPPERCASE', run:s=>s.toUpperCase()},
    {label:'lowercase', run:s=>s.toLowerCase()},
    {label:'Title Case', run:s=>s.replace(/\w\S*/g, w=>w[0].toUpperCase()+w.slice(1).toLowerCase())},
    {label:'Sentence case', run:s=>s.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, c=>c.toUpperCase())},
    {label:'camelCase', run:s=>s.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g,(_,c)=>c.toUpperCase())},
    {label:'PascalCase', run:s=>{const c=s.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g,(_,c)=>c.toUpperCase());return c.charAt(0).toUpperCase()+c.slice(1);}},
    {label:'snake_case', run:s=>s.toLowerCase().trim().replace(/[\s-]+/g,'_').replace(/[^a-z0-9_]/g,'')},
    {label:'kebab-case', run:s=>s.toLowerCase().trim().replace(/[\s_]+/g,'-').replace(/[^a-z0-9-]/g,'')},
    {label:'aLtErNaTiNg', run:s=>s.split('').map((c,i)=>i%2?c.toLowerCase():c.toUpperCase()).join('')},
    {label:'InVeRsE cAsE', run:s=>s.split('').map(c=>c===c.toUpperCase()?c.toLowerCase():c.toUpperCase()).join('')},
  ], info:'<h2>Case Converter</h2><p>Convert text instantly between ten case formats, covering developer formats (camelCase, snake_case, kebab-case) and writing formats (Title Case, Sentence case).</p>'},
{id:'remove-spaces', name:'Remove Extra Spaces', cat:'Text Tools', ab:'Rs', desc:'Clean whitespace and extra spaces from text', kind:'text',
  transforms:[
    {label:'Remove Extra Spaces', run:s=>s.trim().replace(/[ \t]+/g,' ').replace(/\n\s*\n/g,'\n\n')},
    {label:'Trim Only', run:s=>s.trim()},
    {label:'Remove Blank Lines', run:s=>s.split('\n').filter(l=>l.trim()).join('\n')},
    {label:'Remove ALL Spaces', run:s=>s.replace(/\s/g,'')},
  ], info:'<h2>Remove Extra Spaces</h2><p>Clean up whitespace left over from copy-pasting from PDFs, emails or scraped web pages.</p>'},
{id:'text-sorter', name:'Text Sorter', cat:'Text Tools', ab:'Ts', desc:'Sort lines alphabetically or reverse', kind:'text',
  transforms:[
    {label:'A to Z', run:s=>s.split('\n').sort((a,b)=>a.localeCompare(b)).join('\n')},
    {label:'Z to A', run:s=>s.split('\n').sort((a,b)=>b.localeCompare(a)).join('\n')},
    {label:'By Length', run:s=>s.split('\n').sort((a,b)=>a.length-b.length).join('\n')},
    {label:'Shuffle', run:s=>{const a=s.split('\n');for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('\n');}},
    {label:'Reverse Order', run:s=>s.split('\n').reverse().join('\n')},
  ], info:'<h2>Text Sorter</h2><p>Sort lines of text alphabetically, by length, or shuffle them randomly. One line per item.</p>'},
{id:'remove-duplicates', name:'Duplicate Line Remover', cat:'Text Tools', ab:'Dl', desc:'Remove duplicate lines from text instantly', kind:'text',
  transforms:[
    {label:'Remove Duplicates', run:s=>[...new Set(s.split('\n'))].join('\n')},
    {label:'Remove (Case-Insensitive)', run:s=>{const seen=new Set();return s.split('\n').filter(l=>{const k=l.toLowerCase();if(seen.has(k))return false;seen.add(k);return true;}).join('\n');}},
  ], info:'<h2>Duplicate Line Remover</h2><p>Paste a list and remove duplicate lines. Useful for cleaning CSV exports, email lists or any line-based data.</p>'},
{id:'random-word-generator', name:'Random Word Generator', cat:'Text Tools', ab:'Rw', desc:'Generate random placeholder words', kind:'calc',
  fields:[{id:'n',label:'How many words',type:'number',value:10,min:1,max:200}],
  compute:v=>{const n=Math.min(200,Math.max(1,parseInt(v.n)||10));const out=[];for(let i=0;i<n;i++)out.push(WORDLIST[Math.floor(Math.random()*WORDLIST.length)]);return `<div class="res-box">${out.join(' ')}</div>`;},
  info:'<h2>Random Word Generator</h2><p>Generates random English words - handy for naming things, word games or testing text fields.</p>'},
{id:'slug-generator', name:'Slug Generator', cat:'Text Tools', ab:'Sl', desc:'Convert text to URL-friendly slug', badge:'pop', kind:'text',
  transforms:[
    {label:'Generate Slug', run:s=>s.normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[^\w\s-]/g,'').trim().toLowerCase().replace(/[\s_]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'')},
  ], single:true, info:'<h2>URL Slug Generator</h2><p>A slug is the readable part of a URL. Good slugs are short, lowercase and use hyphens only.</p><h3>Good vs bad slugs</h3><ul><li>Good: /how-to-make-sourdough-bread</li><li>Bad: /post?id=123</li></ul>'},
{id:'text-reverser', name:'Text Reverser', cat:'Text Tools', ab:'Rv', desc:'Reverse any text or string', kind:'text',
  transforms:[
    {label:'Reverse Characters', run:s=>s.split('').reverse().join('')},
    {label:'Reverse Words', run:s=>s.split(/\s+/).reverse().join(' ')},
    {label:'Reverse Lines', run:s=>s.split('\n').reverse().join('\n')},
  ], info:'<h2>Text Reverser</h2><p>Reverse text by character, word or line order.</p>'},
{id:'lorem-ipsum', name:'Lorem Ipsum Generator', cat:'Text Tools', ab:'Li', desc:'Generate Lorem Ipsum placeholder text', badge:'pop', kind:'calc',
  fields:[{id:'n',label:'Amount',type:'number',value:3,min:1,max:50},{id:'type',label:'Type',type:'select',options:[['paras','Paragraphs'],['sentences','Sentences'],['words','Words']]}],
  compute:v=>{const n=Math.min(50,Math.max(1,parseInt(v.n)||3));const out=genLorem(n,v.type);return `<div class="fg"><label class="fl">Generated Text <button class="cpbtn" onclick="copyText(document.getElementById('loremOut').value,this)">Copy</button></label><textarea class="fc" id="loremOut" rows="10" readonly>${esc(out)}</textarea></div>`;},
  info:'<h2>Lorem Ipsum Generator</h2><p>Classic placeholder text for mockups and layouts, generated in paragraphs, sentences or words.</p>'},
{id:'find-replace', name:'Find and Replace', cat:'Text Tools', ab:'Fr', desc:'Find and replace text in bulk', kind:'custom', info:'<h2>Find and Replace</h2><p>Bulk find-and-replace across a block of text, with optional case-sensitive and whole-word matching, and regex support.</p>'},
{id:'line-counter', name:'Line Counter', cat:'Text Tools', ab:'Lc', desc:'Count lines in any text', kind:'text',
  transforms:[{label:'Count', run:t=>t}], extra:'linecount', info:'<h2>Line Counter</h2><p>Counts total lines, non-empty lines and blank lines in your text.</p>'},
{id:'text-compare', name:'Text Compare', cat:'Text Tools', ab:'Tc', desc:'Compare two texts side by side', kind:'compare', info:'<h2>Text Compare</h2><p>Compares two blocks of text line by line and highlights which lines differ.</p>'},
{id:'text-repeater', name:'Text Repeater', cat:'Text Tools', ab:'Tr', desc:'Repeat text multiple times', kind:'calc',
  fields:[{id:'txt',label:'Text to repeat',type:'text',value:'Hello'},{id:'n',label:'Times',type:'number',value:5,min:1,max:1000},{id:'sep',label:'Separator',type:'select',options:[['nl','New line'],['sp','Space'],['cm','Comma']]}],
  compute:v=>{const n=Math.min(1000,Math.max(1,parseInt(v.n)||1));const sep=v.sep==='nl'?'\n':v.sep==='cm'?', ':' ';const out=Array(n).fill(v.txt||'').join(sep);return `<div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('repOut').value,this)">Copy</button></label><textarea class="fc" id="repOut" rows="8" readonly>${esc(out)}</textarea></div>`;},
  info:'<h2>Text Repeater</h2><p>Repeat any word, phrase or symbol a set number of times.</p>'},
{id:'text-to-html', name:'Text to HTML', cat:'Text Tools', ab:'Th', desc:'Convert plain text to HTML format', kind:'text',
  transforms:[{label:'Convert to HTML', run:s=>s.split('\n\n').map(p=>'<p>'+esc(p).replace(/\n/g,'<br>')+'</p>').join('\n')}],
  single:true, mono:true, info:'<h2>Text to HTML</h2><p>Wraps paragraphs in <code>&lt;p&gt;</code> tags and line breaks in <code>&lt;br&gt;</code>, and escapes special characters, so plain text becomes safe HTML.</p>'},
{id:'html-encode', name:'HTML Entity Encoder/Decoder', cat:'Text Tools', ab:'He', desc:'Encode or decode HTML entities', kind:'text',
  transforms:[{label:'Encode', run:s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))},
    {label:'Decode', run:s=>{const t=document.createElement('textarea');t.innerHTML=s;return t.value;}}],
  info:'<h2>HTML Entity Encoder / Decoder</h2><p>Escape special characters for safe HTML embedding, or decode HTML entities back to plain text.</p>'},
{id:'word-frequency', name:'Word Frequency Counter', cat:'Text Tools', ab:'Wf', desc:'Count how often each word appears', kind:'custom', info:'<h2>Word Frequency Counter</h2><p>Shows how many times each word appears in a block of text, sorted by frequency.</p>'},
{id:'remove-line-breaks', name:'Remove Line Breaks', cat:'Text Tools', ab:'Lb', desc:'Join wrapped lines into one paragraph', kind:'text',
  transforms:[{label:'Remove Line Breaks', run:s=>s.replace(/\r?\n+/g,' ').replace(/\s+/g,' ').trim()},
    {label:'Replace with Space', run:s=>s.replace(/\r?\n/g,' ')}],
  info:'<h2>Remove Line Breaks</h2><p>Joins text that was wrapped across multiple lines (common when pasting from PDFs) back into continuous paragraphs.</p>'},
{id:'add-line-numbers', name:'Add Line Numbers', cat:'Text Tools', ab:'Ln', desc:'Prefix every line with its number', kind:'text',
  transforms:[{label:'Add Line Numbers', run:s=>s.split('\n').map((l,i)=>`${i+1}. ${l}`).join('\n')}], single:true, mono:true,
  info:'<h2>Add Line Numbers</h2><p>Numbers every line of a text block - useful for code snippets, scripts or lists.</p>'},
{id:'pig-latin', name:'Pig Latin Converter', cat:'Text Tools', ab:'Pl', desc:'Translate English text to Pig Latin', kind:'text',
  transforms:[{label:'Convert', run:s=>s.replace(/[a-zA-Z]+/g, w=>{
    const vowels='aeiouAEIOU'; if(vowels.includes(w[0])) return w+'way';
    let i=0; while(i<w.length && !vowels.includes(w[i])) i++;
    return w.slice(i)+w.slice(0,i)+'ay';
  })}], single:true, info:'<h2>Pig Latin Converter</h2><p>Translates English text into Pig Latin using the classic consonant-cluster-shift rule.</p>'},
{id:'rot13', name:'ROT13 Encoder/Decoder', cat:'Text Tools', ab:'R1', desc:'Encode or decode ROT13 cipher text', kind:'text',
  transforms:[{label:'ROT13', run:s=>s.replace(/[a-zA-Z]/g,c=>{const base=c<='Z'?65:97;return String.fromCharCode((c.charCodeAt(0)-base+13)%26+base);})}],
  single:true, mono:true, info:'<h2>ROT13 Encoder / Decoder</h2><p>ROT13 shifts every letter 13 places through the alphabet. Applying it twice returns the original text - the same button encodes and decodes.</p>'},
{id:'caesar-cipher', name:'Caesar Cipher', cat:'Text Tools', ab:'Cs', desc:'Shift letters by a chosen amount', kind:'custom', info:'<h2>Caesar Cipher</h2><p>A classic substitution cipher that shifts each letter by a fixed number of places in the alphabet.</p>'},
{id:'morse-code', name:'Morse Code Translator', cat:'Text Tools', ab:'Mc', desc:'Convert text to Morse code and back', kind:'custom', info:'<h2>Morse Code Translator</h2><p>Translate plain text to Morse code, or decode Morse code (dots, dashes, spaces) back to text.</p>'},
{id:'binary-text', name:'Text to Binary Converter', cat:'Text Tools', ab:'Bt', desc:'Convert text to binary and back', kind:'text',
  transforms:[
    {label:'Text to Binary', run:s=>s.split('').map(c=>c.charCodeAt(0).toString(2).padStart(8,'0')).join(' ')},
    {label:'Binary to Text', run:s=>s.trim().split(/\s+/).map(b=>String.fromCharCode(parseInt(b,2))).join('')},
  ], mono:true, info:'<h2>Text to Binary Converter</h2><p>Converts each character to its 8-bit binary (ASCII/UTF-16 code unit) representation, and back.</p>'},
{id:'nato-phonetic', name:'NATO Phonetic Alphabet', cat:'Text Tools', ab:'Np', desc:'Spell out text using the NATO alphabet', kind:'text',
  transforms:[{label:'Convert', run:s=>s.toUpperCase().split('').map(c=>NATO[c]||(c===' '?'/':c)).join(' ')}], single:true,
  info:'<h2>NATO Phonetic Alphabet</h2><p>Spells out each letter using the NATO phonetic alphabet (Alpha, Bravo, Charlie…) used by pilots, radio operators and the military.</p>'},
{id:'leetspeak', name:'Leetspeak Converter', cat:'Text Tools', ab:'1337', desc:'Convert text to 1337 speak', kind:'text',
  transforms:[{label:'Convert', run:s=>s.replace(/[aeiostlbgAEIOSTLBG]/g,c=>({a:'4',e:'3',i:'1',o:'0',s:'5',t:'7',l:'1',b:'8',g:'9',A:'4',E:'3',I:'1',O:'0',S:'5',T:'7',L:'1',B:'8',G:'9'}[c]))}],
  single:true, info:'<h2>Leetspeak Converter</h2><p>Replaces letters with lookalike numbers (A=4, E=3, I=1 …) for the classic "1337" internet style.</p>'},
{id:'palindrome-checker', name:'Palindrome Checker', cat:'Text Tools', ab:'Pc', desc:'Check if text reads the same backwards', kind:'calc',
  fields:[{id:'t',label:'Text',type:'text',value:'',placeholder:'e.g. A man a plan a canal Panama'}],
  compute:v=>{const clean=(v.t||'').toLowerCase().replace(/[^a-z0-9]/g,'');const rev=clean.split('').reverse().join('');const is=clean.length>0 && clean===rev;
    return `<div class="alert ${is?'alert-ok':'alert-err'}">${is?'Yes, this is a palindrome.':'Not a palindrome.'}</div>${clean?`<div class="res-box">Cleaned: ${clean}</div>`:''}`;},
  info:'<h2>Palindrome Checker</h2><p>Checks whether text reads the same forwards and backwards, ignoring spaces, punctuation and capitalisation.</p>'},
{id:'anagram-checker', name:'Anagram Checker', cat:'Text Tools', ab:'Ac', desc:'Check if two words are anagrams', kind:'compare', compareMode:'anagram', info:'<h2>Anagram Checker</h2><p>Checks whether two words or phrases are anagrams of each other (contain exactly the same letters).</p>'},
{id:'acronym-generator', name:'Acronym Generator', cat:'Text Tools', ab:'Ag', desc:'Generate an acronym from a phrase', kind:'calc',
  fields:[{id:'t',label:'Phrase',type:'text',value:'',placeholder:'e.g. As Soon As Possible'}],
  compute:v=>{const words=(v.t||'').trim().split(/\s+/).filter(Boolean);const ac=words.map(w=>w[0]?.toUpperCase()||'').join('');return `<div class="res-box">${ac||'-'}</div>`;},
  info:'<h2>Acronym Generator</h2><p>Builds an acronym from the first letter of each word in a phrase.</p>'},
{id:'string-length', name:'String Length Checker', cat:'Text Tools', ab:'Sl2', desc:'Check string length against social limits', kind:'text',
  transforms:[{label:'Check', run:t=>t}], extra:'strlen', info:'<h2>String Length Checker</h2><p>Shows character count against common limits: Twitter/X (280), SMS (160), meta description (160), title tag (60).</p>'},
{id:'syllable-counter', name:'Syllable Counter', cat:'Text Tools', ab:'Sy', desc:'Estimate syllables in text', kind:'text', transforms:[{label:'Count', run:t=>t}], extra:'syllable',
  info:'<h2>Syllable Counter</h2><p>Estimates the number of syllables per word using a vowel-group heuristic - handy for poetry, haiku, and readability checks.</p>'},

// ---------------- CALCULATOR TOOLS ----------------
{id:'age-calculator', name:'Age Calculator', cat:'Calculator Tools', ab:'Ag', desc:'Calculate exact age from birthdate', badge:'pop', kind:'dedicated'},
{id:'percentage-calculator', name:'Percentage Calculator', cat:'Calculator Tools', ab:'Pc', desc:'Calculate percentages easily', badge:'pop', kind:'custom', info:'<h2>Percentage Calculator</h2><p>Three common percentage calculations in one tool: find X% of Y, find what percentage X is of Y, and find the percentage change between two values.</p>'},
{id:'emi-calculator', name:'EMI Calculator', cat:'Calculator Tools', ab:'Em', desc:'Calculate monthly loan EMI', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:500000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:9,step:0.1},{id:'n',label:'Tenure (months)',type:'number',value:60}],
  compute:v=>{const P=+v.p,annR=+v.r,N=+v.n;if(!P||!N) return '';const r=annR/12/100;const emi=r===0?P/N:P*r*Math.pow(1+r,N)/(Math.pow(1+r,N)-1);const total=emi*N;const interest=total-P;
    return statBlock([['Monthly EMI',fmtMoney(emi)],['Total Interest',fmtMoney(interest)],['Total Payment',fmtMoney(total)]]);},
  info:'<h2>EMI Calculator</h2><p>Calculates your Equated Monthly Installment for a loan given the principal, annual interest rate, and tenure in months.</p><p><strong>Formula:</strong> EMI = P × r × (1+r)ⁿ ÷ ((1+r)ⁿ − 1)</p>'},
{id:'loan-calculator', name:'Loan Calculator', cat:'Calculator Tools', ab:'Ln', desc:'Calculate total loan repayments', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:200000},{id:'r',label:'Annual Rate (%)',type:'number',value:7.5,step:0.1},{id:'y',label:'Term (years)',type:'number',value:15}],
  compute:v=>{const P=+v.p,annR=+v.r,N=(+v.y)*12;if(!P||!N) return '';const r=annR/12/100;const emi=r===0?P/N:P*r*Math.pow(1+r,N)/(Math.pow(1+r,N)-1);const total=emi*N;
    return statBlock([['Monthly Payment',fmtMoney(emi)],['Total Interest',fmtMoney(total-P)],['Total Repaid',fmtMoney(total)]]);},
  info:'<h2>Loan Calculator</h2><p>Estimates monthly payment, total interest and total repayment for a fixed-rate loan.</p>'},
{id:'gst-calculator', name:'GST Calculator', cat:'Calculator Tools', ab:'Gs', desc:'Add or remove GST from any amount', kind:'calc',
  fields:[{id:'amt',label:'Amount',type:'number',value:1000},{id:'rate',label:'GST Rate (%)',type:'select',options:[['5','5%'],['12','12%'],['18','18%'],['28','28%']]},{id:'mode',label:'Mode',type:'select',options:[['add','Add GST'],['remove','Remove GST']]}],
  compute:v=>{const amt=+v.amt,rate=+v.rate;if(!amt)return'';let base,gst,total;
    if(v.mode==='add'){base=amt;gst=amt*rate/100;total=base+gst;} else {total=amt;base=amt/(1+rate/100);gst=total-base;}
    return statBlock([['Base Amount',fmtMoney(base)],['GST ('+rate+'%)',fmtMoney(gst)],['Total Amount',fmtMoney(total)]]);},
  info:'<h2>GST Calculator</h2><p>Add GST to a base price, or work backward to find the base price and GST portion of a GST-inclusive amount.</p>'},
{id:'discount-calculator', name:'Discount Calculator', cat:'Calculator Tools', ab:'Dc', desc:'Calculate discount and final price', kind:'calc',
  fields:[{id:'price',label:'Original Price',type:'number',value:1000},{id:'pct',label:'Discount (%)',type:'number',value:20}],
  compute:v=>{const p=+v.price,d=+v.pct;if(!p)return'';const saved=p*d/100;const final=p-saved;
    return statBlock([['You Save',fmtMoney(saved)],['Final Price',fmtMoney(final)],['Discount',d+'%']]);},
  info:'<h2>Discount Calculator</h2><p>Enter the original price and discount percentage to see the savings and final price.</p>'},
{id:'bmi-calculator', name:'BMI Calculator', cat:'Calculator Tools', ab:'Bm', desc:'Calculate Body Mass Index (BMI)', badge:'pop', kind:'dedicated'},
{id:'scientific-calculator', name:'Scientific Calculator', cat:'Calculator Tools', ab:'Sc', desc:'Full scientific calculator', kind:'custom', info:'<h2>Scientific Calculator</h2><p>A keyboard-friendly calculator supporting standard arithmetic plus trigonometric, logarithmic and power functions.</p>'},
{id:'simple-interest', name:'Simple Interest Calculator', cat:'Calculator Tools', ab:'Si', desc:'Calculate simple interest on loans', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:10000},{id:'r',label:'Annual Rate (%)',type:'number',value:6,step:0.1},{id:'t',label:'Time (years)',type:'number',value:3,step:0.1}],
  compute:v=>{const P=+v.p,R=+v.r,T=+v.t;if(!P)return'';const si=P*R*T/100;return statBlock([['Interest',fmtMoney(si)],['Total Amount',fmtMoney(P+si)]]);},
  info:'<h2>Simple Interest Calculator</h2><p><strong>Formula:</strong> SI = (P × R × T) ÷ 100</p>'},
{id:'compound-interest', name:'Compound Interest Calculator', cat:'Calculator Tools', ab:'Ci', desc:'Calculate compound interest', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:10000},{id:'r',label:'Annual Rate (%)',type:'number',value:6,step:0.1},{id:'t',label:'Time (years)',type:'number',value:5,step:0.1},{id:'n',label:'Compounds/year',type:'select',options:[['1','Annually'],['2','Semi-annually'],['4','Quarterly'],['12','Monthly'],['365','Daily']]}],
  compute:v=>{const P=+v.p,R=+v.r/100,T=+v.t,n=+v.n;if(!P)return'';const A=P*Math.pow(1+R/n,n*T);return statBlock([['Final Amount',fmtMoney(A)],['Interest Earned',fmtMoney(A-P)]]);},
  info:'<h2>Compound Interest Calculator</h2><p><strong>Formula:</strong> A = P(1 + r/n)^(nt)</p>'},
{id:'tip-calculator', name:'Tip Calculator', cat:'Calculator Tools', ab:'Tp', desc:'Calculate restaurant tips easily', kind:'calc',
  fields:[{id:'bill',label:'Bill Amount',type:'number',value:50},{id:'pct',label:'Tip %',type:'number',value:15},{id:'people',label:'Split Between',type:'number',value:1,min:1}],
  compute:v=>{const b=+v.bill,p=+v.pct,people=Math.max(1,+v.people||1);if(!b)return'';const tip=b*p/100;const total=b+tip;
    return statBlock([['Tip',fmtMoney(tip)],['Total',fmtMoney(total)],['Per Person',fmtMoney(total/people)]]);},
  info:'<h2>Tip Calculator</h2><p>Calculates tip amount, total bill, and amount per person when splitting.</p>'},
{id:'fuel-cost', name:'Fuel Cost Calculator', cat:'Calculator Tools', ab:'Fc', desc:'Calculate trip fuel costs', kind:'calc',
  fields:[{id:'dist',label:'Distance (km)',type:'number',value:300},{id:'eff',label:'Efficiency (km per liter)',type:'number',value:15},{id:'price',label:'Fuel Price per liter',type:'number',value:100}],
  compute:v=>{const d=+v.dist,e=+v.eff,p=+v.price;if(!d||!e)return'';const liters=d/e;return statBlock([['Fuel Needed',liters.toFixed(2)+' L'],['Total Cost',fmtMoney(liters*p)]]);},
  info:'<h2>Fuel Cost Calculator</h2><p>Estimates fuel needed and total cost for a trip based on distance and fuel efficiency.</p>'},
{id:'cgpa-calculator', name:'CGPA / GPA Calculator', cat:'Calculator Tools', ab:'Gp', desc:'Calculate GPA from grades and credits', kind:'custom', info:'<h2>CGPA / GPA Calculator</h2><p>Add each course\'s grade point and credit hours to calculate your weighted GPA.</p>'},
{id:'mean-median-mode-calculator', name:'Mean, Median & Mode Calculator', cat:'Calculator Tools', ab:'Av', desc:'Calculate mean, median, mode and standard deviation', kind:'calc',
  fields:[{id:'nums',label:'Numbers (comma or space separated)',type:'text',value:'4, 8, 6, 5, 3, 8, 9'}],
  compute:v=>{const nums=parseNums(v.nums);if(!nums.length)return'';const mean=nums.reduce((a,b)=>a+b,0)/nums.length;
    const sorted=[...nums].sort((a,b)=>a-b);const mid=Math.floor(sorted.length/2);const median=sorted.length%2?sorted[mid]:(sorted[mid-1]+sorted[mid])/2;
    const freq={};nums.forEach(n=>freq[n]=(freq[n]||0)+1);const maxF=Math.max(...Object.values(freq));const modes=Object.keys(freq).filter(k=>freq[k]===maxF);
    const variance=nums.reduce((a,b)=>a+(b-mean)**2,0)/nums.length;const stdev=Math.sqrt(variance);
    return statBlock([['Mean',round4(mean)],['Median',round4(median)],['Mode',maxF>1?modes.join(', '):'No mode'],['Std Deviation',round4(stdev)],['Range',round4(Math.max(...nums)-Math.min(...nums))],['Count',nums.length]]);},
  info:'<h2>Mean, Median &amp; Mode Calculator</h2><p>Computes mean, median, mode, standard deviation and range for a list of numbers.</p>'},
{id:'hourly-to-annual-salary', name:'Hourly to Annual Salary Calculator', cat:'Calculator Tools', ab:'Sa', desc:'Convert hourly, weekly, monthly and annual pay', kind:'calc',
  fields:[{id:'rate',label:'Hourly Rate',type:'number',value:25},{id:'hours',label:'Hours per week',type:'number',value:40}],
  compute:v=>{const r=+v.rate,h=+v.hours;if(!r||!h)return'';return statBlock([['Daily (8h)',fmtMoney(r*8)],['Weekly',fmtMoney(r*h)],['Monthly',fmtMoney(r*h*52/12)],['Annual',fmtMoney(r*h*52)]]);},
  info:'<h2>Hourly to Annual Salary Calculator</h2><p>Converts an hourly wage into daily, weekly, monthly and annual pay (52-week year).</p>'},
{id:'savings-goal', name:'Savings Goal Calculator', cat:'Calculator Tools', ab:'Sg', desc:'Find how much to save monthly for a goal', kind:'calc',
  fields:[{id:'goal',label:'Target Amount',type:'number',value:10000},{id:'have',label:'Already Saved',type:'number',value:1000},{id:'months',label:'Months to Save',type:'number',value:12}],
  compute:v=>{const goal=+v.goal,have=+v.have||0,m=+v.months;if(!goal||!m)return'';const need=Math.max(0,goal-have);
    return statBlock([['Remaining to Save',fmtMoney(need)],['Save per Month',fmtMoney(need/m)]]);},
  info:'<h2>Savings Goal Calculator</h2><p>Works out how much you need to set aside each month to reach a savings target by a given date.</p>'},
{id:'markup-calculator', name:'Markup & Margin Calculator', cat:'Calculator Tools', ab:'Mk', desc:'Calculate markup percentage and profit margin', kind:'calc',
  fields:[{id:'cost',label:'Cost Price',type:'number',value:50},{id:'sell',label:'Selling Price',type:'number',value:80}],
  compute:v=>{const c=+v.cost,s=+v.sell;if(!c||!s)return'';const profit=s-c;const markup=(profit/c)*100;const margin=(profit/s)*100;
    return statBlock([['Profit',fmtMoney(profit)],['Markup',round4(markup)+'%'],['Margin',round4(margin)+'%']]);},
  info:'<h2>Markup &amp; Margin Calculator</h2><p>Markup is profit as a percentage of cost; margin is profit as a percentage of the selling price. The two are often confused.</p>'},
{id:'break-even', name:'Break-Even Point Calculator', cat:'Calculator Tools', ab:'Be', desc:'Find your break-even sales volume', kind:'calc',
  fields:[{id:'fixed',label:'Fixed Costs',type:'number',value:5000},{id:'price',label:'Price per Unit',type:'number',value:25},{id:'cost',label:'Variable Cost per Unit',type:'number',value:10}],
  compute:v=>{const f=+v.fixed,p=+v.price,c=+v.cost;if(p<=c)return '<div class="alert alert-warn">Price must be higher than variable cost per unit.</div>';
    const units=f/(p-c);return statBlock([['Break-even Units',Math.ceil(units).toLocaleString()],['Break-even Revenue',fmtMoney(units*p)]]);},
  info:'<h2>Break-Even Point Calculator</h2><p>Finds the number of units you need to sell to cover your fixed costs.</p>'},
{id:'vat-calculator', name:'VAT Calculator', cat:'Calculator Tools', ab:'Vt', desc:'Add or remove VAT from a price', kind:'calc',
  fields:[{id:'amt',label:'Amount',type:'number',value:100},{id:'rate',label:'VAT Rate (%)',type:'number',value:20},{id:'mode',label:'Mode',type:'select',options:[['add','Add VAT'],['remove','Remove VAT']]}],
  compute:v=>{const amt=+v.amt,rate=+v.rate;if(!amt)return'';let base,vat,total;
    if(v.mode==='add'){base=amt;vat=amt*rate/100;total=base+vat;} else {total=amt;base=amt/(1+rate/100);vat=total-base;}
    return statBlock([['Net Amount',fmtMoney(base)],['VAT',fmtMoney(vat)],['Gross Amount',fmtMoney(total)]]);},
  info:'<h2>VAT Calculator</h2><p>Add VAT to a net price, or extract the VAT portion from a VAT-inclusive price.</p>'},
{id:'currency-converter', name:'Currency Converter', cat:'Calculator Tools', ab:'Cu', desc:'Convert between world currencies', kind:'custom', info:'<h2>Currency Converter</h2><p>Converts between major world currencies using indicative reference rates bundled in this page. For live, up-to-the-minute rates before a real transaction, check your bank or a live FX source.</p>'},
{id:'ratio-simplifier', name:'Ratio Simplifier', cat:'Calculator Tools', ab:'Rt', desc:'Simplify a ratio to its lowest terms', kind:'calc',
  fields:[{id:'a',label:'A',type:'number',value:12},{id:'b',label:'B',type:'number',value:18}],
  compute:v=>{const a=Math.round(+v.a),b=Math.round(+v.b);if(!a||!b)return'';const g=gcd(Math.abs(a),Math.abs(b));return statBlock([['Simplified Ratio',`${a/g} : ${b/g}`],['Decimal',round4(a/b)]]);},
  info:'<h2>Ratio Simplifier</h2><p>Reduces any ratio A:B to its simplest whole-number form.</p>'},

// ---------------- IMAGE TOOLS ----------------
{id:'image-resizer', name:'Image Resizer', cat:'Image Tools', ab:'Ir', desc:'Resize images to any dimension', badge:'pop', kind:'custom', info:'<h2>Image Resizer</h2><p>Resize any image to exact pixel dimensions or by percentage, right in your browser - nothing is uploaded anywhere.</p>'},
{id:'image-compressor', name:'Image Compressor', cat:'Image Tools', ab:'Ic', desc:'Compress images without a big quality loss', kind:'custom', info:'<h2>Image Compressor</h2><p>Re-encodes JPEG/WebP images at a chosen quality level to reduce file size, entirely in your browser.</p>'},
{id:'jpg-to-png', name:'JPG to PNG Converter', cat:'Image Tools', ab:'Jp', desc:'Convert JPG images to PNG format', kind:'custom', info:'<h2>JPG to PNG Converter</h2><p>Converts a JPG/JPEG image to PNG format locally in your browser.</p>'},
{id:'png-to-jpg', name:'PNG to JPG Converter', cat:'Image Tools', ab:'Pj', desc:'Convert PNG images to JPG format', kind:'custom', info:'<h2>PNG to JPG Converter</h2><p>Converts a PNG image to JPG format (flattened onto a white background), locally in your browser.</p>'},
{id:'image-crop', name:'Image Crop Tool', cat:'Image Tools', ab:'Cr', desc:'Crop images to custom dimensions', kind:'custom', info:'<h2>Image Crop Tool</h2><p>Drag to select a crop area on your image and export just that region.</p>'},
{id:'image-color-picker', name:'Image Color Picker', cat:'Image Tools', ab:'Cp', desc:'Pick colors from any image', kind:'custom', info:'<h2>Image Color Picker</h2><p>Click anywhere on an uploaded image to read off its exact HEX and RGB color value.</p>'},
{id:'image-to-base64', name:'Image to Base64', cat:'Image Tools', ab:'B6', desc:'Convert image to Base64 string', kind:'custom', info:'<h2>Image to Base64</h2><p>Converts an image file into a Base64-encoded data URI you can paste directly into HTML or CSS.</p>'},
{id:'base64-to-image', name:'Base64 to Image', cat:'Image Tools', ab:'B2i', desc:'Convert Base64 string back to image', kind:'custom', info:'<h2>Base64 to Image</h2><p>Paste a Base64 data URI (or raw Base64 string) and preview it as an image, with a download link.</p>'},
{id:'image-rotator', name:'Image Rotate & Flip', cat:'Image Tools', ab:'Rt2', desc:'Rotate or mirror an image', kind:'custom', info:'<h2>Image Rotate &amp; Flip</h2><p>Rotate an image in 90° steps, or flip it horizontally/vertically.</p>'},
{id:'favicon-generator', name:'Favicon Generator', cat:'Image Tools', ab:'Fv', desc:'Generate a favicon from any image', kind:'custom', info:'<h2>Favicon Generator</h2><p>Resizes an uploaded image down to the standard favicon sizes (16×16, 32×32, 48×48) for download.</p>'},

// ---------------- DEVELOPER TOOLS ----------------
{id:'json-formatter', name:'JSON Formatter', cat:'Developer Tools', ab:'{}', desc:'Format and validate JSON data', badge:'pop', kind:'dedicated'},
{id:'password-generator', name:'Password Generator', cat:'Developer Tools', ab:'Pw', desc:'Generate strong secure passwords', badge:'pop', kind:'dedicated'},
{id:'base64-encoder', name:'Base64 Encoder & Decoder', cat:'Developer Tools', ab:'B6', desc:'Encode text or data to Base64', kind:'text',
  transforms:[{label:'Encode', run:s=>btoa(unescape(encodeURIComponent(s)))},{label:'Decode', run:s=>decodeURIComponent(escape(atob(s)))}],
  mono:true, info:'<h2>Base64 Encoder &amp; Decoder</h2><p>Base64 encodes binary data as ASCII text, commonly used for embedding data in HTML/CSS/JSON or transmitting it over text-safe protocols.</p>'},
{id:'url-encoder', name:'URL Encoder & Decoder', cat:'Developer Tools', ab:'Ur', desc:'Encode URLs for safe transmission', kind:'text',
  transforms:[{label:'Encode', run:s=>encodeURIComponent(s)},{label:'Decode', run:s=>decodeURIComponent(s)}],
  mono:true, info:'<h2>URL Encoder &amp; Decoder</h2><p>Percent-encodes special characters for safe use in URLs, or decodes an encoded URL back to readable text.</p>'},
{id:'uuid-generator', name:'UUID Generator', cat:'Developer Tools', ab:'Id', desc:'Generate unique UUIDs (v4)', kind:'calc',
  fields:[{id:'n',label:'How many',type:'number',value:5,min:1,max:100},{id:'case',label:'Case',type:'select',options:[['lower','lowercase'],['upper','UPPERCASE']]}],
  compute:v=>{const n=Math.min(100,Math.max(1,parseInt(v.n)||1));const out=[];for(let i=0;i<n;i++){let u=crypto.randomUUID();if(v.case==='upper')u=u.toUpperCase();out.push(u);}
    return `<div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('uuidOut').value,this)">Copy All</button></label><textarea class="fc mono" id="uuidOut" rows="${Math.min(12,n)}" readonly>${out.join('\n')}</textarea></div>`;},
  info:'<h2>UUID Generator</h2><p>Generates cryptographically random version-4 UUIDs using your browser\'s secure random number generator.</p>'},
{id:'md5-hash', name:'MD5 Hash Generator', cat:'Developer Tools', ab:'M5', desc:'Generate MD5 hash of any text', kind:'text',
  transforms:[{label:'Generate MD5', run:s=>SparkMD5.hash(s)}], single:true, mono:true, info:'<h2>MD5 Hash Generator</h2><p>Computes the MD5 hash of your text. MD5 is fast but cryptographically broken - do not use it for passwords or security-sensitive hashing. Use SHA-256 or better instead.</p>'},
{id:'hash-generator', name:'Hash Generator (SHA-1/256/384/512)', cat:'Developer Tools', ab:'Hg', desc:'Generate MD5, SHA1, SHA256 hashes', badge:'pop', kind:'custom', info:'<h2>Hash Generator</h2><p>Generates MD5, SHA-1, SHA-256, SHA-384 and SHA-512 hashes of your text using your browser\'s built-in Web Crypto engine.</p>'},
{id:'regex-tester', name:'Regex Tester', cat:'Developer Tools', ab:'Re', desc:'Test and debug regex patterns', kind:'custom', info:'<h2>Regex Tester</h2><p>Test a regular expression against sample text and see every match highlighted, with capture groups listed.</p>'},
{id:'color-converter', name:'Color Converter', cat:'Developer Tools', ab:'Co', desc:'Convert HEX, RGB, HSL colors', kind:'custom', info:'<h2>Color Converter</h2><p>Convert a color between HEX, RGB and HSL formats, with a live swatch preview.</p>'},
{id:'jwt-decoder', name:'JWT Decoder', cat:'Developer Tools', ab:'Jw', desc:'Decode and inspect JWT tokens', kind:'custom', info:'<h2>JWT Decoder</h2><p>Decodes a JSON Web Token\'s header and payload locally in your browser. This does not verify the signature - never paste a token from a system you don\'t trust into any website.</p>'},
{id:'markdown-html', name:'Markdown to HTML', cat:'Developer Tools', ab:'Md', desc:'Convert Markdown to HTML', kind:'custom', info:'<h2>Markdown to HTML</h2><p>Converts Markdown syntax (headings, bold, lists, links, code) into HTML markup.</p>'},
{id:'csv-json', name:'CSV to JSON Converter', cat:'Developer Tools', ab:'Cj', desc:'Convert CSV data to JSON', kind:'text',
  transforms:[{label:'CSV to JSON', run:s=>{const rows=parseCSV(s);if(!rows.length)return'';const [h,...body]=rows;return JSON.stringify(body.map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]??'']))),null,2);}},
  {label:'JSON to CSV', run:s=>{let data;try{data=JSON.parse(s);}catch(e){return 'Invalid JSON: '+e.message;}if(!Array.isArray(data)||!data.length)return 'Provide a JSON array of objects.';
    const headers=[...new Set(data.flatMap(o=>Object.keys(o)))];const esc=v=>{v=String(v??'');return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;};
    return [headers.join(','),...data.map(o=>headers.map(h=>esc(o[h])).join(','))].join('\n');}}],
  mono:true, info:'<h2>CSV and JSON Converter</h2><p>Converts CSV data (with a header row) to a JSON array of objects, or back from JSON to CSV.</p>'},
{id:'html-formatter', name:'HTML Formatter', cat:'Developer Tools', ab:'Hf', desc:'Format and indent HTML code', kind:'text', transforms:[{label:'Format', run:s=>formatHTML(s)}], single:true, mono:true,
  info:'<h2>HTML Formatter</h2><p>Adds consistent indentation to minified or messy HTML markup.</p>'},
{id:'css-minifier', name:'CSS Minifier', cat:'Developer Tools', ab:'Cm', desc:'Minify CSS by removing whitespace', kind:'text',
  transforms:[{label:'Minify', run:s=>s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{}:;,])\s*/g,'$1').replace(/;}/g,'}').trim()}],
  single:true, mono:true, info:'<h2>CSS Minifier</h2><p>Strips comments and unnecessary whitespace from CSS to reduce file size.</p>'},
{id:'js-minifier', name:'JS Whitespace Minifier', cat:'Developer Tools', ab:'Jm', desc:'Strip comments and extra whitespace from JS', kind:'text',
  transforms:[{label:'Minify', run:s=>s.replace(/\/\/.*$/gm,'').replace(/\/\*[\s\S]*?\*\//g,'').split('\n').map(l=>l.trim()).filter(Boolean).join('\n')}],
  single:true, mono:true, info:'<h2>JS Whitespace Minifier</h2><p>Removes comments, blank lines and leading whitespace from JavaScript. For production use, a proper minifier (e.g. Terser) is recommended for variable renaming and dead-code removal.</p>'},
{id:'cron-explainer', name:'Cron Expression Explainer', cat:'Developer Tools', ab:'Cx', desc:'Explain what a cron expression means', kind:'calc',
  fields:[{id:'c',label:'Cron Expression',type:'text',value:'*/15 9-17 * * 1-5'}],
  compute:v=>{try{return `<div class="res-box ok">${explainCron(v.c)}</div>`;}catch(e){return `<div class="res-box er">${e.message}</div>`;}},
  info:'<h2>Cron Expression Explainer</h2><p>Explains a standard 5-field cron expression (minute, hour, day-of-month, month, day-of-week) in plain English.</p>'},
{id:'number-base', name:'Number Base Converter', cat:'Developer Tools', ab:'Nb', desc:'Convert binary, decimal, hex, octal', kind:'base', info:'<h2>Number Base Converter</h2><p>Converts a number between binary, octal, decimal and hexadecimal.</p>'},
{id:'timestamp-converter', name:'Unix Timestamp Converter', cat:'Date & Time Tools', ab:'Ux', desc:'Convert Unix timestamps to dates', kind:'custom', info:'<h2>Unix Timestamp Converter</h2><p>Converts a Unix timestamp (seconds or milliseconds) to a readable date, or a date to its timestamp.</p>'},
{id:'json-validator', name:'JSON Validator', cat:'Developer Tools', ab:'Jv', desc:'Validate JSON and view structure stats', kind:'text', transforms:[{label:'Validate', run:t=>t}], extra:'jsonvalidate',
  info:'<h2>JSON Validator</h2><p>Validates JSON syntax and reports key count, nesting depth and value types.</p>'},
{id:'xml-formatter', name:'XML Formatter', cat:'Developer Tools', ab:'Xm', desc:'Format and indent XML', kind:'text', transforms:[{label:'Format', run:s=>formatHTML(s)}], single:true, mono:true,
  info:'<h2>XML Formatter</h2><p>Adds consistent indentation to XML markup.</p>'},

// ---------------- UNIT CONVERTERS ----------------
{id:'length-converter', name:'Length Converter', cat:'Unit Converters', ab:'Ln', desc:'Convert meters, feet, inches, miles', kind:'convert', table:'U_LENGTH', def:{amt:1,from:'m',to:'ft'}},
{id:'weight-converter', name:'Weight Converter', cat:'Unit Converters', ab:'Wt', desc:'Convert kg, lbs, grams, ounces', badge:'pop', kind:'convert', table:'U_WEIGHT', def:{amt:1,from:'kg',to:'lb'}},
{id:'temperature-converter', name:'Temperature Converter', cat:'Unit Converters', ab:'Tm', desc:'Convert Celsius, Fahrenheit, Kelvin', badge:'pop', kind:'custom', info:'<h2>Temperature Converter</h2><p>Converts between Celsius, Fahrenheit and Kelvin.</p>'},
{id:'speed-converter', name:'Speed Converter', cat:'Unit Converters', ab:'Sp', desc:'Convert km/h, mph, m/s, knots', kind:'convert', table:'U_SPEED', def:{amt:1,from:'kmh',to:'mph'}},
{id:'area-converter', name:'Area Converter', cat:'Unit Converters', ab:'Ar', desc:'Convert sq meters, acres, sq feet', kind:'convert', table:'U_AREA', def:{amt:1,from:'m2',to:'ft2'}},
{id:'volume-converter', name:'Volume Converter', cat:'Unit Converters', ab:'Vl', desc:'Convert liters, gallons, cups', kind:'convert', table:'U_VOLUME', def:{amt:1,from:'l',to:'gal'}},
{id:'time-unit-converter', name:'Time Unit Converter', cat:'Unit Converters', ab:'Tc2', desc:'Convert seconds, minutes, hours, days', kind:'convert', table:'U_TIME', def:{amt:1,from:'h',to:'min'}},
{id:'data-storage-converter', name:'Data Storage Converter', cat:'Unit Converters', ab:'Db', desc:'Convert bytes, KB, MB, GB, TB', kind:'convert', table:'U_DATA', def:{amt:1,from:'gb',to:'mb'}},
{id:'energy-converter', name:'Energy Converter', cat:'Unit Converters', ab:'En', desc:'Convert joules, calories, kWh', kind:'convert', table:'U_ENERGY', def:{amt:1,from:'kcal',to:'kj'}},
{id:'pressure-converter', name:'Pressure Converter', cat:'Unit Converters', ab:'Pr', desc:'Convert Pa, bar, psi, atm', kind:'convert', table:'U_PRESSURE', def:{amt:1,from:'bar',to:'psi'}},
{id:'power-converter', name:'Power Converter', cat:'Unit Converters', ab:'Pw2', desc:'Convert watts, kilowatts, horsepower', kind:'convert', table:'U_POWER', def:{amt:1,from:'hp',to:'w'}},
{id:'force-converter', name:'Force Converter', cat:'Unit Converters', ab:'Fo', desc:'Convert newtons, pound-force, kgf', kind:'convert', table:'U_FORCE', def:{amt:1,from:'n',to:'lbf'}},
{id:'angle-converter', name:'Angle Converter', cat:'Unit Converters', ab:'Ag2', desc:'Convert degrees, radians, gradians', kind:'convert', table:'U_ANGLE', def:{amt:180,from:'deg',to:'rad'}},
{id:'frequency-converter', name:'Frequency Converter', cat:'Unit Converters', ab:'Fr2', desc:'Convert Hz, kHz, MHz, GHz', kind:'convert', table:'U_FREQ', def:{amt:1,from:'ghz',to:'mhz'}},
{id:'fuel-economy', name:'Fuel Economy Converter', cat:'Unit Converters', ab:'Fe', desc:'Convert MPG, L/100km, km/L', kind:'custom', info:'<h2>Fuel Economy Converter</h2><p>Converts between miles per gallon (US/UK) and liters per 100km / kilometers per liter.</p>'},
{id:'shoe-size', name:'Shoe Size Converter', cat:'Unit Converters', ab:'Sh', desc:'Convert shoe sizes between regions', kind:'custom', info:'<h2>Shoe Size Converter</h2><p>Converts shoe sizes between US, UK and EU sizing systems (approximate - brands vary).</p>'},
{id:'cooking-converter', name:'Cooking Measurement Converter', cat:'Unit Converters', ab:'Ck', desc:'Convert cups, tablespoons, grams', kind:'convert', table:'U_VOLUME', def:{amt:1,from:'cup',to:'ml'}},

// ---------------- DATE & TIME TOOLS ----------------
{id:'date-difference', name:'Date Difference Calculator', cat:'Date & Time Tools', ab:'Dd', desc:'Calculate days between two dates', badge:'pop', kind:'custom', info:'<h2>Date Difference Calculator</h2><p>Calculates the exact number of years, months and days between two dates.</p>'},
{id:'timezone-converter', name:'Time Zone Converter', cat:'Date & Time Tools', ab:'Tz', desc:'Convert times across time zones', kind:'custom', info:'<h2>Time Zone Converter</h2><p>Shows the current time across major time zones around the world, side by side.</p>'},
{id:'days-until', name:'Days Until Date', cat:'Date & Time Tools', ab:'Du', desc:'Count days until any event', kind:'calc',
  fields:[{id:'d',label:'Target Date',type:'date',value:''}],
  compute:v=>{if(!v.d)return'';const target=new Date(v.d+'T00:00:00');const today=new Date();today.setHours(0,0,0,0);const diff=Math.round((target-today)/86400000);
    return statBlock([[diff>=0?'Days Remaining':'Days Ago',Math.abs(diff)],['Weeks',round4(Math.abs(diff)/7)]]);},
  info:'<h2>Days Until Date</h2><p>Counts the number of days until (or since) any date.</p>'},
{id:'week-number', name:'Week Number Calculator', cat:'Date & Time Tools', ab:'Wn', desc:'Find week number of any date', kind:'calc',
  fields:[{id:'d',label:'Date',type:'date',value:new Date().toISOString().slice(0,10)}],
  compute:v=>{if(!v.d)return'';const d=new Date(v.d+'T00:00:00');return statBlock([['ISO Week',getISOWeek(d)],['Year',d.getFullYear()],['Day of Year',getDayOfYear(d)]]);},
  info:'<h2>Week Number Calculator</h2><p>Finds the ISO 8601 week number and day-of-year for any date.</p>'},
{id:'unix-timestamp', name:'Unix Timestamp Now', cat:'Date & Time Tools', ab:'Ut2', desc:'Current Unix timestamp, live', kind:'custom', info:'<h2>Unix Timestamp</h2><p>Shows the current Unix timestamp, updating live.</p>'},
{id:'date-formatter', name:'Date Formatter', cat:'Date & Time Tools', ab:'Df', desc:'Format dates in any format', kind:'calc',
  fields:[{id:'d',label:'Date',type:'date',value:new Date().toISOString().slice(0,10)}],
  compute:v=>{if(!v.d)return'';const d=new Date(v.d+'T00:00:00');const pad=n=>String(n).padStart(2,'0');
    const formats=[['DD/MM/YYYY',`${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()}`],
      ['MM/DD/YYYY',`${pad(d.getMonth()+1)}/${pad(d.getDate())}/${d.getFullYear()}`],
      ['YYYY-MM-DD',`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`],
      ['Long',d.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})],
      ['Short',d.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'})]];
    return formats.map(([l,v])=>`<div class="trow"><span>${l}</span><strong class="mono">${v}</strong></div>`).join('');},
  info:'<h2>Date Formatter</h2><p>Displays a date in multiple common formats at once.</p>'},
{id:'business-days', name:'Business Days Calculator', cat:'Date & Time Tools', ab:'Bd', desc:'Calculate working days between dates', kind:'calc',
  fields:[{id:'a',label:'Start Date',type:'date',value:''},{id:'b',label:'End Date',type:'date',value:''}],
  compute:v=>{if(!v.a||!v.b)return'';let start=new Date(v.a+'T00:00:00'),end=new Date(v.b+'T00:00:00');if(start>end)[start,end]=[end,start];
    let days=0;const cur=new Date(start);while(cur<=end){const dow=cur.getDay();if(dow!==0&&dow!==6)days++;cur.setDate(cur.getDate()+1);}
    return statBlock([['Business Days',days],['Weekend Days',Math.round((end-start)/86400000)+1-days]]);},
  info:'<h2>Business Days Calculator</h2><p>Counts working days (Monday-Friday) between two dates, excluding weekends.</p>'},
{id:'stopwatch', name:'Stopwatch', cat:'Date & Time Tools', ab:'Sw', desc:'Online stopwatch with lap timer', kind:'custom', info:'<h2>Stopwatch</h2><p>A simple stopwatch with lap timing, running entirely in your browser tab.</p>'},
{id:'countdown-timer', name:'Countdown Timer', cat:'Date & Time Tools', ab:'Ct', desc:'Set a countdown to any date and time', kind:'custom', info:'<h2>Countdown Timer</h2><p>Set a target date and time and watch a live countdown.</p>'},
{id:'pomodoro-timer', name:'Pomodoro Timer', cat:'Date & Time Tools', ab:'Po', desc:'Focus timer using the Pomodoro technique', kind:'custom', info:'<h2>Pomodoro Timer</h2><p>A 25-minute focus / 5-minute break timer based on the Pomodoro productivity technique.</p>'},
{id:'leap-year', name:'Leap Year Checker', cat:'Date & Time Tools', ab:'Ly', desc:'Check if a year is a leap year', kind:'calc',
  fields:[{id:'y',label:'Year',type:'number',value:new Date().getFullYear()}],
  compute:v=>{const y=parseInt(v.y);if(!y)return'';const isLeap=(y%4===0 && y%100!==0) || y%400===0;
    return `<div class="alert ${isLeap?'alert-ok':'alert-info'}">${y} is ${isLeap?'':'not '}a leap year.</div>`;},
  info:'<h2>Leap Year Checker</h2><p>A year is a leap year if divisible by 4, except century years, which must be divisible by 400.</p>'},
{id:'world-clock', name:'World Clock', cat:'Date & Time Tools', ab:'Wc2', desc:'See the current time in major cities', kind:'custom', info:'<h2>World Clock</h2><p>Shows the current local time in major cities around the world, updating live.</p>'},
{id:'age-in-days', name:'Age in Days Calculator', cat:'Date & Time Tools', ab:'Ad', desc:'Find your exact age in total days', kind:'calc',
  fields:[{id:'d',label:'Date of Birth',type:'date',value:''}],
  compute:v=>{if(!v.d)return'';const dob=new Date(v.d+'T00:00:00');const today=new Date();today.setHours(0,0,0,0);const days=Math.floor((today-dob)/86400000);
    return statBlock([['Total Days',days.toLocaleString()],['Total Weeks',Math.floor(days/7).toLocaleString()],['Total Hours',(days*24).toLocaleString()]]);},
  info:'<h2>Age in Days Calculator</h2><p>Converts your age into total days, weeks and hours lived.</p>'},

// ---------------- UTILITY TOOLS ----------------
{id:'qr-generator', name:'QR Code Generator', cat:'Utility Tools', ab:'Qr', desc:'Generate QR codes instantly', badge:'pop', kind:'custom', info:'<h2>QR Code Generator</h2><p>Generates QR codes for URLs, text, email, phone, SMS and Wi-Fi - rendered locally in your browser with no data sent anywhere.</p>'},
{id:'ip-lookup', name:'My IP Address', cat:'Utility Tools', ab:'Ip', desc:'Find your public IP address', kind:'custom', info:'<h2>My IP Address</h2><p>Shows your current public IP address. This is the one tool on this site that contacts an external service (a public IP-echo API) to do its job - see our Privacy Policy for details.</p>'},
{id:'random-number', name:'Random Number Generator', cat:'Utility Tools', ab:'Rn', desc:'Generate random numbers in a range', kind:'calc',
  fields:[{id:'min',label:'Min',type:'number',value:1},{id:'max',label:'Max',type:'number',value:100},{id:'n',label:'How many',type:'number',value:1,min:1,max:50},{id:'uniq',label:'No duplicates',type:'checkbox'}],
  compute:v=>{let min=Math.round(+v.min),max=Math.round(+v.max);if(min>max)[min,max]=[max,min];const n=Math.min(50,Math.max(1,parseInt(v.n)||1));
    const range=max-min+1;if(v.uniq && n>range) return '<div class="alert alert-warn">Range too small for that many unique numbers.</div>';
    let out=[];if(v.uniq){const pool=[];for(let i=min;i<=max;i++)pool.push(i);for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}out=pool.slice(0,n);}
    else{for(let i=0;i<n;i++)out.push(Math.floor(Math.random()*range)+min);}
    return `<div class="res-box ok" style="font-size:20px;font-weight:700">${out.join(', ')}</div>`;},
  info:'<h2>Random Number Generator</h2><p>Generates random whole numbers within a range, with an option to disallow duplicates.</p>'},
{id:'coin-flip', name:'Coin Flip', cat:'Utility Tools', ab:'Cf', desc:'Virtual coin flip tool', kind:'custom', info:'<h2>Coin Flip</h2><p>Flips a virtual coin using your browser\'s random number generator.</p>'},
{id:'dice-roller', name:'Dice Roller', cat:'Utility Tools', ab:'Dr', desc:'Roll virtual dice online', kind:'custom', info:'<h2>Dice Roller</h2><p>Roll 1 to 10 dice with any number of sides (d4, d6, d8, d10, d12, d20…).</p>'},
{id:'reading-time', name:'Reading Time Calculator', cat:'Utility Tools', ab:'Rt3', desc:'Estimate article reading time', kind:'calc',
  fields:[{id:'words',label:'Word Count',type:'number',value:1000},{id:'wpm',label:'Reading Speed (WPM)',type:'number',value:200}],
  compute:v=>{const w=+v.words,wpm=+v.wpm||200;if(!w)return'';const min=w/wpm;return statBlock([['Reading Time',min<1?Math.round(min*60)+' sec':round4(min)+' min']]);},
  info:'<h2>Reading Time Calculator</h2><p>Estimates how long an article takes to read based on word count and reading speed (average adult reads ~200-250 WPM).</p>'},
{id:'number-to-words', name:'Number to Words', cat:'Utility Tools', ab:'Nw', desc:'Convert numbers to English words', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:12345}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n))return'';return `<div class="res-box ok">${numberToWords(n)}</div>`;},
  info:'<h2>Number to Words</h2><p>Spells out any whole number (up to trillions) in English words.</p>'},
{id:'text-to-speech', name:'Text to Speech', cat:'Utility Tools', ab:'Tts', desc:'Convert text to audio speech', kind:'custom', info:'<h2>Text to Speech</h2><p>Reads your text aloud using your browser\'s built-in speech synthesis - no audio leaves your device.</p>'},
{id:'password-passphrase', name:'Passphrase Generator', cat:'Utility Tools', ab:'Pp', desc:'Generate a memorable word-based passphrase', kind:'custom', info:'<h2>Passphrase Generator</h2><p>Generates a random multi-word passphrase from a curated word list - often easier to remember and type than a random character password, while still offering strong entropy.</p>'},
{id:'random-color', name:'Random Color Generator', cat:'Utility Tools', ab:'Rc', desc:'Generate random colors with codes', kind:'custom', info:'<h2>Random Color Generator</h2><p>Generates random colors with HEX, RGB and HSL values shown.</p>'},
{id:'name-picker', name:'Random Name Picker', cat:'Utility Tools', ab:'Np2', desc:'Pick a random name from a list', kind:'calc',
  fields:[{id:'list',label:'Names (one per line)',type:'textarea',value:'Alex\nJordan\nTaylor\nMorgan\nCasey'}],
  compute:v=>{const names=(v.list||'').split('\n').map(s=>s.trim()).filter(Boolean);if(!names.length)return'';const pick=names[Math.floor(Math.random()*names.length)];
    return `<div class="res-box ok" style="font-size:22px;font-weight:700;text-align:center">${esc(pick)}</div>`;},
  info:'<h2>Random Name Picker</h2><p>Paste a list of names (one per line) and pick a random winner - for raffles, team assignments, or deciding who goes first.</p>'},
{id:'spin-wheel', name:'Spin the Wheel', cat:'Utility Tools', ab:'Sw2', desc:'Spin a wheel to pick a random option', kind:'custom', info:'<h2>Spin the Wheel</h2><p>Enter options and spin an animated wheel to pick one at random.</p>'},
{id:'bmr-calculator', name:'BMR Calculator', cat:'Utility Tools', ab:'Br', desc:'Estimate basal metabolic rate', kind:'custom', info:'<h2>BMR Calculator</h2><p>Estimates basal metabolic rate (calories burned at rest) using the Mifflin-St Jeor formula. This is a general estimate, not medical advice - consult a professional for personalised guidance.</p>'},
{id:'water-intake', name:'Water Intake Calculator', cat:'Utility Tools', ab:'Wi', desc:'Estimate daily water intake', kind:'calc',
  fields:[{id:'w',label:'Body Weight (kg)',type:'number',value:70},{id:'activity',label:'Activity Level',type:'select',options:[['low','Low (little exercise)'],['mod','Moderate (3-5x/week)'],['high','High (daily intense)']]}],
  compute:v=>{const w=+v.w;if(!w)return'';const mult=v.activity==='high'?45:v.activity==='mod'?38:33;const ml=w*mult;
    return statBlock([['Suggested Daily Intake',(ml/1000).toFixed(1)+' L'],['In Cups (250ml)',Math.round(ml/250)]])+'<div class="alert alert-info">General wellness estimate only - not medical advice.</div>';},
  info:'<h2>Water Intake Calculator</h2><p>Gives a general daily water-intake estimate based on body weight and activity level. This is a general wellness guide, not medical advice.</p>'},
{id:'pace-calculator', name:'Running Pace Calculator', cat:'Utility Tools', ab:'Pc2', desc:'Calculate running pace, time or distance', kind:'custom', info:'<h2>Running Pace Calculator</h2><p>Calculates pace per km/mile, total time, or distance - given any two of the three.</p>'},
{id:'simple-tax-estimator', name:'Simple Tax Estimator', cat:'Utility Tools', ab:'Tx2', desc:'Estimate tax using custom bracket rates', kind:'custom', info:'<h2>Simple Tax Estimator</h2><p>Estimates tax owed using progressive brackets you define yourself. For an indicative, educational estimate only - not tax advice.</p>'},
{id:'electricity-cost', name:'Electricity Cost Calculator', cat:'Utility Tools', ab:'El', desc:'Estimate appliance running cost', kind:'calc',
  fields:[{id:'watts',label:'Appliance Power (Watts)',type:'number',value:1500},{id:'hours',label:'Hours per day',type:'number',value:2},{id:'rate',label:'Rate per kWh',type:'number',value:8}],
  compute:v=>{const w=+v.watts,h=+v.hours,r=+v.rate;if(!w)return'';const kwhDay=(w*h)/1000;
    return statBlock([['kWh per Day',round4(kwhDay)],['Cost per Day',fmtMoney(kwhDay*r)],['Cost per Month',fmtMoney(kwhDay*r*30)]]);},
  info:'<h2>Electricity Cost Calculator</h2><p>Estimates the running cost of an appliance based on its wattage, daily usage hours, and your electricity rate.</p>'},

// ---------------- SEO TOOLS ----------------
{id:'meta-tag-generator', name:'Meta Tag Generator', cat:'SEO Tools', ab:'Mt2', desc:'Generate SEO meta tags for any page', badge:'pop', kind:'custom', info:'<h2>Meta Tag Generator</h2><p>Generates title, description, keyword, and Open Graph meta tags ready to paste into your page\'s <code>&lt;head&gt;</code>.</p>'},
{id:'keyword-density', name:'Keyword Density Checker', cat:'SEO Tools', ab:'Kd', desc:'Analyze keyword density in content', kind:'custom', info:'<h2>Keyword Density Checker</h2><p>Analyzes how often each word and phrase appears in your content, as a percentage of total words.</p>'},
{id:'open-graph-generator', name:'Open Graph Tag Generator', cat:'SEO Tools', ab:'Og', desc:'Generate Open Graph social tags', kind:'custom', info:'<h2>Open Graph Tag Generator</h2><p>Generates Open Graph meta tags that control how your page looks when shared on social media.</p>'},
{id:'robots-txt-generator', name:'Robots.txt Generator', cat:'SEO Tools', ab:'Rb', desc:'Generate a robots.txt file', kind:'custom', info:'<h2>Robots.txt Generator</h2><p>Generates a robots.txt file to control which crawlers can access which parts of your site.</p>'},
{id:'schema-generator', name:'Schema Markup Generator', cat:'SEO Tools', ab:'Sg2', desc:'Generate JSON-LD schema markup', badge:'new', kind:'custom', info:'<h2>Schema Markup Generator</h2><p>Generates JSON-LD structured data for Article, Product, or FAQ page types, ready to paste into your page.</p>'},
{id:'title-analyzer', name:'Title Tag Analyzer', cat:'SEO Tools', ab:'Ta', desc:'Analyze and optimize title tags', kind:'text', transforms:[{label:'Analyze', run:t=>t}], extra:'titleanalyze',
  info:'<h2>Title Tag Analyzer</h2><p>Checks your page title\'s character length against Google\'s typical display limit (~60 characters / ~580px) and shows a search-result preview.</p>'},
{id:'meta-description-checker', name:'Meta Description Analyzer', cat:'SEO Tools', ab:'Mda', desc:'Check meta description length', kind:'text', transforms:[{label:'Analyze', run:t=>t}], extra:'metadescanalyze',
  info:'<h2>Meta Description Analyzer</h2><p>Checks your meta description length against Google\'s typical display limit (~155-160 characters) and previews it as a search snippet.</p>'},
{id:'utm-builder', name:'UTM Link Builder', cat:'SEO Tools', ab:'Um', desc:'Build UTM parameter tracking URLs', badge:'new', kind:'custom', info:'<h2>UTM Link Builder</h2><p>Builds a campaign-tracking URL with UTM source, medium, campaign, term and content parameters for use in Google Analytics.</p>'},
{id:'sitemap-generator', name:'Sitemap Generator', cat:'SEO Tools', ab:'Sm', desc:'Generate XML sitemaps for your site', kind:'custom', info:'<h2>Sitemap Generator</h2><p>Paste a list of URLs (one per line) and generate a valid sitemap.xml file.</p>'},
{id:'url-structure-checker', name:'URL Structure Checker', cat:'SEO Tools', ab:'Us', desc:'Check a URL for common SEO issues', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'urlcheck',
  info:'<h2>URL Structure Checker</h2><p>Flags common SEO issues in a URL: length, uppercase letters, underscores, special characters, and stop words.</p>'},
{id:'alt-text-checker', name:'Image Alt Text Checker', cat:'SEO Tools', ab:'At', desc:'Find images missing alt text in HTML', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'alttext',
  info:'<h2>Image Alt Text Checker</h2><p>Paste HTML and find every <code>&lt;img&gt;</code> tag missing an <code>alt</code> attribute - important for accessibility and image SEO.</p>'},
{id:'content-length-checker', name:'Content Length Checker', cat:'SEO Tools', ab:'Cl2', desc:'Check content length against SEO benchmarks', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'seolength',
  info:'<h2>Content Length Checker</h2><p>Checks word count against common SEO content-length benchmarks for blog posts and landing pages.</p>'},

// ---------------- SECURITY TOOLS ----------------
{id:'password-strength', name:'Password Strength Checker', cat:'Security Tools', ab:'Ps', desc:'Check password strength score', badge:'pop', kind:'custom', info:'<h2>Password Strength Checker</h2><p>Scores a password on length and character variety, and flags common weak patterns.</p>'},
{id:'token-generator', name:'Random Token Generator', cat:'Security Tools', ab:'Tk', desc:'Generate secure random tokens', kind:'calc',
  fields:[{id:'len',label:'Length',type:'number',value:32,min:8,max:128},{id:'fmt',label:'Format',type:'select',options:[['hex','Hex'],['b64','Base64']]}],
  compute:v=>{const len=Math.min(128,Math.max(8,parseInt(v.len)||32));const bytes=new Uint8Array(len);crypto.getRandomValues(bytes);
    const tok=v.fmt==='b64'?btoa(String.fromCharCode(...bytes)).replace(/=/g,''):[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
    return `<div class="res-box ok mono">${tok}</div>`;},
  info:'<h2>Random Token Generator</h2><p>Generates a cryptographically secure random token using your browser\'s secure random number generator - suitable as an API key seed or session secret.</p>'},
{id:'htpasswd', name:'HTPASSWD Generator', cat:'Security Tools', ab:'Hp', desc:'Generate .htpasswd password hashes', kind:'custom', info:'<h2>HTPASSWD Generator</h2><p>Generates a bcrypt-style htpasswd line for Apache/Nginx basic auth.</p>'},
{id:'fake-data-generator', name:'Fake Data Generator', cat:'Security Tools', ab:'Fd', desc:'Generate fake test data (names, emails)', kind:'custom', info:'<h2>Fake Data Generator</h2><p>Generates clearly-fake sample data - names, emails, phone numbers - for filling test forms and demos. Not real personal information.</p>'},
{id:'credit-card-check', name:'Credit Card Number Validator', cat:'Security Tools', ab:'Cc2', desc:'Validate a card number with the Luhn check', kind:'calc',
  fields:[{id:'n',label:'Card Number',type:'text',value:'4111 1111 1111 1111'}],
  compute:v=>{const digits=(v.n||'').replace(/\D/g,'');if(!digits)return'';const valid=luhnCheck(digits);const brand=detectCardBrand(digits);
    return `<div class="alert ${valid?'alert-ok':'alert-err'}">${valid?'Passes the Luhn checksum':'Fails the Luhn checksum, not a valid card number'}</div>${brand?`<div class="res-box">Likely network: ${brand}</div>`:''}<div class="alert alert-info">This only checks number format, it does not verify a real account. Never paste a real card number into any website unless you trust it completely.</div>`;},
  info:'<h2>Credit Card Number Validator</h2><p>Checks whether a card number passes the Luhn checksum algorithm used by all major card networks. This does not verify that the card is real, active, or valid for payment - it is a format check only.</p>'},
{id:'password-entropy', name:'Password Entropy Calculator', cat:'Security Tools', ab:'Pe', desc:'Estimate password entropy in bits', kind:'calc',
  fields:[{id:'p',label:'Password',type:'text',value:''}],
  compute:v=>{const p=v.p||'';if(!p)return'';let pool=0;if(/[a-z]/.test(p))pool+=26;if(/[A-Z]/.test(p))pool+=26;if(/[0-9]/.test(p))pool+=10;if(/[^a-zA-Z0-9]/.test(p))pool+=33;
    const entropy=p.length*Math.log2(pool||1);const crackTime=Math.pow(2,entropy)/1e10;
    return statBlock([['Entropy',round4(entropy)+' bits'],['Character Pool',pool],['Est. offline crack time (10B guesses/sec)',fmtDuration(crackTime)]]);},
  info:'<h2>Password Entropy Calculator</h2><p>Estimates password entropy in bits based on length and character pool, and a rough brute-force time estimate against a fast offline attack.</p>'},

// ---------------- MATH TOOLS ----------------
{id:'square-root', name:'Square & Cube Root Calculator', cat:'Math Tools', ab:'Sq', desc:'Calculate square and cube roots', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:144}],
  compute:v=>{const n=+v.n;if(isNaN(n))return'';return statBlock([['Square Root',n<0?'undefined (negative)':round4(Math.sqrt(n))],['Cube Root',round4(Math.cbrt(n))],['Square',round4(n*n)],['Cube',round4(n*n*n)]]);},
  info:'<h2>Square &amp; Cube Root Calculator</h2><p>Calculates the square root, cube root, square and cube of any number.</p>'},
{id:'prime-checker', name:'Prime Number Checker', cat:'Math Tools', ab:'Pn', desc:'Check if a number is prime', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:97}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n)||n<2)return '<div class="alert alert-info">Enter a whole number greater than 1.</div>';
    let isPrime=true;for(let i=2;i*i<=n;i++){if(n%i===0){isPrime=false;break;}}
    return `<div class="alert ${isPrime?'alert-ok':'alert-err'}">${n} is ${isPrime?'':'not '}a prime number.</div>`;},
  info:'<h2>Prime Number Checker</h2><p>Checks whether a number has exactly two distinct factors (1 and itself).</p>'},
{id:'fibonacci', name:'Fibonacci Sequence Generator', cat:'Math Tools', ab:'Fb', desc:'Generate Fibonacci number sequences', kind:'calc',
  fields:[{id:'n',label:'How many terms',type:'number',value:15,min:1,max:200}],
  compute:v=>{const n=Math.min(200,Math.max(1,parseInt(v.n)||1));const seq=[0,1];for(let i=2;i<n;i++)seq.push(seq[i-1]+seq[i-2]);
    return `<div class="res-box mono">${seq.slice(0,n).join(', ')}</div>`;},
  info:'<h2>Fibonacci Sequence Generator</h2><p>Generates the Fibonacci sequence, where each number is the sum of the two preceding ones.</p>'},
{id:'hcf-lcm', name:'HCF & LCM Calculator', cat:'Math Tools', ab:'Hl', desc:'Calculate HCF and LCM of numbers', kind:'calc',
  fields:[{id:'nums',label:'Numbers (comma separated)',type:'text',value:'12, 18, 24'}],
  compute:v=>{const nums=parseNums(v.nums).map(n=>Math.round(Math.abs(n))).filter(n=>n>0);if(nums.length<2)return'<div class="alert alert-info">Enter at least 2 positive numbers.</div>';
    const h=nums.reduce((a,b)=>gcd(a,b));const l=nums.reduce((a,b)=>a*b/gcd(a,b));
    return statBlock([['HCF (GCD)',h],['LCM',l]]);},
  info:'<h2>HCF &amp; LCM Calculator</h2><p>Calculates the Highest Common Factor and Lowest Common Multiple of a list of numbers.</p>'},
{id:'factorial', name:'Factorial Calculator', cat:'Math Tools', ab:'Ft', desc:'Calculate factorial of any number', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:10,min:0,max:170}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n)||n<0)return'<div class="alert alert-info">Enter a whole number ≥ 0.</div>';if(n>170)return '<div class="alert alert-warn">Number too large (exceeds floating point range at 171!).</div>';
    let f=1n;for(let i=2;i<=n;i++)f*=BigInt(i);return `<div class="res-box mono" style="word-break:break-all">${n}! = ${f.toString()}</div>`;},
  info:'<h2>Factorial Calculator</h2><p>Calculates n! = n × (n-1) × (n-2) × ... × 1, using exact big-integer arithmetic.</p>'},
{id:'binary-converter', name:'Binary and Decimal Converter', cat:'Math Tools', ab:'Bn', desc:'Convert binary, decimal, hex, octal', kind:'base'},
{id:'roman-numerals', name:'Roman Numeral Converter', cat:'Math Tools', ab:'Rm', desc:'Convert between Arabic and Roman numerals', kind:'custom', info:'<h2>Roman Numeral Converter</h2><p>Converts between Arabic numbers (1-3999) and Roman numerals.</p>'},
{id:'quadratic-solver', name:'Quadratic Equation Solver', cat:'Math Tools', ab:'Qd', desc:'Solve ax² + bx + c = 0', kind:'calc',
  fields:[{id:'a',label:'a',type:'number',value:1},{id:'b',label:'b',type:'number',value:-3},{id:'c',label:'c',type:'number',value:2}],
  compute:v=>{const a=+v.a,b=+v.b,c=+v.c;if(!a)return '<div class="alert alert-info">Coefficient "a" must not be zero.</div>';
    const disc=b*b-4*a*c;
    if(disc>0){const x1=(-b+Math.sqrt(disc))/(2*a),x2=(-b-Math.sqrt(disc))/(2*a);return statBlock([['x₁',round4(x1)],['x₂',round4(x2)],['Discriminant',round4(disc)]]);}
    if(disc===0){const x=-b/(2*a);return statBlock([['x (double root)',round4(x)],['Discriminant',0]]);}
    const re=-b/(2*a),im=Math.sqrt(-disc)/(2*a);return statBlock([['x₁',`${round4(re)} + ${round4(im)}i`],['x₂',`${round4(re)} − ${round4(im)}i`],['Discriminant',round4(disc)]]);},
  info:'<h2>Quadratic Equation Solver</h2><p>Solves ax² + bx + c = 0 using the quadratic formula, including complex roots when the discriminant is negative.</p>'},
{id:'percent-error', name:'Percentage Error Calculator', cat:'Math Tools', ab:'Pe2', desc:'Calculate percentage error', kind:'calc',
  fields:[{id:'exp',label:'Expected (True) Value',type:'number',value:100},{id:'obs',label:'Observed (Measured) Value',type:'number',value:95}],
  compute:v=>{const exp=+v.exp,obs=+v.obs;if(!exp)return'';const err=Math.abs((obs-exp)/exp)*100;return statBlock([['Percentage Error',round4(err)+'%'],['Absolute Difference',round4(Math.abs(obs-exp))]]);},
  info:'<h2>Percentage Error Calculator</h2><p><strong>Formula:</strong> |Observed − Expected| ÷ Expected × 100</p>'},
{id:'permutation-combination', name:'Permutation & Combination Calculator', cat:'Math Tools', ab:'Pc3', desc:'Calculate nPr and nCr', kind:'calc',
  fields:[{id:'n',label:'n',type:'number',value:10,min:0},{id:'r',label:'r',type:'number',value:3,min:0}],
  compute:v=>{const n=Math.round(+v.n),r=Math.round(+v.r);if(isNaN(n)||isNaN(r)||r>n||n<0||r<0)return '<div class="alert alert-info">Require 0 ≤ r ≤ n.</div>';
    const fact=k=>{let f=1n;for(let i=2;i<=k;i++)f*=BigInt(i);return f;};
    const nPr=fact(n)/fact(n-r);const nCr=nPr/fact(r);
    return statBlock([['nPr (Permutations)',nPr.toString()],['nCr (Combinations)',nCr.toString()]]);},
  info:'<h2>Permutation &amp; Combination Calculator</h2><p>Calculates nPr (ordered arrangements) and nCr (unordered selections) for choosing r items from n.</p>'},
{id:'log-calculator', name:'Logarithm Calculator', cat:'Math Tools', ab:'Lg', desc:'Calculate log and antilog of a number', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:1000},{id:'base',label:'Base',type:'number',value:10}],
  compute:v=>{const n=+v.n,base=+v.base;if(n<=0||base<=0||base===1)return '<div class="alert alert-info">Number must be positive; base must be positive and ≠ 1.</div>';
    const result=Math.log(n)/Math.log(base);return statBlock([[`log base ${base} of ${n}`,round4(result)],['Natural log (ln)',round4(Math.log(n))],['log base 10',round4(Math.log10(n))],['log base 2',round4(Math.log2(n))]]);},
  info:'<h2>Logarithm Calculator</h2><p>Calculates the logarithm of a number to any base, plus natural log, log₁₀ and log₂.</p>'},
{id:'triangle-calculator', name:'Right Triangle Calculator', cat:'Math Tools', ab:'Tri', desc:'Solve a right triangle (Pythagoras)', kind:'calc',
  fields:[{id:'a',label:'Side a',type:'number',value:3},{id:'b',label:'Side b',type:'number',value:4}],
  compute:v=>{const a=+v.a,b=+v.b;if(!a||!b)return'';const c=Math.sqrt(a*a+b*b);const area=(a*b)/2;const angA=Math.atan(a/b)*180/Math.PI;const angB=90-angA;
    return statBlock([['Hypotenuse (c)',round4(c)],['Area',round4(area)],['Angle A',round4(angA)+'°'],['Angle B',round4(angB)+'°']]);},
  info:'<h2>Right Triangle Calculator</h2><p>Given the two legs of a right triangle, calculates the hypotenuse, area and both acute angles using the Pythagorean theorem.</p>'},
// ---- India finance calculators ----
{id:'sip-calculator', name:'SIP Calculator', cat:'Calculator Tools', ab:'Sp', badge:'new', desc:'Estimate the future value of a monthly SIP', kind:'calc',
  fields:[{id:'m',label:'Monthly Investment',type:'number',value:5000},{id:'r',label:'Expected Annual Return (%)',type:'number',value:12,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:10}],
  compute:v=>{const P=+v.m,R=+v.r,Y=+v.y;if(!(P>0)||!(Y>0)||R<0)return'';const n=Y*12,i=R/12/100;const fv=i===0?P*n:P*((Math.pow(1+i,n)-1)/i)*(1+i);const inv=P*n;
    return statBlock([['Invested Amount',fmtMoney(inv)],['Estimated Returns',fmtMoney(fv-inv)],['Total Value',fmtMoney(fv)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes a constant return and investment at the start of each month. Real market returns vary and are not guaranteed.</p>';},
  info:'<h2>SIP Calculator</h2><p>A Systematic Investment Plan (SIP) invests a fixed amount every month. This calculator estimates the future value using monthly compounding.</p><p><strong>Formula:</strong> FV = P x ((1+i)^n - 1) / i x (1+i), where i is the monthly rate and n is the number of months.</p>'},
{id:'fd-calculator', name:'FD / Lumpsum Calculator', cat:'Calculator Tools', ab:'Fd', badge:'new', desc:'Maturity value of a fixed deposit or lumpsum', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:100000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:7,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:5,step:0.5},{id:'q',label:'Compounding',type:'select',options:[['4','Quarterly'],['12','Monthly'],['2','Half-yearly'],['1','Yearly']]}],
  compute:v=>{const P=+v.p,R=+v.r,Y=+v.y,q=+v.q||4;if(!(P>0)||!(Y>0)||R<0)return'';const m=P*Math.pow(1+R/100/q,q*Y);
    return statBlock([['Principal',fmtMoney(P)],['Interest Earned',fmtMoney(m-P)],['Maturity Value',fmtMoney(m)]]);},
  info:'<h2>FD / Lumpsum Calculator</h2><p>Calculates the maturity value of a one-time investment with compound interest. Most Indian banks compound fixed deposits quarterly.</p><p><strong>Formula:</strong> A = P x (1 + r/q)^(q x t)</p>'},
{id:'ppf-calculator', name:'PPF Calculator', cat:'Calculator Tools', ab:'Pf', badge:'new', desc:'Estimate Public Provident Fund maturity', kind:'calc',
  fields:[{id:'a',label:'Yearly Deposit (max 150000)',type:'number',value:150000},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:7.1,step:0.1},{id:'y',label:'Years (minimum 15)',type:'number',value:15}],
  compute:v=>{const A=Math.min(+v.a,150000),R=+v.r,Y=+v.y;if(!(A>0)||!(Y>=15)||R<0)return'<div class="alert alert-warn">PPF has a minimum tenure of 15 years. Enter 15 or more.</div>';const r=R/100;const fv=r===0?A*Y:A*((Math.pow(1+r,Y)-1)/r)*(1+r);const inv=A*Y;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Total Interest',fmtMoney(fv-inv)],['Maturity Value',fmtMoney(fv)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes the deposit is made before the 5th of April each year and the rate stays constant. The government revises the PPF rate every quarter, so check the current rate.</p>';},
  info:'<h2>PPF Calculator</h2><p>The Public Provident Fund is a 15-year government-backed savings scheme in India. Interest is compounded yearly and the yearly deposit is capped at 1,50,000.</p>'},
{id:'cagr-calculator', name:'CAGR Calculator', cat:'Calculator Tools', ab:'Cg', badge:'new', desc:'Compound annual growth rate of an investment', kind:'calc',
  fields:[{id:'s',label:'Starting Value',type:'number',value:100000},{id:'e',label:'Ending Value',type:'number',value:250000},{id:'y',label:'Years',type:'number',value:5,step:0.5}],
  compute:v=>{const S=+v.s,E=+v.e,Y=+v.y;if(!(S>0)||!(E>0)||!(Y>0))return'';const c=(Math.pow(E/S,1/Y)-1)*100;
    return statBlock([['CAGR',c.toFixed(2)+'%'],['Total Growth',((E/S-1)*100).toFixed(2)+'%'],['Absolute Gain',fmtMoney(E-S)]]);},
  info:'<h2>CAGR Calculator</h2><p>CAGR is the steady yearly growth rate that takes an investment from its starting value to its ending value.</p><p><strong>Formula:</strong> CAGR = (Ending / Starting)^(1 / years) - 1</p>'},
{id:'income-tax-india', name:'Income Tax Calculator (India)', cat:'Calculator Tools', ab:'It', badge:'new', desc:'Compare old and new tax regime, FY 2026-27', kind:'calc',
  fields:[{id:'inc',label:'Annual Gross Income',type:'number',value:1500000},{id:'sal',label:'Salaried?',type:'select',options:[['1','Yes (standard deduction applies)'],['0','No']]},{id:'ded',label:'Deductions for old regime (80C, 80D, HRA etc.)',type:'number',value:150000}],
  compute:v=>{const inc=+v.inc,sal=v.sal==='1',ded=Math.max(0,+v.ded||0);if(!(inc>=0))return'';
    const slab=(t,sl)=>{let tax=0,prev=0;for(const [lim,rt] of sl){if(t>prev)tax+=(Math.min(t,lim)-prev)*rt;prev=lim;}return tax;};
    const NEW=[[400000,0],[800000,.05],[1200000,.10],[1600000,.15],[2000000,.20],[2400000,.25],[Infinity,.30]];
    const OLD=[[250000,0],[500000,.05],[1000000,.20],[Infinity,.30]];
    let tn=Math.max(0,inc-(sal?75000:0)); let xn=slab(tn,NEW); if(tn<=1200000) xn=0; else xn=Math.min(xn,tn-1200000); const cn=xn*0.04;
    let to=Math.max(0,inc-(sal?50000:0)-ded); let xo=slab(to,OLD); if(to<=500000) xo=0; const co=xo*0.04;
    const totN=xn+cn,totO=xo+co; const better=totN<=totO?'New regime':'Old regime'; const save=Math.abs(totN-totO);
    return statBlock([['New Regime Tax',fmtMoney(totN)],['Old Regime Tax',fmtMoney(totO)],['Better Option',better]])
      +`<div class="alert alert-info">${better} saves about ${fmtMoney(save)} for this income.</div>`
      +`<p style="font-size:12px;color:var(--tm);margin-top:10px">Taxable income: ${fmtMoney(tn)} (new), ${fmtMoney(to)} (old). Includes 4% cess and Section 87A rebate. Excludes surcharge (applies above 50 lakh), other income types and capital gains. This is an estimate for individuals under 60. Confirm with the Income Tax Department or a chartered accountant before filing.</p>`;},
  info:'<h2>Income Tax Calculator (India)</h2><p>Compares tax under the new and old regime for an individual under 60 for FY 2026-27 (AY 2027-28).</p><p><strong>New regime:</strong> no tax up to 4 lakh, then 5%, 10%, 15%, 20%, 25% and 30% above 24 lakh. Standard deduction 75,000 and Section 87A rebate up to 60,000 for taxable income up to 12 lakh.</p><p><strong>Old regime:</strong> no tax up to 2.5 lakh, then 5%, 20% and 30% above 10 lakh. Standard deduction 50,000, rebate up to 12,500 for taxable income up to 5 lakh.</p>'},
// ---- PDF tools (run in the browser using pdf-lib, loaded on demand) ----
{id:'pdf-merge', name:'Merge PDF', cat:'PDF Tools', ab:'Mg', badge:'new', desc:'Combine several PDF files into one', kind:'custom', info:'<h2>Merge PDF</h2><p>Select two or more PDF files, put them in the order you want and download one combined PDF. Files are processed on your device and are never uploaded.</p>'},
{id:'pdf-split', name:'Split / Extract PDF Pages', cat:'PDF Tools', ab:'Sx', badge:'new', desc:'Extract chosen pages from a PDF', kind:'custom', info:'<h2>Split / Extract PDF Pages</h2><p>Enter the pages you want, such as 1-3,5,8-10, and download a new PDF containing only those pages. Processing happens on your device.</p>'},
{id:'images-to-pdf', name:'Images to PDF', cat:'PDF Tools', ab:'Ip', badge:'new', desc:'Turn JPG and PNG images into one PDF', kind:'custom', info:'<h2>Images to PDF</h2><p>Add JPG or PNG images, arrange them and download a single PDF with one image per page. Nothing is uploaded.</p>'},
{id:'pdf-rotate', name:'Rotate PDF', cat:'PDF Tools', ab:'Rp', badge:'new', desc:'Rotate every page of a PDF', kind:'custom', info:'<h2>Rotate PDF</h2><p>Rotate all pages of a PDF by 90, 180 or 270 degrees and download the result. Processing happens on your device.</p>'},
// ---- more India finance calculators ----
{id:'hra-calculator', name:'HRA Exemption Calculator', cat:'Calculator Tools', ab:'Hr', badge:'new', desc:'Work out the tax-exempt part of your HRA', kind:'calc',
  fields:[{id:'b',label:'Basic Salary + DA (monthly)',type:'number',value:50000},{id:'h',label:'HRA Received (monthly)',type:'number',value:20000},{id:'r',label:'Rent Paid (monthly)',type:'number',value:18000},{id:'m',label:'City',type:'select',options:[['0.5','Metro (Delhi, Mumbai, Kolkata, Chennai)'],['0.4','Non-metro']]}],
  compute:v=>{const b=+v.b,h=+v.h,r=+v.r,p=+v.m;if(!(b>0)||h<0||r<0)return'';const a=h,c=Math.max(0,r-0.1*b),d=p*b;const ex=Math.max(0,Math.min(a,c,d));
    return statBlock([['Exempt HRA (monthly)',fmtMoney(ex)],['Exempt HRA (yearly)',fmtMoney(ex*12)],['Taxable HRA (yearly)',fmtMoney((h-ex)*12)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Exemption is the lowest of: actual HRA (${fmtMoney(a)}), rent paid minus 10% of basic (${fmtMoney(c)}), and ${p*100}% of basic (${fmtMoney(d)}). HRA exemption is available only under the old tax regime.</p>`;},
  info:'<h2>HRA Exemption Calculator</h2><p>If you receive House Rent Allowance and pay rent, part of it can be exempt from income tax under the old regime. The exempt amount is the lowest of three figures: the HRA you actually receive, rent paid minus 10% of salary, and 50% (metro) or 40% (non-metro) of salary.</p>'},
{id:'gratuity-calculator', name:'Gratuity Calculator', cat:'Calculator Tools', ab:'Gr', badge:'new', desc:'Estimate gratuity payable on leaving a job', kind:'calc',
  fields:[{id:'s',label:'Last Drawn Basic + DA (monthly)',type:'number',value:60000},{id:'y',label:'Years of Service',type:'number',value:8},{id:'m',label:'Extra Months',type:'number',value:7}],
  compute:v=>{const S=+v.s,Y=Math.floor(+v.y),M=Math.floor(+v.m)||0;if(!(S>0)||!(Y>=0))return'';if(Y<5)return'<div class="alert alert-warn">Gratuity is generally payable only after 5 years of continuous service.</div>';const yrs=Y+(M>=6?1:0);const g=15/26*S*yrs;const cap=2000000;
    return statBlock([['Years Counted',String(yrs)],['Gratuity (formula)',fmtMoney(g)],['Payable (cap 20 lakh)',fmtMoney(Math.min(g,cap))]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Formula for employees covered by the Payment of Gratuity Act: last drawn salary x 15 / 26 x completed years, with 6 months or more rounded up. Your employer\'s policy may be more generous.</p>';},
  info:'<h2>Gratuity Calculator</h2><p>Gratuity is a lump sum paid by an employer after at least 5 years of service. For employees covered by the Payment of Gratuity Act it equals last drawn monthly basic plus DA, multiplied by 15/26, multiplied by completed years of service.</p>'},
{id:'swp-calculator', name:'SWP Calculator', cat:'Calculator Tools', ab:'Sw', badge:'new', desc:'See how long a corpus lasts with monthly withdrawals', kind:'calc',
  fields:[{id:'c',label:'Starting Corpus',type:'number',value:2000000},{id:'w',label:'Monthly Withdrawal',type:'number',value:15000},{id:'r',label:'Expected Annual Return (%)',type:'number',value:8,step:0.1},{id:'y',label:'Withdrawal Period (years)',type:'number',value:15}],
  compute:v=>{const C=+v.c,W=+v.w,R=+v.r,Y=+v.y;if(!(C>0)||!(W>0)||!(Y>0)||R<0)return'';const i=R/12/100;let bal=C,months=0,drawn=0;for(let k=1;k<=Y*12;k++){bal=bal*(1+i);const take=Math.min(W,bal);bal-=take;drawn+=take;months=k;if(bal<=0.005){bal=0;break;}}
    const lasted=bal<=0&&months<Y*12;return statBlock([['Total Withdrawn',fmtMoney(drawn)],['Final Balance',fmtMoney(bal)],['Lasts For',lasted?(Math.floor(months/12)+' yr '+(months%12)+' mo'):(Y+' yr (full period)')]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes a constant return and withdrawals at the end of each month. Real returns vary, and taxes are not included.</p>';},
  info:'<h2>SWP Calculator</h2><p>A Systematic Withdrawal Plan takes a fixed amount from an investment every month. The calculator shows the balance left after your chosen period and how long the corpus lasts if you withdraw too much.</p>'},
{id:'stepup-sip-calculator', name:'Step-up SIP Calculator', cat:'Calculator Tools', ab:'Ss', badge:'new', desc:'SIP that grows by a fixed percentage every year', kind:'calc',
  fields:[{id:'m',label:'Starting Monthly Investment',type:'number',value:5000},{id:'s',label:'Yearly Step-up (%)',type:'number',value:10,step:0.5},{id:'r',label:'Expected Annual Return (%)',type:'number',value:12,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:10}],
  compute:v=>{const P=+v.m,S=+v.s,R=+v.r,Y=Math.floor(+v.y);if(!(P>0)||!(Y>0)||R<0||S<0)return'';const i=R/12/100;let bal=0,inv=0,cur=P;for(let k=0;k<Y*12;k++){if(k>0&&k%12===0)cur*=1+S/100;bal=(bal+cur)*(1+i);inv+=cur;}
    return statBlock([['Invested Amount',fmtMoney(inv)],['Estimated Returns',fmtMoney(bal-inv)],['Total Value',fmtMoney(bal)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Investment is assumed at the start of each month and the amount rises once a year. Market returns are not guaranteed.</p>';},
  info:'<h2>Step-up SIP Calculator</h2><p>A step-up SIP raises your monthly investment by a fixed percentage every year, usually in line with your salary. This usually builds a much larger corpus than a flat SIP over the same period.</p>'},
{id:'loan-prepayment-calculator', name:'Loan Prepayment Calculator', cat:'Calculator Tools', ab:'Lp', badge:'new', desc:'Interest saved by prepaying part of a loan', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:3000000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:8.5,step:0.05},{id:'n',label:'Tenure (months)',type:'number',value:240},{id:'k',label:'Prepay After Month',type:'number',value:24},{id:'a',label:'Prepayment Amount',type:'number',value:300000}],
  compute:v=>{const P=+v.p,R=+v.r,N=Math.floor(+v.n),K=Math.floor(+v.k),A=+v.a;if(!(P>0)||!(N>0)||R<0||!(K>=0)||A<0||K>=N)return'';const i=R/12/100;const emi=i===0?P/N:P*i*Math.pow(1+i,N)/(Math.pow(1+i,N)-1);const base=emi*N-P;
    let bal=P,int=0,m=0;while(bal>0.005&&m<N*2){const it=bal*i;int+=it;bal=bal+it-emi;m++;if(m===K){bal=Math.max(0,bal-A);}}if(bal<0)bal=0;const saved=base-int;
    return statBlock([['Monthly EMI',fmtMoney(emi)],['Interest Saved',fmtMoney(saved)],['Months Saved',String(N-m)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Without prepayment you pay ${fmtMoney(base)} interest over ${N} months. With it, the loan ends in ${m} months and costs ${fmtMoney(int)} interest. The EMI stays the same and the tenure shortens. Check your lender for prepayment charges.</p>`;},
  info:'<h2>Loan Prepayment Calculator</h2><p>Paying part of your loan early, while keeping the EMI the same, shortens the tenure and cuts the total interest. Enter your loan, the month you plan to prepay and the amount to see the saving.</p>'},
{id:'rd-calculator', name:'RD Calculator', cat:'Calculator Tools', ab:'Rd', badge:'new', desc:'Maturity value of a recurring deposit', kind:'calc',
  fields:[{id:'d',label:'Monthly Deposit',type:'number',value:5000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:6.5,step:0.1},{id:'n',label:'Tenure (months)',type:'number',value:60}],
  compute:v=>{const D=+v.d,R=+v.r,N=Math.floor(+v.n);if(!(D>0)||!(N>0)||R<0)return'';const q=R/400;let mat=0;for(let k=0;k<N;k++){mat+=D*Math.pow(1+q,(N-k)/3);}const inv=D*N;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Interest Earned',fmtMoney(mat-inv)],['Maturity Value',fmtMoney(mat)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Uses quarterly compounding, which most Indian banks follow. Your bank may round differently, so the final figure can vary slightly.</p>';},
  info:'<h2>RD Calculator</h2><p>A Recurring Deposit lets you save a fixed amount every month at a fixed interest rate. This calculator uses quarterly compounding, as most Indian banks do.</p>'},
// ---- more India finance calculators ----
{id:'nps-calculator', name:'NPS Calculator', cat:'Calculator Tools', ab:'Np', badge:'new', desc:'Estimate NPS corpus, lump sum and monthly pension', kind:'calc',
  fields:[{id:'m',label:'Monthly Contribution',type:'number',value:5000},{id:'a',label:'Current Age',type:'number',value:30},{id:'ra',label:'Retirement Age',type:'number',value:60},{id:'r',label:'Expected Annual Return (%)',type:'number',value:10,step:0.1},{id:'an',label:'Share of Corpus Used for Annuity (%)',type:'number',value:40,step:1},{id:'ar',label:'Annuity Rate (% p.a.)',type:'number',value:6,step:0.1}],
  compute:v=>{const M=+v.m,A=Math.floor(+v.a),RA=Math.floor(+v.ra),R=+v.r,AN=+v.an,AR=+v.ar;if(!(M>0)||!(RA>A)||!(A>=0)||R<0||!(AN>=0&&AN<=100)||AR<0)return'';const n=(RA-A)*12,i=R/12/100;const fv=i===0?M*n:M*((Math.pow(1+i,n)-1)/i)*(1+i);const inv=M*n;const ann=fv*AN/100,lump=fv-ann;const pen=ann*AR/100/12;
    return statBlock([['Total Corpus',fmtMoney(fv)],['Lump Sum at Retirement',fmtMoney(lump)],['Monthly Pension',fmtMoney(pen)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">You invest ${fmtMoney(inv)} in total over ${RA-A} years. Assumes a constant return and a deposit at the start of each month. The minimum annuity share and the tax treatment of the lump sum are set by PFRDA and the Income Tax Act and have changed in the past, so check the current rules.</p>`;},
  info:'<h2>NPS Calculator</h2><p>The National Pension System is a market-linked retirement scheme in India. This calculator projects your corpus from a monthly contribution, then splits it into a lump sum and an annuity that pays a monthly pension.</p><p>Returns are not guaranteed. Change the return and annuity inputs to see how sensitive the result is.</p>'},
{id:'epf-calculator', name:'EPF Calculator', cat:'Calculator Tools', ab:'Ep', badge:'new', desc:'Estimate your EPF balance at retirement', kind:'calc',
  fields:[{id:'b',label:'Monthly Basic + DA',type:'number',value:30000},{id:'a',label:'Current Age',type:'number',value:30},{id:'ra',label:'Retirement Age',type:'number',value:58},{id:'g',label:'Yearly Salary Growth (%)',type:'number',value:5,step:0.5},{id:'r',label:'EPF Interest Rate (% p.a.)',type:'number',value:8.25,step:0.05},{id:'cur',label:'Current EPF Balance',type:'number',value:0}],
  compute:v=>{let B=+v.b;const A=Math.floor(+v.a),RA=Math.floor(+v.ra),G=+v.g,R=+v.r;let bal=Math.max(0,+v.cur||0);if(!(B>0)||!(RA>A)||G<0||R<0)return'';let emp=0,er=0,intr=0;for(let y=0;y<RA-A;y++){let acc=0;for(let m=0;m<12;m++){const e=B*0.12;const eps=Math.min(0.0833*Math.min(B,15000),1250);const c=B*0.12-eps;acc+=bal*R/100/12;bal+=e+c;emp+=e;er+=c;}bal+=acc;intr+=acc;B*=1+G/100;}
    return statBlock([['Estimated Balance',fmtMoney(bal)],['Your Contribution',fmtMoney(emp)],['Employer Contribution',fmtMoney(er)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Interest earned: ${fmtMoney(intr)}. You contribute 12% of basic, and the employer puts 12% too, of which 8.33% of wages up to 15,000 (maximum 1,250 a month) goes to the pension scheme (EPS) and the rest to your EPF. Interest is worked out monthly and credited yearly. The EPF rate is declared every year, so treat this as an estimate.</p>`;},
  info:'<h2>EPF Calculator</h2><p>The Employees\' Provident Fund collects 12% of your basic pay from you and 12% from your employer. Part of the employer share goes to the Employees\' Pension Scheme, so only the remainder adds to your EPF balance.</p><p>Enter your basic pay plus dearness allowance, your expected salary growth and the interest rate to estimate the balance at retirement.</p>'},
{id:'home-loan-eligibility', name:'Home Loan Eligibility Calculator', cat:'Calculator Tools', ab:'He', badge:'new', desc:'How much home loan your income can support', kind:'calc',
  fields:[{id:'inc',label:'Monthly Net Income',type:'number',value:100000},{id:'emi',label:'Existing Monthly EMIs',type:'number',value:10000},{id:'f',label:'Share of Income Lenders Allow for EMIs (%)',type:'number',value:50,step:1},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:8.5,step:0.05},{id:'y',label:'Tenure (years)',type:'number',value:20}],
  compute:v=>{const I=+v.inc,E=Math.max(0,+v.emi||0),F=+v.f,R=+v.r,Y=+v.y;if(!(I>0)||!(F>0&&F<=100)||R<0||!(Y>0))return'';const cap=I*F/100-E;if(cap<=0)return'<div class="alert alert-warn">Your existing EMIs already use up the share of income lenders allow, so no new EMI fits.</div>';const n=Y*12,i=R/12/100;const loan=i===0?cap*n:cap*(1-Math.pow(1+i,-n))/i;const pay=cap*n;
    return statBlock([['Eligible Loan',fmtMoney(loan)],['Affordable EMI',fmtMoney(cap)],['Total Interest',fmtMoney(pay-loan)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">A rough guide only. Banks also look at your credit score, age, job type, property value and other debts, so the offer you get can be lower or higher.</p>';},
  info:'<h2>Home Loan Eligibility Calculator</h2><p>Lenders limit your total monthly EMIs to a share of your income, often around 40% to 55%. This calculator takes that share, subtracts your current EMIs and works out the loan that the remaining EMI can repay over your chosen tenure.</p>'},
{id:'ssy-calculator', name:'Sukanya Samriddhi Calculator', cat:'Calculator Tools', ab:'Sy', badge:'new', desc:'Estimate Sukanya Samriddhi Yojana maturity', kind:'calc',
  fields:[{id:'a',label:'Yearly Deposit (250 to 150000)',type:'number',value:150000},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:8.2,step:0.1}],
  compute:v=>{const A=+v.a,R=+v.r;if(!(A>=250)||A>150000||R<0)return'<div class="alert alert-warn">Enter a yearly deposit between 250 and 1,50,000.</div>';let bal=0;for(let y=1;y<=21;y++){if(y<=15)bal+=A;bal+=bal*R/100;}const inv=A*15;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Total Interest',fmtMoney(bal-inv)],['Maturity Value (Year 21)',fmtMoney(bal)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Deposits are made for 15 years and the account matures in year 21. Assumes the full deposit is made before the 5th of April each year and a constant rate. The rate is reset by the government every quarter, so use the current rate.</p>';},
  info:'<h2>Sukanya Samriddhi Calculator</h2><p>Sukanya Samriddhi Yojana is a small savings scheme for the girl child in India. You deposit for 15 years and the account matures 21 years after opening. Interest is compounded yearly.</p>'},
{id:'inflation-calculator', name:'Inflation Calculator', cat:'Calculator Tools', ab:'If', badge:'new', desc:'See what today\'s money will cost or buy later', kind:'calc',
  fields:[{id:'c',label:'Amount Today',type:'number',value:100000},{id:'i',label:'Yearly Inflation (%)',type:'number',value:6,step:0.1},{id:'y',label:'Years',type:'number',value:10}],
  compute:v=>{const C=+v.c,I=+v.i,Y=+v.y;if(!(C>0)||I<0||!(Y>0))return'';const f=C*Math.pow(1+I/100,Y),p=C/Math.pow(1+I/100,Y);
    return statBlock([['Same Things Will Cost',fmtMoney(f)],['Today\'s Amount Will Buy Only',fmtMoney(p)],['Loss in Buying Power',((1-p/C)*100).toFixed(1)+'%']]);},
  info:'<h2>Inflation Calculator</h2><p>Inflation makes the same things cost more every year. Enter an amount, a yearly inflation rate and a number of years to see what the same basket of goods will cost, and how much of today\'s money\'s buying power is lost.</p><p><strong>Formula:</strong> Future cost = Amount x (1 + inflation)^years</p>'},
// ---- more image and PDF tools ----
{id:'webp-converter', name:'WebP Converter', cat:'Image Tools', ab:'Wp', badge:'new', desc:'Convert images to or from WebP', kind:'custom', info:'<h2>WebP Converter</h2><p>Convert JPG or PNG images to the smaller WebP format, or turn WebP back into JPG or PNG. Everything happens in your browser and nothing is uploaded.</p>'},
{id:'pdf-to-jpg', name:'PDF to JPG', cat:'PDF Tools', ab:'Pj', badge:'new', desc:'Turn each PDF page into an image', kind:'custom', info:'<h2>PDF to JPG</h2><p>Render every page of a PDF as a JPG image and download them one by one. The PDF stays on your device.</p>'},
{id:'pdf-delete-pages', name:'Delete PDF Pages', cat:'PDF Tools', ab:'Pd2', badge:'new', desc:'Remove unwanted pages from a PDF', kind:'custom', info:'<h2>Delete PDF Pages</h2><p>Enter the pages you want to remove, such as 2,4-6, and download the PDF without them.</p>'},
{id:'pdf-page-numbers', name:'Add Page Numbers to PDF', cat:'PDF Tools', ab:'Pn', badge:'new', desc:'Stamp page numbers on every page', kind:'custom', info:'<h2>Add Page Numbers to PDF</h2><p>Add "Page 1 of N" style numbers at the bottom of every page and download the new PDF.</p>'},

];

;
// ============================================================
// TOOL_CUSTOM - implementations for every kind:'custom' tool.
// Each entry: { body(): string, init?(): void }
// ============================================================
const TOOL_CUSTOM = {};

// ---------- find-replace ----------
TOOL_CUSTOM['find-replace'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="fr-in" rows="8"></textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Find</label><input class="fc" id="fr-find"></div>
      <div class="fg"><label class="fl">Replace With</label><input class="fc" id="fr-rep"></div>
    </div>
    <div style="display:flex;gap:16px;margin-bottom:12px;font-size:13px">
      <label style="display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" id="fr-case"> Case sensitive</label>
      <label style="display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" id="fr-regex"> Use regex</label>
    </div>
    <button class="btn btn-p" onclick="frRun()">Find & Replace All</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Result <button class="cpbtn" onclick="copyText(document.getElementById('fr-out').value,this)">Copy</button></label><textarea class="fc" id="fr-out" rows="8" readonly></textarea></div>
    <div id="fr-stat" style="font-size:13px;color:var(--tm)"></div>`,
  init: () => {
    window.frRun = () => {
      const text = document.getElementById('fr-in').value;
      const find = document.getElementById('fr-find').value;
      const rep = document.getElementById('fr-rep').value;
      const cs = document.getElementById('fr-case').checked;
      const useRegex = document.getElementById('fr-regex').checked;
      if (!find) return;
      try {
        let count = 0, out;
        if (useRegex) {
          const re = new RegExp(find, 'g'+(cs?'':'i'));
          out = text.replace(re, (...m)=>{count++; return rep;});
        } else {
          const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'g'+(cs?'':'i'));
          out = text.replace(re, ()=>{count++; return rep;});
        }
        document.getElementById('fr-out').value = out;
        document.getElementById('fr-stat').textContent = `Replaced ${count} occurrence(s).`;
      } catch(e){ document.getElementById('fr-stat').textContent = 'Error: '+e.message; }
    };
  }
};

// ---------- word-frequency ----------
TOOL_CUSTOM['word-frequency'] = {
  body: () => `<div class="fg"><label class="fl">Text</label><textarea class="fc" id="wf-in" rows="8" oninput="wfRun()"></textarea></div><div id="wf-out"></div>`,
  init: () => { window.wfRun = () => {
    const t = document.getElementById('wf-in').value.toLowerCase();
    const words = t.replace(/[^a-z0-9'\s]/g,'').split(/\s+/).filter(Boolean);
    const freq = {}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
    const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,25);
    document.getElementById('wf-out').innerHTML = top.length ? top.map(([w,n])=>`<div class="trow"><span>${esc(w)}</span><strong>${n}</strong></div>`).join('') : '<div class="alert alert-info">Type some text.</div>';
  };}
};

// ---------- caesar-cipher ----------
TOOL_CUSTOM['caesar-cipher'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="cz-in" rows="6" oninput="czRun()"></textarea></div>
    <div class="fg"><label class="fl">Shift Amount: <strong id="cz-shiftlbl">3</strong></label><input type="range" min="1" max="25" value="3" id="cz-shift" oninput="document.getElementById('cz-shiftlbl').textContent=this.value;czRun()"></div>
    <div class="bgrp" style="margin-bottom:12px"><button class="btn btn-p btn-sm" onclick="czRun('enc')">Encrypt</button><button class="btn btn-s btn-sm" onclick="czRun('dec')">Decrypt</button></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('cz-out').value,this)">Copy</button></label><textarea class="fc mono" id="cz-out" rows="6" readonly></textarea></div>`,
  init: () => { window.czRun = (mode) => {
    mode = mode || 'enc';
    const shift = parseInt(document.getElementById('cz-shift').value) * (mode==='dec'?-1:1);
    const t = document.getElementById('cz-in').value;
    const out = t.replace(/[a-zA-Z]/g, c => { const base = c<='Z'?65:97; return String.fromCharCode((((c.charCodeAt(0)-base+shift)%26)+26)%26+base); });
    document.getElementById('cz-out').value = out;
  };}
};

// ---------- morse-code ----------
TOOL_CUSTOM['morse-code'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="mo-in" rows="6" placeholder="HELLO WORLD"></textarea></div>
    <div class="bgrp" style="margin-bottom:12px"><button class="btn btn-p btn-sm" onclick="moRun('t2m')">Text to Morse</button><button class="btn btn-s btn-sm" onclick="moRun('m2t')">Morse to Text</button></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('mo-out').value,this)">Copy</button></label><textarea class="fc mono" id="mo-out" rows="6" readonly></textarea></div>`,
  init: () => { window.moRun = (mode) => {
    const t = document.getElementById('mo-in').value;
    let out;
    if (mode==='t2m') out = t.toUpperCase().split('').map(c => c===' ' ? '/' : (MORSE[c]||'')).join(' ');
    else out = t.trim().split(' / ').map(w => w.trim().split(/\s+/).map(code=>MORSE_REV[code]||'').join('')).join(' ');
    document.getElementById('mo-out').value = out;
  };}
};

// ---------- percentage-calculator ----------
TOOL_CUSTOM['percentage-calculator'] = {
  body: () => `
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">What is X% of Y?</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">Percentage (%)</label><input type="number" class="fc" id="pc1-pct" placeholder="e.g. 15" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">Of Number</label><input type="number" class="fc" id="pc1-num" placeholder="e.g. 200" oninput="pcAll()"></div>
      </div>
      <div id="pc1-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">X is what % of Y?</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">Value X</label><input type="number" class="fc" id="pc2-x" placeholder="e.g. 30" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">Total Y</label><input type="number" class="fc" id="pc2-y" placeholder="e.g. 200" oninput="pcAll()"></div>
      </div>
      <div id="pc2-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">Percentage Change from X to Y</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">From</label><input type="number" class="fc" id="pc3-from" placeholder="e.g. 100" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">To</label><input type="number" class="fc" id="pc3-to" placeholder="e.g. 150" oninput="pcAll()"></div>
      </div>
      <div id="pc3-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>`,
  init: () => { window.pcAll = () => {
    const pct=parseFloat(document.getElementById('pc1-pct').value), num=parseFloat(document.getElementById('pc1-num').value);
    document.getElementById('pc1-res').textContent = (isNaN(pct)||isNaN(num)) ? '' : `${pct}% of ${num} = ${round4(pct/100*num)}`;
    const x=parseFloat(document.getElementById('pc2-x').value), y=parseFloat(document.getElementById('pc2-y').value);
    document.getElementById('pc2-res').textContent = (isNaN(x)||isNaN(y)||y===0) ? '' : `${x} is ${round4(x/y*100)}% of ${y}`;
    const from=parseFloat(document.getElementById('pc3-from').value), to=parseFloat(document.getElementById('pc3-to').value);
    const r=document.getElementById('pc3-res');
    if (isNaN(from)||isNaN(to)||from===0) r.innerHTML=''; else { const ch=((to-from)/Math.abs(from))*100; r.innerHTML = `<span style="color:${ch>=0?'var(--ok)':'var(--err)'}">${ch>=0?'+':''}${round4(ch)}% ${ch>=0?'increase':'decrease'}</span>`; }
  };}
};

// ---------- scientific-calculator ----------
TOOL_CUSTOM['scientific-calculator'] = {
  body: () => `
    <input class="fc mono" id="sc-disp" readonly style="font-size:24px;text-align:right;margin-bottom:10px;height:56px">
    <div id="sc-grid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:7px"></div>`,
  init: () => {
    const btns = ['sin','cos','tan','log','ln','(',')','√','^','C','7','8','9','/','π','4','5','6','*','e','1','2','3','-','%','0','.','=','+','DEL'];
    const grid = document.getElementById('sc-grid');
    grid.innerHTML = btns.map(b=>`<button class="btn btn-s btn-sm" onclick="scPress('${b}')">${b}</button>`).join('');
    window.scExpr = '';
    window.scPress = (b) => {
      const disp = document.getElementById('sc-disp');
      if (b==='C'){ scExpr=''; disp.value=''; return; }
      if (b==='DEL'){ scExpr=scExpr.slice(0,-1); disp.value=scExpr; return; }
      if (b==='='){
        try {
          let e = scExpr.replace(/π/g,'Math.PI').replace(/√/g,'Math.sqrt').replace(/\^/g,'**')
            .replace(/sin\(/g,'Math.sin(').replace(/cos\(/g,'Math.cos(').replace(/tan\(/g,'Math.tan(')
            .replace(/log\(/g,'Math.log10(').replace(/ln\(/g,'Math.log(').replace(/e(?![a-zA-Z])/g,'Math.E');
          if (!/^[\d\s+\-*/.()Mathsincoqrtlgepw%,E]*$/.test(e)) throw new Error('invalid');
          const result = Function('"use strict";return ('+e+')')();
          scExpr = String(result); disp.value = scExpr;
        } catch(err){ disp.value = 'Error'; scExpr=''; }
        return;
      }
      if (b==='√'){ scExpr+='√('; disp.value=scExpr; return; }
      if (['sin','cos','tan','log','ln'].includes(b)){ scExpr+=b+'('; disp.value=scExpr; return; }
      scExpr += b; disp.value = scExpr;
    };
  }
};

// ---------- cgpa-calculator ----------
TOOL_CUSTOM['cgpa-calculator'] = {
  body: () => `
    <div id="cg-rows"></div>
    <button class="btn btn-s btn-sm" onclick="cgAddRow()" style="margin:10px 0">+ Add Course</button>
    <div id="cg-result"></div>`,
  init: () => {
    let n = 0;
    window.cgAddRow = () => {
      n++;
      const row = document.createElement('div');
      row.style.cssText = 'display:grid;grid-template-columns:1fr 100px 100px 30px;gap:8px;margin-bottom:8px;align-items:center';
      row.innerHTML = `<input class="fc" placeholder="Course ${n}" value="Course ${n}">
        <input class="fc" type="number" placeholder="Grade pt" value="4" min="0" max="10" step="0.1" oninput="cgCalc()">
        <input class="fc" type="number" placeholder="Credits" value="3" min="0" oninput="cgCalc()">
        <button class="btn btn-s btn-sm" onclick="this.parentElement.remove();cgCalc()" aria-label="Remove">${svgIcon('ui_close',14)}</button>`;
      document.getElementById('cg-rows').appendChild(row);
      cgCalc();
    };
    window.cgCalc = () => {
      const rows = [...document.getElementById('cg-rows').children];
      let totalPts=0, totalCredits=0;
      rows.forEach(r => { const [,g,c] = r.querySelectorAll('input'); const gp=parseFloat(g.value)||0, cr=parseFloat(c.value)||0; totalPts+=gp*cr; totalCredits+=cr; });
      document.getElementById('cg-result').innerHTML = totalCredits ? statBlock([['CGPA',round4(totalPts/totalCredits)],['Total Credits',totalCredits]]) : '';
    };
    cgAddRow(); cgAddRow(); cgAddRow();
  }
};

// ---------- currency-converter ----------
const FX_RATES = {USD:1, EUR:0.92, GBP:0.79, INR:84.1, JPY:152.3, AUD:1.52, CAD:1.37, CNY:7.24, CHF:0.88, SGD:1.34, ZAR:18.2};
TOOL_CUSTOM['currency-converter'] = {
  body: () => {
    const opts = Object.keys(FX_RATES).map(c=>`<option value="${c}">${c}</option>`).join('');
    return `
    <div class="fg"><label class="fl">Amount</label><input type="number" class="fc" id="cur-amt" value="100" oninput="curRun()"></div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:end;margin-bottom:16px">
      <div class="fg" style="margin:0"><label class="fl">From</label><select class="fc" id="cur-from" onchange="curRun()">${opts}</select></div>
      <button class="btn btn-s btn-sm" onclick="curSwap()" aria-label="Swap">${svgIcon('ui_swap',16)}</button>
      <div class="fg" style="margin:0"><label class="fl">To</label><select class="fc" id="cur-to" onchange="curRun()">${opts}</select></div>
    </div>
    <div class="res-box ok" id="cur-result" style="font-size:20px;font-weight:700;text-align:center"></div>
    <div class="alert alert-info" style="margin-top:12px" id="cur-note">Loading current rates...</div>`;
  },
  init: () => {
    document.getElementById('cur-from').value='USD'; document.getElementById('cur-to').value='INR';
    window.curSwap = () => { const f=document.getElementById('cur-from'),t=document.getElementById('cur-to'); [f.value,t.value]=[t.value,f.value]; curRun(); };
    window.curRun = () => {
      const amt = parseFloat(document.getElementById('cur-amt').value);
      const from = document.getElementById('cur-from').value, to = document.getElementById('cur-to').value;
      const out = document.getElementById('cur-result');
      if (isNaN(amt)) { out.textContent='Enter an amount'; return; }
      const usd = amt / FX_RATES[from];
      const result = usd * FX_RATES[to];
      out.innerHTML = `${amt} ${from} = <span style="color:var(--p)">${result.toLocaleString(undefined,{maximumFractionDigits:2})} ${to}</span>`;
    };
    curRun();
    const note = document.getElementById('cur-note');
    const fallback = () => { if(note) note.innerHTML = 'Could not load live rates. Showing bundled indicative rates. Check your bank or card provider for real transactions.'; };
    const ctl = new AbortController(); const to = setTimeout(()=>ctl.abort(), 6000);
    fetch('https://api.frankfurter.app/latest?from=USD&to='+Object.keys(FX_RATES).filter(c=>c!=='USD').join(','), {signal: ctl.signal})
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => { clearTimeout(to); Object.keys(d.rates||{}).forEach(k => { FX_RATES[k] = d.rates[k]; });
        if(note) note.textContent = 'Rates from Frankfurter (European Central Bank reference rates), dated ' + d.date + '. For real transactions, check your bank or card provider.';
        if (document.getElementById('cur-result')) curRun(); })
      .catch(() => { clearTimeout(to); fallback(); });
  }
};

// ---------- image tools (shared canvas helpers) ----------
function imgUploadBody(extraControls, resultId){
  return `
    <div class="fg"><label class="fl">Upload Image</label><input type="file" class="fc" id="im-file" accept="image/*"></div>
    ${extraControls||''}
    <div id="${resultId||'im-result'}" style="margin-top:14px"></div>`;
}
function imgLoadFile(fileInput, cb){
  const f = fileInput.files[0]; if (!f) return;
  const img = new Image();
  const reader = new FileReader();
  reader.onload = e => { img.onload = () => cb(img, f); img.src = e.target.result; };
  reader.readAsDataURL(f);
}

TOOL_CUSTOM['image-resizer'] = {
  body: () => imgUploadBody(`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Width (px)</label><input type="number" class="fc" id="ir-w"></div>
      <div class="fg"><label class="fl">Height (px)</label><input type="number" class="fc" id="ir-h"></div>
    </div>
    <label style="display:flex;gap:8px;align-items:center;font-size:13px;margin-bottom:12px;cursor:pointer"><input type="checkbox" id="ir-lock" checked> Lock aspect ratio</label>
    <button class="btn btn-p" id="ir-btn" disabled onclick="irResize()">Resize & Download</button>`),
  init: () => {
    let img=null, ratio=1;
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{
      img=image; ratio=image.width/image.height;
      document.getElementById('ir-w').value=image.width; document.getElementById('ir-h').value=image.height;
      document.getElementById('ir-btn').disabled=false;
      document.getElementById('im-result').innerHTML = `<div style="font-size:12px;color:var(--tm)">Original: ${image.width}×${image.height}px</div>`;
    }));
    document.getElementById('ir-w').addEventListener('input', ()=>{ if(document.getElementById('ir-lock').checked) document.getElementById('ir-h').value = Math.round(document.getElementById('ir-w').value/ratio); });
    document.getElementById('ir-h').addEventListener('input', ()=>{ if(document.getElementById('ir-lock').checked) document.getElementById('ir-w').value = Math.round(document.getElementById('ir-h').value*ratio); });
    window.irResize = () => {
      const w=parseInt(document.getElementById('ir-w').value), h=parseInt(document.getElementById('ir-h').value);
      const c = document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      const url = c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="resized.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
  }
};
TOOL_CUSTOM['image-compressor'] = {
  body: () => imgUploadBody(`<div class="fg"><label class="fl">Quality: <strong id="icq-lbl">80%</strong></label><input type="range" min="10" max="100" value="80" id="ic-q" oninput="document.getElementById('icq-lbl').textContent=this.value+'%';icRun()"></div>`),
  init: () => {
    let img=null, origSize=0;
    document.getElementById('im-file').addEventListener('change', e => { origSize=e.target.files[0].size; imgLoadFile(e.target, (image)=>{ img=image; icRun(); }); });
    window.icRun = () => {
      if (!img) return;
      const c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
      c.getContext('2d').drawImage(img,0,0);
      const q = document.getElementById('ic-q').value/100;
      const url = c.toDataURL('image/jpeg', q);
      const newSize = Math.round((url.length-22)*0.75);
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px">
        ${statBlock([['Original',Math.round(origSize/1024)+' KB'],['Compressed',Math.round(newSize/1024)+' KB'],['Saved',Math.round((1-newSize/origSize)*100)+'%']])}
        <a href="${url}" download="compressed.jpg" class="btn btn-p btn-sm">Download JPG</a>`;
    };
  }
};
TOOL_CUSTOM['jpg-to-png'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const c=document.createElement('canvas'); c.width=img.width; c.height=img.height; c.getContext('2d').drawImage(img,0,0);
    const url=c.toDataURL('image/png');
    document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="converted.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
  })); }
};
TOOL_CUSTOM['png-to-jpg'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
    const ctx=c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0);
    const url=c.toDataURL('image/jpeg',0.92);
    document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="converted.jpg" class="btn btn-p btn-sm" style="margin-top:10px">Download JPG</a>`;
  })); }
};
TOOL_CUSTOM['image-crop'] = {
  body: () => imgUploadBody(`<div style="position:relative;display:inline-block;max-width:100%" id="ic2-wrap"></div><div class="bgrp" style="margin-top:10px"><button class="btn btn-p btn-sm" onclick="icCrop()">Crop & Download</button></div>`),
  init: () => {
    let img=null, sel=null, startX,startY,dragging=false, dispScale=1;
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{
      img=image;
      const wrap = document.getElementById('ic2-wrap');
      const maxW = 560; dispScale = Math.min(1, maxW/image.width);
      wrap.innerHTML = `<img id="ic2-img" src="${image.src}" style="width:${image.width*dispScale}px;display:block;cursor:crosshair;user-select:none"><div id="ic2-sel" style="position:absolute;border:2px dashed #1D4ED8;background:rgba(29,78,216,.15);display:none;pointer-events:none"></div>`;
      const im = document.getElementById('ic2-img'), selEl = document.getElementById('ic2-sel');
      im.addEventListener('mousedown', ev => { const r=im.getBoundingClientRect(); startX=ev.clientX-r.left; startY=ev.clientY-r.top; dragging=true; selEl.style.display='block'; });
      window.addEventListener('mousemove', ev => { if(!dragging) return; const r=im.getBoundingClientRect(); const x=Math.max(0,Math.min(ev.clientX-r.left,r.width)); const y=Math.max(0,Math.min(ev.clientY-r.top,r.height));
        const l=Math.min(x,startX), t=Math.min(y,startY), w=Math.abs(x-startX), h=Math.abs(y-startY);
        selEl.style.left=l+'px'; selEl.style.top=t+'px'; selEl.style.width=w+'px'; selEl.style.height=h+'px';
        sel={x:l/dispScale,y:t/dispScale,w:w/dispScale,h:h/dispScale}; });
      window.addEventListener('mouseup', ()=>dragging=false);
    }));
    window.icCrop = () => {
      if (!img || !sel || !sel.w || !sel.h) { toast('Drag on the image to select a crop area first','er'); return; }
      const c=document.createElement('canvas'); c.width=sel.w; c.height=sel.h;
      c.getContext('2d').drawImage(img, sel.x, sel.y, sel.w, sel.h, 0,0, sel.w, sel.h);
      const url=c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="cropped.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
  }
};
TOOL_CUSTOM['image-color-picker'] = {
  body: () => imgUploadBody(`<div style="font-size:12px;color:var(--tm);margin-bottom:10px">Click anywhere on the uploaded image to read its color.</div><canvas id="cp-canvas" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px;cursor:crosshair"></canvas>`),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const canvas = document.getElementById('cp-canvas');
    const scale = Math.min(1, 560/img.width);
    canvas.width = img.width*scale; canvas.height = img.height*scale;
    const ctx = canvas.getContext('2d'); ctx.drawImage(img,0,0,canvas.width,canvas.height);
    canvas.onclick = ev => {
      const r = canvas.getBoundingClientRect();
      const x = Math.round((ev.clientX-r.left) * (canvas.width/r.width)), y = Math.round((ev.clientY-r.top) * (canvas.height/r.height));
      const [R,G,B] = ctx.getImageData(x,y,1,1).data;
      const hex = '#'+[R,G,B].map(v=>v.toString(16).padStart(2,'0')).join('');
      document.getElementById('im-result').innerHTML = `<div style="display:flex;gap:14px;align-items:center;margin-top:10px"><div style="width:56px;height:56px;border-radius:8px;border:1px solid var(--bdr);background:${hex}"></div><div>${statBlock([['HEX',hex.toUpperCase()],['RGB',`${R}, ${G}, ${B}`]])}</div></div>`;
    };
  })); }
};
TOOL_CUSTOM['image-to-base64'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => { const f=e.target.files[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = ev => { document.getElementById('im-result').innerHTML = `${statBlock([['Size',Math.round(f.size/1024)+' KB']])}<div class="fg"><label class="fl">Base64 Data URI <button class="cpbtn" onclick="copyText(document.getElementById('b64img-out').value,this)">Copy</button></label><textarea class="fc mono" id="b64img-out" rows="8" readonly>${ev.target.result}</textarea></div>`; };
    reader.readAsDataURL(f);
  }); }
};
TOOL_CUSTOM['base64-to-image'] = {
  body: () => `<div class="fg"><label class="fl">Base64 String (with or without data: prefix)</label><textarea class="fc mono" id="b2i-in" rows="6"></textarea></div><button class="btn btn-p" onclick="b2iRun()">Preview Image</button><div id="b2i-out" style="margin-top:14px"></div>`,
  init: () => { window.b2iRun = () => {
    let s = document.getElementById('b2i-in').value.trim();
    if (!s) return;
    if (!s.startsWith('data:')) s = 'data:image/png;base64,'+s;
    const img = new Image();
    img.onerror = () => document.getElementById('b2i-out').innerHTML = '<div class="alert alert-err">Invalid Base64 image data.</div>';
    img.onload = () => document.getElementById('b2i-out').innerHTML = `<img src="${s}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${s}" download="image.png" class="btn btn-p btn-sm" style="margin-top:10px">Download</a>`;
    img.src = s;
  };}
};
TOOL_CUSTOM['image-rotator'] = {
  body: () => imgUploadBody(`<div class="bgrp" style="margin-bottom:12px"><button class="btn btn-s btn-sm" onclick="imRotate(90)">Rotate 90°</button><button class="btn btn-s btn-sm" onclick="imRotate(-90)">Rotate -90°</button><button class="btn btn-s btn-sm" onclick="imFlip('h')">Flip Horizontal</button><button class="btn btn-s btn-sm" onclick="imFlip('v')">Flip Vertical</button></div>`),
  init: () => {
    let img=null, angle=0, flipH=1, flipV=1;
    const render = () => {
      if (!img) return;
      const rad = angle*Math.PI/180;
      const swap = angle%180!==0;
      const c = document.createElement('canvas'); c.width = swap?img.height:img.width; c.height = swap?img.width:img.height;
      const ctx = c.getContext('2d'); ctx.translate(c.width/2,c.height/2); ctx.rotate(rad); ctx.scale(flipH,flipV);
      ctx.drawImage(img,-img.width/2,-img.height/2);
      const url = c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="edited.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{ img=image; angle=0; flipH=1; flipV=1; render(); }));
    window.imRotate = (d) => { angle=(angle+d+360)%360; render(); };
    window.imFlip = (axis) => { if (axis==='h') flipH*=-1; else flipV*=-1; render(); };
  }
};
TOOL_CUSTOM['favicon-generator'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const sizes=[16,32,48]; let html='<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">';
    sizes.forEach(s => { const c=document.createElement('canvas'); c.width=s; c.height=s; c.getContext('2d').drawImage(img,0,0,s,s); const url=c.toDataURL('image/png');
      html += `<div style="text-align:center"><img src="${url}" style="width:${s}px;height:${s}px;border:1px solid var(--bdr);border-radius:4px"><div style="font-size:11px;margin-top:4px">${s}×${s}</div><a href="${url}" download="favicon-${s}.png" class="cpbtn" style="display:block;margin-top:4px">Download</a></div>`; });
    document.getElementById('im-result').innerHTML = html+'</div>';
  })); }
};

// ---------- hash-generator ----------
TOOL_CUSTOM['hash-generator'] = {
  body: () => `<div class="fg"><label class="fl">Input Text</label><textarea class="fc" id="hg-in" rows="5" oninput="hgRun()"></textarea></div><div id="hg-out"></div>`,
  init: () => {
    window.hgRun = async () => {
      const t = document.getElementById('hg-in').value;
      const out = document.getElementById('hg-out');
      if (!t) { out.innerHTML=''; return; }
      const md5 = SparkMD5.hash(t);
      const enc = new TextEncoder().encode(t);
      const algos = ['SHA-1','SHA-256','SHA-384','SHA-512'];
      let html = `<div class="trow"><span>MD5</span><button class="cpbtn mono" style="max-width:100%;overflow:hidden;text-overflow:ellipsis" onclick="copyText('${md5}',this)">${md5}</button></div>`;
      out.innerHTML = html + algos.map(a=>`<div class="trow"><span>${a}</span><span class="mono" id="hg-${a}" style="font-size:11px;word-break:break-all;max-width:70%;text-align:right">computing…</span></div>`).join('');
      for (const a of algos) {
        const buf = await crypto.subtle.digest(a, enc);
        const hex = [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
        const el = document.getElementById('hg-'+a); if (el) el.textContent = hex;
      }
    };
  }
};

// ---------- regex-tester ----------
TOOL_CUSTOM['regex-tester'] = {
  body: () => `
    <div class="fg"><label class="fl">Pattern</label><input class="fc mono" id="rx-pat" placeholder="e.g. \\\\d+" oninput="rxRun()"></div>
    <div class="fg"><label class="fl">Flags</label><input class="fc mono" id="rx-flags" value="g" oninput="rxRun()" style="max-width:100px"></div>
    <div class="fg"><label class="fl">Test String</label><textarea class="fc" id="rx-str" rows="6" oninput="rxRun()"></textarea></div>
    <div id="rx-out"></div>`,
  init: () => { window.rxRun = () => {
    const pat = document.getElementById('rx-pat').value, flags = document.getElementById('rx-flags').value, str = document.getElementById('rx-str').value;
    const out = document.getElementById('rx-out');
    if (!pat) { out.innerHTML=''; return; }
    try {
      const re = new RegExp(pat, flags);
      const matches = [...str.matchAll(flags.includes('g')?re:new RegExp(pat,flags+'g'))];
      let highlighted = esc(str);
      if (matches.length) {
        let result='', last=0;
        matches.forEach(m => { result += esc(str.slice(last,m.index)) + '<mark style="background:#FEF08A">'+esc(m[0])+'</mark>'; last = m.index+m[0].length; });
        result += esc(str.slice(last));
        highlighted = result;
      }
      out.innerHTML = `<div class="alert alert-ok">${matches.length} match(es)</div><div class="res-box" style="white-space:pre-wrap">${highlighted||'(empty)'}</div>` +
        (matches.length ? '<div style="margin-top:10px">'+matches.slice(0,20).map((m,i)=>`<div class="trow"><span>Match ${i+1}</span><span class="mono">${esc(m[0])}${m.length>1?' - groups: '+m.slice(1).map(g=>esc(g??'')).join(', '):''}</span></div>`).join('')+'</div>' : '');
    } catch(e){ out.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`; }
  };}
};

// ---------- color-converter ----------
TOOL_CUSTOM['color-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Color</label><div style="display:flex;gap:10px"><input type="color" id="cc-picker" value="#1D4ED8" style="width:48px;height:38px;padding:2px;border:1px solid var(--bdr);border-radius:6px" oninput="ccFromPicker()"><input class="fc mono" id="cc-hex" value="#1D4ED8" oninput="ccFromHex()"></div></div>
    <div id="cc-out" style="margin-top:14px"></div>`,
  init: () => {
    const hexToRgb = h => { h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255]; };
    const rgbToHsl = (r,g,b) => { r/=255;g/=255;b/=255;const max=Math.max(r,g,b),min=Math.min(r,g,b);let h,s,l=(max+min)/2;
      if(max===min){h=s=0;}else{const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);
        switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;break;}h/=6;}
      return [Math.round(h*360),Math.round(s*100),Math.round(l*100)]; };
    const render = (hex) => {
      const [r,g,b] = hexToRgb(hex); const [h,s,l] = rgbToHsl(r,g,b);
      document.getElementById('cc-out').innerHTML = `<div style="width:100%;height:70px;border-radius:8px;border:1px solid var(--bdr);background:${hex};margin-bottom:12px"></div>` +
        statBlock([['HEX',hex.toUpperCase()],['RGB',`rgb(${r}, ${g}, ${b})`],['HSL',`hsl(${h}, ${s}%, ${l}%)`],['CMYK',cmyk(r,g,b)]]);
    };
    const cmyk = (r,g,b) => { r/=255;g/=255;b/=255; const k=1-Math.max(r,g,b); if(k===1) return '0, 0, 0, 100'; const c=(1-r-k)/(1-k),m=(1-g-k)/(1-k),y=(1-b-k)/(1-k);
      return `${Math.round(c*100)}, ${Math.round(m*100)}, ${Math.round(y*100)}, ${Math.round(k*100)}`; };
    window.ccFromPicker = () => { const h = document.getElementById('cc-picker').value; document.getElementById('cc-hex').value=h; render(h); };
    window.ccFromHex = () => { let h = document.getElementById('cc-hex').value.trim(); if(!/^#?[0-9a-fA-F]{3}$|^#?[0-9a-fA-F]{6}$/.test(h)) return; if(!h.startsWith('#')) h='#'+h; document.getElementById('cc-picker').value = h.length===4?'#'+h[1]+h[1]+h[2]+h[2]+h[3]+h[3]:h; render(h); };
    render('#1D4ED8');
  }
};

// ---------- jwt-decoder ----------
TOOL_CUSTOM['jwt-decoder'] = {
  body: () => `<div class="fg"><label class="fl">JWT Token</label><textarea class="fc mono" id="jw-in" rows="5" oninput="jwRun()"></textarea></div><div id="jw-out"></div>`,
  init: () => { window.jwRun = () => {
    const t = document.getElementById('jw-in').value.trim();
    const out = document.getElementById('jw-out');
    if (!t) { out.innerHTML=''; return; }
    const parts = t.split('.');
    if (parts.length < 2) { out.innerHTML = '<div class="alert alert-err">Not a valid JWT (expected header.payload.signature).</div>'; return; }
    try {
      const dec = s => JSON.parse(decodeURIComponent(escape(atob(s.replace(/-/g,'+').replace(/_/g,'/')))));
      const header = dec(parts[0]), payload = dec(parts[1]);
      out.innerHTML = `<div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin-bottom:6px">Header</div><pre class="res-box mono">${esc(JSON.stringify(header,null,2))}</pre>
        <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:14px 0 6px">Payload</div><pre class="res-box mono">${esc(JSON.stringify(payload,null,2))}</pre>
        <div class="alert alert-info" style="margin-top:12px">Signature is not verified by this tool.</div>`;
    } catch(e){ out.innerHTML = `<div class="alert alert-err">Could not decode: ${esc(e.message)}</div>`; }
  };}
};

// ---------- markdown-html ----------
TOOL_CUSTOM['markdown-html'] = {
  body: () => `<div class="fg"><label class="fl">Markdown</label><textarea class="fc mono" id="md-in" rows="10" oninput="mdRun()" placeholder="# Heading\n\n**bold** _italic_\n\n- item one\n- item two\n\n[link](https://example.com)"></textarea></div>
    <div class="fg"><label class="fl">HTML Output <button class="cpbtn" onclick="copyText(document.getElementById('md-out').value,this)">Copy</button></label><textarea class="fc mono" id="md-out" rows="10" readonly></textarea></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:14px 0 6px">Preview</div><div class="res-box" id="md-preview"></div>`,
  init: () => { window.mdRun = () => {
    const src = document.getElementById('md-in').value;
    const html = mdToHtml(src);
    document.getElementById('md-out').value = html;
    document.getElementById('md-preview').innerHTML = html;
  }; mdRun(); }
};
function mdToHtml(src){
  let lines = src.split('\n'); let html=''; let inList=false;
  const inlineFmt = s => esc(s).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>').replace(/_(.+?)_/g,'<em>$1</em>').replace(/`(.+?)`/g,'<code>$1</code>').replace(/\[(.+?)\]\((.+?)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>');
  lines.forEach(line => {
    const h = line.match(/^(#{1,6})\s+(.*)/);
    if (h) { if(inList){html+='</ul>';inList=false;} html += `<h${h[1].length}>${inlineFmt(h[2])}</h${h[1].length}>`; return; }
    const li = line.match(/^[-*]\s+(.*)/);
    if (li) { if(!inList){html+='<ul>';inList=true;} html += `<li>${inlineFmt(li[1])}</li>`; return; }
    if (inList) { html+='</ul>'; inList=false; }
    if (line.trim()==='') return;
    html += `<p>${inlineFmt(line)}</p>`;
  });
  if (inList) html += '</ul>';
  return html;
}

// ---------- timestamp-converter / unix-timestamp ----------
TOOL_CUSTOM['timestamp-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Unix Timestamp</label><input class="fc mono" id="tc-ts" placeholder="e.g. 1700000000" oninput="tcFromTs()"></div>
    <div class="fg"><label class="fl">Or pick a date/time</label><input type="datetime-local" class="fc" id="tc-dt" oninput="tcFromDt()"></div>
    <div id="tc-out"></div>`,
  init: () => {
    window.tcFromTs = () => {
      let v = document.getElementById('tc-ts').value.trim(); if (!v) return;
      let n = parseInt(v); if (String(n).length <= 10) n*=1000;
      const d = new Date(n);
      if (isNaN(d)) { document.getElementById('tc-out').innerHTML = '<div class="alert alert-err">Invalid timestamp.</div>'; return; }
      document.getElementById('tc-dt').value = new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);
      document.getElementById('tc-out').innerHTML = statBlock([['UTC',d.toUTCString()],['Local',d.toString()],['ISO',d.toISOString()]]);
    };
    window.tcFromDt = () => {
      const v = document.getElementById('tc-dt').value; if (!v) return;
      const d = new Date(v); const ts = Math.floor(d.getTime()/1000);
      document.getElementById('tc-ts').value = ts;
      document.getElementById('tc-out').innerHTML = statBlock([['Unix (seconds)',ts],['Unix (ms)',d.getTime()],['ISO',d.toISOString()]]);
    };
    document.getElementById('tc-ts').value = Math.floor(Date.now()/1000);
    tcFromTs();
  }
};
TOOL_CUSTOM['unix-timestamp'] = {
  body: () => `<div class="res-box ok mono" id="ut-now" style="font-size:28px;text-align:center;font-weight:700"></div><div class="bgrp" style="margin-top:12px;justify-content:center"><button class="cpbtn" onclick="copyText(document.getElementById('ut-now').textContent,this)">Copy</button></div>`,
  init: () => {
    const tick = () => { const el=document.getElementById('ut-now'); if (!el) { clearInterval(window.__utInt); return; } el.textContent = Math.floor(Date.now()/1000); };
    tick(); window.__utInt = setInterval(tick, 1000);
  }
};

// ---------- temperature-converter ----------
TOOL_CUSTOM['temperature-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Value</label><input type="number" class="fc" id="tp-val" value="100" oninput="tpRun()"></div>
    <div class="fg"><label class="fl">From</label><select class="fc" id="tp-from" onchange="tpRun()"><option value="c">Celsius (°C)</option><option value="f">Fahrenheit (°F)</option><option value="k">Kelvin (K)</option></select></div>
    <div id="tp-out"></div>`,
  init: () => { window.tpRun = () => {
    const v = parseFloat(document.getElementById('tp-val').value); if (isNaN(v)) return;
    const from = document.getElementById('tp-from').value;
    let c; if (from==='c') c=v; else if (from==='f') c=(v-32)*5/9; else c=v-273.15;
    const f = c*9/5+32, k = c+273.15;
    document.getElementById('tp-out').innerHTML = statBlock([['Celsius',round4(c)+' °C'],['Fahrenheit',round4(f)+' °F'],['Kelvin',round4(k)+' K']]);
  }; tpRun(); }
};

// ---------- fuel-economy ----------
TOOL_CUSTOM['fuel-economy'] = {
  body: () => `
    <div class="fg"><label class="fl">Value</label><input type="number" class="fc" id="fe-val" value="30" oninput="feRun()"></div>
    <div class="fg"><label class="fl">From</label><select class="fc" id="fe-from" onchange="feRun()"><option value="mpgus">Miles per Gallon (US)</option><option value="mpguk">Miles per Gallon (UK)</option><option value="l100">L / 100km</option><option value="kml">km / Liter</option></select></div>
    <div id="fe-out"></div>`,
  init: () => { window.feRun = () => {
    const v = parseFloat(document.getElementById('fe-val').value); if (!v) return;
    const from = document.getElementById('fe-from').value;
    let l100;
    if (from==='mpgus') l100 = 235.214/v; else if (from==='mpguk') l100 = 282.481/v; else if (from==='l100') l100=v; else l100 = 100/v;
    const mpgus = 235.214/l100, mpguk = 282.481/l100, kml = 100/l100;
    document.getElementById('fe-out').innerHTML = statBlock([['MPG (US)',round4(mpgus)],['MPG (UK)',round4(mpguk)],['L/100km',round4(l100)],['km/L',round4(kml)]]);
  }; feRun(); }
};

// ---------- shoe-size ----------
const SHOE_SIZES = [ // [US, UK, EU]
  [6,5.5,39],[6.5,6,39.5],[7,6.5,40],[7.5,7,40.5],[8,7.5,41],[8.5,8,42],[9,8.5,42.5],[9.5,9,43],[10,9.5,44],[10.5,10,44.5],[11,10.5,45],[12,11.5,46],[13,12.5,47]
];
TOOL_CUSTOM['shoe-size'] = {
  body: () => `
    <div class="fg"><label class="fl">System</label><select class="fc" id="ss-from" onchange="ssRun()"><option value="0">US</option><option value="1">UK</option><option value="2">EU</option></select></div>
    <div class="fg"><label class="fl">Size</label><input type="number" step="0.5" class="fc" id="ss-val" value="9" oninput="ssRun()"></div>
    <div id="ss-out"></div><div class="alert alert-info" style="margin-top:10px">Approximate - sizing varies by brand.</div>`,
  init: () => { window.ssRun = () => {
    const col = parseInt(document.getElementById('ss-from').value);
    const v = parseFloat(document.getElementById('ss-val').value); if (isNaN(v)) return;
    let closest = SHOE_SIZES[0], diff=Infinity;
    SHOE_SIZES.forEach(row => { const d=Math.abs(row[col]-v); if (d<diff){diff=d;closest=row;} });
    document.getElementById('ss-out').innerHTML = statBlock([['US',closest[0]],['UK',closest[1]],['EU',closest[2]]]);
  }; ssRun(); }
};

// ---------- date-difference ----------
TOOL_CUSTOM['date-difference'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Start Date</label><input type="date" class="fc" id="dd-a" oninput="ddRun()"></div>
      <div class="fg"><label class="fl">End Date</label><input type="date" class="fc" id="dd-b" oninput="ddRun()"></div>
    </div>
    <div id="dd-out"></div>`,
  init: () => { window.ddRun = () => {
    const a = document.getElementById('dd-a').value, b = document.getElementById('dd-b').value;
    if (!a || !b) return;
    let d1 = new Date(a+'T00:00:00'), d2 = new Date(b+'T00:00:00');
    if (d1>d2) [d1,d2]=[d2,d1];
    let y=d2.getFullYear()-d1.getFullYear(), m=d2.getMonth()-d1.getMonth(), d=d2.getDate()-d1.getDate();
    if (d<0){ m--; d += new Date(d2.getFullYear(),d2.getMonth(),0).getDate(); }
    if (m<0){ y--; m+=12; }
    const totalDays = Math.round((d2-d1)/86400000);
    document.getElementById('dd-out').innerHTML = statBlock([['Years',y],['Months',m],['Days',d],['Total Days',totalDays.toLocaleString()],['Total Weeks',Math.round(totalDays/7).toLocaleString()],['Total Months',(y*12+m)]]);
  };}
};

// ---------- timezone-converter / world-clock ----------
const TZ_LIST = [['UTC','UTC'],['America/New_York','New York'],['America/Los_Angeles','Los Angeles'],['America/Sao_Paulo','São Paulo'],['Europe/London','London'],['Europe/Paris','Paris'],['Europe/Moscow','Moscow'],['Asia/Dubai','Dubai'],['Asia/Kolkata','India (IST)'],['Asia/Dhaka','Dhaka'],['Asia/Bangkok','Bangkok'],['Asia/Shanghai','Shanghai'],['Asia/Tokyo','Tokyo'],['Australia/Sydney','Sydney'],['Pacific/Auckland','Auckland']];
function renderClocks(containerId){
  const el = document.getElementById(containerId); if (!el) return;
  el.innerHTML = TZ_LIST.map(([tz,label]) => `<div class="trow"><span>${label}</span><strong class="mono" id="clk-${tz.replace(/\W/g,'')}"></strong></div>`).join('');
  const tick = () => { TZ_LIST.forEach(([tz]) => { const e=document.getElementById('clk-'+tz.replace(/\W/g,'')); if(!e) return;
    e.textContent = new Date().toLocaleString('en-US',{timeZone:tz,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true,month:'short',day:'numeric'}); }); };
  tick();
  if (window.__clkInt) clearInterval(window.__clkInt);
  window.__clkInt = setInterval(()=>{ if (!document.getElementById(containerId)) { clearInterval(window.__clkInt); return; } tick(); }, 1000);
}
TOOL_CUSTOM['timezone-converter'] = { body: () => `<div id="tz-list"></div>`, init: () => renderClocks('tz-list') };
TOOL_CUSTOM['world-clock'] = { body: () => `<div id="wc-list"></div>`, init: () => renderClocks('wc-list') };

// ---------- stopwatch ----------
TOOL_CUSTOM['stopwatch'] = {
  body: () => `<div class="res-box ok mono" id="sw-disp" style="font-size:36px;text-align:center;font-weight:700">00:00:00.0</div>
    <div class="bgrp" style="justify-content:center;margin-top:14px"><button class="btn btn-p" id="sw-start" onclick="swToggle()">Start</button><button class="btn btn-s" onclick="swLap()">Lap</button><button class="btn btn-s" onclick="swReset()">Reset</button></div>
    <div id="sw-laps" style="margin-top:14px"></div>`,
  init: () => {
    let running=false, startTime=0, elapsed=0, laps=[], raf;
    const fmt = ms => { const h=Math.floor(ms/3600000), m=Math.floor(ms%3600000/60000), s=Math.floor(ms%60000/1000), t=Math.floor(ms%1000/100);
      return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${t}`; };
    const tick = () => { if (!document.getElementById('sw-disp')) { cancelAnimationFrame(raf); return; } if (running) { document.getElementById('sw-disp').textContent = fmt(elapsed+Date.now()-startTime); raf=requestAnimationFrame(tick); } };
    window.swToggle = () => { running=!running; const btn=document.getElementById('sw-start');
      if (running) { startTime=Date.now(); btn.textContent='Pause'; tick(); } else { elapsed += Date.now()-startTime; btn.textContent='Resume'; } };
    window.swLap = () => { const cur = running ? elapsed+Date.now()-startTime : elapsed; laps.unshift(cur); document.getElementById('sw-laps').innerHTML = laps.map((l,i)=>`<div class="trow"><span>Lap ${laps.length-i}</span><strong class="mono">${fmt(l)}</strong></div>`).join(''); };
    window.swReset = () => { running=false; elapsed=0; laps=[]; document.getElementById('sw-disp').textContent='00:00:00.0'; document.getElementById('sw-start').textContent='Start'; document.getElementById('sw-laps').innerHTML=''; };
  }
};

// ---------- countdown-timer ----------
TOOL_CUSTOM['countdown-timer'] = {
  body: () => `<div class="fg"><label class="fl">Target Date & Time</label><input type="datetime-local" class="fc" id="cd-target"></div><button class="btn btn-p" onclick="cdStart()">Start Countdown</button>
    <div class="res-box ok mono" id="cd-disp" style="font-size:24px;text-align:center;font-weight:700;margin-top:14px">Set a target above</div>`,
  init: () => { window.cdStart = () => {
    const v = document.getElementById('cd-target').value; if (!v) return;
    const target = new Date(v).getTime();
    if (window.__cdInt) clearInterval(window.__cdInt);
    const tick = () => {
      const disp = document.getElementById('cd-disp'); if (!disp) { clearInterval(window.__cdInt); return; }
      const diff = target - Date.now();
      if (diff<=0) { disp.textContent = 'Time reached!'; clearInterval(window.__cdInt); return; }
      const d=Math.floor(diff/86400000), h=Math.floor(diff%86400000/3600000), m=Math.floor(diff%3600000/60000), s=Math.floor(diff%60000/1000);
      disp.textContent = `${d}d ${h}h ${m}m ${s}s`;
    };
    tick(); window.__cdInt = setInterval(tick,1000);
  };}
};

// ---------- pomodoro-timer ----------
TOOL_CUSTOM['pomodoro-timer'] = {
  body: () => `<div class="res-box ok mono" id="po-disp" style="font-size:40px;text-align:center;font-weight:700">25:00</div>
    <div style="text-align:center;font-size:13px;color:var(--tm);margin-top:6px" id="po-mode">Focus session</div>
    <div class="bgrp" style="justify-content:center;margin-top:14px"><button class="btn btn-p" id="po-btn" onclick="poToggle()">Start</button><button class="btn btn-s" onclick="poReset()">Reset</button></div>`,
  init: () => {
    let secs=25*60, running=false, focus=true;
    const render = () => { const el=document.getElementById('po-disp'); if (!el) return; const m=Math.floor(secs/60), s=secs%60; el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };
    window.poToggle = () => {
      running = !running; document.getElementById('po-btn').textContent = running?'Pause':'Resume';
      if (running) { if (window.__poInt) clearInterval(window.__poInt); window.__poInt = setInterval(()=>{
        if (!document.getElementById('po-disp')) { clearInterval(window.__poInt); return; }
        secs--; if (secs<=0) { focus=!focus; secs = focus?25*60:5*60; document.getElementById('po-mode').textContent = focus?'Focus session':'Break'; toast(focus?'Break over - back to focus':'Focus done - take a break','ok'); }
        render();
      },1000); }
      else clearInterval(window.__poInt);
    };
    window.poReset = () => { running=false; if(window.__poInt) clearInterval(window.__poInt); secs=25*60; focus=true; document.getElementById('po-mode').textContent='Focus session'; document.getElementById('po-btn').textContent='Start'; render(); };
    render();
  }
};

// ---------- qr-generator ----------
TOOL_CUSTOM['qr-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Content Type</label><select class="fc" id="qr-type" onchange="qrFields()"><option value="text">Text / URL</option><option value="email">Email</option><option value="phone">Phone</option><option value="sms">SMS</option><option value="wifi">Wi-Fi</option></select></div>
    <div id="qr-fields"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Size (px)</label><select class="fc" id="qr-size"><option value="128">128</option><option value="200" selected>200</option><option value="300">300</option><option value="400">400</option></select></div>
      <div class="fg"><label class="fl">Error Correction</label><select class="fc" id="qr-ec"><option value="L">L (Low)</option><option value="M" selected>M (Medium)</option><option value="Q">Q (High)</option><option value="H">H (Very High)</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="qrGen()">Generate QR Code</button>
    <div id="qr-result" style="margin-top:18px;text-align:center"></div>`,
  init: () => {
    window.qrFields = () => {
      const type = document.getElementById('qr-type').value;
      const f = document.getElementById('qr-fields');
      const map = {
        text: `<div class="fg"><label class="fl">Text or URL</label><input class="fc" id="qr-text" placeholder="https://example.com"></div>`,
        email: `<div class="fg"><label class="fl">Email</label><input type="email" class="fc" id="qr-text" placeholder="hello@example.com"></div>`,
        phone: `<div class="fg"><label class="fl">Phone</label><input class="fc" id="qr-text" placeholder="+1234567890"></div>`,
        sms: `<div class="fg"><label class="fl">Phone</label><input class="fc" id="qr-text" placeholder="+1234567890"></div><div class="fg"><label class="fl">Message</label><textarea class="fc" id="qr-msg" rows="2"></textarea></div>`,
        wifi: `<div class="fg"><label class="fl">Network Name (SSID)</label><input class="fc" id="qr-text"></div><div class="fg"><label class="fl">Password</label><input class="fc" id="qr-wifi-pass"></div><div class="fg"><label class="fl">Security</label><select class="fc" id="qr-wifi-sec"><option value="WPA">WPA/WPA2</option><option value="WEP">WEP</option><option value="nopass">None</option></select></div>`,
      };
      f.innerHTML = map[type] || map.text;
    };
    window.qrGen = () => {
      const type = document.getElementById('qr-type').value;
      const textEl = document.getElementById('qr-text');
      if (!textEl || !textEl.value.trim()) { document.getElementById('qr-result').innerHTML = '<div class="alert alert-warn">Enter some content first.</div>'; return; }
      let data = textEl.value.trim();
      if (type==='email') data = 'mailto:'+data;
      else if (type==='phone') data = 'tel:'+data;
      else if (type==='sms') { const msg=document.getElementById('qr-msg'); data = 'sms:'+data+(msg&&msg.value?'?body='+encodeURIComponent(msg.value):''); }
      else if (type==='wifi') { const pass=document.getElementById('qr-wifi-pass').value, sec=document.getElementById('qr-wifi-sec').value; data = `WIFI:T:${sec};S:${data};P:${pass};;`; }
      const size = parseInt(document.getElementById('qr-size').value);
      const ec = document.getElementById('qr-ec').value;
      try {
        const qr = qrcode(0, ec);
        qr.addData(data); qr.make();
        const cellSize = Math.max(2, Math.floor(size / qr.getModuleCount()));
        const svg = qr.createSvgTag({cellSize, margin:4});
        document.getElementById('qr-result').innerHTML = `<div style="display:inline-block;background:#fff;padding:14px;border-radius:12px;border:1px solid var(--bdr)">${svg}</div>
          <div style="margin-top:12px"><button class="btn btn-s btn-sm" onclick="qrDownload()">Download PNG</button></div>`;
      } catch(e) { document.getElementById('qr-result').innerHTML = `<div class="alert alert-err">Could not generate QR code: ${esc(e.message)}</div>`; }
    };
    window.qrDownload = () => {
      const svgEl = document.querySelector('#qr-result svg');
      if (!svgEl) return;
      const svgData = new XMLSerializer().serializeToString(svgEl);
      const img = new Image();
      const svgBlob = new Blob([svgData], {type:'image/svg+xml;charset=utf-8'});
      const url = URL.createObjectURL(svgBlob);
      img.onload = () => {
        const c = document.createElement('canvas'); c.width=img.width||300; c.height=img.height||300;
        const ctx = c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0);
        const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'qrcode.png'; a.click();
        URL.revokeObjectURL(url);
      };
      img.src = url;
    };
    qrFields();
  }
};

// ---------- ip-lookup ----------
TOOL_CUSTOM['ip-lookup'] = {
  body: () => `<div class="res-box ok mono" id="ip-disp" style="font-size:22px;text-align:center;font-weight:700">Looking up…</div>`,
  init: async () => {
    try {
      const res = await fetch('https://api.ipify.org?format=json');
      const data = await res.json();
      document.getElementById('ip-disp').textContent = data.ip;
    } catch(e) { const el=document.getElementById('ip-disp'); if (el) { el.className='res-box er'; el.textContent = 'Could not reach the lookup service. Check your connection.'; } }
  }
};

// ---------- coin-flip / dice-roller ----------
TOOL_CUSTOM['coin-flip'] = {
  body: () => `<div style="text-align:center"><div id="cf-coin" style="width:120px;height:120px;border-radius:50%;background:var(--p);color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;margin:0 auto 18px">Flip!</div><button class="btn btn-p" onclick="cfFlip()">Flip Coin</button><div id="cf-stats" style="margin-top:16px"></div></div>`,
  init: () => { let heads=0, tails=0; window.cfFlip = () => {
    const result = Math.random()<0.5 ? 'Heads' : 'Tails'; if (result==='Heads') heads++; else tails++;
    document.getElementById('cf-coin').textContent = result;
    document.getElementById('cf-stats').innerHTML = statBlock([['Heads',heads],['Tails',tails]]);
  };}
};
TOOL_CUSTOM['dice-roller'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Number of Dice</label><input type="number" class="fc" id="dr-n" value="2" min="1" max="10"></div>
      <div class="fg"><label class="fl">Sides</label><select class="fc" id="dr-sides"><option value="4">d4</option><option value="6" selected>d6</option><option value="8">d8</option><option value="10">d10</option><option value="12">d12</option><option value="20">d20</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="drRoll()">Roll Dice</button>
    <div id="dr-out" style="margin-top:16px"></div>`,
  init: () => { window.drRoll = () => {
    const n = Math.min(10,Math.max(1,parseInt(document.getElementById('dr-n').value)||1));
    const sides = parseInt(document.getElementById('dr-sides').value);
    const rolls = Array.from({length:n},()=>Math.floor(Math.random()*sides)+1);
    document.getElementById('dr-out').innerHTML = `<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">${rolls.map(r=>`<div style="width:46px;height:46px;border-radius:8px;background:var(--pl);color:var(--p);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px">${r}</div>`).join('')}</div><div style="text-align:center;margin-top:10px;font-weight:700">Total: ${rolls.reduce((a,b)=>a+b,0)}</div>`;
  };}
};

// ---------- text-to-speech ----------
TOOL_CUSTOM['text-to-speech'] = {
  body: () => `<div class="fg"><label class="fl">Text</label><textarea class="fc" id="ts-in" rows="6" placeholder="Type something to hear it..."></textarea></div>
    <div style="display:grid;grid-template-columns:1fr 100px 100px;gap:10px">
      <div class="fg"><label class="fl">Voice</label><select class="fc" id="ts-voice"></select></div>
      <div class="fg"><label class="fl">Rate</label><input type="number" class="fc" id="ts-rate" value="1" step="0.1" min="0.5" max="2"></div>
      <div class="fg"><label class="fl">Pitch</label><input type="number" class="fc" id="ts-pitch" value="1" step="0.1" min="0" max="2"></div>
    </div>
    <div class="bgrp"><button class="btn btn-p" onclick="ttsSpeak()">Speak</button><button class="btn btn-s" onclick="speechSynthesis.cancel()">Stop</button></div>`,
  init: () => {
    const populate = () => { const sel=document.getElementById('ts-voice'); if (!sel) return; const voices = speechSynthesis.getVoices();
      sel.innerHTML = voices.map((v,i)=>`<option value="${i}">${v.name} (${v.lang})</option>`).join('') || '<option>Default</option>'; };
    populate();
    if (speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.onvoiceschanged = populate;
    window.ttsSpeak = () => {
      const text = document.getElementById('ts-in').value; if (!text) return;
      const u = new SpeechSynthesisUtterance(text);
      const voices = speechSynthesis.getVoices(); const idx = parseInt(document.getElementById('ts-voice').value);
      if (voices[idx]) u.voice = voices[idx];
      u.rate = parseFloat(document.getElementById('ts-rate').value)||1;
      u.pitch = parseFloat(document.getElementById('ts-pitch').value)||1;
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    };
  }
};

// ---------- password-passphrase ----------
TOOL_CUSTOM['password-passphrase'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Words</label><input type="number" class="fc" id="pp-n" value="4" min="3" max="10"></div>
      <div class="fg"><label class="fl">Separator</label><select class="fc" id="pp-sep"><option value="-">Hyphen -</option><option value=".">Dot .</option><option value=" ">Space</option></select></div>
      <div class="fg"><label class="fl">Add Number</label><select class="fc" id="pp-num"><option value="1">Yes</option><option value="0">No</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="ppGen()">Generate Passphrase</button>
    <div class="res-box ok mono" id="pp-out" style="font-size:18px;text-align:center;margin-top:14px"></div>`,
  init: () => { window.ppGen = () => {
    const n = Math.min(10,Math.max(3,parseInt(document.getElementById('pp-n').value)||4));
    const sep = document.getElementById('pp-sep').value;
    const words = Array.from({length:n},()=>PASSPHRASE_WORDS[Math.floor(Math.random()*PASSPHRASE_WORDS.length)]);
    let phrase = words.join(sep);
    if (document.getElementById('pp-num').value==='1') phrase += sep + Math.floor(Math.random()*90+10);
    document.getElementById('pp-out').textContent = phrase;
  }; ppGen(); }
};

// ---------- random-color ----------
TOOL_CUSTOM['random-color'] = {
  body: () => `<div style="width:100%;height:100px;border-radius:12px;border:1px solid var(--bdr)" id="rc-swatch"></div><div id="rc-out" style="margin-top:14px"></div><button class="btn btn-p" onclick="rcGen()" style="margin-top:10px">Generate New Color</button>`,
  init: () => { window.rcGen = () => {
    const hex = '#'+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0');
    document.getElementById('rc-swatch').style.background = hex;
    const n = parseInt(hex.slice(1),16); const r=n>>16&255,g=n>>8&255,b=n&255;
    document.getElementById('rc-out').innerHTML = statBlock([['HEX',hex.toUpperCase()],['RGB',`${r}, ${g}, ${b}`]]);
  }; rcGen(); }
};

// ---------- spin-wheel ----------
TOOL_CUSTOM['spin-wheel'] = {
  body: () => `<div class="fg"><label class="fl">Options (one per line)</label><textarea class="fc" id="sp-in" rows="5">Pizza\nSushi\nTacos\nBurgers\nSalad</textarea></div>
    <canvas id="sp-canvas" width="280" height="280" style="margin:14px auto;display:block"></canvas>
    <button class="btn btn-p btn-full" onclick="spSpin()">Spin</button>
    <div class="res-box ok" id="sp-result" style="text-align:center;font-weight:700;margin-top:14px;display:none"></div>`,
  init: () => {
    const colors = ['#1D4ED8','#0F766E','#A16207','#991B1B','#BE123C','#0E7490','#B45309','#4338CA'];
    let rotation = 0;
    const draw = () => {
      const opts = document.getElementById('sp-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
      const c = document.getElementById('sp-canvas'); if (!c) return; const ctx = c.getContext('2d');
      const cx=140, cy=140, r=130; ctx.clearRect(0,0,280,280);
      const n = Math.max(1,opts.length); const arc = 2*Math.PI/n;
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(rotation);
      opts.forEach((opt,i) => {
        ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0,0,r, i*arc, (i+1)*arc); ctx.closePath();
        ctx.fillStyle = colors[i%colors.length]; ctx.fill();
        ctx.save(); ctx.rotate(i*arc+arc/2); ctx.fillStyle='#fff'; ctx.font='12px sans-serif'; ctx.textAlign='right';
        ctx.fillText(opt.slice(0,14), r-10, 4); ctx.restore();
      });
      ctx.restore();
      ctx.beginPath(); ctx.moveTo(cx+r+6,cy); ctx.lineTo(cx+r-10,cy-8); ctx.lineTo(cx+r-10,cy+8); ctx.closePath(); ctx.fillStyle='#0F172A'; ctx.fill();
      return opts;
    };
    document.getElementById('sp-in').addEventListener('input', draw);
    window.spSpin = () => {
      const opts = document.getElementById('sp-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
      if (!opts.length) return;
      const n = opts.length, arc = 2*Math.PI/n;
      const extraSpins = 5+Math.random()*3;
      const target = Math.random()*2*Math.PI;
      const finalRotation = extraSpins*2*Math.PI + target;
      const start = rotation, duration=2500, startTime=performance.now();
      const animate = (t) => {
        const p = Math.min(1,(t-startTime)/duration); const ease = 1-Math.pow(1-p,3);
        rotation = start + (finalRotation-start)*ease; draw();
        if (p<1) requestAnimationFrame(animate);
        else {
          const normalized = ((2*Math.PI - (rotation % (2*Math.PI))) + 2*Math.PI - Math.PI/2*0) % (2*Math.PI);
          const idx = Math.floor((normalized) / arc) % n;
          const resEl = document.getElementById('sp-result'); resEl.style.display='block'; resEl.textContent = 'Result: '+opts[idx];
        }
      };
      requestAnimationFrame(animate);
    };
    draw();
  }
};

// ---------- bmr-calculator ----------
TOOL_CUSTOM['bmr-calculator'] = {
  body: () => `
    <div class="bgrp" style="margin-bottom:14px"><button class="btn btn-p btn-sm" id="bmr-metric-btn" onclick="bmrUnit('metric')">Metric</button><button class="btn btn-s btn-sm" id="bmr-imp-btn" onclick="bmrUnit('imperial')">Imperial</button></div>
    <div id="bmr-metric">
      <div class="fg"><label class="fl">Weight (kg)</label><input type="number" class="fc" id="bmr-kg" value="70" oninput="bmrRun()"></div>
      <div class="fg"><label class="fl">Height (cm)</label><input type="number" class="fc" id="bmr-cm" value="175" oninput="bmrRun()"></div>
    </div>
    <div id="bmr-imperial" style="display:none">
      <div class="fg"><label class="fl">Weight (lbs)</label><input type="number" class="fc" id="bmr-lbs" value="154" oninput="bmrRun()"></div>
      <div class="fg"><label class="fl">Height (inches)</label><input type="number" class="fc" id="bmr-in" value="69" oninput="bmrRun()"></div>
    </div>
    <div class="fg"><label class="fl">Age</label><input type="number" class="fc" id="bmr-age" value="30" oninput="bmrRun()"></div>
    <div class="fg"><label class="fl">Sex</label><select class="fc" id="bmr-sex" onchange="bmrRun()"><option value="m">Male</option><option value="f">Female</option></select></div>
    <div id="bmr-out"></div><div class="alert alert-info" style="margin-top:10px">General estimate only, not medical advice.</div>`,
  init: () => {
    let unit='metric';
    window.bmrUnit = (u) => { unit=u; document.getElementById('bmr-metric').style.display=u==='metric'?'':'none'; document.getElementById('bmr-imperial').style.display=u==='imperial'?'':'none';
      document.getElementById('bmr-metric-btn').className = u==='metric'?'btn btn-p btn-sm':'btn btn-s btn-sm'; document.getElementById('bmr-imp-btn').className = u==='imperial'?'btn btn-p btn-sm':'btn btn-s btn-sm'; bmrRun(); };
    window.bmrRun = () => {
      let kg,cm; if (unit==='metric'){ kg=+document.getElementById('bmr-kg').value; cm=+document.getElementById('bmr-cm').value; } else { kg=+document.getElementById('bmr-lbs').value*0.453592; cm=+document.getElementById('bmr-in').value*2.54; }
      const age=+document.getElementById('bmr-age').value, sex=document.getElementById('bmr-sex').value;
      if (!kg||!cm||!age) { document.getElementById('bmr-out').innerHTML=''; return; }
      const bmr = sex==='m' ? 10*kg+6.25*cm-5*age+5 : 10*kg+6.25*cm-5*age-161;
      document.getElementById('bmr-out').innerHTML = statBlock([['BMR',Math.round(bmr)+' kcal/day'],['Light Activity',Math.round(bmr*1.375)+' kcal/day'],['Moderate Activity',Math.round(bmr*1.55)+' kcal/day'],['Very Active',Math.round(bmr*1.725)+' kcal/day']]);
    };
    bmrRun();
  }
};

// ---------- pace-calculator ----------
TOOL_CUSTOM['pace-calculator'] = {
  body: () => `
    <div class="fg"><label class="fl">Distance (km)</label><input type="number" class="fc" id="pa-dist" value="5" oninput="paRun()"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Hours</label><input type="number" class="fc" id="pa-h" value="0" oninput="paRun()"></div>
      <div class="fg"><label class="fl">Minutes</label><input type="number" class="fc" id="pa-m" value="25" oninput="paRun()"></div>
      <div class="fg"><label class="fl">Seconds</label><input type="number" class="fc" id="pa-s" value="0" oninput="paRun()"></div>
    </div>
    <div id="pa-out"></div>`,
  init: () => { window.paRun = () => {
    const dist = +document.getElementById('pa-dist').value;
    const totalSec = (+document.getElementById('pa-h').value||0)*3600 + (+document.getElementById('pa-m').value||0)*60 + (+document.getElementById('pa-s').value||0);
    if (!dist || !totalSec) return;
    const paceSecPerKm = totalSec/dist;
    const pm=Math.floor(paceSecPerKm/60), ps=Math.round(paceSecPerKm%60);
    const paceMi = paceSecPerKm*1.60934; const pmM=Math.floor(paceMi/60), psM=Math.round(paceMi%60);
    const speedKmh = dist/(totalSec/3600);
    document.getElementById('pa-out').innerHTML = statBlock([['Pace per km',`${pm}:${String(ps).padStart(2,'0')}`],['Pace per mile',`${pmM}:${String(psM).padStart(2,'0')}`],['Speed',round4(speedKmh)+' km/h']]);
  }; paRun(); }
};

// ---------- tax-bracket ----------
TOOL_CUSTOM['simple-tax-estimator'] = {
  body: () => `
    <div class="fg"><label class="fl">Income</label><input type="number" class="fc" id="tb-income" value="60000" oninput="tbRun()"></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:10px 0 6px">Tax Brackets</div>
    <div id="tb-rows"></div>
    <button class="btn btn-s btn-sm" onclick="tbAddRow()">+ Add Bracket</button>
    <div id="tb-out" style="margin-top:14px"></div>
    <div class="alert alert-info" style="margin-top:10px">Educational estimate using progressive brackets you define - not tax advice.</div>`,
  init: () => {
    const defaults = [[0,10],[40000,20],[100000,30]];
    window.tbAddRow = (from,rate) => {
      const row = document.createElement('div'); row.style.cssText='display:grid;grid-template-columns:1fr 1fr 30px;gap:8px;margin-bottom:8px';
      row.innerHTML = `<input class="fc" type="number" placeholder="From" value="${from??''}" oninput="tbRun()"><input class="fc" type="number" placeholder="Rate %" value="${rate??''}" oninput="tbRun()"><button class="btn btn-s btn-sm" onclick="this.parentElement.remove();tbRun()">${svgIcon('ui_close',14)}</button>`;
      document.getElementById('tb-rows').appendChild(row);
    };
    defaults.forEach(([f,r])=>tbAddRow(f,r));
    window.tbRun = () => {
      const income = +document.getElementById('tb-income').value; if (!income) return;
      const rows = [...document.getElementById('tb-rows').children].map(r => { const [f,ra] = r.querySelectorAll('input'); return {from:+f.value||0, rate:+ra.value||0}; }).sort((a,b)=>a.from-b.from);
      let tax=0;
      for (let i=0;i<rows.length;i++){ const upper = i<rows.length-1?rows[i+1].from:Infinity; if (income>rows[i].from){ const amt = Math.min(income,upper)-rows[i].from; tax += amt*rows[i].rate/100; } }
      document.getElementById('tb-out').innerHTML = statBlock([['Estimated Tax',fmtMoney(tax)],['Net Income',fmtMoney(income-tax)],['Effective Rate',round4(tax/income*100)+'%']]);
    };
    tbRun();
  }
};

// ---------- SEO tools ----------
TOOL_CUSTOM['meta-tag-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Page Title</label><input class="fc" id="mt-title" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Meta Description</label><textarea class="fc" id="mt-desc" rows="3" oninput="mtRun()"></textarea></div>
    <div class="fg"><label class="fl">Keywords (comma separated)</label><input class="fc" id="mt-kw" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Author</label><input class="fc" id="mt-author" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('mt-out').value,this)">Copy</button></label><textarea class="fc mono" id="mt-out" rows="8" readonly></textarea></div>`,
  init: () => { window.mtRun = () => {
    const t=document.getElementById('mt-title').value, d=document.getElementById('mt-desc').value, k=document.getElementById('mt-kw').value, a=document.getElementById('mt-author').value;
    let out = '';
    if (t) out += `<title>${esc(t)}</title>\n`;
    if (d) out += `<meta name="description" content="${esc(d)}">\n`;
    if (k) out += `<meta name="keywords" content="${esc(k)}">\n`;
    if (a) out += `<meta name="author" content="${esc(a)}">\n`;
    out += `<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<meta name="robots" content="index, follow">`;
    document.getElementById('mt-out').value = out;
  }; mtRun(); }
};
TOOL_CUSTOM['keyword-density'] = {
  body: () => `<div class="fg"><label class="fl">Content</label><textarea class="fc" id="kd-in" rows="8" oninput="kdRun()"></textarea></div><div id="kd-out"></div>`,
  init: () => { window.kdRun = () => {
    const t = document.getElementById('kd-in').value.toLowerCase();
    const words = t.replace(/[^a-z0-9'\s]/g,'').split(/\s+/).filter(w=>w.length>2);
    const total = words.length;
    const freq = {}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
    const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,15);
    document.getElementById('kd-out').innerHTML = total ? statBlock([['Total Words',total]]) + top.map(([w,n])=>`<div class="trow"><span>${esc(w)}</span><strong>${n} (${round4(n/total*100)}%)</strong></div>`).join('') : '<div class="alert alert-info">Paste some content.</div>';
  };}
};
TOOL_CUSTOM['open-graph-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">og:title</label><input class="fc" id="og-title" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:description</label><textarea class="fc" id="og-desc" rows="2" oninput="ogRun()"></textarea></div>
    <div class="fg"><label class="fl">og:image URL</label><input class="fc" id="og-img" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:url</label><input class="fc" id="og-url" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:type</label><select class="fc" id="og-type" onchange="ogRun()"><option value="website">website</option><option value="article">article</option><option value="product">product</option></select></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('og-out').value,this)">Copy</button></label><textarea class="fc mono" id="og-out" rows="7" readonly></textarea></div>`,
  init: () => { window.ogRun = () => {
    const f = id => document.getElementById(id).value;
    let out = `<meta property="og:title" content="${esc(f('og-title'))}">\n<meta property="og:description" content="${esc(f('og-desc'))}">\n<meta property="og:type" content="${esc(f('og-type'))}">\n`;
    if (f('og-img')) out += `<meta property="og:image" content="${esc(f('og-img'))}">\n`;
    if (f('og-url')) out += `<meta property="og:url" content="${esc(f('og-url'))}">\n`;
    out += `<meta name="twitter:card" content="summary_large_image">`;
    document.getElementById('og-out').value = out;
  };}
};
TOOL_CUSTOM['robots-txt-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Disallow Paths (one per line)</label><textarea class="fc" id="rm-disallow" rows="4" placeholder="/admin/\n/private/"></textarea></div>
    <div class="fg"><label class="fl">Sitemap URL (optional)</label><input class="fc" id="rm-sitemap" placeholder="https://example.com/sitemap.xml"></div>
    <button class="btn btn-p" onclick="rmRun()">Generate</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('rm-out').value,this)">Copy</button></label><textarea class="fc mono" id="rm-out" rows="8" readonly></textarea></div>`,
  init: () => { window.rmRun = () => {
    const paths = document.getElementById('rm-disallow').value.split('\n').map(s=>s.trim()).filter(Boolean);
    const sitemap = document.getElementById('rm-sitemap').value.trim();
    let out = 'User-agent: *\n';
    out += paths.length ? paths.map(p=>'Disallow: '+p).join('\n') : 'Allow: /';
    if (sitemap) out += '\n\nSitemap: '+sitemap;
    document.getElementById('rm-out').value = out;
  }; rmRun(); }
};
TOOL_CUSTOM['schema-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Schema Type</label><select class="fc" id="sc2-type" onchange="sc2Render()"><option value="Article">Article</option><option value="Product">Product</option><option value="FAQPage">FAQ Page</option></select></div>
    <div id="sc2-fields"></div>
    <div class="fg"><label class="fl">JSON-LD Output <button class="cpbtn" onclick="copyText(document.getElementById('sc2-out').value,this)">Copy</button></label><textarea class="fc mono" id="sc2-out" rows="10" readonly></textarea></div>`,
  init: () => {
    window.sc2Render = () => {
      const type = document.getElementById('sc2-type').value;
      const f = document.getElementById('sc2-fields');
      if (type==='Article') f.innerHTML = `<div class="fg"><label class="fl">Headline</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Author</label><input class="fc" id="sc2-2" oninput="sc2Run()"></div><div class="fg"><label class="fl">Date Published (YYYY-MM-DD)</label><input class="fc" id="sc2-3" oninput="sc2Run()"></div>`;
      else if (type==='Product') f.innerHTML = `<div class="fg"><label class="fl">Name</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Price</label><input class="fc" id="sc2-2" oninput="sc2Run()"></div><div class="fg"><label class="fl">Currency (e.g. USD)</label><input class="fc" id="sc2-3" oninput="sc2Run()"></div>`;
      else f.innerHTML = `<div class="fg"><label class="fl">Question</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Answer</label><textarea class="fc" id="sc2-2" rows="3" oninput="sc2Run()"></textarea></div>`;
      sc2Run();
    };
    window.sc2Run = () => {
      const type = document.getElementById('sc2-type').value;
      const v1=document.getElementById('sc2-1')?.value||'', v2=document.getElementById('sc2-2')?.value||'', v3=document.getElementById('sc2-3')?.value||'';
      let obj;
      if (type==='Article') obj = {'@context':'https://schema.org','@type':'Article',headline:v1,author:{'@type':'Person',name:v2},datePublished:v3};
      else if (type==='Product') obj = {'@context':'https://schema.org','@type':'Product',name:v1,offers:{'@type':'Offer',price:v2,priceCurrency:v3}};
      else obj = {'@context':'https://schema.org','@type':'FAQPage',mainEntity:[{'@type':'Question',name:v1,acceptedAnswer:{'@type':'Answer',text:v2}}]};
      document.getElementById('sc2-out').value = JSON.stringify(obj,null,2);
    };
    sc2Render();
  }
};
TOOL_CUSTOM['utm-builder'] = {
  body: () => `
    <div class="fg"><label class="fl">Website URL</label><input class="fc" id="um-url" placeholder="https://example.com" oninput="umRun()"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Source</label><input class="fc" id="um-source" placeholder="newsletter" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Medium</label><input class="fc" id="um-medium" placeholder="email" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Campaign</label><input class="fc" id="um-campaign" placeholder="spring_sale" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Term (optional)</label><input class="fc" id="um-term" oninput="umRun()"></div>
    </div>
    <div class="fg"><label class="fl">Content (optional)</label><input class="fc" id="um-content" oninput="umRun()"></div>
    <div class="fg"><label class="fl">Generated URL <button class="cpbtn" onclick="copyText(document.getElementById('um-out').value,this)">Copy</button></label><textarea class="fc mono" id="um-out" rows="4" readonly></textarea></div>`,
  init: () => { window.umRun = () => {
    const url = document.getElementById('um-url').value.trim(); if (!url) { document.getElementById('um-out').value=''; return; }
    const params = new URLSearchParams();
    const s=document.getElementById('um-source').value, m=document.getElementById('um-medium').value, c=document.getElementById('um-campaign').value, t=document.getElementById('um-term').value, ct=document.getElementById('um-content').value;
    if (s) params.set('utm_source',s); if (m) params.set('utm_medium',m); if (c) params.set('utm_campaign',c); if (t) params.set('utm_term',t); if (ct) params.set('utm_content',ct);
    const sep = url.includes('?') ? '&' : '?';
    document.getElementById('um-out').value = params.toString() ? url+sep+params.toString() : url;
  };}
};
TOOL_CUSTOM['sitemap-generator'] = {
  body: () => `<div class="fg"><label class="fl">URLs (one per line)</label><textarea class="fc" id="sm-in" rows="8" placeholder="https://example.com/\nhttps://example.com/about"></textarea></div>
    <button class="btn btn-p" onclick="smRun()">Generate sitemap.xml</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('sm-out').value,this)">Copy</button></label><textarea class="fc mono" id="sm-out" rows="10" readonly></textarea></div>`,
  init: () => { window.smRun = () => {
    const urls = document.getElementById('sm-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
    const today = new Date().toISOString().slice(0,10);
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`  <url><loc>${esc(u)}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>`;
    document.getElementById('sm-out').value = xml;
  };}
};

// ---------- password-strength ----------
TOOL_CUSTOM['password-strength'] = {
  body: () => `<div class="fg"><label class="fl">Password</label><div style="position:relative"><input type="password" class="fc" id="ps-in" oninput="psRun()" style="padding-right:80px"><button onclick="psToggle()" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;font-size:12px;font-weight:600;color:var(--t2);cursor:pointer" id="ps-btn">Show</button></div></div><div id="ps-out"></div>`,
  init: () => {
    window.psToggle = () => { const i=document.getElementById('ps-in'); i.type = i.type==='password'?'text':'password'; document.getElementById('ps-btn').textContent = i.type==='password'?'Show':'Hide'; };
    window.psRun = () => {
      const p = document.getElementById('ps-in').value; const out = document.getElementById('ps-out');
      if (!p) { out.innerHTML=''; return; }
      let score=0; const checks={length:p.length>=8,upper:/[A-Z]/.test(p),lower:/[a-z]/.test(p),number:/[0-9]/.test(p),special:/[^A-Za-z0-9]/.test(p)};
      if (checks.length) score+=20; if (p.length>=12) score+=10; if (p.length>=16) score+=10;
      if (checks.upper) score+=15; if (checks.lower) score+=15; if (checks.number) score+=15; if (checks.special) score+=15;
      const common=['password','123456','qwerty','abc123','letmein','monkey','dragon','welcome'];
      let noCommon = !common.some(c=>p.toLowerCase().includes(c)); if (!noCommon) score=Math.min(score,25);
      score=Math.min(100,score);
      let label,color; if(score<30){label='Very Weak';color='#B91C1C';}else if(score<50){label='Weak';color='#B45309';}else if(score<70){label='Fair';color='#A16207';}else if(score<85){label='Strong';color='#0F766E';}else{label='Very Strong';color='#065F46';}
      const items=[['length','At least 8 characters'],['upper','Uppercase letters'],['lower','Lowercase letters'],['number','Numbers'],['special','Special characters']];
      out.innerHTML = `<div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rl);padding:18px;margin-top:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:10px"><span style="font-weight:700;color:${color}">${label}</span><span style="font-weight:700;color:${color}">${score}/100</span></div>
        <div class="pr-bar"><div class="pr-fill" style="width:${score}%;background:${color}"></div></div>
        <div style="margin-top:14px;display:grid;grid-template-columns:1fr 1fr;gap:6px">${items.map(([k,l])=>`<div style="font-size:12px;color:${checks[k]?'var(--ok)':'var(--err)'}">${checks[k]?svgIcon('ui_check',12):svgIcon('ui_close',12)} ${l}</div>`).join('')}</div>
        ${!noCommon?'<div class="alert alert-warn" style="margin-top:12px">Contains a common weak pattern.</div>':''}
      </div>`;
    };
  }
};

// ---------- htpasswd ----------
TOOL_CUSTOM['htpasswd'] = {
  body: () => `<div class="fg"><label class="fl">Username</label><input class="fc" id="hp-user" value="admin"></div><div class="fg"><label class="fl">Password</label><input class="fc" id="hp-pass" type="password" value=""></div><button class="btn btn-p" onclick="hpRun()">Generate</button><div id="hp-out" style="margin-top:14px"></div>`,
  init: () => { window.hpRun = async () => {
    const user = document.getElementById('hp-user').value, pass = document.getElementById('hp-pass').value;
    if (!user || !pass) { toast('Enter username and password','er'); return; }
    const enc = new TextEncoder().encode(pass);
    const buf = await crypto.subtle.digest('SHA-1', enc);
    const hashB64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
    const line = `${user}:{SHA}${hashB64}`;
    document.getElementById('hp-out').innerHTML = `<div class="res-box mono ok">${esc(line)}</div><button class="cpbtn" style="margin-top:8px" onclick="copyText('${line.replace(/'/g,"\\'")}',this)">Copy</button><div class="alert alert-info" style="margin-top:10px">Uses the {SHA} htpasswd format. Apache also supports bcrypt/APR1 - check your server's requirements.</div>`;
  };}
};

// ---------- ssn-fake (fake test data) ----------
const FAKE_FIRST = ['Alex','Jordan','Taylor','Morgan','Casey','Riley','Avery','Quinn','Sam','Jamie','Drew','Cameron','Rowan','Skyler','Reese'];
const FAKE_LAST = ['Johnson','Smith','Williams','Brown','Davis','Miller','Wilson','Moore','Taylor','Anderson','Thomas','Jackson','White','Harris'];
TOOL_CUSTOM['fake-data-generator'] = {
  body: () => `<div class="fg"><label class="fl">How many records</label><input type="number" class="fc" id="fd-n" value="5" min="1" max="50" oninput="fdRun()"></div><div id="fd-out"></div>`,
  init: () => { window.fdRun = () => {
    const n = Math.min(50,Math.max(1,parseInt(document.getElementById('fd-n').value)||5));
    let rows = '';
    for (let i=0;i<n;i++){
      const fn=FAKE_FIRST[Math.floor(Math.random()*FAKE_FIRST.length)], ln=FAKE_LAST[Math.floor(Math.random()*FAKE_LAST.length)];
      const email = `${fn.toLowerCase()}.${ln.toLowerCase()}${Math.floor(Math.random()*99)}@example.com`;
      const phone = `555-${String(Math.floor(Math.random()*900+100))}-${String(Math.floor(Math.random()*9000+1000))}`;
      rows += `<div class="trow"><span>${fn} ${ln}</span><span class="mono" style="font-size:11px">${email} · ${phone}</span></div>`;
    }
    document.getElementById('fd-out').innerHTML = rows + '<div class="alert alert-info" style="margin-top:10px">All names use the example.com domain and 555 phone prefix reserved for fictional use - not real people.</div>';
  }; fdRun(); }
};

// ---------- roman-numerals ----------
TOOL_CUSTOM['roman-numerals'] = {
  body: () => `
    <div class="bgrp" style="margin-bottom:14px"><button class="btn btn-p btn-sm" id="rn-a2r-btn" onclick="rnMode('a2r')">Number to Roman</button><button class="btn btn-s btn-sm" id="rn-r2a-btn" onclick="rnMode('r2a')">Roman to Number</button></div>
    <div class="fg"><label class="fl" id="rn-label">Number (1-3999)</label><input class="fc" id="rn-in" value="1994" oninput="rnRun()"></div>
    <div class="res-box ok" id="rn-out" style="font-size:22px;text-align:center;font-weight:700"></div>`,
  init: () => {
    const toRoman = n => { const map=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']]; let r=''; for (const [v,s] of map) while(n>=v){r+=s;n-=v;} return r; };
    const fromRoman = s => { const vals={I:1,V:5,X:10,L:50,C:100,D:500,M:1000}; s=s.toUpperCase(); let total=0; for(let i=0;i<s.length;i++){ const v=vals[s[i]]; if(!v) return null; if (v<(vals[s[i+1]]||0)) total-=v; else total+=v; } return total; };
    let mode='a2r';
    window.rnMode = (m) => { mode=m; document.getElementById('rn-a2r-btn').className = m==='a2r'?'btn btn-p btn-sm':'btn btn-s btn-sm'; document.getElementById('rn-r2a-btn').className = m==='r2a'?'btn btn-p btn-sm':'btn btn-s btn-sm';
      document.getElementById('rn-label').textContent = m==='a2r'?'Number (1-3999)':'Roman Numeral'; document.getElementById('rn-in').value = m==='a2r'?'1994':'MCMXCIV'; rnRun(); };
    window.rnRun = () => {
      const v = document.getElementById('rn-in').value.trim(); const out = document.getElementById('rn-out');
      if (mode==='a2r'){ const n=parseInt(v); if(!n||n<1||n>3999){out.textContent='Enter 1-3999';return;} out.textContent=toRoman(n); }
      else { const n=fromRoman(v); if(n===null){out.textContent='Invalid Roman numeral';return;} out.textContent=n; }
    };
    rnRun();
  }
};

// PDF tools: pdf-lib is loaded on demand from /vendor/pdf-lib.min.js (kept out of the main bundle).
let __pdfLibPromise = null;
function loadPdfLib(){
  if (window.PDFLib) return Promise.resolve(window.PDFLib);
  if (__pdfLibPromise) return __pdfLibPromise;
  __pdfLibPromise = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = (/^https?:$/.test(location.protocol) ? '/vendor/' : 'vendor/') + 'pdf-lib.min.js';
    s.onload = () => res(window.PDFLib);
    s.onerror = () => { __pdfLibPromise = null; rej(new Error('Could not load the PDF library')); };
    document.head.appendChild(s);
  });
  return __pdfLibPromise;
}
function pdfReadFile(f){ return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(new Uint8Array(r.result)); r.onerror = () => rej(new Error('Could not read ' + f.name)); r.readAsArrayBuffer(f); }); }
function pdfDownload(bytes, name){
  const blob = new Blob([bytes], {type:'application/pdf'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
}
function pdfMsg(id, html, kind){ const el = document.getElementById(id); if (el) el.innerHTML = `<div class="alert alert-${kind||'info'}">${html}</div>`; }
function pdfFileList(files, listId){
  const el = document.getElementById(listId); if (!el) return;
  el.innerHTML = files.map((f, i) => `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid var(--bdr);border-radius:8px;margin-bottom:6px;background:var(--bg2)"><span style="flex:1;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)} <span style="color:var(--tm)">(${Math.max(1,Math.round(f.size/1024))} KB)</span></span><button type="button" class="btn btn-s btn-sm" onclick="pdfMove('${listId}',${i},-1)" aria-label="Move up">${svgIcon('ui_up',14)}</button><button type="button" class="btn btn-s btn-sm" onclick="pdfMove('${listId}',${i},1)" aria-label="Move down" style="transform:rotate(180deg)">${svgIcon('ui_up',14)}</button><button type="button" class="btn btn-s btn-sm" onclick="pdfRemove('${listId}',${i})" aria-label="Remove">${svgIcon('ui_close',14)}</button></div>`).join('');
}
const __pdfState = {};
function pdfMove(listId, i, d){ const a = __pdfState[listId]; const j = i + d; if (!a || j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; pdfFileList(a, listId); }
function pdfRemove(listId, i){ const a = __pdfState[listId]; if (!a) return; a.splice(i, 1); pdfFileList(a, listId); }
function pdfPicker(inputId, listId, accept, multi){
  __pdfState[listId] = [];
  const inp = document.getElementById(inputId);
  inp.addEventListener('change', () => { const add = Array.from(inp.files).filter(f => accept.test(f.name) || accept.test(f.type)); if (multi) __pdfState[listId].push(...add); else __pdfState[listId] = add.slice(0, 1); inp.value = ''; pdfFileList(__pdfState[listId], listId); });
}
const PDF_UP = (id, lid, accept, multi, label) => `<div class="fg"><label class="fl" for="${id}">${label}</label><input type="file" class="fc" id="${id}" accept="${accept}" ${multi ? 'multiple' : ''}></div><div id="${lid}"></div>`;

TOOL_CUSTOM['pdf-merge'] = {
  body: () => PDF_UP('pm-in', 'pm-list', 'application/pdf,.pdf', true, 'Add PDF files') + `<button type="button" class="btn btn-p" id="pm-go">Merge and download</button><div id="pm-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pm-in', 'pm-list', /\.pdf$|application\/pdf/i, true);
    document.getElementById('pm-go').onclick = async () => {
      const files = __pdfState['pm-list']; if (!files || files.length < 2) return pdfMsg('pm-msg', 'Add at least two PDF files.', 'warn');
      try {
        pdfMsg('pm-msg', 'Merging...');
        const { PDFDocument } = await loadPdfLib(); const out = await PDFDocument.create();
        for (const f of files) { const src = await PDFDocument.load(await pdfReadFile(f)); const pages = await out.copyPages(src, src.getPageIndices()); pages.forEach(p => out.addPage(p)); }
        pdfDownload(await out.save(), 'merged.pdf'); pdfMsg('pm-msg', `Done. ${out.getPageCount()} pages merged.`, 'ok');
      } catch (e) { pdfMsg('pm-msg', 'Could not merge. One of the files may be damaged or password protected.', 'err'); }
    };
  }
};
function pdfParseRanges(str, max){
  const out = []; const seen = new Set();
  for (const part of str.split(',').map(s => s.trim()).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:\s*-\s*(\d+))?$/); if (!m) return null;
    let a = +m[1], b = m[2] ? +m[2] : a; if (a < 1 || b < 1 || a > max || b > max) return null;
    const step = a <= b ? 1 : -1; for (let i = a; step > 0 ? i <= b : i >= b; i += step) { if (!seen.has(i)) { seen.add(i); out.push(i - 1); } }
  }
  return out.length ? out : null;
}
TOOL_CUSTOM['pdf-split'] = {
  body: () => PDF_UP('ps-in', 'ps-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="ps-range">Pages to keep</label><input class="fc" id="ps-range" placeholder="e.g. 1-3,5,8-10"></div><button type="button" class="btn btn-p" id="ps-go">Extract and download</button><div id="ps-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('ps-in', 'ps-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('ps-go').onclick = async () => {
      const f = (__pdfState['ps-list'] || [])[0]; if (!f) return pdfMsg('ps-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument } = await loadPdfLib(); const src = await PDFDocument.load(await pdfReadFile(f)); const total = src.getPageCount();
        const idx = pdfParseRanges(document.getElementById('ps-range').value, total);
        if (!idx) return pdfMsg('ps-msg', `Enter valid pages between 1 and ${total}, like 1-3,5.`, 'warn');
        const out = await PDFDocument.create(); (await out.copyPages(src, idx)).forEach(p => out.addPage(p));
        pdfDownload(await out.save(), f.name.replace(/\.pdf$/i, '') + '-pages.pdf'); pdfMsg('ps-msg', `Done. ${idx.length} of ${total} pages extracted.`, 'ok');
      } catch (e) { pdfMsg('ps-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['images-to-pdf'] = {
  body: () => PDF_UP('ip-in', 'ip-list', 'image/jpeg,image/png,.jpg,.jpeg,.png', true, 'Add JPG or PNG images') + `<button type="button" class="btn btn-p" id="ip-go">Create PDF</button><div id="ip-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('ip-in', 'ip-list', /\.(jpe?g|png)$|image\/(jpeg|png)/i, true);
    document.getElementById('ip-go').onclick = async () => {
      const files = __pdfState['ip-list']; if (!files || !files.length) return pdfMsg('ip-msg', 'Add at least one image.', 'warn');
      try {
        pdfMsg('ip-msg', 'Creating PDF...');
        const { PDFDocument } = await loadPdfLib(); const out = await PDFDocument.create();
        for (const f of files) { const bytes = await pdfReadFile(f); const img = /png$/i.test(f.name) || f.type === 'image/png' ? await out.embedPng(bytes) : await out.embedJpg(bytes); const pg = out.addPage([img.width, img.height]); pg.drawImage(img, {x:0, y:0, width:img.width, height:img.height}); }
        pdfDownload(await out.save(), 'images.pdf'); pdfMsg('ip-msg', `Done. ${files.length} image${files.length > 1 ? 's' : ''} added.`, 'ok');
      } catch (e) { pdfMsg('ip-msg', 'Could not add one of the images. Use standard JPG or PNG files.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-rotate'] = {
  body: () => PDF_UP('pr-in', 'pr-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pr-deg">Rotate pages by</label><select class="fc" id="pr-deg"><option value="90">90 degrees clockwise</option><option value="180">180 degrees</option><option value="270">90 degrees counter-clockwise</option></select></div><button type="button" class="btn btn-p" id="pr-go">Rotate and download</button><div id="pr-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pr-in', 'pr-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pr-go').onclick = async () => {
      const f = (__pdfState['pr-list'] || [])[0]; if (!f) return pdfMsg('pr-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument, degrees } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const d = +document.getElementById('pr-deg').value;
        doc.getPages().forEach(p => p.setRotation(degrees((p.getRotation().angle + d) % 360)));
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-rotated.pdf'); pdfMsg('pr-msg', 'Done. All pages rotated.', 'ok');
      } catch (e) { pdfMsg('pr-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};

// More tools. Uses helpers from pdf-tools.js (loaded before this file).
let __pdfJsPromise = null;
function loadPdfJs(){
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (__pdfJsPromise) return __pdfJsPromise;
  const base = /^https?:$/.test(location.protocol) ? '/vendor/' : 'vendor/';
  __pdfJsPromise = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = base + 'pdf.min.js';
    s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = base + 'pdf.worker.min.js'; res(window.pdfjsLib); };
    s.onerror = () => { __pdfJsPromise = null; rej(new Error('Could not load the PDF viewer library')); };
    document.head.appendChild(s);
  });
  return __pdfJsPromise;
}
TOOL_CUSTOM['pdf-to-jpg'] = {
  body: () => PDF_UP('pj-in', 'pj-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pj-scale">Image quality</label><select class="fc" id="pj-scale"><option value="1">Standard (screen)</option><option value="1.5" selected>High</option><option value="2.5">Very high (large files)</option></select></div><button type="button" class="btn btn-p" id="pj-go">Convert pages</button><div id="pj-msg" style="margin-top:12px"></div><div id="pj-out" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pj-in', 'pj-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pj-go').onclick = async () => {
      const f = (__pdfState['pj-list'] || [])[0]; if (!f) return pdfMsg('pj-msg', 'Choose a PDF file first.', 'warn');
      const out = document.getElementById('pj-out'); out.innerHTML = '';
      try {
        pdfMsg('pj-msg', 'Rendering...');
        const lib = await loadPdfJs(); const doc = await lib.getDocument({ data: await pdfReadFile(f) }).promise; const sc = +document.getElementById('pj-scale').value;
        const total = Math.min(doc.numPages, 100);
        for (let n = 1; n <= total; n++) {
          const page = await doc.getPage(n); const vp = page.getViewport({ scale: sc }); const c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
          const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); await page.render({ canvasContext: ctx, viewport: vp }).promise;
          const url = c.toDataURL('image/jpeg', 0.92);
          out.insertAdjacentHTML('beforeend', `<div style="border:1px solid var(--bdr);border-radius:8px;padding:8px;text-align:center"><img src="${url}" alt="Page ${n}" style="max-width:100%;border-radius:4px"><a class="btn btn-s btn-sm" style="margin-top:8px" href="${url}" download="${esc(f.name.replace(/\.pdf$/i, ''))}-page-${n}.jpg">Download page ${n}</a></div>`);
        }
        pdfMsg('pj-msg', `Done. ${total} page${total > 1 ? 's' : ''} converted${doc.numPages > 100 ? ' (first 100 pages only)' : ''}.`, 'ok');
      } catch (e) { pdfMsg('pj-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-delete-pages'] = {
  body: () => PDF_UP('pd-in', 'pd-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pd-range">Pages to delete</label><input class="fc" id="pd-range" placeholder="e.g. 2,4-6"></div><button type="button" class="btn btn-p" id="pd-go">Delete and download</button><div id="pd-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pd-in', 'pd-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pd-go').onclick = async () => {
      const f = (__pdfState['pd-list'] || [])[0]; if (!f) return pdfMsg('pd-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const total = doc.getPageCount();
        const idx = pdfParseRanges(document.getElementById('pd-range').value, total);
        if (!idx) return pdfMsg('pd-msg', `Enter valid pages between 1 and ${total}, like 2,4-6.`, 'warn');
        if (idx.length >= total) return pdfMsg('pd-msg', 'You cannot delete every page.', 'warn');
        idx.sort((a, b) => b - a).forEach(i => doc.removePage(i));
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-edited.pdf'); pdfMsg('pd-msg', `Done. ${idx.length} page${idx.length > 1 ? 's' : ''} removed, ${doc.getPageCount()} left.`, 'ok');
      } catch (e) { pdfMsg('pd-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-page-numbers'] = {
  body: () => PDF_UP('pn-in', 'pn-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pn-fmt">Format</label><select class="fc" id="pn-fmt"><option value="n">1</option><option value="pn">Page 1</option><option value="pnn" selected>Page 1 of N</option></select></div><div class="fg"><label class="fl" for="pn-pos">Position</label><select class="fc" id="pn-pos"><option value="c">Bottom centre</option><option value="r">Bottom right</option><option value="l">Bottom left</option></select></div><button type="button" class="btn btn-p" id="pn-go">Add numbers and download</button><div id="pn-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pn-in', 'pn-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pn-go').onclick = async () => {
      const f = (__pdfState['pn-list'] || [])[0]; if (!f) return pdfMsg('pn-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument, StandardFonts, rgb } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const font = await doc.embedFont(StandardFonts.Helvetica);
        const fmt = document.getElementById('pn-fmt').value, pos = document.getElementById('pn-pos').value; const pages = doc.getPages(); const N = pages.length;
        pages.forEach((pg, i) => {
          const label = fmt === 'n' ? String(i + 1) : fmt === 'pn' ? `Page ${i + 1}` : `Page ${i + 1} of ${N}`; const { width } = pg.getSize(); const size = 10; const w = font.widthOfTextAtSize(label, size);
          const x = pos === 'c' ? (width - w) / 2 : pos === 'r' ? width - w - 30 : 30;
          pg.drawText(label, { x, y: 20, size, font, color: rgb(0.25, 0.25, 0.25) });
        });
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-numbered.pdf'); pdfMsg('pn-msg', `Done. Numbers added to ${N} pages.`, 'ok');
      } catch (e) { pdfMsg('pn-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['webp-converter'] = {
  body: () => `<div class="fg"><label class="fl" for="wp-in">Choose images (JPG, PNG or WebP)</label><input type="file" class="fc" id="wp-in" accept="image/jpeg,image/png,image/webp" multiple></div><div class="fg"><label class="fl" for="wp-fmt">Convert to</label><select class="fc" id="wp-fmt"><option value="image/webp">WebP</option><option value="image/jpeg">JPG</option><option value="image/png">PNG</option></select></div><div class="fg"><label class="fl" for="wp-q">Quality: <span id="wp-qv">80</span>% (WebP and JPG only)</label><input type="range" id="wp-q" min="40" max="100" value="80" style="width:100%"></div><div id="wp-msg" style="margin-top:12px"></div><div id="wp-out" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-top:12px"></div>`,
  init: () => {
    const inp = document.getElementById('wp-in'), q = document.getElementById('wp-q'), fmt = document.getElementById('wp-fmt'), out = document.getElementById('wp-out');
    const run = async () => {
      out.innerHTML = ''; const files = Array.from(inp.files || []); if (!files.length) return;
      const type = fmt.value, ext = type === 'image/webp' ? 'webp' : type === 'image/jpeg' ? 'jpg' : 'png';
      for (const f of files) {
        try {
          const bmp = await createImageBitmap(f); const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height; const ctx = c.getContext('2d');
          if (type === 'image/jpeg') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); } ctx.drawImage(bmp, 0, 0);
          const blob = await new Promise(r => c.toBlob(r, type, +q.value / 100)); if (!blob) throw new Error('unsupported');
          const url = URL.createObjectURL(blob); const name = f.name.replace(/\.[^.]+$/, '') + '.' + ext;
          out.insertAdjacentHTML('beforeend', `<div style="border:1px solid var(--bdr);border-radius:8px;padding:8px;text-align:center"><img src="${url}" alt="${esc(name)}" style="max-width:100%;max-height:120px;border-radius:4px"><div style="font-size:12px;color:var(--t2);margin-top:6px">${Math.max(1, Math.round(f.size / 1024))} KB to ${Math.max(1, Math.round(blob.size / 1024))} KB</div><a class="btn btn-s btn-sm" style="margin-top:6px" href="${url}" download="${esc(name)}">Download</a></div>`);
        } catch (e) { out.insertAdjacentHTML('beforeend', `<div class="alert alert-err">Could not convert ${esc(f.name)}.</div>`); }
      }
    };
    inp.addEventListener('change', run); fmt.addEventListener('change', run); q.addEventListener('input', () => { document.getElementById('wp-qv').textContent = q.value; });
    q.addEventListener('change', run);
  }
};

;
// ============================================================
// Logic for the 5 dedicated (hand-built) tool pages
// ============================================================

// ---------- WORD COUNTER ----------
function analyzeWC(){
  const t = document.getElementById('wcText').value;
  const words = t.trim() ? t.trim().split(/\s+/).length : 0;
  const chars = t.length;
  const charsNo = t.replace(/\s/g,'').length;
  const sents = t.trim() ? ((t.match(/[.!?]+/g)||[]).length || 1) : 0;
  const paras = t.trim() ? t.trim().split(/\n\s*\n/).filter(p=>p.trim()).length : 0;
  const readMin = Math.max(1, Math.round(words/200));
  document.getElementById('wc-words').textContent = words.toLocaleString();
  document.getElementById('wc-chars').textContent = chars.toLocaleString();
  document.getElementById('wc-chars-no').textContent = charsNo.toLocaleString();
  document.getElementById('wc-sents').textContent = sents;
  document.getElementById('wc-para').textContent = paras || (t.trim()?1:0);
  document.getElementById('wc-read').textContent = readMin+'m';
  document.getElementById('wcBar').style.width = Math.min(100,(chars/5000)*100)+'%';
  const kw = document.getElementById('wcKeywords');
  if (!t.trim()) { kw.innerHTML = '<span style="color:var(--tm);font-size:13px">Type some text to see top keywords...</span>'; return; }
  const wfreq = {};
  t.toLowerCase().replace(/[^a-z\s]/g,'').split(/\s+/).forEach(w => { if (w.length>3) wfreq[w]=(wfreq[w]||0)+1; });
  const top = Object.entries(wfreq).sort((a,b)=>b[1]-a[1]).slice(0,10);
  kw.innerHTML = top.map(([w,n]) => `<span class="tag">${esc(w)} <strong style="color:var(--p)">${n}</strong></span>`).join('');
}
function clearWC(){ document.getElementById('wcText').value=''; analyzeWC(); }
function copyWCStats(){
  const stats = `Words: ${document.getElementById('wc-words').textContent}\nCharacters: ${document.getElementById('wc-chars').textContent}\nChars (no spaces): ${document.getElementById('wc-chars-no').textContent}\nSentences: ${document.getElementById('wc-sents').textContent}\nParagraphs: ${document.getElementById('wc-para').textContent}\nRead Time: ${document.getElementById('wc-read').textContent}`;
  copyText(stats);
}

// ---------- PASSWORD GENERATOR ----------
const PG_CHARS = { upper:'ABCDEFGHIJKLMNOPQRSTUVWXYZ', lower:'abcdefghijklmnopqrstuvwxyz', nums:'0123456789', spec:'!@#$%^&*()_+-=[]{}|;:,.<>?', ambig:/[lI1O0]/g };
function genPG(){
  const lenEl = document.getElementById('pgLen'); if (!lenEl) return;
  const len = parseInt(lenEl.value);
  const useUpper = document.getElementById('pgUpper').checked;
  const useLower = document.getElementById('pgLower').checked;
  const useNums = document.getElementById('pgNums').checked;
  const useSpec = document.getElementById('pgSpec').checked;
  const noAmb = document.getElementById('pgAmb').checked;
  let pool = '';
  if (useUpper) pool += PG_CHARS.upper;
  if (useLower) pool += PG_CHARS.lower;
  if (useNums) pool += PG_CHARS.nums;
  if (useSpec) pool += PG_CHARS.spec;
  if (noAmb) pool = pool.replace(PG_CHARS.ambig,'');
  if (!pool) { document.getElementById('pgPass').textContent = 'Select at least one character type'; return; }
  let pass = '';
  const arr = new Uint32Array(len); crypto.getRandomValues(arr);
  for (let i=0;i<len;i++) pass += pool[arr[i]%pool.length];
  document.getElementById('pgPass').textContent = pass;
  const types = [useUpper,useLower,useNums,useSpec].filter(Boolean).length;
  const score = Math.min(100, len*3+types*10);
  const bar = document.getElementById('pgStr'), lbl = document.getElementById('pgStrLbl');
  bar.style.width = score+'%';
  if (score<40){ bar.style.background='#B91C1C'; lbl.textContent='Weak'; lbl.style.color='#B91C1C'; }
  else if (score<65){ bar.style.background='#B45309'; lbl.textContent='Fair'; lbl.style.color='#B45309'; }
  else if (score<85){ bar.style.background='#0F766E'; lbl.textContent='Strong'; lbl.style.color='#0F766E'; }
  else { bar.style.background='#065F46'; lbl.textContent='Very Strong'; lbl.style.color='#065F46'; }
  return pass;
}
function genPGMulti(){
  const count = Math.min(20, parseInt(document.getElementById('pgCount').value)||1);
  const passes = []; for (let i=0;i<count;i++) passes.push(genPG());
  if (count>1) {
    document.getElementById('pgMulti').innerHTML = `
      <div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rs);padding:14px">
        <div style="font-size:12px;font-weight:700;color:var(--tm);margin-bottom:10px;text-transform:uppercase">Generated ${count} Passwords</div>
        ${passes.map(p=>`<div style="font-family:var(--fm);font-size:13px;padding:6px 0;border-bottom:1px solid var(--bdr);display:flex;justify-content:space-between;align-items:center"><span>${esc(p)}</span><button class="cpbtn" onclick="copyText('${p.replace(/'/g,"\\'")}',this)">Copy</button></div>`).join('')}
      </div>`;
  } else { document.getElementById('pgMulti').innerHTML = ''; }
}
function copyPG(){ copyText(document.getElementById('pgPass').textContent, document.getElementById('pgCopyBtn')); }

// ---------- JSON FORMATTER ----------
function formatJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const out = document.getElementById('jsonOut'), al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { const parsed = JSON.parse(inp); out.textContent = JSON.stringify(parsed,null,2); out.className='res-box mono ok'; al.innerHTML='<div class="alert alert-ok">Valid JSON - formatted successfully.</div>'; }
  catch(e){ out.textContent = 'Invalid JSON:\n'+e.message; out.className='res-box mono er'; al.innerHTML=`<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
}
function minifyJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const out = document.getElementById('jsonOut'), al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { const parsed = JSON.parse(inp); out.textContent = JSON.stringify(parsed); out.className='res-box mono ok'; al.innerHTML='<div class="alert alert-ok">JSON minified successfully.</div>'; }
  catch(e){ out.textContent = e.message; out.className='res-box mono er'; al.innerHTML=`<div class="alert alert-err">${esc(e.message)}</div>`; }
}
function validateJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { JSON.parse(inp); al.innerHTML='<div class="alert alert-ok">Valid JSON.</div>'; }
  catch(e){ al.innerHTML = `<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
}
function clearJSON(){
  document.getElementById('jsonIn').value='';
  document.getElementById('jsonOut').textContent='Result will appear here...';
  document.getElementById('jsonOut').className='res-box mono';
  document.getElementById('jsonAlert').innerHTML='';
}
function copyJSON(){ copyText(document.getElementById('jsonOut').textContent, document.getElementById('jsonCopyBtn')); }

// ---------- BMI CALCULATOR ----------
let bmiUnit = 'metric';
function setBMIUnit(u){
  bmiUnit = u;
  document.getElementById('bmi-metric').style.display = u==='metric'?'':'none';
  document.getElementById('bmi-imperial').style.display = u==='imperial'?'':'none';
  document.getElementById('bmi-metric-btn').className = u==='metric'?'btn btn-p btn-sm':'btn btn-s btn-sm';
  document.getElementById('bmi-imp-btn').className = u==='imperial'?'btn btn-p btn-sm':'btn btn-s btn-sm';
  document.getElementById('bmi-result').innerHTML='';
}
function calcBMI(){
  let weight, height;
  if (bmiUnit==='metric'){ weight=parseFloat(document.getElementById('bmi-kg').value); height=parseFloat(document.getElementById('bmi-cm').value)/100; }
  else { weight=parseFloat(document.getElementById('bmi-lbs').value)*0.453592; const ft=parseFloat(document.getElementById('bmi-ft').value)||0, inch=parseFloat(document.getElementById('bmi-in').value)||0; height=(ft*12+inch)*0.0254; }
  if (!weight || !height || height<=0) { document.getElementById('bmi-result').innerHTML=''; return; }
  const bmi = weight/(height*height);
  let cat,color,bg,advice;
  if (bmi<18.5){ cat='Underweight'; color='#1E40AF'; bg='#DBEAFE'; advice='Consider a balanced, higher-calorie diet and consult a doctor if concerned.'; }
  else if (bmi<25){ cat='Normal Weight'; color='#065F46'; bg='#D1FAE5'; advice='This is a healthy range - maintain it with regular activity and balanced eating.'; }
  else if (bmi<30){ cat='Overweight'; color='#92400E'; bg='#FEF3C7'; advice='Consider more physical activity and reviewing your diet. A doctor can advise further.'; }
  else { cat='Obese'; color='#991B1B'; bg='#FEE2E2'; advice='Consulting a healthcare professional for a personalised plan is recommended.'; }
  const pct = Math.min(100,Math.max(0,(bmi-10)/30*100));
  document.getElementById('bmi-result').innerHTML = `
    <div style="background:${bg};border:1px solid ${color}33;border-radius:var(--rl);padding:20px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <div style="font-size:12px;color:${color};font-weight:700;text-transform:uppercase;margin-bottom:4px">Your BMI</div>
          <div style="font-size:48px;font-weight:700;color:${color};letter-spacing:-.02em;line-height:1">${bmi.toFixed(1)}</div>
          <div style="margin-top:8px"><span style="background:${color};color:#fff;padding:4px 14px;border-radius:6px;font-size:13px;font-weight:700">${cat}</span></div>
        </div>
        <div style="flex:1;min-width:200px">
          <div style="font-size:12px;font-weight:700;color:${color};margin-bottom:6px">BMI Scale</div>
          <div class="pr-bar"><div class="pr-fill" style="width:${pct}%;background:${color}"></div></div>
          <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tm);margin-top:4px"><span>10</span><span>18.5</span><span>25</span><span>30</span><span>40</span></div>
        </div>
      </div>
      <div style="margin-top:14px;font-size:13px;color:${color};line-height:1.6">${advice}</div>
      ${bmiUnit==='metric'?`<div style="margin-top:10px;font-size:12px;color:var(--tm)">Weight: ${weight.toFixed(1)}kg · Height: ${(height*100).toFixed(1)}cm</div>`:''}
    </div>`;
}

// ---------- AGE CALCULATOR ----------
function calcAge(){
  const dob = document.getElementById('ac-dob').value; if (!dob) return;
  const targetVal = document.getElementById('ac-target').value;
  const birthDate = new Date(dob); const today = targetVal ? new Date(targetVal) : new Date();
  if (birthDate > today) { document.getElementById('ac-result').innerHTML='<div class="alert alert-err">Birth date cannot be in the future.</div>'; return; }
  let years = today.getFullYear()-birthDate.getFullYear(), months = today.getMonth()-birthDate.getMonth(), days = today.getDate()-birthDate.getDate();
  if (days<0){ months--; const lastMonth=new Date(today.getFullYear(),today.getMonth(),0); days+=lastMonth.getDate(); }
  if (months<0){ years--; months+=12; }
  const totalDays = Math.floor((today-birthDate)/86400000);
  const totalHours = totalDays*24;
  const nextBday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (nextBday<=today) nextBday.setFullYear(today.getFullYear()+1);
  const daysUntilBday = Math.ceil((nextBday-today)/86400000);
  const weekday = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][birthDate.getDay()];
  document.getElementById('ac-result').innerHTML = `
    <div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rl);padding:20px">
      <div style="text-align:center;margin-bottom:18px">
        <div style="font-size:48px;font-weight:700;color:var(--p);letter-spacing:-.02em;line-height:1">${years}</div>
        <div style="font-size:16px;color:var(--t2);font-weight:600">Years Old</div>
        <div style="font-size:14px;color:var(--tm);margin-top:4px">${years} years, ${months} months and ${days} days</div>
      </div>
      <div class="sgrid">
        <div class="sc"><span class="sn">${years}</span><span class="sl">Years</span></div>
        <div class="sc"><span class="sn">${months}</span><span class="sl">Months</span></div>
        <div class="sc"><span class="sn">${days}</span><span class="sl">Days</span></div>
        <div class="sc"><span class="sn">${totalDays.toLocaleString()}</span><span class="sl">Total Days</span></div>
        <div class="sc"><span class="sn">${totalHours.toLocaleString()}</span><span class="sl">Total Hours</span></div>
        <div class="sc"><span class="sn">${daysUntilBday}</span><span class="sl">Days to Bday</span></div>
      </div>
      <div style="margin-top:14px;background:#fff;border:1px solid var(--bdr);border-radius:8px;padding:12px;font-size:13px;color:var(--t2)">
        You were born on a <strong>${weekday}</strong>. ${daysUntilBday===365?'Happy Birthday!':`Your next birthday is in <strong>${daysUntilBday} days</strong>.`}
      </div>
    </div>`;
}

;
document.getElementById('statTotal').textContent = TOOLS.length;
const _sc=document.getElementById('statCats'); if(_sc) _sc.textContent = Object.keys(CAT_CONFIG).length;
const _sg=document.getElementById('statGuides'); if(_sg) _sg.textContent = GUIDES.length;

;
// ============================================================
// TOOLHUB PRO - Engine: navigation, rendering, search, templates
// ============================================================

// ---------- TOAST / COPY ----------
function toast(msg, type=''){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast on${type ? ' '+type+'-t' : ''}`;
  setTimeout(() => el.classList.remove('on'), 2600);
}
function copyText(text, btn){
  navigator.clipboard.writeText(text).then(() => {
    toast('Copied to clipboard', 'ok');
    if (btn) { const o=btn.textContent; btn.textContent='Copied'; btn.classList.add('copied'); setTimeout(()=>{btn.textContent=o;btn.classList.remove('copied')},1600); }
  }).catch(() => {
    const t = document.createElement('textarea');
    t.value = text; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t);
    toast('Copied', 'ok');
  });
}

// ---------- NAVIGATION ----------
const LANG = document.documentElement.lang==='hi' ? 'hi' : 'en';
const HOME = LANG==='hi' ? '/hi/' : '/';
const TOOLP = LANG==='hi' ? '/hi/tools/' : '/tools/';
let currentPage = 'home';
let navStack = [];
let currentView = 'home';
function navigate(page, opts){
  opts = opts || {};
  const view = page==='generic-tool' ? (opts.toolId||page) : page;
  if (!opts.back && !opts.noPush && currentView !== view) navStack.push(currentView);
  currentView = view;
  document.querySelectorAll('.page').forEach(p => { p.classList.remove('active'); p.style.display='none'; });
  const el = document.getElementById('pg-' + page);
  if (el) { el.classList.add('active'); el.style.display='block'; currentPage = page; }
  window.scrollTo(0,0); document.documentElement.scrollTop=0; document.body.scrollTop=0;
  closeMenu();
  document.querySelectorAll('.hnav a').forEach(a => a.classList.remove('act'));
  const na = document.getElementById('nav-' + page); if (na) na.classList.add('act');
  if (history && history.pushState && !opts.noHash) {
    const toolId = opts.toolId || page;
    const isTool = !!TOOLS.find(t=>t.id===toolId);
    if (USE_PATH) {
      const path = page==='home' ? HOME : (isTool ? TOOLP+toolId+'/' : '/'+page+'/');
      if (location.pathname !== path || location.hash) history.pushState({i:histIdx()+1},'', path);
    } else {
      const hash = page==='home' ? '' : (isTool ? '#tool='+toolId : '#page='+page);
      if (location.hash !== hash) history.pushState({i:histIdx()+1},'', location.pathname + hash);
    }
  }
  if (LANG==='hi') document.documentElement.lang = (page==='home' || TOOLS.find(x=>x.id===(opts.toolId||page))) ? 'hi' : 'en';
  updateMeta(page, opts.toolId);
  if (opts.toolId || TOOLS.find(t=>t.id===page)) { const id = opts.toolId || page; trackRecent(id); ensureActions(id); track('tool_open',{tool_id:id}); }
  const hs = document.getElementById('homeShelf'); if (hs && page==='home') renderShelf();
  fixLabels(document.querySelector('.page.active'));
}
const USE_PATH = /^https?:$/.test(location.protocol);
const PAGE_TITLES = {home: LANG==='hi' ? 'Kitwell | 150+ मुफ्त ऑनलाइन टूल्स' : 'Kitwell | 150+ Free Online Tools', about:'About Kitwell', contact:'Contact Kitwell', privacy:'Privacy Policy | Kitwell', terms:'Terms and Conditions | Kitwell', disclaimer:'Disclaimer | Kitwell'};
function updateLangLink(page, toolId){
  const a=document.getElementById('langBtn'); if(!a||!USE_PATH) return;
  const t=TOOLS.find(x=>x.id===(toolId||page)); const to = LANG==='hi' ? '' : '/hi';
  let href;
  if (t) href = to+'/tools/'+t.id+'/';
  else if (page==='home') { const m=location.pathname.match(/\/category\/([a-z-]+)\/?$/); href = m ? to+'/category/'+m[1]+'/' : (LANG==='hi' ? '/' : '/hi/'); }
  else href = LANG==='hi' ? '/' : '/hi/';
  a.setAttribute('href', href);
}
function addGuideLink(tool){
  const pg=document.querySelector('.page.active'); if(!pg||!tool) return;
  const hd=pg.querySelector('.tool-hd'); if(!hd) return;
  const old=hd.querySelector('.glink'); if(old) old.remove();
  const g=GUIDE_BY_TOOL[tool.id]; if(!g||LANG==='hi'||!USE_PATH) return;
  const a=document.createElement('a'); a.className='glink'; a.href='/guides/'+g.slug+'/'; a.textContent='Guide: '+g.title; hd.appendChild(a);
}
function hiTitles(tool){
  if (LANG!=='hi' || !tool) return;
  const pg=document.querySelector('.page.active'); if(!pg) return;
  const h=pg.querySelector('.tool-hd h1'), d=pg.querySelector('.tool-hd p');
  if (h) h.textContent = trN(tool); if (d) d.textContent = trD(tool);
  const bc=pg.querySelectorAll('.bc > a'); if (bc[0]) bc[0].textContent='वापस'; if (bc[1]) bc[1].textContent='होम';
}
function updateMeta(page, toolId){
  const t = TOOLS.find(x=>x.id===(toolId||page));
  document.title = t ? (LANG==='hi' ? `${trN(t)}: मुफ्त ऑनलाइन टूल | Kitwell` : `${t.name}: Free Online Tool | Kitwell`) : (PAGE_TITLES[page] || PAGE_TITLES.home);
  if (USE_PATH) { const c=document.querySelector('link[rel=canonical]'); if (c) c.href = location.origin + (t && /^\/embed\//.test(location.pathname) ? '/tools/'+t.id+'/' : location.pathname);
  updateLangLink(page, toolId); if (/^\/embed\//.test(location.pathname)) { const r=document.querySelector('meta[name=robots]'); if (r) r.content='noindex, follow'; } }
}
// ---------- FAVOURITES / RECENT (per-browser, localStorage) ----------
function lsGet(k){ try{ return JSON.parse(localStorage.getItem(k)||'[]'); }catch(e){ return []; } }
function lsSet(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function trackRecent(id){ const r = lsGet('th-recent').filter(x=>x!==id); r.unshift(id); lsSet('th-recent', r.slice(0,8)); }
function isFav(id){ return lsGet('th-fav').includes(id); }
function toggleFav(id){
  let f = lsGet('th-fav'); f = f.includes(id) ? f.filter(x=>x!==id) : [id].concat(f);
  lsSet('th-fav', f.slice(0,24)); ensureActions(id); toast(f.includes(id)?'Saved to your tools':'Removed from your tools');
}
function shareTool(id){
  const url = USE_PATH ? location.origin + TOOLP + id + '/' + (currentView===id ? location.search : '') : location.href;
  const t = TOOLS.find(x=>x.id===id);
  if (navigator.share) { navigator.share({title:t?t.name:'Kitwell', url}).catch(()=>{}); }
  else copyText(url);
}
function downloadOutput(id){
  const root = document.querySelector('.page.active');
  if (!root) return;
  const parts = [];
  root.querySelectorAll('textarea[readonly], .res-box, .sgrid, #gtBody textarea[id$="out"], #gtBody textarea[id*="output"], pre.out').forEach(el => { const v = (el.value!==undefined && el.tagName==='TEXTAREA') ? el.value : el.innerText; if (v && v.trim()) parts.push(v.trim()); });
  if (!parts.length) { toast('Nothing to download yet', 'err'); return; }
  const blob = new Blob([parts.join('\n\n')+'\n'], {type:'text/plain'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = id + '-result.txt';
  document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function ensureActions(id){
  const root = document.querySelector('.page.active'); if (!root) return;
  const bc = root.querySelector('.bc'); if (!bc) return;
  let box = bc.querySelector('.tact'); if (!box) { box = document.createElement('div'); box.className='tact'; bc.appendChild(box); }
  const fav = isFav(id);
  box.innerHTML = `<button type="button" class="tbtn${fav?' on':''}" onclick="toggleFav('${id}')" aria-pressed="${fav}">${svgIcon('star',15)}<span>${fav?'Saved':'Save'}</span></button>`
    + `<button type="button" class="tbtn" onclick="shareTool('${id}')">${svgIcon('share',15)}<span>Share</span></button>`
    + (USE_PATH ? `<button type="button" class="tbtn" onclick="showEmbed('${id}')">${svgIcon('code',15)}<span>Embed</span></button>` : '')
    + `<button type="button" class="tbtn" onclick="downloadOutput('${id}')">${svgIcon('ui_down',15)}<span>Download</span></button>`
    + ((TOOLS.find(x=>x.id===id)||{}).kind==='calc' ? `<button type="button" class="tbtn" onclick="saveResult('${id}')">${svgIcon('ui_check',15)}<span>${LANG==='hi'?'नतीजा सेव':'Save result'}</span></button><button type="button" class="tbtn" onclick="shareCard('${id}')">${svgIcon('image',15)}<span>${LANG==='hi'?'इमेज':'Image'}</span></button>` : '');
  if (typeof renderSaved==='function') renderSaved(id);
}
function showEmbed(id){
  const t = TOOLS.find(x=>x.id===id); if(!t) return;
  const src = location.origin + '/embed/' + id + '/';
  const code = `<iframe src="${src}" width="100%" height="620" style="border:1px solid #e2e8f0;border-radius:12px" loading="lazy" title="${t.name}"></iframe>`;
  let d = document.getElementById('embedDlg'); if (d) d.remove();
  d = document.createElement('div'); d.id='embedDlg'; d.className='dlg'; d.setAttribute('role','dialog'); d.setAttribute('aria-modal','true'); d.setAttribute('aria-label','Embed this tool');
  d.innerHTML = `<div class="dlg-ov" onclick="document.getElementById('embedDlg').remove()"></div><div class="dlg-bx"><div class="dlg-hd"><h3>Embed ${esc(t.name)}</h3><button type="button" class="mclose dlg-x" onclick="document.getElementById('embedDlg').remove()" aria-label="Close">${svgIcon('ui_close',18)}</button></div><p style="font-size:13px;color:var(--t2);margin-bottom:10px">Paste this on your website or blog. The tool runs inside the frame and links back to Kitwell.</p><textarea class="fc mono" id="embedCode" rows="4" readonly>${esc(code)}</textarea><div style="display:flex;gap:8px;margin-top:12px"><button type="button" class="btn btn-p btn-sm" onclick="copyText(document.getElementById('embedCode').value,this)">Copy code</button><a class="btn btn-s btn-sm" href="${src}" target="_blank" rel="noopener">Preview</a></div></div>`;
  document.body.appendChild(d); const ta=d.querySelector('textarea'); if(ta){ ta.focus(); ta.select(); }
}
function renderShelf(){
  const el = document.getElementById('homeShelf'); if (!el) return;
  const favs = lsGet('th-fav').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean);
  const rec = lsGet('th-recent').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean).filter(t=>!favs.includes(t)).slice(0,6);
  const chip = t => `<a class="shc" href="${USE_PATH?TOOLP+t.id+'/':'#tool='+t.id}" onclick="event.preventDefault();openTool('${t.id}')">${toolIconSvg(t,16)}<span>${esc(trN(t))}</span></a>`;
  let h='';
  if (favs.length) h += `<div class="shr"><div class="shl">${LANG==="hi"?"सेव किए":"Saved"}</div><div class="shg">${favs.map(chip).join('')}</div></div>`;
  if (rec.length) h += `<div class="shr"><div class="shl">${LANG==="hi"?"हाल में इस्तेमाल किए":"Recently used"}</div><div class="shg">${rec.map(chip).join('')}</div></div>`;
  el.innerHTML = h; el.style.display = h ? '' : 'none';
}
// ---------- THEME ----------
function openMenu(){ const m=document.getElementById('mnav'); if(!m) return; m.classList.add('on'); document.body.style.overflow='hidden'; const b=document.getElementById('mtog'); if(b) b.setAttribute('aria-expanded','true'); setTimeout(()=>{const c=m.querySelector('.mclose'); if(c) c.focus();},60); }
function closeMenu(){ const m=document.getElementById('mnav'); if(!m) return; m.classList.remove('on'); document.body.style.overflow=''; const b=document.getElementById('mtog'); if(b){ b.setAttribute('aria-expanded','false'); } }
document.addEventListener('keydown', e => { if (e.key==='Escape') closeMenu(); });
function setTheme(t){
  if (t==='dark') document.documentElement.setAttribute('data-theme','dark'); else document.documentElement.removeAttribute('data-theme');
  try{ localStorage.setItem('th-theme', t); }catch(e){}
  ['themeBtn','themeBtn2'].forEach((id,i)=>{ const b = document.getElementById(id); if (b) { b.innerHTML = svgIcon(t==='dark'?'ui_sun':'ui_moon',17) + (i?'<span>'+(t==='dark'?'Light theme':'Dark theme')+'</span>':''); b.setAttribute('aria-label', t==='dark'?'Switch to light theme':'Switch to dark theme'); } });
}
function toggleTheme(){ setTheme(document.documentElement.getAttribute('data-theme')==='dark' ? 'light' : 'dark'); }
function fixLabels(root){
  (root||document).querySelectorAll('label.fl').forEach(l=>{
    if (l.hasAttribute('for') || l.querySelector('input,select,textarea')) return;
    const c=l.parentElement && l.parentElement.querySelector('input:not([type=hidden]),select,textarea'); if(!c) return;
    if(!c.id) c.id='fld-'+Math.random().toString(36).slice(2,8); l.setAttribute('for', c.id);
  });
}
function histIdx(){ return (history.state && history.state.i) || 0; }
function goBack(){
  if (history && histIdx() > 0) { navStack.pop(); history.back(); return; }
  navStack = []; navigate('home');
}
function nav2(page){ navigate(page); }

function openTool(id, opts){
  try{
    const tool = TOOLS.find(t => t.id === id);
    if (!tool) return;
    if (tool.kind === 'dedicated') { navigate(id, opts); if (typeof setupToolPage === 'function') setupToolPage(id); hiTitles(tool); addGuideLink(tool); return; }
    renderGenericTool(tool, opts); hiTitles(tool); addGuideLink(tool);
  } catch(e){ console.error('openTool error:', e); }
}
function scrollToCat(id){ setTimeout(()=>{ const el=document.getElementById('cat-'+id); if (el) el.scrollIntoView({behavior:'smooth',block:'start'}); }, 80); }

// ---------- CATEGORY ICON ----------
function catIcon(cat, size){
  const cfg = CAT_CONFIG[cat] || {ab:'?',bg:'#64748B'};
  return `<div style="background:${cfg.bg};width:${size}px;height:${size}px;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0">${catIconSvg(cat, Math.round(size*0.55))}</div>`;
}

// ---------- HOME RENDER ----------
function trN(t){ return LANG==='hi' && HI_TOOLS[t.id] ? HI_TOOLS[t.id].n : t.name; }
function trD(t){ return LANG==='hi' && HI_TOOLS[t.id] ? HI_TOOLS[t.id].d : t.desc; }
function switchLang(e){ if(!USE_PATH) return false; return true; }
function renderHome(){
  const area = document.getElementById('toolsArea');
  if (!area) return;
  const cats = Object.keys(CAT_CONFIG);
  let html = '';
  cats.forEach(cat => {
    const cfg = CAT_CONFIG[cat];
    const catTools = TOOLS.filter(t => t.cat === cat);
    if (!catTools.length) return;
    html += `
      <section class="cat-sec" id="cat-${cfg.id}" data-cat="${cat}">
        <div class="cat-hd">
          ${catIcon(cat,38)}
          <div><h2>${LANG==='hi'?(HI_CAT[cat]||cat):cat}</h2><p>${LANG==='hi' ? catTools.length+' '+HI_UI.tools+': '+esc(HI_CAT_USE[cat]||'') : catTools.length+' tools for '+esc(CAT_USE[cat]||'everyday use')}</p></div>
        </div>
        <div class="tgrid">
          ${catTools.map(t => `
            <div class="tc" role="link" tabindex="0" onclick="openTool('${t.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openTool('${t.id}')}">
              <div class="tc-ic" style="background:${cfg.bg}">${toolIconSvg(t,20)}</div>
              <div class="tc-nm">${esc(trN(t))}</div>
              <div class="tc-ds">${esc(trD(t))}</div>
              ${t.badge ? `<span class="tc-bd ${t.badge==='pop'?'bd-pop':'bd-new'}">${LANG==='hi'?(t.badge==='pop'?'लोकप्रिय':'नया'):(t.badge==='pop'?'Popular':'New')}</span>` : ''}
            </div>
          `).join('')}
        </div>
      </section>`;
  });
  area.innerHTML = html;
}
function filterCat(cat, btn){
  document.querySelectorAll('.cb').forEach(b => b.classList.remove('act'));
  btn.classList.add('act');
  if (typeof USE_PATH!=='undefined' && USE_PATH && history.pushState){ const path = cat==='all' ? HOME : HOME+'category/'+catSlug(cat)+'/'; if (location.pathname!==path) history.pushState({i:histIdx()+1},'',path); document.title = cat==='all' ? PAGE_TITLES.home : (LANG==='hi' ? (HI_CAT[cat]||cat)+': मुफ्त ऑनलाइन टूल्स | Kitwell' : cat+': Free Online Tools | Kitwell'); }
  document.querySelectorAll('.cat-sec').forEach(s => { s.style.display = (cat==='all' || s.dataset.cat===cat) ? '' : 'none'; });
  updateLangLink('home');
}
function renderRelated(containerId, cat, currentName, limit=6){
  const el = document.getElementById(containerId);
  if (!el) return;
  const cur = TOOLS.find(t => t.name === currentName);
  let related = ((cur && RELATED[cur.id]) || []).map(id => TOOLS.find(t => t.id === id)).filter(Boolean);
  if (related.length < limit) {
    const have = new Set(related.map(t => t.id).concat(cur ? [cur.id] : []));
    related = related.concat(TOOLS.filter(t => t.cat === cat && !have.has(t.id) && t.name !== currentName).sort((x,y)=>x.id<y.id?-1:1));
  }
  related = related.slice(0, limit);
  el.innerHTML = related.map(t => `
    <div class="tc" role="link" tabindex="0" onclick="openTool('${t.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openTool('${t.id}')}">
      <div class="tc-ic" style="background:${CAT_CONFIG[t.cat].bg}">${toolIconSvg(t,20)}</div>
      <div class="tc-nm">${esc(trN(t))}</div>
      <div class="tc-ds">${esc(trD(t))}</div>
    </div>`).join('');
}

// ---------- SEARCH ----------
function lev1(a,b){ if(a===b) return true; if(Math.abs(a.length-b.length)>1) return false; let i=0,j=0,d=0; while(i<a.length&&j<b.length){ if(a[i]===b[j]){i++;j++;continue;} if(++d>1) return false; if(a.length>b.length) i++; else if(a.length<b.length) j++; else {i++;j++;} } return d + (a.length-i) + (b.length-j) <= 1; }
function searchTools(q, limit){
  q = q.trim().toLowerCase(); if (q.length<2) return [];
  const toks = q.split(/\s+/).filter(Boolean);
  const scored = [];
  TOOLS.forEach(t => {
    const hi = LANG==='hi' && HI_TOOLS[t.id] ? (HI_TOOLS[t.id].n+' '+HI_TOOLS[t.id].d).toLowerCase() : '';
    const name=t.name.toLowerCase(), hay=(name+' '+t.desc.toLowerCase()+' '+t.cat.toLowerCase()+' '+t.id.replace(/-/g,' ')+' '+hi);
    const words=hay.split(/[^a-z0-9\u0900-\u097f]+/).filter(Boolean);
    let score=0, all=true;
    toks.forEach(tok => {
      if (name.startsWith(tok)) score+=100; else if (name.includes(tok)) score+=60; else if (hay.includes(tok)) score+=30;
      else if (tok.length>=4 && words.some(w=>w.length>=4 && lev1(tok,w))) score+=15; else all=false;
    });
    if (all && score>0) scored.push([score + (t.badge==='pop'?5:0), t]);
  });
  return scored.sort((a,b)=>b[0]-a[0]).slice(0,limit||8).map(x=>x[1]);
}
function doSearch(q){
  const res = document.getElementById('sRes');
  q = q.trim().toLowerCase();
  if (q.length < 2) { res.classList.remove('on'); return; }
  const hits = searchTools(q, 8);
  res.innerHTML = hits.length
    ? hits.map(t => `<div class="sri" onclick="document.getElementById('sIn').value='';document.getElementById('sRes').classList.remove('on');openTool('${t.id}')"><span class="sri-ic" style="background:${CAT_CONFIG[t.cat].bg};color:#fff">${toolIconSvg(t,15)}</span><div style="flex:1"><div style="font-weight:600">${esc(trN(t))}</div><div style="font-size:11px;color:var(--tm)">${esc(trD(t))}</div></div><span class="sri-cat">${esc(t.cat.split(' ')[0])}</span></div>`).join('')
    : `<div class="sri" style="color:var(--tm)">${LANG==="hi"?"कोई टूल नहीं मिला":"No tools found for"} "${esc(q)}"</div>`;
  res.classList.add('on');
}
function renderMenuCats(){
  const el=document.getElementById('mCats'); if(!el) return;
  el.innerHTML = Object.keys(CAT_CONFIG).map(cat=>{ const c=CAT_CONFIG[cat]; return `<button type="button" class="mcat" onclick="closeMenu();navigate('home');scrollToCat('${c.id}')"><span class="ci" style="background:${c.bg}">${catIconSvg(cat,15)}</span>${esc(LANG==='hi' ? (HI_CAT_SHORT[cat]||cat) : cat.replace(' Tools','').replace('Calculator','Calculators'))}</button>`; }).join('');
}
function mobileSearch(q){
  const res = document.getElementById('mSRes');
  q = q.trim().toLowerCase();
  if (q.length < 2) { res.innerHTML=''; return; }
  const hits = searchTools(q, 6);
  res.innerHTML = hits.map(t => `<button class="mlink" onclick="closeMenu();openTool('${t.id}')">${esc(t.name)}</button>`).join('');
}
document.addEventListener('keydown', e => { const tg=(e.target.tagName||'').toLowerCase(); if (e.key==='/' && !e.ctrlKey && !e.metaKey && tg!=='input' && tg!=='textarea' && tg!=='select' && !e.target.isContentEditable){ const i=document.getElementById('sIn'); if(i && i.offsetParent!==null){ e.preventDefault(); i.focus(); i.select(); } } });
document.addEventListener('keydown', e => { if (e.key==='Enter' && e.target && e.target.id==='sIn'){ const h=searchTools(e.target.value,1); if(h[0]){ e.target.value=''; const r=document.getElementById('sRes'); if(r) r.classList.remove('on'); openTool(h[0].id); } } });
document.addEventListener('click', e => { if (!e.target.closest('.hdr-search')) { const r=document.getElementById('sRes'); if (r) r.classList.remove('on'); } });

// ============================================================
// GENERIC TOOL RENDERER - dispatches by tool.kind
// ============================================================
function renderGenericTool(tool, opts){
  document.getElementById('gtBc').innerHTML = `<a class="bc-back" href="#" onclick="goBack();return false">Back</a><a href="#" onclick="navigate('home');return false">Home</a><span class="bc-sep">›</span><span style="color:var(--tm)">${esc(tool.cat)}</span><span class="bc-sep">›</span><span class="bc-cur">${esc(tool.name)}</span>`;
  document.getElementById('gtTitle').textContent = tool.name;
  document.getElementById('gtDesc').textContent = tool.desc;
  document.getElementById('gtBoxTitle').textContent = tool.name;
  document.getElementById('gtSidebar').innerHTML = `<h3>About This Tool</h3><p style="font-size:13px;color:var(--t2);line-height:1.7">${esc(tool.desc)}</p>`;

  let bodyHtml = '', initFn = null;
  if (tool.kind === 'convert') { ({bodyHtml, initFn} = buildConvertTool(tool)); }
  else if (tool.kind === 'text') { ({bodyHtml, initFn} = buildTextTool(tool)); }
  else if (tool.kind === 'compare') { ({bodyHtml, initFn} = buildCompareTool(tool)); }
  else if (tool.kind === 'calc') { ({bodyHtml, initFn} = buildCalcTool(tool)); }
  else if (tool.kind === 'base') { ({bodyHtml, initFn} = buildBaseTool(tool)); }
  else if (tool.kind === 'custom') {
    const impl = (typeof TOOL_CUSTOM !== 'undefined') && TOOL_CUSTOM[tool.id];
    if (impl) { bodyHtml = impl.body(); initFn = impl.init; }
    else { bodyHtml = `<div class="alert alert-warn">This tool is being finished. Check back soon.</div>`; }
  }
  document.getElementById('gtBody').innerHTML = bodyHtml;
  document.getElementById('gtInfo').innerHTML = ctHtml(tool, esc);
  renderRelated('gt-related', tool.cat, tool.name);
  navigate('generic-tool', Object.assign({toolId: tool.id}, opts||{}));
  if (initFn) setTimeout(initFn, 0);
}
function clearGeneric(){
  document.querySelectorAll('#gtBody textarea, #gtBody input[type=text], #gtBody input[type=number], #gtBody input[type=email], #gtBody input[type=password]').forEach(el => el.value='');
}

// ---------- TEMPLATE: CONVERT ----------
function buildConvertTool(tool){
  const table = (new Function('return ' + tool.table))();
  const units = table.units;
  const keys = Object.keys(units);
  const def = tool.def || {amt:1, from:keys[0], to:keys[1]};
  const opts = keys.map(k => `<option value="${k}">${units[k].l} (${k})</option>`).join('');
  const bodyHtml = `
    <div class="fg"><label class="fl">Amount</label><input type="number" class="fc" id="cv-amt" value="${def.amt}" oninput="cvRun('${tool.id}')"></div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:end;margin-bottom:16px">
      <div class="fg" style="margin:0"><label class="fl">From</label><select class="fc" id="cv-from" onchange="cvRun('${tool.id}')">${opts}</select></div>
      <button class="btn btn-s btn-sm" style="margin-bottom:1px" onclick="cvSwap('${tool.id}')" title="Swap" aria-label="Swap">${svgIcon('ui_swap',16)}</button>
      <div class="fg" style="margin:0"><label class="fl">To</label><select class="fc" id="cv-to" onchange="cvRun('${tool.id}')">${opts}</select></div>
    </div>
    <div class="res-box ok" id="cv-result" style="font-size:20px;font-weight:700;text-align:center"></div>
    <div class="divider"></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">All Conversions</div>
    <div id="cv-table"></div>`;
  const initFn = () => {
    document.getElementById('cv-from').value = def.from;
    document.getElementById('cv-to').value = def.to;
    const q = qsRead(); const uk = Object.keys(table.units);
    if (q.has('a')) document.getElementById('cv-amt').value = q.get('a');
    if (q.has('f') && uk.includes(q.get('f'))) document.getElementById('cv-from').value = q.get('f');
    if (q.has('t') && uk.includes(q.get('t'))) document.getElementById('cv-to').value = q.get('t');
    cvRun(tool.id);
  };
  return {bodyHtml, initFn};
}
function cvSwap(id){
  const f=document.getElementById('cv-from'), t=document.getElementById('cv-to');
  const tmp=f.value; f.value=t.value; t.value=tmp; cvRun(id);
}
function cvRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const table = (new Function('return ' + tool.table))();
  const amt = parseFloat(document.getElementById('cv-amt').value);
  const from = document.getElementById('cv-from').value;
  const to = document.getElementById('cv-to').value;
  const out = document.getElementById('cv-result');
  const tbl = document.getElementById('cv-table');
  qsWrite({a:document.getElementById('cv-amt').value, f:from, t:to});
  if (isNaN(amt)) { out.textContent = 'Enter a number'; tbl.innerHTML=''; return; }
  const baseVal = amt * table.units[from].f;
  const result = baseVal / table.units[to].f;
  out.innerHTML = `${amt} ${from} = <span style="color:var(--p)">${round4(result)} ${to}</span>`;
  tbl.innerHTML = Object.keys(table.units).map(k => {
    const v = baseVal / table.units[k].f;
    return `<div class="trow"><span>${esc(table.units[k].l)}</span><strong class="mono">${round4(v)} ${k}</strong></div>`;
  }).join('');
}

// ---------- TEMPLATE: TEXT (transform / analyzer) ----------
function buildTextTool(tool){
  const single = tool.single;
  const mono = tool.mono ? ' mono' : '';
  const btns = (tool.transforms||[]).map(tr => `<button class="btn ${tool.transforms.indexOf(tr)===0?'btn-p':'btn-s'} btn-sm" onclick="txRun('${tool.id}','${tool.transforms.indexOf(tr)}')">${esc(tr.label)}</button>`).join('');
  const liveAttr = tool.extra ? `oninput="txAnalyze('${tool.id}')"` : '';
  const bodyHtml = `
    <div class="fg"><label class="fl">Input</label><textarea class="fc${mono}" id="tx-in" rows="8" placeholder="Type or paste text here..." ${liveAttr}></textarea></div>
    ${btns ? `<div class="bgrp" style="margin-bottom:12px">${btns}</div>` : ''}
    ${tool.extra ? `<div id="tx-analysis"></div>` : `<div class="fg"><label class="fl">Output <button class="cpbtn" id="tx-cp" onclick="copyText(document.getElementById('tx-out').value,this)">Copy</button></label><textarea class="fc${mono}" id="tx-out" rows="8" readonly placeholder="Result will appear here..."></textarea></div>`}`;
  const initFn = () => { if (tool.extra) txAnalyze(tool.id); };
  return {bodyHtml, initFn};
}
function txRun(id, idx){
  const tool = TOOLS.find(t=>t.id===id);
  const tr = tool.transforms[+idx];
  const input = document.getElementById('tx-in').value;
  try { document.getElementById('tx-out').value = tr.run(input); }
  catch(e){ document.getElementById('tx-out').value = 'Error: '+e.message; }
}
function txAnalyze(id){
  const tool = TOOLS.find(t=>t.id===id);
  const text = document.getElementById('tx-in').value;
  const el = document.getElementById('tx-analysis');
  el.innerHTML = TEXT_ANALYZERS[tool.extra] ? TEXT_ANALYZERS[tool.extra](text) : '';
}

const TEXT_ANALYZERS = {
  charcount: t => {
    const bytes = new TextEncoder().encode(t).length;
    return statBlock([['Characters', t.length], ['No Spaces', t.replace(/\s/g,'').length], ['Bytes (UTF-8)', bytes]]);
  },
  linecount: t => {
    const lines = t.length ? t.split('\n') : [];
    const nonEmpty = lines.filter(l=>l.trim()).length;
    return statBlock([['Total Lines', lines.length], ['Non-empty', nonEmpty], ['Blank', lines.length-nonEmpty]]);
  },
  strlen: t => {
    const n = t.length;
    const limits = [['Tweet / X post',280],['SMS message',160],['Meta description',160],['Title tag',60]];
    return statBlock([['Length', n]]) + limits.map(([l,max]) => `<div class="trow"><span>${l} (${max})</span><strong style="color:${n>max?'var(--err)':'var(--ok)'}">${n}/${max} ${n>max?'over':'ok'}</strong></div>`).join('');
  },
  syllable: t => {
    const words = t.trim() ? t.trim().split(/\s+/) : [];
    let total = 0;
    words.forEach(w => { const m = w.toLowerCase().replace(/[^a-z]/g,'').match(/[aeiouy]+/g); total += Math.max(1, m ? m.length : 1); });
    return statBlock([['Words', words.length], ['Est. Syllables', total], ['Avg per Word', words.length?round4(total/words.length):0]]);
  },
  jsonvalidate: t => {
    if (!t.trim()) return '<div class="alert alert-warn">Paste some JSON first.</div>';
    try {
      const parsed = JSON.parse(t);
      let keys=0, depth=0, maxDepth=0;
      const walk = (o,d) => { maxDepth=Math.max(maxDepth,d); if (o && typeof o==='object') { Object.keys(o).forEach(k=>{keys++; walk(o[k],d+1);}); } };
      walk(parsed,0);
      return '<div class="alert alert-ok">Valid JSON</div>' + statBlock([['Keys/Items', keys], ['Max Depth', maxDepth], ['Type', Array.isArray(parsed)?'array':typeof parsed]]);
    } catch(e) { return `<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
  },
  titleanalyze: t => {
    const n = t.length;
    const ok = n>=30 && n<=60;
    return `<div class="alert ${ok?'alert-ok':'alert-warn'}">${n} characters - ${ok?'good length for a title tag':(n<30?'a bit short; consider 30-60 characters':'may get truncated in search results; aim for 30-60 characters')}</div>
      <div class="res-box" style="margin-top:10px"><div style="color:#1a0dab;font-size:18px;line-height:1.3">${esc(t)||'Your Page Title'}</div><div style="color:#006621;font-size:13px;margin-top:2px">yoursite.com › page</div></div>`;
  },
  metadescanalyze: t => {
    const n = t.length;
    const ok = n>=120 && n<=160;
    return `<div class="alert ${ok?'alert-ok':'alert-warn'}">${n} characters - ${ok?'good length for a meta description':(n<120?'a bit short; aim for 120-160 characters':'may get truncated; aim for 120-160 characters')}</div>
      <div class="res-box" style="margin-top:10px;color:var(--t2)">${esc(t)||'Your meta description will appear here.'}</div>`;
  },
  urlcheck: t => {
    const issues = [];
    if (t.length > 75) issues.push('URL is longer than 75 characters');
    if (/[A-Z]/.test(t)) issues.push('Contains uppercase letters (use lowercase)');
    if (/_/.test(t)) issues.push('Contains underscores (use hyphens instead)');
    if (/[^a-zA-Z0-9\-\/:.?=&]/.test(t)) issues.push('Contains special characters that may need encoding');
    if (/\s/.test(t)) issues.push('Contains spaces');
    if (!t.trim()) return '<div class="alert alert-info">Paste a URL to check.</div>';
    return issues.length ? '<div class="alert alert-warn">'+issues.map(esc).join('<br>')+'</div>' : '<div class="alert alert-ok">No common issues found.</div>';
  },
  alttext: t => {
    const imgs = [...t.matchAll(/<img\b[^>]*>/gi)];
    if (!imgs.length) return '<div class="alert alert-info">Paste HTML containing &lt;img&gt; tags.</div>';
    const missing = imgs.filter(m => !/\balt\s*=/i.test(m[0]));
    return statBlock([['Total Images', imgs.length],['Missing Alt Text', missing.length]]) +
      (missing.length ? '<div class="res-box er" style="margin-top:10px">'+missing.map(m=>esc(m[0])).join('\n')+'</div>' : '<div class="alert alert-ok" style="margin-top:10px">All images have alt text.</div>');
  },
  seolength: t => {
    const words = t.trim() ? t.trim().split(/\s+/).length : 0;
    let note;
    if (words < 300) note = 'Thin content - consider 600+ words for a standard blog post.';
    else if (words < 600) note = 'On the shorter side for competitive SEO content.';
    else if (words < 2000) note = 'Solid length for most blog posts and articles.';
    else note = 'Long-form content - good for comprehensive guides.';
    return statBlock([['Word Count', words]]) + `<div class="alert alert-info">${note}</div>`;
  },
};

// ---------- TEMPLATE: COMPARE ----------
function buildCompareTool(tool){
  const bodyHtml = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="fg"><label class="fl">${tool.compareMode==='anagram'?'Word / Phrase A':'Text A'}</label><textarea class="fc" id="cmp-a" rows="8"></textarea></div>
      <div class="fg"><label class="fl">${tool.compareMode==='anagram'?'Word / Phrase B':'Text B'}</label><textarea class="fc" id="cmp-b" rows="8"></textarea></div>
    </div>
    <button class="btn btn-p" onclick="cmpRun('${tool.id}')">Compare</button>
    <div id="cmp-result" style="margin-top:14px"></div>`;
  return {bodyHtml, initFn: null};
}
function cmpRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const a = document.getElementById('cmp-a').value;
  const b = document.getElementById('cmp-b').value;
  const res = document.getElementById('cmp-result');
  if (tool.compareMode === 'anagram') {
    const clean = s => s.toLowerCase().replace(/[^a-z0-9]/g,'').split('').sort().join('');
    const ca = clean(a), cb = clean(b);
    const is = ca && ca === cb;
    res.innerHTML = `<div class="alert ${is?'alert-ok':'alert-err'}">${is?'These are anagrams of each other.':'These are not anagrams.'}</div>`;
    return;
  }
  const la = a.split('\n'), lb = b.split('\n');
  const max = Math.max(la.length, lb.length);
  let same=0, diff=0, rows='';
  for (let i=0;i<max;i++){
    const x=la[i]??'', y=lb[i]??'';
    const eq = x===y; if(eq) same++; else diff++;
    rows += `<div class="trow" style="background:${eq?'transparent':'var(--errbg)'}"><span class="mono" style="font-size:12px">${esc(x)||'&nbsp;'}</span><span class="mono" style="font-size:12px">${esc(y)||'&nbsp;'}</span></div>`;
  }
  res.innerHTML = statBlock([['Matching Lines',same],['Different Lines',diff]]) + `<div style="margin-top:10px;border:1px solid var(--bdr);border-radius:8px;overflow:hidden">${rows}</div>`;
}

// ---------- TEMPLATE: CALC ----------
function buildCalcTool(tool){
  const fieldHtml = tool.fields.map(f => {
    if (f.type==='select') return `<div class="fg"><label class="fl">${esc(f.label)}</label><select class="fc" id="cf-${f.id}" oninput="calcRun('${tool.id}')" onchange="calcRun('${tool.id}')">${f.options.map(([v,l])=>`<option value="${v}">${esc(l)}</option>`).join('')}</select></div>`;
    if (f.type==='checkbox') return `<label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:14px;cursor:pointer"><input type="checkbox" id="cf-${f.id}" oninput="calcRun('${tool.id}')" onchange="calcRun('${tool.id}')"> ${esc(f.label)}</label>`;
    if (f.type==='textarea') return `<div class="fg"><label class="fl">${esc(f.label)}</label><textarea class="fc" id="cf-${f.id}" rows="5" oninput="calcRun('${tool.id}')">${esc(f.value||'')}</textarea></div>`;
    return `<div class="fg"><label class="fl">${esc(f.label)}</label><input type="${f.type}" class="fc" id="cf-${f.id}" value="${esc(f.value??'')}" placeholder="${esc(f.placeholder||'')}" ${f.min!=null?`min="${f.min}"`:''} ${f.max!=null?`max="${f.max}"`:''} ${f.step!=null?`step="${f.step}"`:''} oninput="calcRun('${tool.id}')"></div>`;
  }).join('');
  const bodyHtml = `${fieldHtml}<div id="calc-result" style="margin-top:4px"></div>`;
  const initFn = () => { const q = qsRead(); tool.fields.forEach(f => { const el = document.getElementById('cf-'+f.id); if (el && q.has(f.id)) { if (f.type==='checkbox') el.checked = q.get(f.id)==='1'; else el.value = q.get(f.id); } }); calcRun(tool.id); };
  return {bodyHtml, initFn};
}
function qsRead(){ try{ return new URLSearchParams(location.search); }catch(e){ return new URLSearchParams(); } }
function qsWrite(obj){
  if (!USE_PATH || !history.replaceState) return;
  const p = new URLSearchParams(); Object.keys(obj).forEach(k => { if (obj[k] !== '' && obj[k] !== undefined && obj[k] !== false) p.set(k, obj[k]===true?'1':obj[k]); });
  const s = p.toString(); const url = location.pathname + (s ? '?'+s : '') + location.hash;
  if (url !== location.pathname + location.search + location.hash) history.replaceState(history.state,'',url);
}
function calcRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const values = {};
  tool.fields.forEach(f => {
    const el = document.getElementById('cf-'+f.id);
    if (!el) return;
    values[f.id] = f.type==='checkbox' ? el.checked : el.value;
  });
  const res = document.getElementById('calc-result');
  if (!window.__noQs) qsWrite(values);
  try { res.innerHTML = tool.compute(values) || ''; }
  catch(e){ res.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`; }
}

// ---------- TEMPLATE: NUMBER BASE ----------
function buildBaseTool(tool){
  const bodyHtml = `
    <div class="fg"><label class="fl">Value</label><input type="text" class="fc mono" id="bs-val" value="255" oninput="bsRun()"></div>
    <div class="fg"><label class="fl">Input Base</label>
      <select class="fc" id="bs-from" onchange="bsRun()"><option value="2">Binary (2)</option><option value="8">Octal (8)</option><option value="10" selected>Decimal (10)</option><option value="16">Hexadecimal (16)</option></select>
    </div>
    <div id="bs-out"></div>`;
  return {bodyHtml, initFn: bsRun};
}
function bsRun(){
  const valEl = document.getElementById('bs-val'); if (!valEl) return;
  const base = parseInt(document.getElementById('bs-from').value);
  const raw = valEl.value.trim();
  const out = document.getElementById('bs-out');
  const n = parseInt(raw, base);
  if (isNaN(n)) { out.innerHTML = '<div class="alert alert-warn">Invalid number for that base.</div>'; return; }
  out.innerHTML = [['Binary',2],['Octal',8],['Decimal',10],['Hexadecimal',16]].map(([l,b]) => `<div class="trow"><span>${l}</span><strong class="mono">${n.toString(b).toUpperCase()}</strong></div>`).join('');
}

// ---------- CONTACT FORM ----------
function setSubject(btn, subject){
  document.querySelectorAll('.subj-btn').forEach(b => b.classList.remove('active-subj'));
  btn.classList.add('active-subj');
  document.getElementById('cf-subject').value = subject;
  document.getElementById('form-subject-hidden').value = 'Kitwell: ' + subject;
}
document.addEventListener('DOMContentLoaded', () => {
  const msg = document.getElementById('cf-msg');
  const cnt = document.getElementById('charCount');
  if (msg && cnt) {
    msg.addEventListener('input', () => {
      const len = msg.value.length;
      cnt.textContent = len + ' / 1000';
      cnt.style.color = len > 900 ? 'var(--err)' : 'var(--tm)';
      if (len > 1000) msg.value = msg.value.slice(0,1000);
    });
  }
});
async function handleFormSubmit(e){
  e.preventDefault();
  const btn = document.getElementById('cf-btn');
  const st = document.getElementById('cf-status');
  const form = document.getElementById('contactForm');
  btn.innerHTML = 'Sending…';
  btn.disabled = true;
  try {
    const res = await fetch(form.action, { method:'POST', body:new FormData(form), headers:{'Accept':'application/json'} });
    if (res.ok) {
      st.innerHTML = '<div class="alert alert-ok">Message sent. We will get back to you within 24 hours.</div>';
      form.reset();
      document.querySelectorAll('.subj-btn').forEach((b,i)=>{ b.classList.remove('active-subj'); if(i===0) b.classList.add('active-subj'); });
      document.getElementById('charCount').textContent = '0 / 1000';
    } else { st.innerHTML = '<div class="alert alert-warn">Something went wrong. Please try again.</div>'; }
  } catch(err){ st.innerHTML = '<div class="alert alert-warn">Connection error. Check your internet and try again.</div>'; }
  btn.innerHTML = 'Send Message';
  btn.disabled = false;
}

// ---------- DEDICATED TOOL PAGE SETUP ----------
function setupToolPage(id){
  (function(){ const t=TOOLS.find(x=>x.id===id); const info=document.querySelector('#pg-'+id+' .tool-info'); if(t && info && !info.dataset.x){ info.dataset.x='1'; info.insertAdjacentHTML('beforeend', ctHtml(Object.assign({},t,{info:''}), esc)); } })();
  if (id==='word-counter') { renderRelated('wc-related','Text Tools','Word Counter'); }
  else if (id==='password-generator') { genPG(); renderRelated('pg-related','Developer Tools','Password Generator'); }
  else if (id==='json-formatter') { renderRelated('json-related','Developer Tools','JSON Formatter'); }
  else if (id==='bmi-calculator') { renderRelated('bmi-related','Calculator Tools','BMI Calculator'); }
  else if (id==='age-calculator') { renderRelated('ac-related','Calculator Tools','Age Calculator'); }
}

// ---------- INIT ----------
function catSlug(cat){ return cat.toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
function initHashRoute(){
  const h = location.hash, p = location.pathname;
  let m = p.match(/\/tools\/([^\/]+)\/?$/);
  if (m && TOOLS.find(t=>t.id===m[1])) { openTool(m[1],{noPush:true,noHash:true}); return; }
  m = p.match(/\/embed\/([^\/]+)\/?$/);
  if (m && TOOLS.find(t=>t.id===m[1])) { openTool(m[1],{noPush:true,noHash:true}); return; }
  m = p.match(/\/category\/([a-z-]+)\/?$/);
  if (m) { const c=Object.keys(CAT_CONFIG).find(k=>catSlug(k)===m[1]); if (c) { navigate('home',{noPush:true,noHash:true}); const cfg=CAT_CONFIG[c]; const btn=[...document.querySelectorAll('.cb')].find(b=>(b.getAttribute('onclick')||'').includes("'"+c+"'")); if (btn) filterCat(c,btn); document.title = LANG==='hi' ? (HI_CAT[c]||c)+': मुफ्त ऑनलाइन टूल्स | Kitwell' : c+': Free Online Tools | Kitwell'; return; } }
  m = p.match(/\/(about|contact|privacy|terms|disclaimer)\/?$/);
  if (m && document.getElementById('pg-'+m[1])) { navigate(m[1],{noPush:true,noHash:true}); return; }
  if (h.startsWith('#tool=')) { const id = h.slice(6); if (TOOLS.find(t=>t.id===id)) { openTool(id,{noPush:true}); return; } }
  if (h.startsWith('#page=')) { const id = h.slice(6); if (document.getElementById('pg-'+id)) { navigate(id,{noPush:true}); return; } }
  navigate('home',{noPush:true,noHash:true});
}
document.getElementById('yr').textContent = new Date().getFullYear();
setTheme(document.documentElement.getAttribute('data-theme')==='dark'?'dark':'light');
(function(){const m={icSearch:['ui_search',16],icSearchM:['ui_search',16],icClose:['ui_close',20],icTb:['ui_arrow',14],icTb2:['ui_arrow',16],icF1:['shield',20],icF2:['ui_check',20],icF3:['star',20],icXA:['calc',16],icXB:['sip',16],icXC:['text',16],icBadge:['ui_check',14],icUp:['ui_up',14],icMHome:['grid',18],icMTools:['tool',18],icMAbout:['person',18],icMContact:['mail',18]};
  Object.keys(m).forEach(k=>{const e=document.getElementById(k); if(e) e.innerHTML=svgIcon(m[k][0],m[k][1]);});})();
function suggestTool(){ navigate('contact'); const b=document.querySelector('#subjectBtns .subj-btn'); if(b && typeof setSubject==='function') setSubject(b,'Suggest a New Tool'); }
function goToTools(e){
  if(e) e.preventDefault();
  const go=()=>{const el=document.getElementById('toolsArea'); if(el) el.scrollIntoView({behavior:'smooth',block:'start'});};
  if(currentPage!=='home'){ navigate('home'); setTimeout(go,60); } else go();
}
renderHome();
renderMenuCats();
document.querySelectorAll('.page').forEach(p => { p.style.display = p.classList.contains('active') ? 'block' : 'none'; });
const todayDate = new Date().toISOString().split('T')[0];
const dobEl = document.getElementById('ac-dob'); if (dobEl) dobEl.max = todayDate;
genPG();
initHashRoute();
window.addEventListener('popstate', initHashRoute);
if (USE_PATH && 'serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(()=>{}); }); }

;
// ---------- ANALYTICS (GA4 events only if gtag exists; no extra cookies set by us) ----------
function track(name, params){ try{ if (typeof gtag==='function') gtag('event', name, params||{}); }catch(e){} }

// ---------- DIALOG HELPERS ----------
let _dlgOpener = null;
function closeDlg(){ document.querySelectorAll('.dlg').forEach(d=>d.remove()); if (_dlgOpener && _dlgOpener.focus) { try{ _dlgOpener.focus(); }catch(e){} } _dlgOpener=null; }
function openDlg(id, label, html){
  _dlgOpener = document.activeElement;
  document.querySelectorAll('.dlg').forEach(d=>d.remove());
  const d=document.createElement('div'); d.id=id; d.className='dlg'; d.setAttribute('role','dialog'); d.setAttribute('aria-modal','true'); d.setAttribute('aria-label',label);
  d.innerHTML=`<div class="dlg-ov" onclick="closeDlg()"></div><div class="dlg-bx">${html}</div>`;
  document.body.appendChild(d); return d;
}

// ---------- COMMAND PALETTE (Ctrl/Cmd + K) ----------
let palSel = 0, palHits = [];
function palHtml(){
  return `<div class="pal"><input type="text" id="palIn" class="pal-in" placeholder="${LANG==='hi'?'टूल खोजें':'Search tools'}" aria-label="${LANG==='hi'?'टूल खोजें':'Search tools'}" role="combobox" aria-expanded="true" aria-controls="palList" aria-autocomplete="list" autocomplete="off"><ul id="palList" class="pal-list" role="listbox"></ul><div class="pal-ft"><span><kbd>↑</kbd><kbd>↓</kbd> ${LANG==='hi'?'चुनें':'move'}</span><span><kbd>Enter</kbd> ${LANG==='hi'?'खोलें':'open'}</span><span><kbd>Esc</kbd> ${LANG==='hi'?'बंद':'close'}</span></div></div>`;
}
function palRender(q){
  const list=document.getElementById('palList'); if(!list) return;
  q=(q||'').trim();
  if (q.length>=2) palHits = searchTools(q, 8);
  else { const rec=lsGet('th-recent').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean); const pop=['word-counter','emi-calculator','sip-calculator','income-tax-india','pdf-merge','password-generator','qr-generator','image-compressor'].map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean); const seen=new Set(); palHits=rec.concat(pop).filter(t=>!seen.has(t.id)&&seen.add(t.id)).slice(0,8); }
  palSel=0;
  list.innerHTML = palHits.length ? palHits.map((t,i)=>`<li id="pal-${i}" role="option" aria-selected="${i===0}" class="pal-it${i===0?' on':''}" data-i="${i}"><span class="sri-ic" style="background:${CAT_CONFIG[t.cat].bg};color:#fff">${toolIconSvg(t,16)}</span><span class="pal-tx"><b>${esc(trN(t))}</b><i>${esc(trD(t))}</i></span></li>`).join('') : `<li class="pal-empty">${LANG==='hi'?'कोई टूल नहीं मिला':'No tools found'}</li>`;
  const inp=document.getElementById('palIn'); if(inp) inp.setAttribute('aria-activedescendant', palHits.length?'pal-0':'');
}
function palMove(d){
  if(!palHits.length) return; palSel=(palSel+d+palHits.length)%palHits.length;
  document.querySelectorAll('#palList .pal-it').forEach((li,i)=>{ li.classList.toggle('on',i===palSel); li.setAttribute('aria-selected',i===palSel); if(i===palSel) li.scrollIntoView({block:'nearest'}); });
  const inp=document.getElementById('palIn'); if(inp) inp.setAttribute('aria-activedescendant','pal-'+palSel);
}
function palOpenSel(){ const t=palHits[palSel]; if(!t) return; closeDlg(); track('palette_open_tool',{tool_id:t.id}); openTool(t.id); }
function showPalette(){
  if (document.getElementById('palDlg')) { closeDlg(); return; }
  closeMenu(); const d=openDlg('palDlg', LANG==='hi'?'टूल खोजें':'Command palette', palHtml()); d.classList.add('dlg-top');
  const inp=d.querySelector('#palIn'); palRender(''); inp.focus(); track('palette_show');
  inp.addEventListener('input',()=>palRender(inp.value));
  inp.addEventListener('keydown',e=>{ if(e.key==='ArrowDown'){e.preventDefault();palMove(1);} else if(e.key==='ArrowUp'){e.preventDefault();palMove(-1);} else if(e.key==='Enter'){e.preventDefault();palOpenSel();} });
  d.querySelector('#palList').addEventListener('click',e=>{ const li=e.target.closest('.pal-it'); if(li){ palSel=+li.dataset.i; palOpenSel(); } });
}

// ---------- SHORTCUTS ----------
function showShortcuts(){
  const rows=[['/', LANG==='hi'?'हेडर में खोजें':'Focus the header search'],['Ctrl + K  or  Cmd + K', LANG==='hi'?'टूल पैलेट खोलें':'Open the tool palette'],['?', LANG==='hi'?'यह सूची खोलें':'Show this list'],['Esc', LANG==='hi'?'डायलॉग बंद करें':'Close a dialog or menu'],['Enter', LANG==='hi'?'खोज में पहले टूल को खोलें':'Open the top search result'],['Alt + ←', LANG==='hi'?'पिछले पेज पर जाएं':'Go back (browser)']];
  openDlg('shortDlg', LANG==='hi'?'कीबोर्ड शॉर्टकट':'Keyboard shortcuts', `<div class="dlg-hd"><h3>${LANG==='hi'?'कीबोर्ड शॉर्टकट':'Keyboard shortcuts'}</h3><button type="button" class="mclose dlg-x" onclick="closeDlg()" aria-label="Close">${svgIcon('ui_close',18)}</button></div><table class="sk-tbl"><tbody>${rows.map(r=>`<tr><td>${r[0].split('  or  ').map(k=>k.split(' + ').map(x=>`<kbd>${esc(x)}</kbd>`).join(' + ')).join(' <span class="sk-or">/</span> ')}</td><td>${esc(r[1])}</td></tr>`).join('')}</tbody></table>`).querySelector('.dlg-x').focus();
}
document.addEventListener('keydown', e => {
  const tg=(e.target.tagName||'').toLowerCase(); const typing = tg==='input'||tg==='textarea'||tg==='select'||e.target.isContentEditable;
  if ((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); showPalette(); return; }
  if (e.key==='Escape'){ if(document.querySelector('.dlg')) closeDlg(); return; }
  if (e.key==='?' && !typing && !e.ctrlKey && !e.metaKey){ e.preventDefault(); showShortcuts(); }
});

// ---------- SAVED RESULTS (this browser only) ----------
function resultPairs(){
  const pg=document.querySelector('.page.active'); if(!pg) return [];
  return [...pg.querySelectorAll('.sgrid .sc')].map(sc=>[(sc.querySelector('.sl')||{}).textContent||'', (sc.querySelector('.sn')||{}).textContent||'']).filter(p=>p[0]&&p[1]);
}
function getSaved(){ try{ return JSON.parse(localStorage.getItem('th-saved')||'[]'); }catch(e){ return []; } }
function putSaved(a){ try{ localStorage.setItem('th-saved', JSON.stringify(a.slice(0,40))); }catch(e){} }
function saveResult(id){
  const pairs=resultPairs(); if(!pairs.length){ toast(LANG==='hi'?'पहले कोई नतीजा निकालें':'Run the calculation first'); return; }
  const a=getSaved(); a.unshift({id, qs: USE_PATH ? location.search : '', t: Date.now(), p: pairs.slice(0,4)});
  putSaved(a); track('save_result',{tool_id:id}); renderSaved(id); toast(LANG==='hi'?'नतीजा सेव हुआ':'Result saved');
}
function deleteSaved(t){ putSaved(getSaved().filter(x=>x.t!==t)); const c=currentToolId(); if(c) renderSaved(c); }
function restoreSaved(t){
  const s=getSaved().find(x=>x.t===t); if(!s) return;
  if (USE_PATH) history.pushState({i:histIdx()+1}, '', TOOLP+s.id+'/'+(s.qs||''));
  openTool(s.id,{noPush:true,noHash:true});
}
function currentToolId(){ const m=location.pathname.match(/\/tools\/([^\/]+)\/?$/); if(m&&TOOLS.find(t=>t.id===m[1])) return m[1]; return (typeof currentView!=='undefined' && TOOLS.find(t=>t.id===currentView)) ? currentView : null; }
function renderSaved(id){
  const pg=document.querySelector('.page.active'); if(!pg) return;
  const t=TOOLS.find(x=>x.id===id); if(!t||t.kind!=='calc'){ const o=pg.querySelector('.svbox'); if(o) o.remove(); return; }
  let box=pg.querySelector('.svbox'); const list=getSaved().filter(x=>x.id===id).slice(0,8);
  if(!list.length){ if(box) box.remove(); return; }
  if(!box){ box=document.createElement('section'); box.className='svbox'; box.setAttribute('aria-label','Saved results'); const anchor=pg.querySelector('.tbox'); if(!anchor) return; anchor.insertAdjacentElement('afterend', box); }
  const fmt=ts=>new Date(ts).toLocaleDateString(undefined,{day:'numeric',month:'short'});
  box.innerHTML=`<h3>${LANG==='hi'?'सेव किए नतीजे':'Saved results'}</h3><ul>${list.map(x=>`<li><span class="sv-tx">${x.p.map(p=>`<b>${esc(p[1])}</b> ${esc(p[0])}`).join('<i>·</i>')}</span><span class="sv-dt">${fmt(x.t)}</span><button type="button" class="tbtn" onclick="restoreSaved(${x.t})">${LANG==='hi'?'वापस लाएं':'Restore'}</button><button type="button" class="tbtn" onclick="deleteSaved(${x.t})">${LANG==='hi'?'हटाएं':'Delete'}</button></li>`).join('')}</ul>`;
}

// ---------- SHARE CARD (PNG drawn in the browser) ----------
async function shareCard(id){
  const t=TOOLS.find(x=>x.id===id); const pairs=resultPairs().slice(0,3);
  if(!t||!pairs.length){ toast(LANG==='hi'?'पहले कोई नतीजा निकालें':'Run the calculation first'); return; }
  try{ await document.fonts.load('700 56px Inter'); await document.fonts.load('500 26px Inter'); }catch(e){}
  const W=1200,H=630,c=document.createElement('canvas'); c.width=W; c.height=H; const x=c.getContext('2d');
  x.fillStyle='#060B16'; x.fillRect(0,0,W,H);
  const glow=(cx,cy,r,col)=>{ const g=x.createRadialGradient(cx,cy,0,cx,cy,r); g.addColorStop(0,col); g.addColorStop(1,'rgba(0,0,0,0)'); x.fillStyle=g; x.fillRect(0,0,W,H); };
  glow(180,80,520,'rgba(36,81,224,.55)'); glow(1080,560,520,'rgba(8,145,178,.40)');
  const rr=(px,py,w,h,r)=>{ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); };
  rr(48,48,W-96,H-96,34); x.fillStyle='rgba(255,255,255,.07)'; x.fill(); x.strokeStyle='rgba(255,255,255,.22)'; x.lineWidth=2; x.stroke();
  x.fillStyle='#fff'; x.font='700 54px Inter, system-ui, sans-serif'; x.textBaseline='alphabetic'; x.fillText(t.name.length>34?t.name.slice(0,33)+'…':t.name, 96, 150);
  x.fillStyle='rgba(255,255,255,.6)'; x.font='500 26px Inter, system-ui, sans-serif'; x.fillText(t.cat, 96, 192);
  const n=pairs.length, gap=24, bw=(W-192-gap*(n-1))/n;
  pairs.forEach((p,i)=>{ const bx=96+i*(bw+gap), by=240; rr(bx,by,bw,210,24); x.fillStyle='rgba(255,255,255,.08)'; x.fill(); x.strokeStyle='rgba(255,255,255,.2)'; x.lineWidth=1.5; x.stroke();
    let fs=52; x.font=`700 ${fs}px Inter, system-ui, sans-serif`; while(x.measureText(p[1]).width>bw-48 && fs>22){ fs-=2; x.font=`700 ${fs}px Inter, system-ui, sans-serif`; }
    x.fillStyle='#fff'; x.fillText(p[1], bx+24, by+110);
    x.fillStyle='rgba(255,255,255,.62)'; x.font='500 24px Inter, system-ui, sans-serif'; x.fillText(p[0].length>26?p[0].slice(0,25)+'…':p[0], bx+24, by+160); });
  x.fillStyle='#fff'; x.font='700 34px Inter, system-ui, sans-serif'; x.fillText('Kitwell', 96, 540);
  x.fillStyle='rgba(255,255,255,.55)'; x.font='500 24px Inter, system-ui, sans-serif'; x.textAlign='right'; x.fillText((USE_PATH?location.host:'kitwell')+TOOLP.replace(/\/$/,'')+'/'+id, W-96, 540); x.textAlign='left';
  c.toBlob(async blob=>{
    if(!blob) return; track('share_card',{tool_id:id});
    const file=new File([blob], id+'-result.png', {type:'image/png'});
    try{ if(navigator.canShare && navigator.canShare({files:[file]})){ await navigator.share({files:[file], title:t.name}); return; } }catch(e){ if(e&&e.name==='AbortError') return; }
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=file.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(a.href),4000);
  },'image/png');
}
