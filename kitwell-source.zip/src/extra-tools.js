// More tools. Uses helpers from pdf-tools.js (loaded before this file).
let __pdfJsPromise = null;
function loadPdfJs(){
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (__pdfJsPromise) return __pdfJsPromise;
  const base = /^https?:$/.test(location.protocol) ? '/vendor/' : 'vendor/';
  __pdfJsPromise = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = base + 'pdf.min.js';
    s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = base + 'pdf.worker.min.js'; res(window.pdfjsLib); };
    s.onerror = () => { __pdfJsPromise = null; rej(new Error('Could not load the PDF viewer library')); };
    document.head.appendChild(s);
  });
  return __pdfJsPromise;
}
TOOL_CUSTOM['pdf-to-jpg'] = {
  body: () => PDF_UP('pj-in', 'pj-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pj-scale">Image quality</label><select class="fc" id="pj-scale"><option value="1">Standard (screen)</option><option value="1.5" selected>High</option><option value="2.5">Very high (large files)</option></select></div><button type="button" class="btn btn-p" id="pj-go">Convert pages</button><div id="pj-msg" style="margin-top:12px"></div><div id="pj-out" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pj-in', 'pj-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pj-go').onclick = async () => {
      const f = (__pdfState['pj-list'] || [])[0]; if (!f) return pdfMsg('pj-msg', 'Choose a PDF file first.', 'warn');
      const out = document.getElementById('pj-out'); out.innerHTML = '';
      try {
        pdfMsg('pj-msg', 'Rendering...');
        const lib = await loadPdfJs(); const doc = await lib.getDocument({ data: await pdfReadFile(f) }).promise; const sc = +document.getElementById('pj-scale').value;
        const total = Math.min(doc.numPages, 100);
        for (let n = 1; n <= total; n++) {
          const page = await doc.getPage(n); const vp = page.getViewport({ scale: sc }); const c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
          const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); await page.render({ canvasContext: ctx, viewport: vp }).promise;
          const url = c.toDataURL('image/jpeg', 0.92);
          out.insertAdjacentHTML('beforeend', `<div style="border:1px solid var(--bdr);border-radius:8px;padding:8px;text-align:center"><img src="${url}" alt="Page ${n}" style="max-width:100%;border-radius:4px"><a class="btn btn-s btn-sm" style="margin-top:8px" href="${url}" download="${esc(f.name.replace(/\.pdf$/i, ''))}-page-${n}.jpg">Download page ${n}</a></div>`);
        }
        pdfMsg('pj-msg', `Done. ${total} page${total > 1 ? 's' : ''} converted${doc.numPages > 100 ? ' (first 100 pages only)' : ''}.`, 'ok');
      } catch (e) { pdfMsg('pj-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-delete-pages'] = {
  body: () => PDF_UP('pd-in', 'pd-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pd-range">Pages to delete</label><input class="fc" id="pd-range" placeholder="e.g. 2,4-6"></div><button type="button" class="btn btn-p" id="pd-go">Delete and download</button><div id="pd-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pd-in', 'pd-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pd-go').onclick = async () => {
      const f = (__pdfState['pd-list'] || [])[0]; if (!f) return pdfMsg('pd-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const total = doc.getPageCount();
        const idx = pdfParseRanges(document.getElementById('pd-range').value, total);
        if (!idx) return pdfMsg('pd-msg', `Enter valid pages between 1 and ${total}, like 2,4-6.`, 'warn');
        if (idx.length >= total) return pdfMsg('pd-msg', 'You cannot delete every page.', 'warn');
        idx.sort((a, b) => b - a).forEach(i => doc.removePage(i));
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-edited.pdf'); pdfMsg('pd-msg', `Done. ${idx.length} page${idx.length > 1 ? 's' : ''} removed, ${doc.getPageCount()} left.`, 'ok');
      } catch (e) { pdfMsg('pd-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-page-numbers'] = {
  body: () => PDF_UP('pn-in', 'pn-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pn-fmt">Format</label><select class="fc" id="pn-fmt"><option value="n">1</option><option value="pn">Page 1</option><option value="pnn" selected>Page 1 of N</option></select></div><div class="fg"><label class="fl" for="pn-pos">Position</label><select class="fc" id="pn-pos"><option value="c">Bottom centre</option><option value="r">Bottom right</option><option value="l">Bottom left</option></select></div><button type="button" class="btn btn-p" id="pn-go">Add numbers and download</button><div id="pn-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pn-in', 'pn-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pn-go').onclick = async () => {
      const f = (__pdfState['pn-list'] || [])[0]; if (!f) return pdfMsg('pn-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument, StandardFonts, rgb } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const font = await doc.embedFont(StandardFonts.Helvetica);
        const fmt = document.getElementById('pn-fmt').value, pos = document.getElementById('pn-pos').value; const pages = doc.getPages(); const N = pages.length;
        pages.forEach((pg, i) => {
          const label = fmt === 'n' ? String(i + 1) : fmt === 'pn' ? `Page ${i + 1}` : `Page ${i + 1} of ${N}`; const { width } = pg.getSize(); const size = 10; const w = font.widthOfTextAtSize(label, size);
          const x = pos === 'c' ? (width - w) / 2 : pos === 'r' ? width - w - 30 : 30;
          pg.drawText(label, { x, y: 20, size, font, color: rgb(0.25, 0.25, 0.25) });
        });
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-numbered.pdf'); pdfMsg('pn-msg', `Done. Numbers added to ${N} pages.`, 'ok');
      } catch (e) { pdfMsg('pn-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['webp-converter'] = {
  body: () => `<div class="fg"><label class="fl" for="wp-in">Choose images (JPG, PNG or WebP)</label><input type="file" class="fc" id="wp-in" accept="image/jpeg,image/png,image/webp" multiple></div><div class="fg"><label class="fl" for="wp-fmt">Convert to</label><select class="fc" id="wp-fmt"><option value="image/webp">WebP</option><option value="image/jpeg">JPG</option><option value="image/png">PNG</option></select></div><div class="fg"><label class="fl" for="wp-q">Quality: <span id="wp-qv">80</span>% (WebP and JPG only)</label><input type="range" id="wp-q" min="40" max="100" value="80" style="width:100%"></div><div id="wp-msg" style="margin-top:12px"></div><div id="wp-out" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-top:12px"></div>`,
  init: () => {
    const inp = document.getElementById('wp-in'), q = document.getElementById('wp-q'), fmt = document.getElementById('wp-fmt'), out = document.getElementById('wp-out');
    const run = async () => {
      out.innerHTML = ''; const files = Array.from(inp.files || []); if (!files.length) return;
      const type = fmt.value, ext = type === 'image/webp' ? 'webp' : type === 'image/jpeg' ? 'jpg' : 'png';
      for (const f of files) {
        try {
          const bmp = await createImageBitmap(f); const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height; const ctx = c.getContext('2d');
          if (type === 'image/jpeg') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); } ctx.drawImage(bmp, 0, 0);
          const blob = await new Promise(r => c.toBlob(r, type, +q.value / 100)); if (!blob) throw new Error('unsupported');
          const url = URL.createObjectURL(blob); const name = f.name.replace(/\.[^.]+$/, '') + '.' + ext;
          out.insertAdjacentHTML('beforeend', `<div style="border:1px solid var(--bdr);border-radius:8px;padding:8px;text-align:center"><img src="${url}" alt="${esc(name)}" style="max-width:100%;max-height:120px;border-radius:4px"><div style="font-size:12px;color:var(--t2);margin-top:6px">${Math.max(1, Math.round(f.size / 1024))} KB to ${Math.max(1, Math.round(blob.size / 1024))} KB</div><a class="btn btn-s btn-sm" style="margin-top:6px" href="${url}" download="${esc(name)}">Download</a></div>`);
        } catch (e) { out.insertAdjacentHTML('beforeend', `<div class="alert alert-err">Could not convert ${esc(f.name)}.</div>`); }
      }
    };
    inp.addEventListener('change', run); fmt.addEventListener('change', run); q.addEventListener('input', () => { document.getElementById('wp-qv').textContent = q.value; });
    q.addEventListener('change', run);
  }
};
