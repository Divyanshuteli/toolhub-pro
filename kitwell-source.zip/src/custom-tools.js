// ============================================================
// TOOL_CUSTOM - implementations for every kind:'custom' tool.
// Each entry: { body(): string, init?(): void }
// ============================================================
const TOOL_CUSTOM = {};

// ---------- find-replace ----------
TOOL_CUSTOM['find-replace'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="fr-in" rows="8"></textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Find</label><input class="fc" id="fr-find"></div>
      <div class="fg"><label class="fl">Replace With</label><input class="fc" id="fr-rep"></div>
    </div>
    <div style="display:flex;gap:16px;margin-bottom:12px;font-size:13px">
      <label style="display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" id="fr-case"> Case sensitive</label>
      <label style="display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" id="fr-regex"> Use regex</label>
    </div>
    <button class="btn btn-p" onclick="frRun()">Find & Replace All</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Result <button class="cpbtn" onclick="copyText(document.getElementById('fr-out').value,this)">Copy</button></label><textarea class="fc" id="fr-out" rows="8" readonly></textarea></div>
    <div id="fr-stat" style="font-size:13px;color:var(--tm)"></div>`,
  init: () => {
    window.frRun = () => {
      const text = document.getElementById('fr-in').value;
      const find = document.getElementById('fr-find').value;
      const rep = document.getElementById('fr-rep').value;
      const cs = document.getElementById('fr-case').checked;
      const useRegex = document.getElementById('fr-regex').checked;
      if (!find) return;
      try {
        let count = 0, out;
        if (useRegex) {
          const re = new RegExp(find, 'g'+(cs?'':'i'));
          out = text.replace(re, (...m)=>{count++; return rep;});
        } else {
          const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'g'+(cs?'':'i'));
          out = text.replace(re, ()=>{count++; return rep;});
        }
        document.getElementById('fr-out').value = out;
        document.getElementById('fr-stat').textContent = `Replaced ${count} occurrence(s).`;
      } catch(e){ document.getElementById('fr-stat').textContent = 'Error: '+e.message; }
    };
  }
};

// ---------- word-frequency ----------
TOOL_CUSTOM['word-frequency'] = {
  body: () => `<div class="fg"><label class="fl">Text</label><textarea class="fc" id="wf-in" rows="8" oninput="wfRun()"></textarea></div><div id="wf-out"></div>`,
  init: () => { window.wfRun = () => {
    const t = document.getElementById('wf-in').value.toLowerCase();
    const words = t.replace(/[^a-z0-9'\s]/g,'').split(/\s+/).filter(Boolean);
    const freq = {}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
    const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,25);
    document.getElementById('wf-out').innerHTML = top.length ? top.map(([w,n])=>`<div class="trow"><span>${esc(w)}</span><strong>${n}</strong></div>`).join('') : '<div class="alert alert-info">Type some text.</div>';
  };}
};

// ---------- caesar-cipher ----------
TOOL_CUSTOM['caesar-cipher'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="cz-in" rows="6" oninput="czRun()"></textarea></div>
    <div class="fg"><label class="fl">Shift Amount: <strong id="cz-shiftlbl">3</strong></label><input type="range" min="1" max="25" value="3" id="cz-shift" oninput="document.getElementById('cz-shiftlbl').textContent=this.value;czRun()"></div>
    <div class="bgrp" style="margin-bottom:12px"><button class="btn btn-p btn-sm" onclick="czRun('enc')">Encrypt</button><button class="btn btn-s btn-sm" onclick="czRun('dec')">Decrypt</button></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('cz-out').value,this)">Copy</button></label><textarea class="fc mono" id="cz-out" rows="6" readonly></textarea></div>`,
  init: () => { window.czRun = (mode) => {
    mode = mode || 'enc';
    const shift = parseInt(document.getElementById('cz-shift').value) * (mode==='dec'?-1:1);
    const t = document.getElementById('cz-in').value;
    const out = t.replace(/[a-zA-Z]/g, c => { const base = c<='Z'?65:97; return String.fromCharCode((((c.charCodeAt(0)-base+shift)%26)+26)%26+base); });
    document.getElementById('cz-out').value = out;
  };}
};

// ---------- morse-code ----------
TOOL_CUSTOM['morse-code'] = {
  body: () => `
    <div class="fg"><label class="fl">Text</label><textarea class="fc" id="mo-in" rows="6" placeholder="HELLO WORLD"></textarea></div>
    <div class="bgrp" style="margin-bottom:12px"><button class="btn btn-p btn-sm" onclick="moRun('t2m')">Text to Morse</button><button class="btn btn-s btn-sm" onclick="moRun('m2t')">Morse to Text</button></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('mo-out').value,this)">Copy</button></label><textarea class="fc mono" id="mo-out" rows="6" readonly></textarea></div>`,
  init: () => { window.moRun = (mode) => {
    const t = document.getElementById('mo-in').value;
    let out;
    if (mode==='t2m') out = t.toUpperCase().split('').map(c => c===' ' ? '/' : (MORSE[c]||'')).join(' ');
    else out = t.trim().split(' / ').map(w => w.trim().split(/\s+/).map(code=>MORSE_REV[code]||'').join('')).join(' ');
    document.getElementById('mo-out').value = out;
  };}
};

// ---------- percentage-calculator ----------
TOOL_CUSTOM['percentage-calculator'] = {
  body: () => `
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">What is X% of Y?</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">Percentage (%)</label><input type="number" class="fc" id="pc1-pct" placeholder="e.g. 15" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">Of Number</label><input type="number" class="fc" id="pc1-num" placeholder="e.g. 200" oninput="pcAll()"></div>
      </div>
      <div id="pc1-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">X is what % of Y?</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">Value X</label><input type="number" class="fc" id="pc2-x" placeholder="e.g. 30" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">Total Y</label><input type="number" class="fc" id="pc2-y" placeholder="e.g. 200" oninput="pcAll()"></div>
      </div>
      <div id="pc2-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>
    <div style="border:1px solid var(--bdr);border-radius:var(--r);padding:16px">
      <div style="font-size:13px;font-weight:700;margin-bottom:12px;color:var(--t2)">Percentage Change from X to Y</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg" style="margin:0"><label class="fl">From</label><input type="number" class="fc" id="pc3-from" placeholder="e.g. 100" oninput="pcAll()"></div>
        <div class="fg" style="margin:0"><label class="fl">To</label><input type="number" class="fc" id="pc3-to" placeholder="e.g. 150" oninput="pcAll()"></div>
      </div>
      <div id="pc3-res" style="margin-top:10px;font-size:15px;font-weight:700;color:var(--p)"></div>
    </div>`,
  init: () => { window.pcAll = () => {
    const pct=parseFloat(document.getElementById('pc1-pct').value), num=parseFloat(document.getElementById('pc1-num').value);
    document.getElementById('pc1-res').textContent = (isNaN(pct)||isNaN(num)) ? '' : `${pct}% of ${num} = ${round4(pct/100*num)}`;
    const x=parseFloat(document.getElementById('pc2-x').value), y=parseFloat(document.getElementById('pc2-y').value);
    document.getElementById('pc2-res').textContent = (isNaN(x)||isNaN(y)||y===0) ? '' : `${x} is ${round4(x/y*100)}% of ${y}`;
    const from=parseFloat(document.getElementById('pc3-from').value), to=parseFloat(document.getElementById('pc3-to').value);
    const r=document.getElementById('pc3-res');
    if (isNaN(from)||isNaN(to)||from===0) r.innerHTML=''; else { const ch=((to-from)/Math.abs(from))*100; r.innerHTML = `<span style="color:${ch>=0?'var(--ok)':'var(--err)'}">${ch>=0?'+':''}${round4(ch)}% ${ch>=0?'increase':'decrease'}</span>`; }
  };}
};

// ---------- scientific-calculator ----------
TOOL_CUSTOM['scientific-calculator'] = {
  body: () => `
    <input class="fc mono" id="sc-disp" readonly style="font-size:24px;text-align:right;margin-bottom:10px;height:56px">
    <div id="sc-grid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:7px"></div>`,
  init: () => {
    const btns = ['sin','cos','tan','log','ln','(',')','√','^','C','7','8','9','/','π','4','5','6','*','e','1','2','3','-','%','0','.','=','+','DEL'];
    const grid = document.getElementById('sc-grid');
    grid.innerHTML = btns.map(b=>`<button class="btn btn-s btn-sm" onclick="scPress('${b}')">${b}</button>`).join('');
    window.scExpr = '';
    window.scPress = (b) => {
      const disp = document.getElementById('sc-disp');
      if (b==='C'){ scExpr=''; disp.value=''; return; }
      if (b==='DEL'){ scExpr=scExpr.slice(0,-1); disp.value=scExpr; return; }
      if (b==='='){
        try {
          let e = scExpr.replace(/π/g,'Math.PI').replace(/√/g,'Math.sqrt').replace(/\^/g,'**')
            .replace(/sin\(/g,'Math.sin(').replace(/cos\(/g,'Math.cos(').replace(/tan\(/g,'Math.tan(')
            .replace(/log\(/g,'Math.log10(').replace(/ln\(/g,'Math.log(').replace(/e(?![a-zA-Z])/g,'Math.E');
          if (!/^[\d\s+\-*/.()Mathsincoqrtlgepw%,E]*$/.test(e)) throw new Error('invalid');
          const result = Function('"use strict";return ('+e+')')();
          scExpr = String(result); disp.value = scExpr;
        } catch(err){ disp.value = 'Error'; scExpr=''; }
        return;
      }
      if (b==='√'){ scExpr+='√('; disp.value=scExpr; return; }
      if (['sin','cos','tan','log','ln'].includes(b)){ scExpr+=b+'('; disp.value=scExpr; return; }
      scExpr += b; disp.value = scExpr;
    };
  }
};

// ---------- cgpa-calculator ----------
TOOL_CUSTOM['cgpa-calculator'] = {
  body: () => `
    <div id="cg-rows"></div>
    <button class="btn btn-s btn-sm" onclick="cgAddRow()" style="margin:10px 0">+ Add Course</button>
    <div id="cg-result"></div>`,
  init: () => {
    let n = 0;
    window.cgAddRow = () => {
      n++;
      const row = document.createElement('div');
      row.style.cssText = 'display:grid;grid-template-columns:1fr 100px 100px 30px;gap:8px;margin-bottom:8px;align-items:center';
      row.innerHTML = `<input class="fc" placeholder="Course ${n}" value="Course ${n}">
        <input class="fc" type="number" placeholder="Grade pt" value="4" min="0" max="10" step="0.1" oninput="cgCalc()">
        <input class="fc" type="number" placeholder="Credits" value="3" min="0" oninput="cgCalc()">
        <button class="btn btn-s btn-sm" onclick="this.parentElement.remove();cgCalc()" aria-label="Remove">${svgIcon('ui_close',14)}</button>`;
      document.getElementById('cg-rows').appendChild(row);
      cgCalc();
    };
    window.cgCalc = () => {
      const rows = [...document.getElementById('cg-rows').children];
      let totalPts=0, totalCredits=0;
      rows.forEach(r => { const [,g,c] = r.querySelectorAll('input'); const gp=parseFloat(g.value)||0, cr=parseFloat(c.value)||0; totalPts+=gp*cr; totalCredits+=cr; });
      document.getElementById('cg-result').innerHTML = totalCredits ? statBlock([['CGPA',round4(totalPts/totalCredits)],['Total Credits',totalCredits]]) : '';
    };
    cgAddRow(); cgAddRow(); cgAddRow();
  }
};

// ---------- currency-converter ----------
const FX_RATES = {USD:1, EUR:0.92, GBP:0.79, INR:84.1, JPY:152.3, AUD:1.52, CAD:1.37, CNY:7.24, CHF:0.88, SGD:1.34, ZAR:18.2};
TOOL_CUSTOM['currency-converter'] = {
  body: () => {
    const opts = Object.keys(FX_RATES).map(c=>`<option value="${c}">${c}</option>`).join('');
    return `
    <div class="fg"><label class="fl">Amount</label><input type="number" class="fc" id="cur-amt" value="100" oninput="curRun()"></div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:end;margin-bottom:16px">
      <div class="fg" style="margin:0"><label class="fl">From</label><select class="fc" id="cur-from" onchange="curRun()">${opts}</select></div>
      <button class="btn btn-s btn-sm" onclick="curSwap()" aria-label="Swap">${svgIcon('ui_swap',16)}</button>
      <div class="fg" style="margin:0"><label class="fl">To</label><select class="fc" id="cur-to" onchange="curRun()">${opts}</select></div>
    </div>
    <div class="res-box ok" id="cur-result" style="font-size:20px;font-weight:700;text-align:center"></div>
    <div class="alert alert-info" style="margin-top:12px" id="cur-note">Loading current rates...</div>`;
  },
  init: () => {
    document.getElementById('cur-from').value='USD'; document.getElementById('cur-to').value='INR';
    window.curSwap = () => { const f=document.getElementById('cur-from'),t=document.getElementById('cur-to'); [f.value,t.value]=[t.value,f.value]; curRun(); };
    window.curRun = () => {
      const amt = parseFloat(document.getElementById('cur-amt').value);
      const from = document.getElementById('cur-from').value, to = document.getElementById('cur-to').value;
      const out = document.getElementById('cur-result');
      if (isNaN(amt)) { out.textContent='Enter an amount'; return; }
      const usd = amt / FX_RATES[from];
      const result = usd * FX_RATES[to];
      out.innerHTML = `${amt} ${from} = <span style="color:var(--p)">${result.toLocaleString(undefined,{maximumFractionDigits:2})} ${to}</span>`;
    };
    curRun();
    const note = document.getElementById('cur-note');
    const fallback = () => { if(note) note.innerHTML = 'Could not load live rates. Showing bundled indicative rates. Check your bank or card provider for real transactions.'; };
    const ctl = new AbortController(); const to = setTimeout(()=>ctl.abort(), 6000);
    fetch('https://api.frankfurter.app/latest?from=USD&to='+Object.keys(FX_RATES).filter(c=>c!=='USD').join(','), {signal: ctl.signal})
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => { clearTimeout(to); Object.keys(d.rates||{}).forEach(k => { FX_RATES[k] = d.rates[k]; });
        if(note) note.textContent = 'Rates from Frankfurter (European Central Bank reference rates), dated ' + d.date + '. For real transactions, check your bank or card provider.';
        if (document.getElementById('cur-result')) curRun(); })
      .catch(() => { clearTimeout(to); fallback(); });
  }
};

// ---------- image tools (shared canvas helpers) ----------
function imgUploadBody(extraControls, resultId){
  return `
    <div class="fg"><label class="fl">Upload Image</label><input type="file" class="fc" id="im-file" accept="image/*"></div>
    ${extraControls||''}
    <div id="${resultId||'im-result'}" style="margin-top:14px"></div>`;
}
function imgLoadFile(fileInput, cb){
  const f = fileInput.files[0]; if (!f) return;
  const img = new Image();
  const reader = new FileReader();
  reader.onload = e => { img.onload = () => cb(img, f); img.src = e.target.result; };
  reader.readAsDataURL(f);
}

TOOL_CUSTOM['image-resizer'] = {
  body: () => imgUploadBody(`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Width (px)</label><input type="number" class="fc" id="ir-w"></div>
      <div class="fg"><label class="fl">Height (px)</label><input type="number" class="fc" id="ir-h"></div>
    </div>
    <label style="display:flex;gap:8px;align-items:center;font-size:13px;margin-bottom:12px;cursor:pointer"><input type="checkbox" id="ir-lock" checked> Lock aspect ratio</label>
    <button class="btn btn-p" id="ir-btn" disabled onclick="irResize()">Resize & Download</button>`),
  init: () => {
    let img=null, ratio=1;
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{
      img=image; ratio=image.width/image.height;
      document.getElementById('ir-w').value=image.width; document.getElementById('ir-h').value=image.height;
      document.getElementById('ir-btn').disabled=false;
      document.getElementById('im-result').innerHTML = `<div style="font-size:12px;color:var(--tm)">Original: ${image.width}×${image.height}px</div>`;
    }));
    document.getElementById('ir-w').addEventListener('input', ()=>{ if(document.getElementById('ir-lock').checked) document.getElementById('ir-h').value = Math.round(document.getElementById('ir-w').value/ratio); });
    document.getElementById('ir-h').addEventListener('input', ()=>{ if(document.getElementById('ir-lock').checked) document.getElementById('ir-w').value = Math.round(document.getElementById('ir-h').value*ratio); });
    window.irResize = () => {
      const w=parseInt(document.getElementById('ir-w').value), h=parseInt(document.getElementById('ir-h').value);
      const c = document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(img,0,0,w,h);
      const url = c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="resized.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
  }
};
TOOL_CUSTOM['image-compressor'] = {
  body: () => imgUploadBody(`<div class="fg"><label class="fl">Quality: <strong id="icq-lbl">80%</strong></label><input type="range" min="10" max="100" value="80" id="ic-q" oninput="document.getElementById('icq-lbl').textContent=this.value+'%';icRun()"></div>`),
  init: () => {
    let img=null, origSize=0;
    document.getElementById('im-file').addEventListener('change', e => { origSize=e.target.files[0].size; imgLoadFile(e.target, (image)=>{ img=image; icRun(); }); });
    window.icRun = () => {
      if (!img) return;
      const c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
      c.getContext('2d').drawImage(img,0,0);
      const q = document.getElementById('ic-q').value/100;
      const url = c.toDataURL('image/jpeg', q);
      const newSize = Math.round((url.length-22)*0.75);
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px">
        ${statBlock([['Original',Math.round(origSize/1024)+' KB'],['Compressed',Math.round(newSize/1024)+' KB'],['Saved',Math.round((1-newSize/origSize)*100)+'%']])}
        <a href="${url}" download="compressed.jpg" class="btn btn-p btn-sm">Download JPG</a>`;
    };
  }
};
TOOL_CUSTOM['jpg-to-png'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const c=document.createElement('canvas'); c.width=img.width; c.height=img.height; c.getContext('2d').drawImage(img,0,0);
    const url=c.toDataURL('image/png');
    document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="converted.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
  })); }
};
TOOL_CUSTOM['png-to-jpg'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
    const ctx=c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0);
    const url=c.toDataURL('image/jpeg',0.92);
    document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="converted.jpg" class="btn btn-p btn-sm" style="margin-top:10px">Download JPG</a>`;
  })); }
};
TOOL_CUSTOM['image-crop'] = {
  body: () => imgUploadBody(`<div style="position:relative;display:inline-block;max-width:100%" id="ic2-wrap"></div><div class="bgrp" style="margin-top:10px"><button class="btn btn-p btn-sm" onclick="icCrop()">Crop & Download</button></div>`),
  init: () => {
    let img=null, sel=null, startX,startY,dragging=false, dispScale=1;
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{
      img=image;
      const wrap = document.getElementById('ic2-wrap');
      const maxW = 560; dispScale = Math.min(1, maxW/image.width);
      wrap.innerHTML = `<img id="ic2-img" src="${image.src}" style="width:${image.width*dispScale}px;display:block;cursor:crosshair;user-select:none"><div id="ic2-sel" style="position:absolute;border:2px dashed #1D4ED8;background:rgba(29,78,216,.15);display:none;pointer-events:none"></div>`;
      const im = document.getElementById('ic2-img'), selEl = document.getElementById('ic2-sel');
      im.addEventListener('mousedown', ev => { const r=im.getBoundingClientRect(); startX=ev.clientX-r.left; startY=ev.clientY-r.top; dragging=true; selEl.style.display='block'; });
      window.addEventListener('mousemove', ev => { if(!dragging) return; const r=im.getBoundingClientRect(); const x=Math.max(0,Math.min(ev.clientX-r.left,r.width)); const y=Math.max(0,Math.min(ev.clientY-r.top,r.height));
        const l=Math.min(x,startX), t=Math.min(y,startY), w=Math.abs(x-startX), h=Math.abs(y-startY);
        selEl.style.left=l+'px'; selEl.style.top=t+'px'; selEl.style.width=w+'px'; selEl.style.height=h+'px';
        sel={x:l/dispScale,y:t/dispScale,w:w/dispScale,h:h/dispScale}; });
      window.addEventListener('mouseup', ()=>dragging=false);
    }));
    window.icCrop = () => {
      if (!img || !sel || !sel.w || !sel.h) { toast('Drag on the image to select a crop area first','er'); return; }
      const c=document.createElement('canvas'); c.width=sel.w; c.height=sel.h;
      c.getContext('2d').drawImage(img, sel.x, sel.y, sel.w, sel.h, 0,0, sel.w, sel.h);
      const url=c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="cropped.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
  }
};
TOOL_CUSTOM['image-color-picker'] = {
  body: () => imgUploadBody(`<div style="font-size:12px;color:var(--tm);margin-bottom:10px">Click anywhere on the uploaded image to read its color.</div><canvas id="cp-canvas" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px;cursor:crosshair"></canvas>`),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const canvas = document.getElementById('cp-canvas');
    const scale = Math.min(1, 560/img.width);
    canvas.width = img.width*scale; canvas.height = img.height*scale;
    const ctx = canvas.getContext('2d'); ctx.drawImage(img,0,0,canvas.width,canvas.height);
    canvas.onclick = ev => {
      const r = canvas.getBoundingClientRect();
      const x = Math.round((ev.clientX-r.left) * (canvas.width/r.width)), y = Math.round((ev.clientY-r.top) * (canvas.height/r.height));
      const [R,G,B] = ctx.getImageData(x,y,1,1).data;
      const hex = '#'+[R,G,B].map(v=>v.toString(16).padStart(2,'0')).join('');
      document.getElementById('im-result').innerHTML = `<div style="display:flex;gap:14px;align-items:center;margin-top:10px"><div style="width:56px;height:56px;border-radius:8px;border:1px solid var(--bdr);background:${hex}"></div><div>${statBlock([['HEX',hex.toUpperCase()],['RGB',`${R}, ${G}, ${B}`]])}</div></div>`;
    };
  })); }
};
TOOL_CUSTOM['image-to-base64'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => { const f=e.target.files[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = ev => { document.getElementById('im-result').innerHTML = `${statBlock([['Size',Math.round(f.size/1024)+' KB']])}<div class="fg"><label class="fl">Base64 Data URI <button class="cpbtn" onclick="copyText(document.getElementById('b64img-out').value,this)">Copy</button></label><textarea class="fc mono" id="b64img-out" rows="8" readonly>${ev.target.result}</textarea></div>`; };
    reader.readAsDataURL(f);
  }); }
};
TOOL_CUSTOM['base64-to-image'] = {
  body: () => `<div class="fg"><label class="fl">Base64 String (with or without data: prefix)</label><textarea class="fc mono" id="b2i-in" rows="6"></textarea></div><button class="btn btn-p" onclick="b2iRun()">Preview Image</button><div id="b2i-out" style="margin-top:14px"></div>`,
  init: () => { window.b2iRun = () => {
    let s = document.getElementById('b2i-in').value.trim();
    if (!s) return;
    if (!s.startsWith('data:')) s = 'data:image/png;base64,'+s;
    const img = new Image();
    img.onerror = () => document.getElementById('b2i-out').innerHTML = '<div class="alert alert-err">Invalid Base64 image data.</div>';
    img.onload = () => document.getElementById('b2i-out').innerHTML = `<img src="${s}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${s}" download="image.png" class="btn btn-p btn-sm" style="margin-top:10px">Download</a>`;
    img.src = s;
  };}
};
TOOL_CUSTOM['image-rotator'] = {
  body: () => imgUploadBody(`<div class="bgrp" style="margin-bottom:12px"><button class="btn btn-s btn-sm" onclick="imRotate(90)">Rotate 90°</button><button class="btn btn-s btn-sm" onclick="imRotate(-90)">Rotate -90°</button><button class="btn btn-s btn-sm" onclick="imFlip('h')">Flip Horizontal</button><button class="btn btn-s btn-sm" onclick="imFlip('v')">Flip Vertical</button></div>`),
  init: () => {
    let img=null, angle=0, flipH=1, flipV=1;
    const render = () => {
      if (!img) return;
      const rad = angle*Math.PI/180;
      const swap = angle%180!==0;
      const c = document.createElement('canvas'); c.width = swap?img.height:img.width; c.height = swap?img.width:img.height;
      const ctx = c.getContext('2d'); ctx.translate(c.width/2,c.height/2); ctx.rotate(rad); ctx.scale(flipH,flipV);
      ctx.drawImage(img,-img.width/2,-img.height/2);
      const url = c.toDataURL('image/png');
      document.getElementById('im-result').innerHTML = `<img src="${url}" style="max-width:100%;border:1px solid var(--bdr);border-radius:8px"><br><a href="${url}" download="edited.png" class="btn btn-p btn-sm" style="margin-top:10px">Download PNG</a>`;
    };
    document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (image)=>{ img=image; angle=0; flipH=1; flipV=1; render(); }));
    window.imRotate = (d) => { angle=(angle+d+360)%360; render(); };
    window.imFlip = (axis) => { if (axis==='h') flipH*=-1; else flipV*=-1; render(); };
  }
};
TOOL_CUSTOM['favicon-generator'] = {
  body: () => imgUploadBody(),
  init: () => { document.getElementById('im-file').addEventListener('change', e => imgLoadFile(e.target, (img)=>{
    const sizes=[16,32,48]; let html='<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">';
    sizes.forEach(s => { const c=document.createElement('canvas'); c.width=s; c.height=s; c.getContext('2d').drawImage(img,0,0,s,s); const url=c.toDataURL('image/png');
      html += `<div style="text-align:center"><img src="${url}" style="width:${s}px;height:${s}px;border:1px solid var(--bdr);border-radius:4px"><div style="font-size:11px;margin-top:4px">${s}×${s}</div><a href="${url}" download="favicon-${s}.png" class="cpbtn" style="display:block;margin-top:4px">Download</a></div>`; });
    document.getElementById('im-result').innerHTML = html+'</div>';
  })); }
};

// ---------- hash-generator ----------
TOOL_CUSTOM['hash-generator'] = {
  body: () => `<div class="fg"><label class="fl">Input Text</label><textarea class="fc" id="hg-in" rows="5" oninput="hgRun()"></textarea></div><div id="hg-out"></div>`,
  init: () => {
    window.hgRun = async () => {
      const t = document.getElementById('hg-in').value;
      const out = document.getElementById('hg-out');
      if (!t) { out.innerHTML=''; return; }
      const md5 = SparkMD5.hash(t);
      const enc = new TextEncoder().encode(t);
      const algos = ['SHA-1','SHA-256','SHA-384','SHA-512'];
      let html = `<div class="trow"><span>MD5</span><button class="cpbtn mono" style="max-width:100%;overflow:hidden;text-overflow:ellipsis" onclick="copyText('${md5}',this)">${md5}</button></div>`;
      out.innerHTML = html + algos.map(a=>`<div class="trow"><span>${a}</span><span class="mono" id="hg-${a}" style="font-size:11px;word-break:break-all;max-width:70%;text-align:right">computing…</span></div>`).join('');
      for (const a of algos) {
        const buf = await crypto.subtle.digest(a, enc);
        const hex = [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
        const el = document.getElementById('hg-'+a); if (el) el.textContent = hex;
      }
    };
  }
};

// ---------- regex-tester ----------
TOOL_CUSTOM['regex-tester'] = {
  body: () => `
    <div class="fg"><label class="fl">Pattern</label><input class="fc mono" id="rx-pat" placeholder="e.g. \\\\d+" oninput="rxRun()"></div>
    <div class="fg"><label class="fl">Flags</label><input class="fc mono" id="rx-flags" value="g" oninput="rxRun()" style="max-width:100px"></div>
    <div class="fg"><label class="fl">Test String</label><textarea class="fc" id="rx-str" rows="6" oninput="rxRun()"></textarea></div>
    <div id="rx-out"></div>`,
  init: () => { window.rxRun = () => {
    const pat = document.getElementById('rx-pat').value, flags = document.getElementById('rx-flags').value, str = document.getElementById('rx-str').value;
    const out = document.getElementById('rx-out');
    if (!pat) { out.innerHTML=''; return; }
    try {
      const re = new RegExp(pat, flags);
      const matches = [...str.matchAll(flags.includes('g')?re:new RegExp(pat,flags+'g'))];
      let highlighted = esc(str);
      if (matches.length) {
        let result='', last=0;
        matches.forEach(m => { result += esc(str.slice(last,m.index)) + '<mark style="background:#FEF08A">'+esc(m[0])+'</mark>'; last = m.index+m[0].length; });
        result += esc(str.slice(last));
        highlighted = result;
      }
      out.innerHTML = `<div class="alert alert-ok">${matches.length} match(es)</div><div class="res-box" style="white-space:pre-wrap">${highlighted||'(empty)'}</div>` +
        (matches.length ? '<div style="margin-top:10px">'+matches.slice(0,20).map((m,i)=>`<div class="trow"><span>Match ${i+1}</span><span class="mono">${esc(m[0])}${m.length>1?' - groups: '+m.slice(1).map(g=>esc(g??'')).join(', '):''}</span></div>`).join('')+'</div>' : '');
    } catch(e){ out.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`; }
  };}
};

// ---------- color-converter ----------
TOOL_CUSTOM['color-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Color</label><div style="display:flex;gap:10px"><input type="color" id="cc-picker" value="#1D4ED8" style="width:48px;height:38px;padding:2px;border:1px solid var(--bdr);border-radius:6px" oninput="ccFromPicker()"><input class="fc mono" id="cc-hex" value="#1D4ED8" oninput="ccFromHex()"></div></div>
    <div id="cc-out" style="margin-top:14px"></div>`,
  init: () => {
    const hexToRgb = h => { h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return [n>>16&255,n>>8&255,n&255]; };
    const rgbToHsl = (r,g,b) => { r/=255;g/=255;b/=255;const max=Math.max(r,g,b),min=Math.min(r,g,b);let h,s,l=(max+min)/2;
      if(max===min){h=s=0;}else{const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);
        switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;break;}h/=6;}
      return [Math.round(h*360),Math.round(s*100),Math.round(l*100)]; };
    const render = (hex) => {
      const [r,g,b] = hexToRgb(hex); const [h,s,l] = rgbToHsl(r,g,b);
      document.getElementById('cc-out').innerHTML = `<div style="width:100%;height:70px;border-radius:8px;border:1px solid var(--bdr);background:${hex};margin-bottom:12px"></div>` +
        statBlock([['HEX',hex.toUpperCase()],['RGB',`rgb(${r}, ${g}, ${b})`],['HSL',`hsl(${h}, ${s}%, ${l}%)`],['CMYK',cmyk(r,g,b)]]);
    };
    const cmyk = (r,g,b) => { r/=255;g/=255;b/=255; const k=1-Math.max(r,g,b); if(k===1) return '0, 0, 0, 100'; const c=(1-r-k)/(1-k),m=(1-g-k)/(1-k),y=(1-b-k)/(1-k);
      return `${Math.round(c*100)}, ${Math.round(m*100)}, ${Math.round(y*100)}, ${Math.round(k*100)}`; };
    window.ccFromPicker = () => { const h = document.getElementById('cc-picker').value; document.getElementById('cc-hex').value=h; render(h); };
    window.ccFromHex = () => { let h = document.getElementById('cc-hex').value.trim(); if(!/^#?[0-9a-fA-F]{3}$|^#?[0-9a-fA-F]{6}$/.test(h)) return; if(!h.startsWith('#')) h='#'+h; document.getElementById('cc-picker').value = h.length===4?'#'+h[1]+h[1]+h[2]+h[2]+h[3]+h[3]:h; render(h); };
    render('#1D4ED8');
  }
};

// ---------- jwt-decoder ----------
TOOL_CUSTOM['jwt-decoder'] = {
  body: () => `<div class="fg"><label class="fl">JWT Token</label><textarea class="fc mono" id="jw-in" rows="5" oninput="jwRun()"></textarea></div><div id="jw-out"></div>`,
  init: () => { window.jwRun = () => {
    const t = document.getElementById('jw-in').value.trim();
    const out = document.getElementById('jw-out');
    if (!t) { out.innerHTML=''; return; }
    const parts = t.split('.');
    if (parts.length < 2) { out.innerHTML = '<div class="alert alert-err">Not a valid JWT (expected header.payload.signature).</div>'; return; }
    try {
      const dec = s => JSON.parse(decodeURIComponent(escape(atob(s.replace(/-/g,'+').replace(/_/g,'/')))));
      const header = dec(parts[0]), payload = dec(parts[1]);
      out.innerHTML = `<div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin-bottom:6px">Header</div><pre class="res-box mono">${esc(JSON.stringify(header,null,2))}</pre>
        <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:14px 0 6px">Payload</div><pre class="res-box mono">${esc(JSON.stringify(payload,null,2))}</pre>
        <div class="alert alert-info" style="margin-top:12px">Signature is not verified by this tool.</div>`;
    } catch(e){ out.innerHTML = `<div class="alert alert-err">Could not decode: ${esc(e.message)}</div>`; }
  };}
};

// ---------- markdown-html ----------
TOOL_CUSTOM['markdown-html'] = {
  body: () => `<div class="fg"><label class="fl">Markdown</label><textarea class="fc mono" id="md-in" rows="10" oninput="mdRun()" placeholder="# Heading\n\n**bold** _italic_\n\n- item one\n- item two\n\n[link](https://example.com)"></textarea></div>
    <div class="fg"><label class="fl">HTML Output <button class="cpbtn" onclick="copyText(document.getElementById('md-out').value,this)">Copy</button></label><textarea class="fc mono" id="md-out" rows="10" readonly></textarea></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:14px 0 6px">Preview</div><div class="res-box" id="md-preview"></div>`,
  init: () => { window.mdRun = () => {
    const src = document.getElementById('md-in').value;
    const html = mdToHtml(src);
    document.getElementById('md-out').value = html;
    document.getElementById('md-preview').innerHTML = html;
  }; mdRun(); }
};
function mdToHtml(src){
  let lines = src.split('\n'); let html=''; let inList=false;
  const inlineFmt = s => esc(s).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>').replace(/_(.+?)_/g,'<em>$1</em>').replace(/`(.+?)`/g,'<code>$1</code>').replace(/\[(.+?)\]\((.+?)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>');
  lines.forEach(line => {
    const h = line.match(/^(#{1,6})\s+(.*)/);
    if (h) { if(inList){html+='</ul>';inList=false;} html += `<h${h[1].length}>${inlineFmt(h[2])}</h${h[1].length}>`; return; }
    const li = line.match(/^[-*]\s+(.*)/);
    if (li) { if(!inList){html+='<ul>';inList=true;} html += `<li>${inlineFmt(li[1])}</li>`; return; }
    if (inList) { html+='</ul>'; inList=false; }
    if (line.trim()==='') return;
    html += `<p>${inlineFmt(line)}</p>`;
  });
  if (inList) html += '</ul>';
  return html;
}

// ---------- timestamp-converter / unix-timestamp ----------
TOOL_CUSTOM['timestamp-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Unix Timestamp</label><input class="fc mono" id="tc-ts" placeholder="e.g. 1700000000" oninput="tcFromTs()"></div>
    <div class="fg"><label class="fl">Or pick a date/time</label><input type="datetime-local" class="fc" id="tc-dt" oninput="tcFromDt()"></div>
    <div id="tc-out"></div>`,
  init: () => {
    window.tcFromTs = () => {
      let v = document.getElementById('tc-ts').value.trim(); if (!v) return;
      let n = parseInt(v); if (String(n).length <= 10) n*=1000;
      const d = new Date(n);
      if (isNaN(d)) { document.getElementById('tc-out').innerHTML = '<div class="alert alert-err">Invalid timestamp.</div>'; return; }
      document.getElementById('tc-dt').value = new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);
      document.getElementById('tc-out').innerHTML = statBlock([['UTC',d.toUTCString()],['Local',d.toString()],['ISO',d.toISOString()]]);
    };
    window.tcFromDt = () => {
      const v = document.getElementById('tc-dt').value; if (!v) return;
      const d = new Date(v); const ts = Math.floor(d.getTime()/1000);
      document.getElementById('tc-ts').value = ts;
      document.getElementById('tc-out').innerHTML = statBlock([['Unix (seconds)',ts],['Unix (ms)',d.getTime()],['ISO',d.toISOString()]]);
    };
    document.getElementById('tc-ts').value = Math.floor(Date.now()/1000);
    tcFromTs();
  }
};
TOOL_CUSTOM['unix-timestamp'] = {
  body: () => `<div class="res-box ok mono" id="ut-now" style="font-size:28px;text-align:center;font-weight:700"></div><div class="bgrp" style="margin-top:12px;justify-content:center"><button class="cpbtn" onclick="copyText(document.getElementById('ut-now').textContent,this)">Copy</button></div>`,
  init: () => {
    const tick = () => { const el=document.getElementById('ut-now'); if (!el) { clearInterval(window.__utInt); return; } el.textContent = Math.floor(Date.now()/1000); };
    tick(); window.__utInt = setInterval(tick, 1000);
  }
};

// ---------- temperature-converter ----------
TOOL_CUSTOM['temperature-converter'] = {
  body: () => `
    <div class="fg"><label class="fl">Value</label><input type="number" class="fc" id="tp-val" value="100" oninput="tpRun()"></div>
    <div class="fg"><label class="fl">From</label><select class="fc" id="tp-from" onchange="tpRun()"><option value="c">Celsius (°C)</option><option value="f">Fahrenheit (°F)</option><option value="k">Kelvin (K)</option></select></div>
    <div id="tp-out"></div>`,
  init: () => { window.tpRun = () => {
    const v = parseFloat(document.getElementById('tp-val').value); if (isNaN(v)) return;
    const from = document.getElementById('tp-from').value;
    let c; if (from==='c') c=v; else if (from==='f') c=(v-32)*5/9; else c=v-273.15;
    const f = c*9/5+32, k = c+273.15;
    document.getElementById('tp-out').innerHTML = statBlock([['Celsius',round4(c)+' °C'],['Fahrenheit',round4(f)+' °F'],['Kelvin',round4(k)+' K']]);
  }; tpRun(); }
};

// ---------- fuel-economy ----------
TOOL_CUSTOM['fuel-economy'] = {
  body: () => `
    <div class="fg"><label class="fl">Value</label><input type="number" class="fc" id="fe-val" value="30" oninput="feRun()"></div>
    <div class="fg"><label class="fl">From</label><select class="fc" id="fe-from" onchange="feRun()"><option value="mpgus">Miles per Gallon (US)</option><option value="mpguk">Miles per Gallon (UK)</option><option value="l100">L / 100km</option><option value="kml">km / Liter</option></select></div>
    <div id="fe-out"></div>`,
  init: () => { window.feRun = () => {
    const v = parseFloat(document.getElementById('fe-val').value); if (!v) return;
    const from = document.getElementById('fe-from').value;
    let l100;
    if (from==='mpgus') l100 = 235.214/v; else if (from==='mpguk') l100 = 282.481/v; else if (from==='l100') l100=v; else l100 = 100/v;
    const mpgus = 235.214/l100, mpguk = 282.481/l100, kml = 100/l100;
    document.getElementById('fe-out').innerHTML = statBlock([['MPG (US)',round4(mpgus)],['MPG (UK)',round4(mpguk)],['L/100km',round4(l100)],['km/L',round4(kml)]]);
  }; feRun(); }
};

// ---------- shoe-size ----------
const SHOE_SIZES = [ // [US, UK, EU]
  [6,5.5,39],[6.5,6,39.5],[7,6.5,40],[7.5,7,40.5],[8,7.5,41],[8.5,8,42],[9,8.5,42.5],[9.5,9,43],[10,9.5,44],[10.5,10,44.5],[11,10.5,45],[12,11.5,46],[13,12.5,47]
];
TOOL_CUSTOM['shoe-size'] = {
  body: () => `
    <div class="fg"><label class="fl">System</label><select class="fc" id="ss-from" onchange="ssRun()"><option value="0">US</option><option value="1">UK</option><option value="2">EU</option></select></div>
    <div class="fg"><label class="fl">Size</label><input type="number" step="0.5" class="fc" id="ss-val" value="9" oninput="ssRun()"></div>
    <div id="ss-out"></div><div class="alert alert-info" style="margin-top:10px">Approximate - sizing varies by brand.</div>`,
  init: () => { window.ssRun = () => {
    const col = parseInt(document.getElementById('ss-from').value);
    const v = parseFloat(document.getElementById('ss-val').value); if (isNaN(v)) return;
    let closest = SHOE_SIZES[0], diff=Infinity;
    SHOE_SIZES.forEach(row => { const d=Math.abs(row[col]-v); if (d<diff){diff=d;closest=row;} });
    document.getElementById('ss-out').innerHTML = statBlock([['US',closest[0]],['UK',closest[1]],['EU',closest[2]]]);
  }; ssRun(); }
};

// ---------- date-difference ----------
TOOL_CUSTOM['date-difference'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Start Date</label><input type="date" class="fc" id="dd-a" oninput="ddRun()"></div>
      <div class="fg"><label class="fl">End Date</label><input type="date" class="fc" id="dd-b" oninput="ddRun()"></div>
    </div>
    <div id="dd-out"></div>`,
  init: () => { window.ddRun = () => {
    const a = document.getElementById('dd-a').value, b = document.getElementById('dd-b').value;
    if (!a || !b) return;
    let d1 = new Date(a+'T00:00:00'), d2 = new Date(b+'T00:00:00');
    if (d1>d2) [d1,d2]=[d2,d1];
    let y=d2.getFullYear()-d1.getFullYear(), m=d2.getMonth()-d1.getMonth(), d=d2.getDate()-d1.getDate();
    if (d<0){ m--; d += new Date(d2.getFullYear(),d2.getMonth(),0).getDate(); }
    if (m<0){ y--; m+=12; }
    const totalDays = Math.round((d2-d1)/86400000);
    document.getElementById('dd-out').innerHTML = statBlock([['Years',y],['Months',m],['Days',d],['Total Days',totalDays.toLocaleString()],['Total Weeks',Math.round(totalDays/7).toLocaleString()],['Total Months',(y*12+m)]]);
  };}
};

// ---------- timezone-converter / world-clock ----------
const TZ_LIST = [['UTC','UTC'],['America/New_York','New York'],['America/Los_Angeles','Los Angeles'],['America/Sao_Paulo','São Paulo'],['Europe/London','London'],['Europe/Paris','Paris'],['Europe/Moscow','Moscow'],['Asia/Dubai','Dubai'],['Asia/Kolkata','India (IST)'],['Asia/Dhaka','Dhaka'],['Asia/Bangkok','Bangkok'],['Asia/Shanghai','Shanghai'],['Asia/Tokyo','Tokyo'],['Australia/Sydney','Sydney'],['Pacific/Auckland','Auckland']];
function renderClocks(containerId){
  const el = document.getElementById(containerId); if (!el) return;
  el.innerHTML = TZ_LIST.map(([tz,label]) => `<div class="trow"><span>${label}</span><strong class="mono" id="clk-${tz.replace(/\W/g,'')}"></strong></div>`).join('');
  const tick = () => { TZ_LIST.forEach(([tz]) => { const e=document.getElementById('clk-'+tz.replace(/\W/g,'')); if(!e) return;
    e.textContent = new Date().toLocaleString('en-US',{timeZone:tz,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true,month:'short',day:'numeric'}); }); };
  tick();
  if (window.__clkInt) clearInterval(window.__clkInt);
  window.__clkInt = setInterval(()=>{ if (!document.getElementById(containerId)) { clearInterval(window.__clkInt); return; } tick(); }, 1000);
}
TOOL_CUSTOM['timezone-converter'] = { body: () => `<div id="tz-list"></div>`, init: () => renderClocks('tz-list') };
TOOL_CUSTOM['world-clock'] = { body: () => `<div id="wc-list"></div>`, init: () => renderClocks('wc-list') };

// ---------- stopwatch ----------
TOOL_CUSTOM['stopwatch'] = {
  body: () => `<div class="res-box ok mono" id="sw-disp" style="font-size:36px;text-align:center;font-weight:700">00:00:00.0</div>
    <div class="bgrp" style="justify-content:center;margin-top:14px"><button class="btn btn-p" id="sw-start" onclick="swToggle()">Start</button><button class="btn btn-s" onclick="swLap()">Lap</button><button class="btn btn-s" onclick="swReset()">Reset</button></div>
    <div id="sw-laps" style="margin-top:14px"></div>`,
  init: () => {
    let running=false, startTime=0, elapsed=0, laps=[], raf;
    const fmt = ms => { const h=Math.floor(ms/3600000), m=Math.floor(ms%3600000/60000), s=Math.floor(ms%60000/1000), t=Math.floor(ms%1000/100);
      return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${t}`; };
    const tick = () => { if (!document.getElementById('sw-disp')) { cancelAnimationFrame(raf); return; } if (running) { document.getElementById('sw-disp').textContent = fmt(elapsed+Date.now()-startTime); raf=requestAnimationFrame(tick); } };
    window.swToggle = () => { running=!running; const btn=document.getElementById('sw-start');
      if (running) { startTime=Date.now(); btn.textContent='Pause'; tick(); } else { elapsed += Date.now()-startTime; btn.textContent='Resume'; } };
    window.swLap = () => { const cur = running ? elapsed+Date.now()-startTime : elapsed; laps.unshift(cur); document.getElementById('sw-laps').innerHTML = laps.map((l,i)=>`<div class="trow"><span>Lap ${laps.length-i}</span><strong class="mono">${fmt(l)}</strong></div>`).join(''); };
    window.swReset = () => { running=false; elapsed=0; laps=[]; document.getElementById('sw-disp').textContent='00:00:00.0'; document.getElementById('sw-start').textContent='Start'; document.getElementById('sw-laps').innerHTML=''; };
  }
};

// ---------- countdown-timer ----------
TOOL_CUSTOM['countdown-timer'] = {
  body: () => `<div class="fg"><label class="fl">Target Date & Time</label><input type="datetime-local" class="fc" id="cd-target"></div><button class="btn btn-p" onclick="cdStart()">Start Countdown</button>
    <div class="res-box ok mono" id="cd-disp" style="font-size:24px;text-align:center;font-weight:700;margin-top:14px">Set a target above</div>`,
  init: () => { window.cdStart = () => {
    const v = document.getElementById('cd-target').value; if (!v) return;
    const target = new Date(v).getTime();
    if (window.__cdInt) clearInterval(window.__cdInt);
    const tick = () => {
      const disp = document.getElementById('cd-disp'); if (!disp) { clearInterval(window.__cdInt); return; }
      const diff = target - Date.now();
      if (diff<=0) { disp.textContent = 'Time reached!'; clearInterval(window.__cdInt); return; }
      const d=Math.floor(diff/86400000), h=Math.floor(diff%86400000/3600000), m=Math.floor(diff%3600000/60000), s=Math.floor(diff%60000/1000);
      disp.textContent = `${d}d ${h}h ${m}m ${s}s`;
    };
    tick(); window.__cdInt = setInterval(tick,1000);
  };}
};

// ---------- pomodoro-timer ----------
TOOL_CUSTOM['pomodoro-timer'] = {
  body: () => `<div class="res-box ok mono" id="po-disp" style="font-size:40px;text-align:center;font-weight:700">25:00</div>
    <div style="text-align:center;font-size:13px;color:var(--tm);margin-top:6px" id="po-mode">Focus session</div>
    <div class="bgrp" style="justify-content:center;margin-top:14px"><button class="btn btn-p" id="po-btn" onclick="poToggle()">Start</button><button class="btn btn-s" onclick="poReset()">Reset</button></div>`,
  init: () => {
    let secs=25*60, running=false, focus=true;
    const render = () => { const el=document.getElementById('po-disp'); if (!el) return; const m=Math.floor(secs/60), s=secs%60; el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };
    window.poToggle = () => {
      running = !running; document.getElementById('po-btn').textContent = running?'Pause':'Resume';
      if (running) { if (window.__poInt) clearInterval(window.__poInt); window.__poInt = setInterval(()=>{
        if (!document.getElementById('po-disp')) { clearInterval(window.__poInt); return; }
        secs--; if (secs<=0) { focus=!focus; secs = focus?25*60:5*60; document.getElementById('po-mode').textContent = focus?'Focus session':'Break'; toast(focus?'Break over - back to focus':'Focus done - take a break','ok'); }
        render();
      },1000); }
      else clearInterval(window.__poInt);
    };
    window.poReset = () => { running=false; if(window.__poInt) clearInterval(window.__poInt); secs=25*60; focus=true; document.getElementById('po-mode').textContent='Focus session'; document.getElementById('po-btn').textContent='Start'; render(); };
    render();
  }
};

// ---------- qr-generator ----------
TOOL_CUSTOM['qr-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Content Type</label><select class="fc" id="qr-type" onchange="qrFields()"><option value="text">Text / URL</option><option value="email">Email</option><option value="phone">Phone</option><option value="sms">SMS</option><option value="wifi">Wi-Fi</option></select></div>
    <div id="qr-fields"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Size (px)</label><select class="fc" id="qr-size"><option value="128">128</option><option value="200" selected>200</option><option value="300">300</option><option value="400">400</option></select></div>
      <div class="fg"><label class="fl">Error Correction</label><select class="fc" id="qr-ec"><option value="L">L (Low)</option><option value="M" selected>M (Medium)</option><option value="Q">Q (High)</option><option value="H">H (Very High)</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="qrGen()">Generate QR Code</button>
    <div id="qr-result" style="margin-top:18px;text-align:center"></div>`,
  init: () => {
    window.qrFields = () => {
      const type = document.getElementById('qr-type').value;
      const f = document.getElementById('qr-fields');
      const map = {
        text: `<div class="fg"><label class="fl">Text or URL</label><input class="fc" id="qr-text" placeholder="https://example.com"></div>`,
        email: `<div class="fg"><label class="fl">Email</label><input type="email" class="fc" id="qr-text" placeholder="hello@example.com"></div>`,
        phone: `<div class="fg"><label class="fl">Phone</label><input class="fc" id="qr-text" placeholder="+1234567890"></div>`,
        sms: `<div class="fg"><label class="fl">Phone</label><input class="fc" id="qr-text" placeholder="+1234567890"></div><div class="fg"><label class="fl">Message</label><textarea class="fc" id="qr-msg" rows="2"></textarea></div>`,
        wifi: `<div class="fg"><label class="fl">Network Name (SSID)</label><input class="fc" id="qr-text"></div><div class="fg"><label class="fl">Password</label><input class="fc" id="qr-wifi-pass"></div><div class="fg"><label class="fl">Security</label><select class="fc" id="qr-wifi-sec"><option value="WPA">WPA/WPA2</option><option value="WEP">WEP</option><option value="nopass">None</option></select></div>`,
      };
      f.innerHTML = map[type] || map.text;
    };
    window.qrGen = () => {
      const type = document.getElementById('qr-type').value;
      const textEl = document.getElementById('qr-text');
      if (!textEl || !textEl.value.trim()) { document.getElementById('qr-result').innerHTML = '<div class="alert alert-warn">Enter some content first.</div>'; return; }
      let data = textEl.value.trim();
      if (type==='email') data = 'mailto:'+data;
      else if (type==='phone') data = 'tel:'+data;
      else if (type==='sms') { const msg=document.getElementById('qr-msg'); data = 'sms:'+data+(msg&&msg.value?'?body='+encodeURIComponent(msg.value):''); }
      else if (type==='wifi') { const pass=document.getElementById('qr-wifi-pass').value, sec=document.getElementById('qr-wifi-sec').value; data = `WIFI:T:${sec};S:${data};P:${pass};;`; }
      const size = parseInt(document.getElementById('qr-size').value);
      const ec = document.getElementById('qr-ec').value;
      try {
        const qr = qrcode(0, ec);
        qr.addData(data); qr.make();
        const cellSize = Math.max(2, Math.floor(size / qr.getModuleCount()));
        const svg = qr.createSvgTag({cellSize, margin:4});
        document.getElementById('qr-result').innerHTML = `<div style="display:inline-block;background:#fff;padding:14px;border-radius:12px;border:1px solid var(--bdr)">${svg}</div>
          <div style="margin-top:12px"><button class="btn btn-s btn-sm" onclick="qrDownload()">Download PNG</button></div>`;
      } catch(e) { document.getElementById('qr-result').innerHTML = `<div class="alert alert-err">Could not generate QR code: ${esc(e.message)}</div>`; }
    };
    window.qrDownload = () => {
      const svgEl = document.querySelector('#qr-result svg');
      if (!svgEl) return;
      const svgData = new XMLSerializer().serializeToString(svgEl);
      const img = new Image();
      const svgBlob = new Blob([svgData], {type:'image/svg+xml;charset=utf-8'});
      const url = URL.createObjectURL(svgBlob);
      img.onload = () => {
        const c = document.createElement('canvas'); c.width=img.width||300; c.height=img.height||300;
        const ctx = c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0);
        const a = document.createElement('a'); a.href = c.toDataURL('image/png'); a.download = 'qrcode.png'; a.click();
        URL.revokeObjectURL(url);
      };
      img.src = url;
    };
    qrFields();
  }
};

// ---------- ip-lookup ----------
TOOL_CUSTOM['ip-lookup'] = {
  body: () => `<div class="res-box ok mono" id="ip-disp" style="font-size:22px;text-align:center;font-weight:700">Looking up…</div>`,
  init: async () => {
    try {
      const res = await fetch('https://api.ipify.org?format=json');
      const data = await res.json();
      document.getElementById('ip-disp').textContent = data.ip;
    } catch(e) { const el=document.getElementById('ip-disp'); if (el) { el.className='res-box er'; el.textContent = 'Could not reach the lookup service. Check your connection.'; } }
  }
};

// ---------- coin-flip / dice-roller ----------
TOOL_CUSTOM['coin-flip'] = {
  body: () => `<div style="text-align:center"><div id="cf-coin" style="width:120px;height:120px;border-radius:50%;background:var(--p);color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;margin:0 auto 18px">Flip!</div><button class="btn btn-p" onclick="cfFlip()">Flip Coin</button><div id="cf-stats" style="margin-top:16px"></div></div>`,
  init: () => { let heads=0, tails=0; window.cfFlip = () => {
    const result = Math.random()<0.5 ? 'Heads' : 'Tails'; if (result==='Heads') heads++; else tails++;
    document.getElementById('cf-coin').textContent = result;
    document.getElementById('cf-stats').innerHTML = statBlock([['Heads',heads],['Tails',tails]]);
  };}
};
TOOL_CUSTOM['dice-roller'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Number of Dice</label><input type="number" class="fc" id="dr-n" value="2" min="1" max="10"></div>
      <div class="fg"><label class="fl">Sides</label><select class="fc" id="dr-sides"><option value="4">d4</option><option value="6" selected>d6</option><option value="8">d8</option><option value="10">d10</option><option value="12">d12</option><option value="20">d20</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="drRoll()">Roll Dice</button>
    <div id="dr-out" style="margin-top:16px"></div>`,
  init: () => { window.drRoll = () => {
    const n = Math.min(10,Math.max(1,parseInt(document.getElementById('dr-n').value)||1));
    const sides = parseInt(document.getElementById('dr-sides').value);
    const rolls = Array.from({length:n},()=>Math.floor(Math.random()*sides)+1);
    document.getElementById('dr-out').innerHTML = `<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">${rolls.map(r=>`<div style="width:46px;height:46px;border-radius:8px;background:var(--pl);color:var(--p);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px">${r}</div>`).join('')}</div><div style="text-align:center;margin-top:10px;font-weight:700">Total: ${rolls.reduce((a,b)=>a+b,0)}</div>`;
  };}
};

// ---------- text-to-speech ----------
TOOL_CUSTOM['text-to-speech'] = {
  body: () => `<div class="fg"><label class="fl">Text</label><textarea class="fc" id="ts-in" rows="6" placeholder="Type something to hear it..."></textarea></div>
    <div style="display:grid;grid-template-columns:1fr 100px 100px;gap:10px">
      <div class="fg"><label class="fl">Voice</label><select class="fc" id="ts-voice"></select></div>
      <div class="fg"><label class="fl">Rate</label><input type="number" class="fc" id="ts-rate" value="1" step="0.1" min="0.5" max="2"></div>
      <div class="fg"><label class="fl">Pitch</label><input type="number" class="fc" id="ts-pitch" value="1" step="0.1" min="0" max="2"></div>
    </div>
    <div class="bgrp"><button class="btn btn-p" onclick="ttsSpeak()">Speak</button><button class="btn btn-s" onclick="speechSynthesis.cancel()">Stop</button></div>`,
  init: () => {
    const populate = () => { const sel=document.getElementById('ts-voice'); if (!sel) return; const voices = speechSynthesis.getVoices();
      sel.innerHTML = voices.map((v,i)=>`<option value="${i}">${v.name} (${v.lang})</option>`).join('') || '<option>Default</option>'; };
    populate();
    if (speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.onvoiceschanged = populate;
    window.ttsSpeak = () => {
      const text = document.getElementById('ts-in').value; if (!text) return;
      const u = new SpeechSynthesisUtterance(text);
      const voices = speechSynthesis.getVoices(); const idx = parseInt(document.getElementById('ts-voice').value);
      if (voices[idx]) u.voice = voices[idx];
      u.rate = parseFloat(document.getElementById('ts-rate').value)||1;
      u.pitch = parseFloat(document.getElementById('ts-pitch').value)||1;
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    };
  }
};

// ---------- password-passphrase ----------
TOOL_CUSTOM['password-passphrase'] = {
  body: () => `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Words</label><input type="number" class="fc" id="pp-n" value="4" min="3" max="10"></div>
      <div class="fg"><label class="fl">Separator</label><select class="fc" id="pp-sep"><option value="-">Hyphen -</option><option value=".">Dot .</option><option value=" ">Space</option></select></div>
      <div class="fg"><label class="fl">Add Number</label><select class="fc" id="pp-num"><option value="1">Yes</option><option value="0">No</option></select></div>
    </div>
    <button class="btn btn-p btn-full" onclick="ppGen()">Generate Passphrase</button>
    <div class="res-box ok mono" id="pp-out" style="font-size:18px;text-align:center;margin-top:14px"></div>`,
  init: () => { window.ppGen = () => {
    const n = Math.min(10,Math.max(3,parseInt(document.getElementById('pp-n').value)||4));
    const sep = document.getElementById('pp-sep').value;
    const words = Array.from({length:n},()=>PASSPHRASE_WORDS[Math.floor(Math.random()*PASSPHRASE_WORDS.length)]);
    let phrase = words.join(sep);
    if (document.getElementById('pp-num').value==='1') phrase += sep + Math.floor(Math.random()*90+10);
    document.getElementById('pp-out').textContent = phrase;
  }; ppGen(); }
};

// ---------- random-color ----------
TOOL_CUSTOM['random-color'] = {
  body: () => `<div style="width:100%;height:100px;border-radius:12px;border:1px solid var(--bdr)" id="rc-swatch"></div><div id="rc-out" style="margin-top:14px"></div><button class="btn btn-p" onclick="rcGen()" style="margin-top:10px">Generate New Color</button>`,
  init: () => { window.rcGen = () => {
    const hex = '#'+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0');
    document.getElementById('rc-swatch').style.background = hex;
    const n = parseInt(hex.slice(1),16); const r=n>>16&255,g=n>>8&255,b=n&255;
    document.getElementById('rc-out').innerHTML = statBlock([['HEX',hex.toUpperCase()],['RGB',`${r}, ${g}, ${b}`]]);
  }; rcGen(); }
};

// ---------- spin-wheel ----------
TOOL_CUSTOM['spin-wheel'] = {
  body: () => `<div class="fg"><label class="fl">Options (one per line)</label><textarea class="fc" id="sp-in" rows="5">Pizza\nSushi\nTacos\nBurgers\nSalad</textarea></div>
    <canvas id="sp-canvas" width="280" height="280" style="margin:14px auto;display:block"></canvas>
    <button class="btn btn-p btn-full" onclick="spSpin()">Spin</button>
    <div class="res-box ok" id="sp-result" style="text-align:center;font-weight:700;margin-top:14px;display:none"></div>`,
  init: () => {
    const colors = ['#1D4ED8','#0F766E','#A16207','#991B1B','#BE123C','#0E7490','#B45309','#4338CA'];
    let rotation = 0;
    const draw = () => {
      const opts = document.getElementById('sp-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
      const c = document.getElementById('sp-canvas'); if (!c) return; const ctx = c.getContext('2d');
      const cx=140, cy=140, r=130; ctx.clearRect(0,0,280,280);
      const n = Math.max(1,opts.length); const arc = 2*Math.PI/n;
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(rotation);
      opts.forEach((opt,i) => {
        ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0,0,r, i*arc, (i+1)*arc); ctx.closePath();
        ctx.fillStyle = colors[i%colors.length]; ctx.fill();
        ctx.save(); ctx.rotate(i*arc+arc/2); ctx.fillStyle='#fff'; ctx.font='12px sans-serif'; ctx.textAlign='right';
        ctx.fillText(opt.slice(0,14), r-10, 4); ctx.restore();
      });
      ctx.restore();
      ctx.beginPath(); ctx.moveTo(cx+r+6,cy); ctx.lineTo(cx+r-10,cy-8); ctx.lineTo(cx+r-10,cy+8); ctx.closePath(); ctx.fillStyle='#0F172A'; ctx.fill();
      return opts;
    };
    document.getElementById('sp-in').addEventListener('input', draw);
    window.spSpin = () => {
      const opts = document.getElementById('sp-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
      if (!opts.length) return;
      const n = opts.length, arc = 2*Math.PI/n;
      const extraSpins = 5+Math.random()*3;
      const target = Math.random()*2*Math.PI;
      const finalRotation = extraSpins*2*Math.PI + target;
      const start = rotation, duration=2500, startTime=performance.now();
      const animate = (t) => {
        const p = Math.min(1,(t-startTime)/duration); const ease = 1-Math.pow(1-p,3);
        rotation = start + (finalRotation-start)*ease; draw();
        if (p<1) requestAnimationFrame(animate);
        else {
          const normalized = ((2*Math.PI - (rotation % (2*Math.PI))) + 2*Math.PI - Math.PI/2*0) % (2*Math.PI);
          const idx = Math.floor((normalized) / arc) % n;
          const resEl = document.getElementById('sp-result'); resEl.style.display='block'; resEl.textContent = 'Result: '+opts[idx];
        }
      };
      requestAnimationFrame(animate);
    };
    draw();
  }
};

// ---------- bmr-calculator ----------
TOOL_CUSTOM['bmr-calculator'] = {
  body: () => `
    <div class="bgrp" style="margin-bottom:14px"><button class="btn btn-p btn-sm" id="bmr-metric-btn" onclick="bmrUnit('metric')">Metric</button><button class="btn btn-s btn-sm" id="bmr-imp-btn" onclick="bmrUnit('imperial')">Imperial</button></div>
    <div id="bmr-metric">
      <div class="fg"><label class="fl">Weight (kg)</label><input type="number" class="fc" id="bmr-kg" value="70" oninput="bmrRun()"></div>
      <div class="fg"><label class="fl">Height (cm)</label><input type="number" class="fc" id="bmr-cm" value="175" oninput="bmrRun()"></div>
    </div>
    <div id="bmr-imperial" style="display:none">
      <div class="fg"><label class="fl">Weight (lbs)</label><input type="number" class="fc" id="bmr-lbs" value="154" oninput="bmrRun()"></div>
      <div class="fg"><label class="fl">Height (inches)</label><input type="number" class="fc" id="bmr-in" value="69" oninput="bmrRun()"></div>
    </div>
    <div class="fg"><label class="fl">Age</label><input type="number" class="fc" id="bmr-age" value="30" oninput="bmrRun()"></div>
    <div class="fg"><label class="fl">Sex</label><select class="fc" id="bmr-sex" onchange="bmrRun()"><option value="m">Male</option><option value="f">Female</option></select></div>
    <div id="bmr-out"></div><div class="alert alert-info" style="margin-top:10px">General estimate only, not medical advice.</div>`,
  init: () => {
    let unit='metric';
    window.bmrUnit = (u) => { unit=u; document.getElementById('bmr-metric').style.display=u==='metric'?'':'none'; document.getElementById('bmr-imperial').style.display=u==='imperial'?'':'none';
      document.getElementById('bmr-metric-btn').className = u==='metric'?'btn btn-p btn-sm':'btn btn-s btn-sm'; document.getElementById('bmr-imp-btn').className = u==='imperial'?'btn btn-p btn-sm':'btn btn-s btn-sm'; bmrRun(); };
    window.bmrRun = () => {
      let kg,cm; if (unit==='metric'){ kg=+document.getElementById('bmr-kg').value; cm=+document.getElementById('bmr-cm').value; } else { kg=+document.getElementById('bmr-lbs').value*0.453592; cm=+document.getElementById('bmr-in').value*2.54; }
      const age=+document.getElementById('bmr-age').value, sex=document.getElementById('bmr-sex').value;
      if (!kg||!cm||!age) { document.getElementById('bmr-out').innerHTML=''; return; }
      const bmr = sex==='m' ? 10*kg+6.25*cm-5*age+5 : 10*kg+6.25*cm-5*age-161;
      document.getElementById('bmr-out').innerHTML = statBlock([['BMR',Math.round(bmr)+' kcal/day'],['Light Activity',Math.round(bmr*1.375)+' kcal/day'],['Moderate Activity',Math.round(bmr*1.55)+' kcal/day'],['Very Active',Math.round(bmr*1.725)+' kcal/day']]);
    };
    bmrRun();
  }
};

// ---------- pace-calculator ----------
TOOL_CUSTOM['pace-calculator'] = {
  body: () => `
    <div class="fg"><label class="fl">Distance (km)</label><input type="number" class="fc" id="pa-dist" value="5" oninput="paRun()"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Hours</label><input type="number" class="fc" id="pa-h" value="0" oninput="paRun()"></div>
      <div class="fg"><label class="fl">Minutes</label><input type="number" class="fc" id="pa-m" value="25" oninput="paRun()"></div>
      <div class="fg"><label class="fl">Seconds</label><input type="number" class="fc" id="pa-s" value="0" oninput="paRun()"></div>
    </div>
    <div id="pa-out"></div>`,
  init: () => { window.paRun = () => {
    const dist = +document.getElementById('pa-dist').value;
    const totalSec = (+document.getElementById('pa-h').value||0)*3600 + (+document.getElementById('pa-m').value||0)*60 + (+document.getElementById('pa-s').value||0);
    if (!dist || !totalSec) return;
    const paceSecPerKm = totalSec/dist;
    const pm=Math.floor(paceSecPerKm/60), ps=Math.round(paceSecPerKm%60);
    const paceMi = paceSecPerKm*1.60934; const pmM=Math.floor(paceMi/60), psM=Math.round(paceMi%60);
    const speedKmh = dist/(totalSec/3600);
    document.getElementById('pa-out').innerHTML = statBlock([['Pace per km',`${pm}:${String(ps).padStart(2,'0')}`],['Pace per mile',`${pmM}:${String(psM).padStart(2,'0')}`],['Speed',round4(speedKmh)+' km/h']]);
  }; paRun(); }
};

// ---------- tax-bracket ----------
TOOL_CUSTOM['simple-tax-estimator'] = {
  body: () => `
    <div class="fg"><label class="fl">Income</label><input type="number" class="fc" id="tb-income" value="60000" oninput="tbRun()"></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;margin:10px 0 6px">Tax Brackets</div>
    <div id="tb-rows"></div>
    <button class="btn btn-s btn-sm" onclick="tbAddRow()">+ Add Bracket</button>
    <div id="tb-out" style="margin-top:14px"></div>
    <div class="alert alert-info" style="margin-top:10px">Educational estimate using progressive brackets you define - not tax advice.</div>`,
  init: () => {
    const defaults = [[0,10],[40000,20],[100000,30]];
    window.tbAddRow = (from,rate) => {
      const row = document.createElement('div'); row.style.cssText='display:grid;grid-template-columns:1fr 1fr 30px;gap:8px;margin-bottom:8px';
      row.innerHTML = `<input class="fc" type="number" placeholder="From" value="${from??''}" oninput="tbRun()"><input class="fc" type="number" placeholder="Rate %" value="${rate??''}" oninput="tbRun()"><button class="btn btn-s btn-sm" onclick="this.parentElement.remove();tbRun()">${svgIcon('ui_close',14)}</button>`;
      document.getElementById('tb-rows').appendChild(row);
    };
    defaults.forEach(([f,r])=>tbAddRow(f,r));
    window.tbRun = () => {
      const income = +document.getElementById('tb-income').value; if (!income) return;
      const rows = [...document.getElementById('tb-rows').children].map(r => { const [f,ra] = r.querySelectorAll('input'); return {from:+f.value||0, rate:+ra.value||0}; }).sort((a,b)=>a.from-b.from);
      let tax=0;
      for (let i=0;i<rows.length;i++){ const upper = i<rows.length-1?rows[i+1].from:Infinity; if (income>rows[i].from){ const amt = Math.min(income,upper)-rows[i].from; tax += amt*rows[i].rate/100; } }
      document.getElementById('tb-out').innerHTML = statBlock([['Estimated Tax',fmtMoney(tax)],['Net Income',fmtMoney(income-tax)],['Effective Rate',round4(tax/income*100)+'%']]);
    };
    tbRun();
  }
};

// ---------- SEO tools ----------
TOOL_CUSTOM['meta-tag-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Page Title</label><input class="fc" id="mt-title" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Meta Description</label><textarea class="fc" id="mt-desc" rows="3" oninput="mtRun()"></textarea></div>
    <div class="fg"><label class="fl">Keywords (comma separated)</label><input class="fc" id="mt-kw" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Author</label><input class="fc" id="mt-author" oninput="mtRun()"></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('mt-out').value,this)">Copy</button></label><textarea class="fc mono" id="mt-out" rows="8" readonly></textarea></div>`,
  init: () => { window.mtRun = () => {
    const t=document.getElementById('mt-title').value, d=document.getElementById('mt-desc').value, k=document.getElementById('mt-kw').value, a=document.getElementById('mt-author').value;
    let out = '';
    if (t) out += `<title>${esc(t)}</title>\n`;
    if (d) out += `<meta name="description" content="${esc(d)}">\n`;
    if (k) out += `<meta name="keywords" content="${esc(k)}">\n`;
    if (a) out += `<meta name="author" content="${esc(a)}">\n`;
    out += `<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<meta name="robots" content="index, follow">`;
    document.getElementById('mt-out').value = out;
  }; mtRun(); }
};
TOOL_CUSTOM['keyword-density'] = {
  body: () => `<div class="fg"><label class="fl">Content</label><textarea class="fc" id="kd-in" rows="8" oninput="kdRun()"></textarea></div><div id="kd-out"></div>`,
  init: () => { window.kdRun = () => {
    const t = document.getElementById('kd-in').value.toLowerCase();
    const words = t.replace(/[^a-z0-9'\s]/g,'').split(/\s+/).filter(w=>w.length>2);
    const total = words.length;
    const freq = {}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
    const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,15);
    document.getElementById('kd-out').innerHTML = total ? statBlock([['Total Words',total]]) + top.map(([w,n])=>`<div class="trow"><span>${esc(w)}</span><strong>${n} (${round4(n/total*100)}%)</strong></div>`).join('') : '<div class="alert alert-info">Paste some content.</div>';
  };}
};
TOOL_CUSTOM['open-graph-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">og:title</label><input class="fc" id="og-title" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:description</label><textarea class="fc" id="og-desc" rows="2" oninput="ogRun()"></textarea></div>
    <div class="fg"><label class="fl">og:image URL</label><input class="fc" id="og-img" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:url</label><input class="fc" id="og-url" oninput="ogRun()"></div>
    <div class="fg"><label class="fl">og:type</label><select class="fc" id="og-type" onchange="ogRun()"><option value="website">website</option><option value="article">article</option><option value="product">product</option></select></div>
    <div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('og-out').value,this)">Copy</button></label><textarea class="fc mono" id="og-out" rows="7" readonly></textarea></div>`,
  init: () => { window.ogRun = () => {
    const f = id => document.getElementById(id).value;
    let out = `<meta property="og:title" content="${esc(f('og-title'))}">\n<meta property="og:description" content="${esc(f('og-desc'))}">\n<meta property="og:type" content="${esc(f('og-type'))}">\n`;
    if (f('og-img')) out += `<meta property="og:image" content="${esc(f('og-img'))}">\n`;
    if (f('og-url')) out += `<meta property="og:url" content="${esc(f('og-url'))}">\n`;
    out += `<meta name="twitter:card" content="summary_large_image">`;
    document.getElementById('og-out').value = out;
  };}
};
TOOL_CUSTOM['robots-txt-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Disallow Paths (one per line)</label><textarea class="fc" id="rm-disallow" rows="4" placeholder="/admin/\n/private/"></textarea></div>
    <div class="fg"><label class="fl">Sitemap URL (optional)</label><input class="fc" id="rm-sitemap" placeholder="https://example.com/sitemap.xml"></div>
    <button class="btn btn-p" onclick="rmRun()">Generate</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('rm-out').value,this)">Copy</button></label><textarea class="fc mono" id="rm-out" rows="8" readonly></textarea></div>`,
  init: () => { window.rmRun = () => {
    const paths = document.getElementById('rm-disallow').value.split('\n').map(s=>s.trim()).filter(Boolean);
    const sitemap = document.getElementById('rm-sitemap').value.trim();
    let out = 'User-agent: *\n';
    out += paths.length ? paths.map(p=>'Disallow: '+p).join('\n') : 'Allow: /';
    if (sitemap) out += '\n\nSitemap: '+sitemap;
    document.getElementById('rm-out').value = out;
  }; rmRun(); }
};
TOOL_CUSTOM['schema-generator'] = {
  body: () => `
    <div class="fg"><label class="fl">Schema Type</label><select class="fc" id="sc2-type" onchange="sc2Render()"><option value="Article">Article</option><option value="Product">Product</option><option value="FAQPage">FAQ Page</option></select></div>
    <div id="sc2-fields"></div>
    <div class="fg"><label class="fl">JSON-LD Output <button class="cpbtn" onclick="copyText(document.getElementById('sc2-out').value,this)">Copy</button></label><textarea class="fc mono" id="sc2-out" rows="10" readonly></textarea></div>`,
  init: () => {
    window.sc2Render = () => {
      const type = document.getElementById('sc2-type').value;
      const f = document.getElementById('sc2-fields');
      if (type==='Article') f.innerHTML = `<div class="fg"><label class="fl">Headline</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Author</label><input class="fc" id="sc2-2" oninput="sc2Run()"></div><div class="fg"><label class="fl">Date Published (YYYY-MM-DD)</label><input class="fc" id="sc2-3" oninput="sc2Run()"></div>`;
      else if (type==='Product') f.innerHTML = `<div class="fg"><label class="fl">Name</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Price</label><input class="fc" id="sc2-2" oninput="sc2Run()"></div><div class="fg"><label class="fl">Currency (e.g. USD)</label><input class="fc" id="sc2-3" oninput="sc2Run()"></div>`;
      else f.innerHTML = `<div class="fg"><label class="fl">Question</label><input class="fc" id="sc2-1" oninput="sc2Run()"></div><div class="fg"><label class="fl">Answer</label><textarea class="fc" id="sc2-2" rows="3" oninput="sc2Run()"></textarea></div>`;
      sc2Run();
    };
    window.sc2Run = () => {
      const type = document.getElementById('sc2-type').value;
      const v1=document.getElementById('sc2-1')?.value||'', v2=document.getElementById('sc2-2')?.value||'', v3=document.getElementById('sc2-3')?.value||'';
      let obj;
      if (type==='Article') obj = {'@context':'https://schema.org','@type':'Article',headline:v1,author:{'@type':'Person',name:v2},datePublished:v3};
      else if (type==='Product') obj = {'@context':'https://schema.org','@type':'Product',name:v1,offers:{'@type':'Offer',price:v2,priceCurrency:v3}};
      else obj = {'@context':'https://schema.org','@type':'FAQPage',mainEntity:[{'@type':'Question',name:v1,acceptedAnswer:{'@type':'Answer',text:v2}}]};
      document.getElementById('sc2-out').value = JSON.stringify(obj,null,2);
    };
    sc2Render();
  }
};
TOOL_CUSTOM['utm-builder'] = {
  body: () => `
    <div class="fg"><label class="fl">Website URL</label><input class="fc" id="um-url" placeholder="https://example.com" oninput="umRun()"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="fg"><label class="fl">Source</label><input class="fc" id="um-source" placeholder="newsletter" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Medium</label><input class="fc" id="um-medium" placeholder="email" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Campaign</label><input class="fc" id="um-campaign" placeholder="spring_sale" oninput="umRun()"></div>
      <div class="fg"><label class="fl">Term (optional)</label><input class="fc" id="um-term" oninput="umRun()"></div>
    </div>
    <div class="fg"><label class="fl">Content (optional)</label><input class="fc" id="um-content" oninput="umRun()"></div>
    <div class="fg"><label class="fl">Generated URL <button class="cpbtn" onclick="copyText(document.getElementById('um-out').value,this)">Copy</button></label><textarea class="fc mono" id="um-out" rows="4" readonly></textarea></div>`,
  init: () => { window.umRun = () => {
    const url = document.getElementById('um-url').value.trim(); if (!url) { document.getElementById('um-out').value=''; return; }
    const params = new URLSearchParams();
    const s=document.getElementById('um-source').value, m=document.getElementById('um-medium').value, c=document.getElementById('um-campaign').value, t=document.getElementById('um-term').value, ct=document.getElementById('um-content').value;
    if (s) params.set('utm_source',s); if (m) params.set('utm_medium',m); if (c) params.set('utm_campaign',c); if (t) params.set('utm_term',t); if (ct) params.set('utm_content',ct);
    const sep = url.includes('?') ? '&' : '?';
    document.getElementById('um-out').value = params.toString() ? url+sep+params.toString() : url;
  };}
};
TOOL_CUSTOM['sitemap-generator'] = {
  body: () => `<div class="fg"><label class="fl">URLs (one per line)</label><textarea class="fc" id="sm-in" rows="8" placeholder="https://example.com/\nhttps://example.com/about"></textarea></div>
    <button class="btn btn-p" onclick="smRun()">Generate sitemap.xml</button>
    <div class="fg" style="margin-top:12px"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('sm-out').value,this)">Copy</button></label><textarea class="fc mono" id="sm-out" rows="10" readonly></textarea></div>`,
  init: () => { window.smRun = () => {
    const urls = document.getElementById('sm-in').value.split('\n').map(s=>s.trim()).filter(Boolean);
    const today = new Date().toISOString().slice(0,10);
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`  <url><loc>${esc(u)}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>`;
    document.getElementById('sm-out').value = xml;
  };}
};

// ---------- password-strength ----------
TOOL_CUSTOM['password-strength'] = {
  body: () => `<div class="fg"><label class="fl">Password</label><div style="position:relative"><input type="password" class="fc" id="ps-in" oninput="psRun()" style="padding-right:80px"><button onclick="psToggle()" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;font-size:12px;font-weight:600;color:var(--t2);cursor:pointer" id="ps-btn">Show</button></div></div><div id="ps-out"></div>`,
  init: () => {
    window.psToggle = () => { const i=document.getElementById('ps-in'); i.type = i.type==='password'?'text':'password'; document.getElementById('ps-btn').textContent = i.type==='password'?'Show':'Hide'; };
    window.psRun = () => {
      const p = document.getElementById('ps-in').value; const out = document.getElementById('ps-out');
      if (!p) { out.innerHTML=''; return; }
      let score=0; const checks={length:p.length>=8,upper:/[A-Z]/.test(p),lower:/[a-z]/.test(p),number:/[0-9]/.test(p),special:/[^A-Za-z0-9]/.test(p)};
      if (checks.length) score+=20; if (p.length>=12) score+=10; if (p.length>=16) score+=10;
      if (checks.upper) score+=15; if (checks.lower) score+=15; if (checks.number) score+=15; if (checks.special) score+=15;
      const common=['password','123456','qwerty','abc123','letmein','monkey','dragon','welcome'];
      let noCommon = !common.some(c=>p.toLowerCase().includes(c)); if (!noCommon) score=Math.min(score,25);
      score=Math.min(100,score);
      let label,color; if(score<30){label='Very Weak';color='#B91C1C';}else if(score<50){label='Weak';color='#B45309';}else if(score<70){label='Fair';color='#A16207';}else if(score<85){label='Strong';color='#0F766E';}else{label='Very Strong';color='#065F46';}
      const items=[['length','At least 8 characters'],['upper','Uppercase letters'],['lower','Lowercase letters'],['number','Numbers'],['special','Special characters']];
      out.innerHTML = `<div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rl);padding:18px;margin-top:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:10px"><span style="font-weight:700;color:${color}">${label}</span><span style="font-weight:700;color:${color}">${score}/100</span></div>
        <div class="pr-bar"><div class="pr-fill" style="width:${score}%;background:${color}"></div></div>
        <div style="margin-top:14px;display:grid;grid-template-columns:1fr 1fr;gap:6px">${items.map(([k,l])=>`<div style="font-size:12px;color:${checks[k]?'var(--ok)':'var(--err)'}">${checks[k]?svgIcon('ui_check',12):svgIcon('ui_close',12)} ${l}</div>`).join('')}</div>
        ${!noCommon?'<div class="alert alert-warn" style="margin-top:12px">Contains a common weak pattern.</div>':''}
      </div>`;
    };
  }
};

// ---------- htpasswd ----------
TOOL_CUSTOM['htpasswd'] = {
  body: () => `<div class="fg"><label class="fl">Username</label><input class="fc" id="hp-user" value="admin"></div><div class="fg"><label class="fl">Password</label><input class="fc" id="hp-pass" type="password" value=""></div><button class="btn btn-p" onclick="hpRun()">Generate</button><div id="hp-out" style="margin-top:14px"></div>`,
  init: () => { window.hpRun = async () => {
    const user = document.getElementById('hp-user').value, pass = document.getElementById('hp-pass').value;
    if (!user || !pass) { toast('Enter username and password','er'); return; }
    const enc = new TextEncoder().encode(pass);
    const buf = await crypto.subtle.digest('SHA-1', enc);
    const hashB64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
    const line = `${user}:{SHA}${hashB64}`;
    document.getElementById('hp-out').innerHTML = `<div class="res-box mono ok">${esc(line)}</div><button class="cpbtn" style="margin-top:8px" onclick="copyText('${line.replace(/'/g,"\\'")}',this)">Copy</button><div class="alert alert-info" style="margin-top:10px">Uses the {SHA} htpasswd format. Apache also supports bcrypt/APR1 - check your server's requirements.</div>`;
  };}
};

// ---------- ssn-fake (fake test data) ----------
const FAKE_FIRST = ['Alex','Jordan','Taylor','Morgan','Casey','Riley','Avery','Quinn','Sam','Jamie','Drew','Cameron','Rowan','Skyler','Reese'];
const FAKE_LAST = ['Johnson','Smith','Williams','Brown','Davis','Miller','Wilson','Moore','Taylor','Anderson','Thomas','Jackson','White','Harris'];
TOOL_CUSTOM['fake-data-generator'] = {
  body: () => `<div class="fg"><label class="fl">How many records</label><input type="number" class="fc" id="fd-n" value="5" min="1" max="50" oninput="fdRun()"></div><div id="fd-out"></div>`,
  init: () => { window.fdRun = () => {
    const n = Math.min(50,Math.max(1,parseInt(document.getElementById('fd-n').value)||5));
    let rows = '';
    for (let i=0;i<n;i++){
      const fn=FAKE_FIRST[Math.floor(Math.random()*FAKE_FIRST.length)], ln=FAKE_LAST[Math.floor(Math.random()*FAKE_LAST.length)];
      const email = `${fn.toLowerCase()}.${ln.toLowerCase()}${Math.floor(Math.random()*99)}@example.com`;
      const phone = `555-${String(Math.floor(Math.random()*900+100))}-${String(Math.floor(Math.random()*9000+1000))}`;
      rows += `<div class="trow"><span>${fn} ${ln}</span><span class="mono" style="font-size:11px">${email} · ${phone}</span></div>`;
    }
    document.getElementById('fd-out').innerHTML = rows + '<div class="alert alert-info" style="margin-top:10px">All names use the example.com domain and 555 phone prefix reserved for fictional use - not real people.</div>';
  }; fdRun(); }
};

// ---------- roman-numerals ----------
TOOL_CUSTOM['roman-numerals'] = {
  body: () => `
    <div class="bgrp" style="margin-bottom:14px"><button class="btn btn-p btn-sm" id="rn-a2r-btn" onclick="rnMode('a2r')">Number to Roman</button><button class="btn btn-s btn-sm" id="rn-r2a-btn" onclick="rnMode('r2a')">Roman to Number</button></div>
    <div class="fg"><label class="fl" id="rn-label">Number (1-3999)</label><input class="fc" id="rn-in" value="1994" oninput="rnRun()"></div>
    <div class="res-box ok" id="rn-out" style="font-size:22px;text-align:center;font-weight:700"></div>`,
  init: () => {
    const toRoman = n => { const map=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']]; let r=''; for (const [v,s] of map) while(n>=v){r+=s;n-=v;} return r; };
    const fromRoman = s => { const vals={I:1,V:5,X:10,L:50,C:100,D:500,M:1000}; s=s.toUpperCase(); let total=0; for(let i=0;i<s.length;i++){ const v=vals[s[i]]; if(!v) return null; if (v<(vals[s[i+1]]||0)) total-=v; else total+=v; } return total; };
    let mode='a2r';
    window.rnMode = (m) => { mode=m; document.getElementById('rn-a2r-btn').className = m==='a2r'?'btn btn-p btn-sm':'btn btn-s btn-sm'; document.getElementById('rn-r2a-btn').className = m==='r2a'?'btn btn-p btn-sm':'btn btn-s btn-sm';
      document.getElementById('rn-label').textContent = m==='a2r'?'Number (1-3999)':'Roman Numeral'; document.getElementById('rn-in').value = m==='a2r'?'1994':'MCMXCIV'; rnRun(); };
    window.rnRun = () => {
      const v = document.getElementById('rn-in').value.trim(); const out = document.getElementById('rn-out');
      if (mode==='a2r'){ const n=parseInt(v); if(!n||n<1||n>3999){out.textContent='Enter 1-3999';return;} out.textContent=toRoman(n); }
      else { const n=fromRoman(v); if(n===null){out.textContent='Invalid Roman numeral';return;} out.textContent=n; }
    };
    rnRun();
  }
};
