// ============================================================
// Logic for the 5 dedicated (hand-built) tool pages
// ============================================================

// ---------- WORD COUNTER ----------
function analyzeWC(){
  const t = document.getElementById('wcText').value;
  const words = t.trim() ? t.trim().split(/\s+/).length : 0;
  const chars = t.length;
  const charsNo = t.replace(/\s/g,'').length;
  const sents = t.trim() ? ((t.match(/[.!?]+/g)||[]).length || 1) : 0;
  const paras = t.trim() ? t.trim().split(/\n\s*\n/).filter(p=>p.trim()).length : 0;
  const readMin = Math.max(1, Math.round(words/200));
  document.getElementById('wc-words').textContent = words.toLocaleString();
  document.getElementById('wc-chars').textContent = chars.toLocaleString();
  document.getElementById('wc-chars-no').textContent = charsNo.toLocaleString();
  document.getElementById('wc-sents').textContent = sents;
  document.getElementById('wc-para').textContent = paras || (t.trim()?1:0);
  document.getElementById('wc-read').textContent = readMin+'m';
  document.getElementById('wcBar').style.width = Math.min(100,(chars/5000)*100)+'%';
  const kw = document.getElementById('wcKeywords');
  if (!t.trim()) { kw.innerHTML = '<span style="color:var(--tm);font-size:13px">Type some text to see top keywords...</span>'; return; }
  const wfreq = {};
  t.toLowerCase().replace(/[^a-z\s]/g,'').split(/\s+/).forEach(w => { if (w.length>3) wfreq[w]=(wfreq[w]||0)+1; });
  const top = Object.entries(wfreq).sort((a,b)=>b[1]-a[1]).slice(0,10);
  kw.innerHTML = top.map(([w,n]) => `<span class="tag">${esc(w)} <strong style="color:var(--p)">${n}</strong></span>`).join('');
}
function clearWC(){ document.getElementById('wcText').value=''; analyzeWC(); }
function copyWCStats(){
  const stats = `Words: ${document.getElementById('wc-words').textContent}\nCharacters: ${document.getElementById('wc-chars').textContent}\nChars (no spaces): ${document.getElementById('wc-chars-no').textContent}\nSentences: ${document.getElementById('wc-sents').textContent}\nParagraphs: ${document.getElementById('wc-para').textContent}\nRead Time: ${document.getElementById('wc-read').textContent}`;
  copyText(stats);
}

// ---------- PASSWORD GENERATOR ----------
const PG_CHARS = { upper:'ABCDEFGHIJKLMNOPQRSTUVWXYZ', lower:'abcdefghijklmnopqrstuvwxyz', nums:'0123456789', spec:'!@#$%^&*()_+-=[]{}|;:,.<>?', ambig:/[lI1O0]/g };
function genPG(){
  const lenEl = document.getElementById('pgLen'); if (!lenEl) return;
  const len = parseInt(lenEl.value);
  const useUpper = document.getElementById('pgUpper').checked;
  const useLower = document.getElementById('pgLower').checked;
  const useNums = document.getElementById('pgNums').checked;
  const useSpec = document.getElementById('pgSpec').checked;
  const noAmb = document.getElementById('pgAmb').checked;
  let pool = '';
  if (useUpper) pool += PG_CHARS.upper;
  if (useLower) pool += PG_CHARS.lower;
  if (useNums) pool += PG_CHARS.nums;
  if (useSpec) pool += PG_CHARS.spec;
  if (noAmb) pool = pool.replace(PG_CHARS.ambig,'');
  if (!pool) { document.getElementById('pgPass').textContent = 'Select at least one character type'; return; }
  let pass = '';
  const arr = new Uint32Array(len); crypto.getRandomValues(arr);
  for (let i=0;i<len;i++) pass += pool[arr[i]%pool.length];
  document.getElementById('pgPass').textContent = pass;
  const types = [useUpper,useLower,useNums,useSpec].filter(Boolean).length;
  const score = Math.min(100, len*3+types*10);
  const bar = document.getElementById('pgStr'), lbl = document.getElementById('pgStrLbl');
  bar.style.width = score+'%';
  if (score<40){ bar.style.background='#B91C1C'; lbl.textContent='Weak'; lbl.style.color='#B91C1C'; }
  else if (score<65){ bar.style.background='#B45309'; lbl.textContent='Fair'; lbl.style.color='#B45309'; }
  else if (score<85){ bar.style.background='#0F766E'; lbl.textContent='Strong'; lbl.style.color='#0F766E'; }
  else { bar.style.background='#065F46'; lbl.textContent='Very Strong'; lbl.style.color='#065F46'; }
  return pass;
}
function genPGMulti(){
  const count = Math.min(20, parseInt(document.getElementById('pgCount').value)||1);
  const passes = []; for (let i=0;i<count;i++) passes.push(genPG());
  if (count>1) {
    document.getElementById('pgMulti').innerHTML = `
      <div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rs);padding:14px">
        <div style="font-size:12px;font-weight:700;color:var(--tm);margin-bottom:10px;text-transform:uppercase">Generated ${count} Passwords</div>
        ${passes.map(p=>`<div style="font-family:var(--fm);font-size:13px;padding:6px 0;border-bottom:1px solid var(--bdr);display:flex;justify-content:space-between;align-items:center"><span>${esc(p)}</span><button class="cpbtn" onclick="copyText('${p.replace(/'/g,"\\'")}',this)">Copy</button></div>`).join('')}
      </div>`;
  } else { document.getElementById('pgMulti').innerHTML = ''; }
}
function copyPG(){ copyText(document.getElementById('pgPass').textContent, document.getElementById('pgCopyBtn')); }

// ---------- JSON FORMATTER ----------
function formatJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const out = document.getElementById('jsonOut'), al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { const parsed = JSON.parse(inp); out.textContent = JSON.stringify(parsed,null,2); out.className='res-box mono ok'; al.innerHTML='<div class="alert alert-ok">Valid JSON - formatted successfully.</div>'; }
  catch(e){ out.textContent = 'Invalid JSON:\n'+e.message; out.className='res-box mono er'; al.innerHTML=`<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
}
function minifyJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const out = document.getElementById('jsonOut'), al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { const parsed = JSON.parse(inp); out.textContent = JSON.stringify(parsed); out.className='res-box mono ok'; al.innerHTML='<div class="alert alert-ok">JSON minified successfully.</div>'; }
  catch(e){ out.textContent = e.message; out.className='res-box mono er'; al.innerHTML=`<div class="alert alert-err">${esc(e.message)}</div>`; }
}
function validateJSON(){
  const inp = document.getElementById('jsonIn').value.trim();
  const al = document.getElementById('jsonAlert');
  if (!inp) { al.innerHTML = '<div class="alert alert-warn">Enter some JSON first.</div>'; return; }
  try { JSON.parse(inp); al.innerHTML='<div class="alert alert-ok">Valid JSON.</div>'; }
  catch(e){ al.innerHTML = `<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
}
function clearJSON(){
  document.getElementById('jsonIn').value='';
  document.getElementById('jsonOut').textContent='Result will appear here...';
  document.getElementById('jsonOut').className='res-box mono';
  document.getElementById('jsonAlert').innerHTML='';
}
function copyJSON(){ copyText(document.getElementById('jsonOut').textContent, document.getElementById('jsonCopyBtn')); }

// ---------- BMI CALCULATOR ----------
let bmiUnit = 'metric';
function setBMIUnit(u){
  bmiUnit = u;
  document.getElementById('bmi-metric').style.display = u==='metric'?'':'none';
  document.getElementById('bmi-imperial').style.display = u==='imperial'?'':'none';
  document.getElementById('bmi-metric-btn').className = u==='metric'?'btn btn-p btn-sm':'btn btn-s btn-sm';
  document.getElementById('bmi-imp-btn').className = u==='imperial'?'btn btn-p btn-sm':'btn btn-s btn-sm';
  document.getElementById('bmi-result').innerHTML='';
}
function calcBMI(){
  let weight, height;
  if (bmiUnit==='metric'){ weight=parseFloat(document.getElementById('bmi-kg').value); height=parseFloat(document.getElementById('bmi-cm').value)/100; }
  else { weight=parseFloat(document.getElementById('bmi-lbs').value)*0.453592; const ft=parseFloat(document.getElementById('bmi-ft').value)||0, inch=parseFloat(document.getElementById('bmi-in').value)||0; height=(ft*12+inch)*0.0254; }
  if (!weight || !height || height<=0) { document.getElementById('bmi-result').innerHTML=''; return; }
  const bmi = weight/(height*height);
  let cat,color,bg,advice;
  if (bmi<18.5){ cat='Underweight'; color='#1E40AF'; bg='#DBEAFE'; advice='Consider a balanced, higher-calorie diet and consult a doctor if concerned.'; }
  else if (bmi<25){ cat='Normal Weight'; color='#065F46'; bg='#D1FAE5'; advice='This is a healthy range - maintain it with regular activity and balanced eating.'; }
  else if (bmi<30){ cat='Overweight'; color='#92400E'; bg='#FEF3C7'; advice='Consider more physical activity and reviewing your diet. A doctor can advise further.'; }
  else { cat='Obese'; color='#991B1B'; bg='#FEE2E2'; advice='Consulting a healthcare professional for a personalised plan is recommended.'; }
  const pct = Math.min(100,Math.max(0,(bmi-10)/30*100));
  document.getElementById('bmi-result').innerHTML = `
    <div style="background:${bg};border:1px solid ${color}33;border-radius:var(--rl);padding:20px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <div style="font-size:12px;color:${color};font-weight:700;text-transform:uppercase;margin-bottom:4px">Your BMI</div>
          <div style="font-size:48px;font-weight:700;color:${color};letter-spacing:-.02em;line-height:1">${bmi.toFixed(1)}</div>
          <div style="margin-top:8px"><span style="background:${color};color:#fff;padding:4px 14px;border-radius:6px;font-size:13px;font-weight:700">${cat}</span></div>
        </div>
        <div style="flex:1;min-width:200px">
          <div style="font-size:12px;font-weight:700;color:${color};margin-bottom:6px">BMI Scale</div>
          <div class="pr-bar"><div class="pr-fill" style="width:${pct}%;background:${color}"></div></div>
          <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tm);margin-top:4px"><span>10</span><span>18.5</span><span>25</span><span>30</span><span>40</span></div>
        </div>
      </div>
      <div style="margin-top:14px;font-size:13px;color:${color};line-height:1.6">${advice}</div>
      ${bmiUnit==='metric'?`<div style="margin-top:10px;font-size:12px;color:var(--tm)">Weight: ${weight.toFixed(1)}kg · Height: ${(height*100).toFixed(1)}cm</div>`:''}
    </div>`;
}

// ---------- AGE CALCULATOR ----------
function calcAge(){
  const dob = document.getElementById('ac-dob').value; if (!dob) return;
  const targetVal = document.getElementById('ac-target').value;
  const birthDate = new Date(dob); const today = targetVal ? new Date(targetVal) : new Date();
  if (birthDate > today) { document.getElementById('ac-result').innerHTML='<div class="alert alert-err">Birth date cannot be in the future.</div>'; return; }
  let years = today.getFullYear()-birthDate.getFullYear(), months = today.getMonth()-birthDate.getMonth(), days = today.getDate()-birthDate.getDate();
  if (days<0){ months--; const lastMonth=new Date(today.getFullYear(),today.getMonth(),0); days+=lastMonth.getDate(); }
  if (months<0){ years--; months+=12; }
  const totalDays = Math.floor((today-birthDate)/86400000);
  const totalHours = totalDays*24;
  const nextBday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (nextBday<=today) nextBday.setFullYear(today.getFullYear()+1);
  const daysUntilBday = Math.ceil((nextBday-today)/86400000);
  const weekday = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][birthDate.getDay()];
  document.getElementById('ac-result').innerHTML = `
    <div style="background:var(--bg2);border:1px solid var(--bdr);border-radius:var(--rl);padding:20px">
      <div style="text-align:center;margin-bottom:18px">
        <div style="font-size:48px;font-weight:700;color:var(--p);letter-spacing:-.02em;line-height:1">${years}</div>
        <div style="font-size:16px;color:var(--t2);font-weight:600">Years Old</div>
        <div style="font-size:14px;color:var(--tm);margin-top:4px">${years} years, ${months} months and ${days} days</div>
      </div>
      <div class="sgrid">
        <div class="sc"><span class="sn">${years}</span><span class="sl">Years</span></div>
        <div class="sc"><span class="sn">${months}</span><span class="sl">Months</span></div>
        <div class="sc"><span class="sn">${days}</span><span class="sl">Days</span></div>
        <div class="sc"><span class="sn">${totalDays.toLocaleString()}</span><span class="sl">Total Days</span></div>
        <div class="sc"><span class="sn">${totalHours.toLocaleString()}</span><span class="sl">Total Hours</span></div>
        <div class="sc"><span class="sn">${daysUntilBday}</span><span class="sl">Days to Bday</span></div>
      </div>
      <div style="margin-top:14px;background:#fff;border:1px solid var(--bdr);border-radius:8px;padding:12px;font-size:13px;color:var(--t2)">
        You were born on a <strong>${weekday}</strong>. ${daysUntilBday===365?'Happy Birthday!':`Your next birthday is in <strong>${daysUntilBday} days</strong>.`}
      </div>
    </div>`;
}
