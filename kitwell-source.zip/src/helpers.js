// ============================================================
// Shared helper functions used across tools
// ============================================================
function esc(s){ return String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function round4(n){ if(!isFinite(n)) return String(n); const r=Math.round(n*10000)/10000; return r.toLocaleString(undefined,{maximumFractionDigits:4}); }
function fmtMoney(n){ if(!isFinite(n)) return '-'; return n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
function fmtDuration(seconds){
  if(!isFinite(seconds)) return '-';
  const units=[['year',31536000],['day',86400],['hour',3600],['minute',60],['second',1]];
  if(seconds<1) return '< 1 second';
  for(const [name,secs] of units){ if(seconds>=secs){ const v=Math.round(seconds/secs); return v.toLocaleString()+' '+name+(v===1?'':'s'); } }
  return Math.round(seconds)+' seconds';
}
function statBlock(pairs){
  return '<div class="sgrid">'+pairs.map(([l,v])=>`<div class="sc"><span class="sn" style="font-size:18px">${esc(v)}</span><span class="sl">${esc(l)}</span></div>`).join('')+'</div>';
}
function parseNums(str){ return (str||'').split(/[,\s]+/).map(s=>parseFloat(s)).filter(n=>!isNaN(n)); }
function gcd(a,b){ a=Math.abs(a); b=Math.abs(b); while(b){ [a,b]=[b,a%b]; } return a||1; }

const LOREM_WORDS = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure reprehenderit voluptate velit esse cillum fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim est".split(" ");
function genLorem(num, type){
  const classic = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
  const rWord = () => LOREM_WORDS[Math.floor(Math.random()*LOREM_WORDS.length)];
  const rSent = () => { let w=[]; for(let i=0;i<Math.floor(Math.random()*10+8);i++) w.push(rWord()); return w[0].charAt(0).toUpperCase()+w.join(' ').slice(1)+'.'; };
  const rPara = () => { let s=[]; for(let i=0;i<Math.floor(Math.random()*4+3);i++) s.push(rSent()); return s.join(' '); };
  let result=[];
  if (type==='words'){ let w=[]; for(let i=0;i<num;i++) w.push(rWord()); result=[w.join(' ')]; }
  else if (type==='sentences'){ for(let i=0;i<num;i++) result.push(rSent()); }
  else { for(let i=0;i<num;i++) result.push(rPara()); result[0]=classic+' '+rPara(); }
  return result.join('\n\n');
}

function formatHTML(src){
  src = src.trim().replace(/>\s*</g,'><');
  let formatted='', pad=0;
  const tags = src.split(/(?=<)/);
  tags.forEach(tag=>{
    if(!tag) return;
    if(/^<\/\w/.test(tag)){ pad=Math.max(0,pad-1); formatted += '  '.repeat(pad)+tag+'\n'; }
    else if(/^<\w[^>]*[^\/]>$/.test(tag) && !/^<(br|hr|img|input|meta|link|area|base|col|embed|source|track|wbr)[\s>]/i.test(tag)){
      formatted += '  '.repeat(pad)+tag+'\n'; pad++;
    } else { formatted += '  '.repeat(pad)+tag+'\n'; }
  });
  return formatted.trim();
}

function parseCSV(str){
  const rows=[]; let row=[],field='',inQ=false;
  const s=str.replace(/\r\n/g,'\n');
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(inQ){
      if(c==='"'){ if(s[i+1]==='"'){ field+='"'; i++; } else inQ=false; }
      else field+=c;
    } else {
      if(c==='"') inQ=true;
      else if(c===','){ row.push(field); field=''; }
      else if(c==='\n'){ row.push(field); rows.push(row); row=[]; field=''; }
      else field+=c;
    }
  }
  if(field!=='' || row.length){ row.push(field); rows.push(row); }
  return rows.filter(r=>r.length>1 || r[0]!=='');
}

function explainCron(expr){
  const parts=expr.trim().split(/\s+/);
  if(parts.length!==5) throw new Error('Expected 5 fields: minute hour day-of-month month day-of-week');
  const [min,hour,dom,mon,dow]=parts;
  const names={dow:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],mon:['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']};
  const describe=(field,label,nameArr)=>{
    if(field==='*') return 'every '+label;
    if(field.includes('/')){ const [r,step]=field.split('/'); return `every ${step} ${label}(s)`+(r!=='*'?` starting at ${r}`:''); }
    if(field.includes('-')){ const [a,b]=field.split('-'); return `${label} ${nameArr?nameArr[a]:a} through ${nameArr?nameArr[b]:b}`; }
    if(field.includes(',')) return `${label}s ${field.split(',').map(x=>nameArr?nameArr[x]:x).join(', ')}`;
    return `${label} ${nameArr?nameArr[field]:field}`;
  };
  return `Runs at minute: ${describe(min,'minute')}; hour: ${describe(hour,'hour')}; day of month: ${describe(dom,'day')}; month: ${describe(mon,'month',names.mon)}; day of week: ${describe(dow,'weekday',names.dow)}.`;
}

function numberToWords(num){
  if(num===0) return 'zero';
  const neg = num<0; num=Math.abs(num);
  const ones=['','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen'];
  const tens=['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
  const scales=['','thousand','million','billion','trillion'];
  function chunk(n){
    let s='';
    if(n>=100){ s+=ones[Math.floor(n/100)]+' hundred '; n%=100; }
    if(n>=20){ s+=tens[Math.floor(n/10)]+' '; n%=10; }
    if(n>0) s+=ones[n]+' ';
    return s.trim();
  }
  let intPart=Math.floor(num);
  if(intPart===0) return 'zero';
  let parts=[];
  let scaleIdx=0;
  while(intPart>0){
    const c=intPart%1000;
    if(c>0) parts.unshift(chunk(c)+(scales[scaleIdx]?' '+scales[scaleIdx]:''));
    intPart=Math.floor(intPart/1000);
    scaleIdx++;
  }
  return (neg?'negative ':'')+parts.join(' ').trim();
}

function luhnCheck(digits){
  let sum=0, alt=false;
  for(let i=digits.length-1;i>=0;i--){
    let d=parseInt(digits[i],10);
    if(alt){ d*=2; if(d>9) d-=9; }
    sum+=d; alt=!alt;
  }
  return sum%10===0;
}
function detectCardBrand(digits){
  if(/^4/.test(digits)) return 'Visa';
  if(/^5[1-5]/.test(digits) || /^2(2[2-9]|[3-6]|7[01]|720)/.test(digits)) return 'Mastercard';
  if(/^3[47]/.test(digits)) return 'American Express';
  if(/^6(011|5)/.test(digits)) return 'Discover';
  if(/^3(0[0-5]|[68])/.test(digits)) return 'Diners Club';
  if(/^35/.test(digits)) return 'JCB';
  if(/^(60|65|81|82|508)/.test(digits)) return 'RuPay (possible)';
  return null;
}

function getISOWeek(d){
  d=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  const dayNum=(d.getUTCDay()+6)%7;
  d.setUTCDate(d.getUTCDate()-dayNum+3);
  const firstThursday=new Date(Date.UTC(d.getUTCFullYear(),0,4));
  return 1+Math.round(((d-firstThursday)/86400000-3+((firstThursday.getUTCDay()+6)%7))/7);
}
function getDayOfYear(d){
  const start=new Date(d.getFullYear(),0,0);
  return Math.floor((d-start)/86400000);
}

const NATO = {A:'Alfa',B:'Bravo',C:'Charlie',D:'Delta',E:'Echo',F:'Foxtrot',G:'Golf',H:'Hotel',I:'India',J:'Juliett',K:'Kilo',L:'Lima',M:'Mike',N:'November',O:'Oscar',P:'Papa',Q:'Quebec',R:'Romeo',S:'Sierra',T:'Tango',U:'Uniform',V:'Victor',W:'Whiskey',X:'Xray',Y:'Yankee',Z:'Zulu','0':'Zero','1':'One','2':'Two','3':'Three','4':'Four','5':'Five','6':'Six','7':'Seven','8':'Eight','9':'Nine'};

const MORSE = {A:'.-',B:'-...',C:'-.-.',D:'-..',E:'.',F:'..-.',G:'--.',H:'....',I:'..',J:'.---',K:'-.-',L:'.-..',M:'--',N:'-.',O:'---',P:'.--.',Q:'--.-',R:'.-.',S:'...',T:'-',U:'..-',V:'...-',W:'.--',X:'-..-',Y:'-.--',Z:'--..','0':'-----','1':'.----','2':'..---','3':'...--','4':'....-','5':'.....','6':'-....','7':'--...','8':'---..','9':'----.','.':'.-.-.-',',':'--..--','?':'..--..'};
const MORSE_REV = Object.fromEntries(Object.entries(MORSE).map(([k,v])=>[v,k]));
