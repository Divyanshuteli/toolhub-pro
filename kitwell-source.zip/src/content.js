// Per-tool page content: how-to steps, details and FAQ. Pure functions (used at runtime and at build time).
const CAT_USE = {
  'Text Tools':'writers, students, editors and developers who need to clean, count or reshape text quickly',
  'Calculator Tools':'anyone who needs a fast, correct figure for money, health, study or everyday planning',
  'Image Tools':'designers, bloggers and developers who need to resize, convert or inspect images without uploading them anywhere',
  'Developer Tools':'developers who need to format, encode, decode or generate data while building and debugging',
  'Date & Time Tools':'people planning schedules, deadlines and events across dates and time zones',
  'Unit Converters':'students, engineers, cooks, travellers and anyone comparing measurements across systems',
  'Utility Tools':'everyday tasks such as generating codes, picking randomly or checking simple facts',
  'SEO Tools':'site owners, marketers and content teams who prepare pages for search and social sharing',
  'Security Tools':'people who want stronger passwords and safer test data without sending anything to a server',
  'Math Tools':'students, teachers and hobbyists working through arithmetic, number theory and algebra',
  'PDF Tools':'students, office workers and freelancers who need to merge, split, rotate or build PDF files without installing software',
};
const CAT_TIPS = {
  'Text Tools':['Work on a copy of important text so you can compare before and after.','Paste plain text for the cleanest results. Formatting from word processors can add hidden characters.','For long documents, process one section at a time to spot problems earlier.'],
  'Calculator Tools':['Double-check units and whether a rate is annual or monthly before you enter it.','Run the numbers with a cautious and an optimistic value to see the range of outcomes.','Results are estimates based on the inputs you give. Fees, taxes and rounding rules set by a provider can change the final figure.'],
  'Image Tools':['Images are processed on your device with your browser, so large files depend on your device memory.','Keep your original file. Converting or compressing can discard detail that cannot be restored.','Check the result at full size before using it on a website or in print.'],
  'Developer Tools':['Never paste live production secrets into any online tool, even one that runs locally. Use test values where you can.','Validate output in your own environment before shipping it.','Keep sample inputs handy so you can reproduce a result when debugging.'],
  'Date & Time Tools':['Check the time zone and whether daylight saving applies on the dates you care about.','Dates are calculated using the calendar in your browser, which follows the Gregorian system.','For legal or contractual deadlines, confirm the counting rules that apply to you.'],
  'Unit Converters':['Check whether a unit is metric, US customary or imperial. The names can look alike but the sizes differ.','Rounded display values are fine for everyday use. For engineering work keep more digits.','Use the swap button to sanity check a result by converting it back.'],
  'Utility Tools':['Random results come from your browser random number generator and are not suitable for gambling or security decisions.','Everything resets when you close the tab, so copy anything you want to keep.','Bookmark the tools you use often with the Save button.'],
  'SEO Tools':['Write for people first. Search engines reward pages that are clearly useful.','Keep titles under about 60 characters and descriptions under about 160 so they are not cut off in results.','Re-test pages after changes with the search engine tools you use.'],
  'Security Tools':['Use a different password for every account and store them in a reputable password manager.','Generated values are created in your browser and are not sent anywhere. Copy them into your manager straight away.','Strength meters are guidance. Length and randomness matter more than any single rule.'],
  'PDF Tools':['Keep a copy of your original files. These tools create a new PDF and do not change the originals.','Password protected or damaged PDFs cannot be processed. Remove the password first.','Very large PDFs depend on your device memory. If the page slows down, split the job into smaller parts.'],
  'Math Tools':['Work through a small example by hand to confirm you understand what the tool is doing.','Very large numbers may be shown in rounded or scientific form because of how browsers store numbers.','Check the input format, such as commas between values or one value per line.'],
};
const NETWORK_TOOLS = {'ip-lookup':'This tool contacts the public ipify service to find your public IP address. Nothing you type is sent.','currency-converter':'This tool requests current reference rates from the public Frankfurter API. Only the rate request is sent.'};
function ctSteps(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return tp.steps;
  const name = t.name;
  if (t.kind==='convert'){
    return [`Enter the amount you want to convert in the Amount field.`,`Pick the starting unit under From and the target unit under To. The converter covers ${Object.keys(tableOf(t).units).length} units.`,`Read the result instantly. The full conversions table below it shows the same value in every other unit.`,`Use the swap button to reverse the direction without retyping.`];
  }
  if (t.kind==='text'){
    const labels=(t.transforms||[]).map(x=>x.label);
    return [`Paste or type your text into the input box.`,labels.length?`Choose an action: ${labels.slice(0,8).join(', ')}${labels.length>8?' and more':''}.`:`Review the live analysis shown next to your text.`,`Read the output. It updates as soon as you click.`,`Use Copy to place the result on your clipboard, or Clear to start over.`];
  }
  if (t.kind==='calc'){
    const f=(t.fields||[]).map(x=>x.label);
    return [`Fill in the inputs: ${f.slice(0,8).join(', ')}.`,`The result appears immediately and updates as you change any value.`,`Adjust one input at a time to see how it changes the outcome.`,`Copy the figures you need into your notes or spreadsheet.`];
  }
  if (t.kind==='compare') return [`Paste the first text on the left and the second on the right.`,`Differences are highlighted as soon as both sides contain text.`,`Edit either side to re-check the comparison.`];
  if (t.kind==='base') return [`Type a number into the field for the base it is written in.`,`Every other base updates at the same time.`,`Copy any of the converted values.`];
  return [`Open the tool and fill in the input fields or drop in your file.`,`Press the main action button to run ${name}.`,`Review the result and copy or download it.`,`Change any input and run it again as often as you like.`];
}
function tableOf(t){ return (new Function('return '+t.table))(); }
function ctExample(t){
  try{
    if (t.kind==='convert'){
      const tb=tableOf(t), d=t.def||{amt:1,from:Object.keys(tb.units)[0],to:Object.keys(tb.units)[1]};
      const U=tb.units, f=U[d.from], to=U[d.to];
      if (f && to && typeof f.f==='number' && typeof to.f==='number'){
        const v=(d.amt*f.f/to.f); const r=Math.abs(v)>=1000?v.toLocaleString('en-US',{maximumFractionDigits:2}):String(+v.toPrecision(5));
        return `For example, ${d.amt} ${f.l.toLowerCase()} equals ${r} ${to.l.toLowerCase()}${/s$/.test(to.l)?'':''}.`;
      }
    }
  }catch(e){}
  return '';
}
function ctFaq(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return tp.faq;
  const priv = NETWORK_TOOLS[t.id] || 'Everything is calculated in your browser. What you type or upload is not sent to our servers.';
  const q=[
    [`What is ${t.name}?`, `${t.desc}. It is built for ${CAT_USE[t.cat]||'everyday use'}.`],
    [`Is ${t.name} free to use?`, `Yes. There is no login, no account and no usage limit.`],
    [`Is my data private?`, priv],
    [`Do I need to install anything?`, `No. ${t.name} runs in your browser tab. There is nothing to download, and it keeps working after the page has loaded, apart from the tools that clearly say they need a network request.`],
    [`Does ${t.name} work on my phone?`, `Yes. The layout adapts to phones and tablets, and the tool works in any modern browser.`],
  ];
  if (t.kind==='convert'){ const tb=tableOf(t); q.push([`How accurate are the results?`,`Conversions use standard factors against a base unit of ${tb.base}, and results are rounded for display only. Very large or very small values may be shown in rounded form.`]); }
  if (t.kind==='calc') q.push([`Can I rely on this for important decisions?`,`The arithmetic is exact for the numbers you enter, but real-world outcomes depend on terms, fees and rules the calculator cannot see. Treat the result as an estimate and confirm it with a qualified professional where money, health or legal matters are involved.`]);
  if (t.kind==='text') q.push([`Is there a limit on text length?`,`There is no fixed limit. Very large inputs depend on your device's memory and may feel slower.`]);
  return q;
}
function ctInfo(t){
  const tp = (typeof topOf==='function') && topOf(t); if (tp) return `<h2>${t.name}</h2><p>${tp.intro}</p>`;
  if (t.info) return t.info;
  return `<h2>About ${t.name}</h2><p>${t.desc}. ${t.name} is part of the ${t.cat} on Kitwell. It is built for ${CAT_USE[t.cat]||'everyday use'}. It opens instantly, needs no account and has no usage limits, so you can run it as many times as you need.</p>`;
}
function ctText(t){
  const steps=ctSteps(t), faq=ctFaq(t), ex=ctExample(t);
  const parts=[ctInfo(t).replace(/<[^>]+>/g,' '),ex,steps.join(' '),((topOf(t)&&topOf(t).tips)||CAT_TIPS[t.cat]||[]).join(' '),faq.map(x=>x.join(' ')).join(' ')];
  return parts.join(' ').replace(/\s+/g,' ').trim();
}
function ctHtml(t, esc){
  const steps=ctSteps(t), faq=ctFaq(t), ex=ctExample(t);
  return `${ctInfo(t)}${ex?`<p>${esc(ex)}</p>`:''}<h2>How to use ${esc(t.name)}</h2><ol>${steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol><h2>Tips for better results</h2><ul>${(((typeof topOf==='function'&&topOf(t))||{}).tips||CAT_TIPS[t.cat]||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h2>Frequently asked questions</h2>${faq.map(([q,a])=>`<h3>${esc(q)}</h3><p>${esc(a)}</p>`).join('')}`;
}

// Hand-picked related tools (fallback: same category)
const RELATED = {
  'nps-calculator':['epf-calculator','ppf-calculator','sip-calculator','income-tax-india','inflation-calculator'],
  'epf-calculator':['nps-calculator','ppf-calculator','gratuity-calculator','hra-calculator','income-tax-india'],
  'home-loan-eligibility':['emi-calculator','loan-prepayment-calculator','loan-calculator','income-tax-india'],
  'ssy-calculator':['ppf-calculator','fd-calculator','rd-calculator','sip-calculator','inflation-calculator'],
  'inflation-calculator':['compound-interest','cagr-calculator','sip-calculator','fd-calculator','percentage-calculator'],
  'emi-calculator':['loan-calculator','loan-prepayment-calculator','income-tax-india','sip-calculator','compound-interest','percentage-calculator'],
  'loan-calculator':['emi-calculator','loan-prepayment-calculator','compound-interest','simple-interest'],
  'loan-prepayment-calculator':['emi-calculator','loan-calculator','sip-calculator','fd-calculator'],
  'sip-calculator':['stepup-sip-calculator','swp-calculator','fd-calculator','ppf-calculator','cagr-calculator','compound-interest'],
  'stepup-sip-calculator':['sip-calculator','swp-calculator','cagr-calculator','rd-calculator'],
  'swp-calculator':['sip-calculator','fd-calculator','compound-interest','cagr-calculator'],
  'fd-calculator':['rd-calculator','ppf-calculator','compound-interest','simple-interest','sip-calculator'],
  'rd-calculator':['fd-calculator','ppf-calculator','sip-calculator','savings-goal'],
  'ppf-calculator':['fd-calculator','rd-calculator','sip-calculator','income-tax-india'],
  'cagr-calculator':['sip-calculator','compound-interest','percentage-calculator','percent-error'],
  'income-tax-india':['hra-calculator','gst-calculator','hourly-to-annual-salary','ppf-calculator','gratuity-calculator'],
  'hra-calculator':['income-tax-india','hourly-to-annual-salary','gratuity-calculator'],
  'gratuity-calculator':['hourly-to-annual-salary','income-tax-india','hra-calculator'],
  'hourly-to-annual-salary':['income-tax-india','hra-calculator','gratuity-calculator','percentage-calculator'],
  'gst-calculator':['vat-calculator','discount-calculator','percentage-calculator','markup-calculator'],
  'percentage-calculator':['percent-error','discount-calculator','gst-calculator','ratio-simplifier','mean-median-mode-calculator'],
  'bmi-calculator':['bmr-calculator','water-intake','age-calculator','weight-converter'],
  'age-calculator':['age-in-days','date-difference','days-until','bmi-calculator'],
  'word-counter':['character-counter','line-counter','reading-time','case-converter','text-compare'],
  'character-counter':['word-counter','string-length','line-counter','case-converter'],
  'case-converter':['word-counter','text-sorter','remove-spaces','slug-generator'],
  'password-generator':['password-strength','password-passphrase','token-generator','uuid-generator','hash-generator'],
  'json-formatter':['json-validator','csv-json','xml-formatter','base64-encoder','regex-tester'],
  'qr-generator':['url-encoder','base64-encoder','image-color-picker','image-compressor'],
  'image-compressor':['image-resizer','webp-converter','jpg-to-png','png-to-jpg','images-to-pdf'],
  'image-resizer':['image-compressor','image-crop','webp-converter','image-rotator'],
  'webp-converter':['image-compressor','jpg-to-png','png-to-jpg','image-resizer'],
  'images-to-pdf':['pdf-merge','pdf-to-jpg','image-compressor','pdf-split'],
  'pdf-merge':['pdf-split','pdf-delete-pages','pdf-rotate','images-to-pdf','pdf-page-numbers'],
  'pdf-split':['pdf-merge','pdf-delete-pages','pdf-rotate','pdf-to-jpg'],
  'pdf-delete-pages':['pdf-split','pdf-merge','pdf-rotate','pdf-page-numbers'],
  'pdf-to-jpg':['images-to-pdf','pdf-split','image-compressor','webp-converter'],
  'pdf-rotate':['pdf-merge','pdf-split','pdf-delete-pages'],
  'pdf-page-numbers':['pdf-merge','pdf-split','pdf-delete-pages'],
  'currency-converter':['percentage-calculator','gst-calculator','speed-converter','compound-interest'],
  'weight-converter':['length-converter','temperature-converter','bmi-calculator','speed-converter'],
  'temperature-converter':['weight-converter','length-converter','cooking-converter'],
  'length-converter':['weight-converter','area-converter','volume-converter','speed-converter'],
  'lorem-ipsum':['random-word-generator','word-counter','text-repeater','case-converter'],
  'base64-encoder':['url-encoder','json-formatter','hash-generator','image-to-base64'],
  'uuid-generator':['token-generator','password-generator','hash-generator','random-number'],
  'text-compare':['find-replace','word-counter','remove-duplicates','text-sorter'],
};
