// Guide bodies (build time). All example figures are computed here, never typed by hand.
const f0 = n => Math.round(n).toLocaleString('en-IN');
const f2 = n => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const emiOf = (P, r, n) => { const i = r / 1200; return P * i * Math.pow(1 + i, n) / (Math.pow(1 + i, n) - 1); };
const sipFV = (m, r, y) => { const i = r / 1200, n = y * 12; return m * ((Math.pow(1 + i, n) - 1) / i) * (1 + i); };
const rdFV = (d, r, n) => { const q = r / 400; let s = 0; for (let k = 0; k < n; k++) s += d * Math.pow(1 + q, (n - k) / 3); return s; };
const slabTax = (t, sl) => { let tax = 0, prev = 0; for (const [lim, rt] of sl) { if (t > prev) tax += (Math.min(t, lim) - prev) * rt; prev = lim; } return tax; };
const NEW_SLABS = [[400000, 0], [800000, .05], [1200000, .10], [1600000, .15], [2000000, .20], [2400000, .25], [Infinity, .30]];
const OLD_SLABS = [[250000, 0], [500000, .05], [1000000, .20], [Infinity, .30]];
const taxNew = inc => { const t = Math.max(0, inc - 75000); let x = slabTax(t, NEW_SLABS); if (t <= 1200000) x = 0; else x = Math.min(x, t - 1200000); return x * 1.04; };
const taxOld = (inc, ded) => { const t = Math.max(0, inc - 50000 - ded); let x = slabTax(t, OLD_SLABS); if (t <= 500000) x = 0; return x * 1.04; };
const table = (head, rows) => `<div class="g-tbl" tabindex="0" role="region" aria-label="Data table"><table><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;

const GUIDE_BODY = {};

GUIDE_BODY['how-emi-is-calculated'] = () => {
  const P = 500000, r = 9, n = 60, e = emiOf(P, r, n), tot = e * n, i = r / 1200;
  let bal = P; const rows = [];
  for (let m = 1; m <= 3; m++) { const it = bal * i, pr = e - it; bal -= pr; rows.push([m, f2(it), f2(pr), f2(bal)]); }
  const e2 = emiOf(P, r, 36), e3 = emiOf(P, r, 84);
  return `<p>An EMI (equated monthly instalment) is the fixed amount you pay every month until a loan is cleared. Each payment is part interest and part principal. The split changes every month, but the total stays the same.</p>
<h2>The formula</h2>
<p><strong>EMI = P x i x (1 + i)^n / ((1 + i)^n - 1)</strong></p>
<p>P is the loan amount, i is the monthly interest rate (the yearly rate divided by 12 and by 100), and n is the number of monthly instalments.</p>
<h2>Worked example</h2>
<p>Take a loan of ${f0(P)} at ${r}% a year for ${n} months. The monthly rate is ${r}/12/100 = ${i}. Putting the numbers into the formula gives an EMI of <strong>${f2(e)}</strong>. Over ${n} months you pay ${f2(tot)} in total, so the interest is <strong>${f2(tot - P)}</strong>.</p>
<h2>How each payment is split</h2>
<p>Interest is charged on the balance you still owe. In month one the balance is the full ${f0(P)}, so the interest is ${f0(P)} x ${i} = ${f2(P * i)}. The rest of the EMI reduces the principal. Because the balance drops, next month's interest is lower and more of the EMI goes to principal.</p>
${table(['Month', 'Interest', 'Principal', 'Balance left'], rows)}
<h2>What changes the total you pay</h2>
<p>Tenure matters more than most people expect. The same loan at the same rate costs very different amounts depending on how long you take:</p>
${table(['Tenure', 'EMI', 'Total interest'], [[36, f2(e2), f2(e2 * 36 - P)], [60, f2(e), f2(tot - P)], [84, f2(e3), f2(e3 * 84 - P)]])}
<p>A longer tenure lowers the EMI but raises the interest. A shorter one does the opposite. If your budget allows it, the shorter tenure is cheaper overall.</p>
<h2>Reducing the interest</h2>
<ul><li>Pay part of the principal early. Since interest follows the balance, an early part-payment saves more than a late one. The prepayment calculator shows the saving.</li><li>Compare lenders on the full cost, including processing fees, not only on the rate.</li><li>Check whether your loan has a floating rate. If the rate changes, the EMI or the tenure changes with it.</li></ul>
<p>The figures above are for a fixed rate and equal monthly payments. Your lender's statement is the final word, since some lenders compute interest on a daily balance.</p>`;
};

GUIDE_BODY['sip-vs-fd'] = () => {
  const m = 5000, y = 10, n = y * 12, inv = m * n;
  const sip = sipFV(m, 12, y), rd = rdFV(m, 6.5, n), sipLow = sipFV(m, 6, y);
  return `<p>People compare a SIP and a fixed deposit as if they were two versions of the same product. They are not. A fixed deposit or recurring deposit gives a known return. A SIP in an equity fund gives an estimate that depends on markets.</p>
<h2>The same monthly amount</h2>
<p>Suppose you put ${f0(m)} a month for ${y} years, so you invest ${f0(inv)} in total. We assume 12% a year for the SIP and 6.5% a year for a recurring deposit (RD) with quarterly compounding. Both rates are assumptions for this example. Check the current rates before you decide.</p>
${table(['', 'Invested', 'Value after ' + y + ' years', 'Gain'], [['SIP at 12% (assumed)', f0(inv), f0(sip), f0(sip - inv)], ['RD at 6.5%', f0(inv), f0(rd), f0(rd - inv)]])}
<p>On paper the SIP is ahead by about ${f0(sip - rd)}. That gap is the reward for taking risk, not a guaranteed edge.</p>
<h2>What the SIP number leaves out</h2>
<ul><li><strong>12% is not promised.</strong> An equity fund can return less than that, and in some years it loses money. At an assumed 6% the same SIP would grow to ${f0(sipLow)}, which is close to the RD.</li><li><strong>Returns are uneven.</strong> A 12% average can hide a bad year just before you need the money.</li><li><strong>Tax is different.</strong> RD interest is added to your income and taxed at your slab rate. Equity gains follow capital gains rules, which the government revises from time to time.</li></ul>
<h2>How to choose</h2>
<p>Match the product to when you need the money. For a goal within about three years, a deposit's certainty is usually worth more than the extra return. For a goal ten years or more away, you have time to ride out falls, so an equity SIP can make sense for part of the money. Many people hold both.</p>
<p>Use the calculators below with your own amounts and rates. Change the SIP return to a low figure and see whether you would still be comfortable with the result.</p>`;
};

GUIDE_BODY['old-vs-new-tax-regime'] = () => {
  const inc = 1500000, ded = 150000;
  const tn = taxNew(inc), to = taxOld(inc, ded);
  let be = null; for (let d = 0; d <= 1500000; d += 1000) { if (taxOld(inc, d) <= taxNew(inc)) { be = d; break; } }
  const rows = [[7, 0], [12, 0], [15, 0], [25, 0]].map(([l]) => { const I = l * 100000; return [l + ' lakh', f0(taxNew(I)), f0(taxOld(I, 150000))]; });
  return `<p>Every salaried taxpayer in India has to pick between two tax regimes each year. The new regime has lower rates and fewer deductions. The old regime has higher rates but lets you subtract things like HRA, 80C and home loan interest. This guide uses the figures our calculator uses for FY 2026-27 (AY 2027-28), for an individual under 60.</p>
<h2>The slabs</h2>
<p><strong>New regime:</strong> no tax up to 4 lakh, then 5% (4 to 8 lakh), 10% (8 to 12 lakh), 15% (12 to 16 lakh), 20% (16 to 20 lakh), 25% (20 to 24 lakh) and 30% above 24 lakh. The standard deduction is 75,000 and there is no tax if taxable income is up to 12 lakh (Section 87A rebate, with marginal relief just above that).</p>
<p><strong>Old regime:</strong> no tax up to 2.5 lakh, then 5% (2.5 to 5 lakh), 20% (5 to 10 lakh) and 30% above 10 lakh. The standard deduction is 50,000 and the rebate applies up to 5 lakh of taxable income.</p>
<p>Both add 4% health and education cess. Surcharge on very high incomes is not included here.</p>
<h2>Example: gross income of 15 lakh</h2>
<p>With a standard deduction in both regimes and 1.5 lakh of other deductions claimed in the old regime, the tax comes to <strong>${f0(tn)}</strong> under the new regime and <strong>${f0(to)}</strong> under the old one. The new regime is cheaper by ${f0(to - tn)}.</p>
<h2>Where the break-even sits</h2>
<p>At 15 lakh, the old regime only starts to win once your deductions reach roughly <strong>${f0(be)}</strong> (on top of the standard deduction). Deductions that count here include HRA exemption, Section 80C, 80D health insurance and home loan interest on a self-occupied property. If you cannot reach that figure, the new regime is the simpler and cheaper choice.</p>
<h2>Tax at a few incomes</h2>
<p>New regime, and old regime with 1.5 lakh of deductions (cess included):</p>
${table(['Gross income', 'New regime', 'Old regime'], rows)}
<h2>Practical points</h2>
<ul><li>Salaried people can switch regime every year. People with business income have stricter rules on switching back.</li><li>Tell your employer which regime you want so that TDS is deducted correctly. You can still choose again when you file the return.</li><li>Work out your real deductions, including HRA, before you compare. Guessing in either direction changes the answer.</li></ul>
<p>Tax rules change in every Budget. Treat this as an estimate and confirm with the Income Tax Department or a chartered accountant before you file.</p>`;
};

GUIDE_BODY['sip-vs-lumpsum'] = () => {
  const m = 12000, y = 10, r = 12, inv = m * y * 12;
  const sip = sipFV(m, r, y), lump = inv * Math.pow(1 + r / 100, y);
  return `<p>If you have a large sum, should you invest it all now or spread it over time? Maths and behaviour give different answers, so it helps to see both.</p>
<h2>The maths, with one fixed return</h2>
<p>Take ${f0(inv)}. In one case you invest it all today. In the other you invest ${f0(m)} a month for ${y} years, which adds up to the same ${f0(inv)}. We assume the same ${r}% a year in both cases. That return is an assumption, not a promise.</p>
${table(['', 'Value after ' + y + ' years'], [['Lumpsum today', f0(lump)], ['Monthly SIP', f0(sip)]])}
<p>The lumpsum is larger because all the money starts compounding on day one, while the SIP money arrives slowly. If returns were the same every year, the lumpsum would always win.</p>
<h2>Why the answer is not that simple</h2>
<ul><li><strong>Returns are not constant.</strong> If markets fall soon after you invest a lumpsum, the whole amount takes the hit. A SIP buys more units when prices are low.</li><li><strong>You may not have the lumpsum.</strong> Most people invest from their salary, so a SIP is the practical choice.</li><li><strong>Regret is real.</strong> An investor who put everything in just before a fall often stops investing. A steady SIP is easier to stick with.</li></ul>
<h2>A common middle path</h2>
<p>If you do receive a large amount, such as a bonus, you can park it in a safe product and move it into equity in monthly parts over six to twelve months. This reduces the risk of bad timing, at the cost of some return if markets rise meanwhile.</p>
<p>Use the SIP and FD calculators below to test your own amounts, and the CAGR calculator to check what return you actually earned on past investments.</p>`;
};

GUIDE_BODY['how-gst-is-calculated'] = () => {
  const base = 10000, rate = 18, g = base * rate / 100, tot = base + g;
  const wrong = tot * rate / 100;
  return `<p>GST is a percentage added to the price of goods and services. You only need two formulas: one to add GST to a price, and one to take it out of a total that already includes it.</p>
<h2>Adding GST</h2>
<p><strong>GST amount = price x rate / 100</strong>, and <strong>total = price + GST amount</strong>.</p>
<p>Example: a price of ${f0(base)} with ${rate}% GST. The GST is ${f0(base)} x ${rate} / 100 = ${f2(g)}, so the total is <strong>${f2(tot)}</strong>.</p>
<h2>Removing GST from a total</h2>
<p><strong>Price before GST = total / (1 + rate / 100)</strong>, and <strong>GST amount = total - price before GST</strong>.</p>
<p>Example: you paid ${f2(tot)} including ${rate}% GST. The price before GST is ${f2(tot)} / ${1 + rate / 100} = <strong>${f2(base)}</strong> and the GST is ${f2(tot - base)}.</p>
<h2>The common mistake</h2>
<p>Many people take ${rate}% of the total to find the GST. That gives ${f2(wrong)}, which is wrong, because the total already contains the GST. The rate applies to the pre-tax price, so you must divide, not multiply.</p>
<h2>CGST, SGST and IGST</h2>
<p>For a sale within one state, the GST is split equally between the Centre (CGST) and the state (SGST). For a sale between states, a single IGST is charged at the full rate. For ${rate}% GST the split within a state is ${rate / 2}% CGST and ${rate / 2}% SGST.</p>
<h2>Which rate applies?</h2>
<p>The rate depends on the item or service, and the GST Council changes rates from time to time. Look up the rate for your item on the official GST portal or ask your accountant. The calculator below works with any rate you enter.</p>`;
};

GUIDE_BODY['bmi-categories-explained'] = () => {
  const kg = 70, cm = 175, b = kg / Math.pow(cm / 100, 2);
  return `<p>Body Mass Index is a quick number that compares your weight to your height. It is useful for spotting broad trends in a population. For one person it is only a starting point.</p>
<h2>How it is calculated</h2>
<p><strong>BMI = weight in kg / (height in metres)^2</strong></p>
<p>Example: ${kg} kg at ${cm} cm. Height in metres is ${cm / 100}, and its square is ${(cm / 100 * cm / 100).toFixed(4)}. So BMI = ${kg} / ${(cm / 100 * cm / 100).toFixed(4)} = <strong>${b.toFixed(1)}</strong>.</p>
<h2>The WHO categories</h2>
${table(['BMI', 'Category'], [['Below 18.5', 'Underweight'], ['18.5 to 24.9', 'Normal weight'], ['25.0 to 29.9', 'Overweight'], ['30.0 and above', 'Obesity']])}
<p>These are the standard adult categories used by the World Health Organization.</p>
<h2>South Asian cut-offs</h2>
<p>Research shows that people of South Asian origin tend to carry more body fat, and to face higher risk of diabetes and heart disease, at a lower BMI. Because of this, some guidelines, including some Indian ones, use lower cut-offs, with overweight starting around 23 and obesity around 25. Ask your doctor which scale applies to you.</p>
<h2>What BMI cannot tell you</h2>
<ul><li><strong>Muscle versus fat.</strong> A muscular person can have a high BMI with little body fat.</li><li><strong>Where the fat is.</strong> Fat around the waist carries more risk than fat elsewhere, and BMI does not show it. Waist measurement helps here.</li><li><strong>Age and sex.</strong> Older adults and women usually have more body fat at the same BMI.</li><li><strong>Children.</strong> Children and teenagers are judged on age-specific charts, not on adult categories.</li></ul>
<p>This is general information, not medical advice. If your result worries you, or if it sits in an unusual range, talk to a doctor.</p>`;
};

GUIDE_BODY['how-compound-interest-works'] = () => {
  const P = 100000, r = 8, y = 10, comp = P * Math.pow(1 + r / 100, y), simple = P * (1 + r / 100 * y);
  const rows = [1, 5, 10, 20, 30].map(t => [t, f0(P * (1 + r / 100 * t)), f0(P * Math.pow(1 + r / 100, t))]);
  const dbl = Math.log(2) / Math.log(1 + r / 100);
  return `<p>Compound interest is interest earned on your earlier interest as well as on your original amount. It is why money left alone for a long time grows faster than a straight line.</p>
<h2>The formula</h2>
<p><strong>A = P x (1 + r/n)^(n x t)</strong></p>
<p>P is the starting amount, r the yearly rate as a decimal, n the number of times interest is added each year and t the number of years. With yearly compounding, n is 1 and the formula becomes A = P x (1 + r)^t.</p>
<h2>Example</h2>
<p>${f0(P)} at ${r}% a year for ${y} years, compounded yearly, grows to <strong>${f0(comp)}</strong>. With simple interest, which is only ever charged on the original ${f0(P)}, the same deposit gives ${f0(simple)}. The extra ${f0(comp - simple)} is the effect of compounding.</p>
<h2>The gap widens with time</h2>
${table(['Years', 'Simple interest', 'Compound interest'], rows)}
<p>After one year the two are identical. After thirty years compounding is far ahead. Time matters more than the rate in the long run, which is why starting early is the standard advice.</p>
<h2>The rule of 72</h2>
<p>To estimate how long money takes to double, divide 72 by the yearly rate. At ${r}%, 72 / ${r} = ${72 / r} years. The exact figure is ${dbl.toFixed(2)} years, so the shortcut is close.</p>
<h2>Compounding works against you too</h2>
<p>The same effect makes credit card dues and some loans grow quickly when unpaid. A balance that compounds monthly at a high rate can double in a few years. Inflation also compounds, which quietly reduces what your money can buy.</p>`;
};

GUIDE_BODY['ppf-vs-fd'] = () => {
  const A = 150000, y = 15, ppf = A * ((Math.pow(1.071, y) - 1) / 0.071) * 1.071;
  const post = 0.07 * (1 - 0.312), fd = A * ((Math.pow(1 + post, y) - 1) / post) * (1 + post);
  return `<p>PPF (Public Provident Fund) and bank fixed deposits both pay a fixed-looking rate, but they behave differently once tax and lock-in are counted.</p>
<h2>The basic differences</h2>
${table(['', 'PPF', 'Bank FD'], [['Tenure', '15 years, extendable in blocks of 5', 'You choose, from days to years'], ['Rate', 'Set by the government, reviewed every quarter', 'Set by the bank, fixed when you book'], ['Interest tax', 'Exempt', 'Taxed at your slab rate'], ['Yearly limit', '1,50,000', 'No limit'], ['Access to money', 'Partial withdrawals after a few years, with rules', 'Premature closure with a penalty']])}
<p>PPF deposits can also earn a Section 80C deduction, but only if you are in the old tax regime.</p>
<h2>An example over ${y} years</h2>
<p>Deposit ${f0(A)} a year for ${y} years. We assume 7.1% for PPF and 7% for the FD. Both are assumptions, so use the current rates. PPF interest is tax-free, so the maturity is about <strong>${f0(ppf)}</strong>.</p>
<p>For the FD we assume you pay tax at the 30% slab plus 4% cess, which is 31.2%, so the interest left after tax is about ${(post * 100).toFixed(2)}% a year. On the same yearly deposits that grows to about <strong>${f0(fd)}</strong>. That is a rough model, since a real FD is taxed each year on the interest it earns, but it shows the size of the gap for someone in the top slab.</p>
<h2>When an FD makes more sense</h2>
<ul><li>You need the money within a few years, so the 15-year lock-in does not fit.</li><li>You want to invest more than 1,50,000 a year in a safe product.</li><li>You are in a low tax slab, where the tax drag on FD interest is small.</li><li>You want a rate that is fixed for the whole period. PPF's rate can change.</li></ul>
<p>Use the calculators below with the rates that apply today and your own tax slab.</p>`;
};

GUIDE_BODY['strong-password-guide'] = () => {
  const bits = (pool, len) => (Math.log2(pool) * len);
  return `<p>A strong password is one that an attacker cannot guess or search through in a realistic time. Length does most of the work.</p>
<h2>Entropy: the measure that matters</h2>
<p>Entropy, in bits, counts how many guesses an attacker would need in the worst case. Each extra bit doubles the work. For a password made of random characters, <strong>entropy = length x log2(pool size)</strong>. The pool is how many different characters each position can be.</p>
${table(['Password type', 'Pool size', 'Length', 'Entropy'], [['Lowercase letters only', 26, 8, bits(26, 8).toFixed(0) + ' bits'], ['Letters and digits', 62, 12, bits(62, 12).toFixed(0) + ' bits'], ['All keyboard symbols', 94, 16, bits(94, 16).toFixed(0) + ' bits'], ['5 random words from a 7,776-word list', 7776, 5, bits(7776, 5).toFixed(0) + ' bits'], ['6 random words from a 7,776-word list', 7776, 6, bits(7776, 6).toFixed(0) + ' bits']])}
<p>The words in the last two rows must be chosen at random by a tool. Words you pick yourself, or famous phrases, are much weaker than these numbers.</p>
<h2>Length beats cleverness</h2>
<p>Swapping letters for look-alike symbols, like a for @, adds almost nothing, because attackers try those swaps first. Adding length adds a lot. Going from 8 to 16 random characters raises the effort by a factor of billions.</p>
<h2>Reuse is the real danger</h2>
<p>Most accounts are not broken by guessing. They are broken because a password leaked from one site is tried on others. A strong password used in two places is only as safe as the weaker of the two sites.</p>
<h2>What to do</h2>
<ul><li>Use a different, random password for every account. A password manager makes this practical.</li><li>For the few passwords you must remember, such as the manager's master password, use a random passphrase of five or six words.</li><li>Turn on two-factor authentication for email, banking and anything that holds money.</li><li>Do not share one-time codes with anyone, even someone who claims to be from your bank.</li></ul>
<p>Our generator creates passwords in your browser using the browser's secure random source, and nothing is sent anywhere.</p>`;
};

GUIDE_BODY['merge-pdf-without-uploading'] = () => `<p>Most online PDF tools upload your file to a server, process it there and send it back. That is a problem if the PDF holds contracts, ID documents or bank statements. Browser-based tools work differently.</p>
<h2>How in-browser merging works</h2>
<p>When you choose files, the browser reads them into memory on your own device. A JavaScript library copies the pages from each file into a new document, and the browser then lets you download the result. The files are never sent to a server, which you can confirm by opening your browser's network panel while you merge.</p>
<h2>Steps with our PDF merge tool</h2>
<ol><li>Open the PDF merge tool and add your files, or drag them onto the page.</li><li>Put them in the order you want. You can move files up or down, and remove any you added by mistake.</li><li>Press the merge button, then download the combined PDF.</li></ol>
<h2>Related tasks</h2>
<ul><li><strong>Split a PDF:</strong> pull out a page range into its own file.</li><li><strong>Delete pages:</strong> enter the page numbers you want removed, such as 2,4-6.</li><li><strong>Rotate pages:</strong> fix scans that came in sideways.</li><li><strong>Add page numbers:</strong> stamp "Page 1 of N" on every page.</li></ul>
<h2>Limits to know about</h2>
<ul><li><strong>Password-protected PDFs</strong> usually cannot be read until you remove the password.</li><li><strong>Very large files</strong> use your device's memory. A phone may struggle with a file of several hundred pages, while a laptop usually copes.</li><li><strong>Form fields and bookmarks</strong> from the original files may not carry across a merge.</li><li><strong>Compression</strong> is not done here. A merged file is about as large as the originals added together.</li></ul>
<p>Always open the merged file and check the page order before you send it to anyone.</p>`;
