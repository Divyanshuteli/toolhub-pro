// ============================================================
// TOOLHUB PRO - Tool catalogue
// Every tool below is a real, working client-side tool. Nothing
// here is a placeholder: each entry either renders through one
// of the shared templates (convert / text / compare / calc / base)
// or supplies its own body()/init() for tools that need a custom UI.
// ============================================================

const CAT_CONFIG = {
  'Text Tools':        {id:'text', ab:'Tx', bg:'#9A3412'},
  'Calculator Tools':  {id:'calc', ab:'Cl', bg:'#0F766E'},
  'Image Tools':       {id:'img',  ab:'Im', bg:'#C2410C'},
  'Developer Tools':   {id:'dev',  ab:'Dv', bg:'#1D4ED8'},
  'Unit Converters':   {id:'unit', ab:'Un', bg:'#0369A1'},
  'Date & Time Tools': {id:'dt',   ab:'Dt', bg:'#A16207'},
  'Utility Tools':     {id:'util', ab:'Ut', bg:'#475569'},
  'SEO Tools':         {id:'seo',  ab:'SE', bg:'#0E7490'},
  'Security Tools':    {id:'sec',  ab:'Sc', bg:'#991B1B'},
  'Math Tools':        {id:'math', ab:'Mt', bg:'#BE123C'},
  'PDF Tools':         {id:'pdf',  ab:'Pd', bg:'#B91C1C'},
};

// ---- unit tables for convert-kind tools (value = multiplier to base unit) ----
const U_LENGTH = {base:'m', units:{
  mm:{l:'Millimeter',f:0.001}, cm:{l:'Centimeter',f:0.01}, m:{l:'Meter',f:1}, km:{l:'Kilometer',f:1000},
  in:{l:'Inch',f:0.0254}, ft:{l:'Foot',f:0.3048}, yd:{l:'Yard',f:0.9144}, mi:{l:'Mile',f:1609.344},
  nmi:{l:'Nautical Mile',f:1852},
}};
const U_WEIGHT = {base:'kg', units:{
  mg:{l:'Milligram',f:0.000001}, g:{l:'Gram',f:0.001}, kg:{l:'Kilogram',f:1}, t:{l:'Metric Ton',f:1000},
  oz:{l:'Ounce',f:0.0283495}, lb:{l:'Pound',f:0.453592}, st:{l:'Stone',f:6.35029},
}};
const U_SPEED = {base:'ms', units:{
  ms:{l:'Meters/sec',f:1}, kmh:{l:'Km/hour',f:0.277778}, mph:{l:'Miles/hour',f:0.44704},
  kn:{l:'Knots',f:0.514444}, fts:{l:'Feet/sec',f:0.3048},
}};
const U_AREA = {base:'m2', units:{
  mm2:{l:'mm²',f:0.000001}, cm2:{l:'cm²',f:0.0001}, m2:{l:'m²',f:1}, ha:{l:'Hectare',f:10000},
  km2:{l:'km²',f:1000000}, in2:{l:'in²',f:0.00064516}, ft2:{l:'ft²',f:0.092903},
  ac:{l:'Acre',f:4046.86}, mi2:{l:'mi²',f:2589988.11},
}};
const U_VOLUME = {base:'l', units:{
  ml:{l:'Milliliter',f:0.001}, l:{l:'Liter',f:1}, m3:{l:'Cubic meter',f:1000},
  tsp:{l:'Teaspoon (US)',f:0.00492892}, tbsp:{l:'Tablespoon (US)',f:0.0147868},
  cup:{l:'Cup (US)',f:0.236588}, pt:{l:'Pint (US)',f:0.473176}, qt:{l:'Quart (US)',f:0.946353},
  gal:{l:'Gallon (US)',f:3.78541}, galuk:{l:'Gallon (UK)',f:4.54609},
}};
const U_TIME = {base:'s', units:{
  ms:{l:'Millisecond',f:0.001}, s:{l:'Second',f:1}, min:{l:'Minute',f:60}, h:{l:'Hour',f:3600},
  d:{l:'Day',f:86400}, wk:{l:'Week',f:604800}, mo:{l:'Month (30d)',f:2592000}, yr:{l:'Year (365d)',f:31536000},
}};
const U_DATA = {base:'b', units:{
  b:{l:'Byte',f:1}, kb:{l:'Kilobyte',f:1024}, mb:{l:'Megabyte',f:1024**2}, gb:{l:'Gigabyte',f:1024**3},
  tb:{l:'Terabyte',f:1024**4}, bit:{l:'Bit',f:0.125}, kbit:{l:'Kilobit',f:128},
}};
const U_ENERGY = {base:'j', units:{
  j:{l:'Joule',f:1}, kj:{l:'Kilojoule',f:1000}, cal:{l:'Calorie',f:4.184}, kcal:{l:'Kilocalorie',f:4184},
  wh:{l:'Watt-hour',f:3600}, kwh:{l:'Kilowatt-hour',f:3600000}, btu:{l:'BTU',f:1055.06},
}};
const U_PRESSURE = {base:'pa', units:{
  pa:{l:'Pascal',f:1}, kpa:{l:'Kilopascal',f:1000}, bar:{l:'Bar',f:100000}, atm:{l:'Atmosphere',f:101325},
  psi:{l:'PSI',f:6894.76}, mmhg:{l:'mmHg',f:133.322},
}};
const U_POWER = {base:'w', units:{
  w:{l:'Watt',f:1}, kw:{l:'Kilowatt',f:1000}, mw:{l:'Megawatt',f:1000000},
  hp:{l:'Horsepower',f:745.7}, btuh:{l:'BTU/hour',f:0.293071},
}};
const U_FORCE = {base:'n', units:{
  n:{l:'Newton',f:1}, kn:{l:'Kilonewton',f:1000}, lbf:{l:'Pound-force',f:4.44822}, kgf:{l:'Kilogram-force',f:9.80665},
  dyn:{l:'Dyne',f:0.00001},
}};
const U_ANGLE = {base:'deg', units:{
  deg:{l:'Degree',f:1}, rad:{l:'Radian',f:57.29577951}, grad:{l:'Gradian',f:0.9}, rev:{l:'Revolution',f:360},
}};
const U_FREQ = {base:'hz', units:{
  hz:{l:'Hertz',f:1}, khz:{l:'Kilohertz',f:1000}, mhz:{l:'Megahertz',f:1000000}, ghz:{l:'Gigahertz',f:1000000000},
  rpm:{l:'RPM',f:1/60},
}};
const U_FUEL = {base:'l100km', units:{ // handled with custom fn below because mpg is inverse
}};

// === TOOLS ===================================================
// kind: 'custom' tools are implemented in src/custom-tools.js (TOOL_CUSTOM map)
const TOOLS = [
// ---------------- TEXT TOOLS ----------------
{id:'word-counter', name:'Word Counter', cat:'Text Tools', ab:'Wc', desc:'Count words, characters, sentences & reading time', badge:'pop', kind:'dedicated'},
{id:'character-counter', name:'Character Counter', cat:'Text Tools', ab:'Cc', desc:'Count characters with and without spaces', kind:'text',
  transforms:[{label:'Count', run:t=>t}], extra:'charcount', info:'<h2>Character Counter</h2><p>Counts total characters, characters excluding spaces, and bytes (UTF-8 size) of your text as you type.</p>'},
{id:'case-converter', name:'Case Converter', cat:'Text Tools', ab:'Cv', desc:'Convert text to uppercase, lowercase, title case', badge:'pop', kind:'text',
  transforms:[
    {label:'UPPERCASE', run:s=>s.toUpperCase()},
    {label:'lowercase', run:s=>s.toLowerCase()},
    {label:'Title Case', run:s=>s.replace(/\w\S*/g, w=>w[0].toUpperCase()+w.slice(1).toLowerCase())},
    {label:'Sentence case', run:s=>s.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, c=>c.toUpperCase())},
    {label:'camelCase', run:s=>s.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g,(_,c)=>c.toUpperCase())},
    {label:'PascalCase', run:s=>{const c=s.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g,(_,c)=>c.toUpperCase());return c.charAt(0).toUpperCase()+c.slice(1);}},
    {label:'snake_case', run:s=>s.toLowerCase().trim().replace(/[\s-]+/g,'_').replace(/[^a-z0-9_]/g,'')},
    {label:'kebab-case', run:s=>s.toLowerCase().trim().replace(/[\s_]+/g,'-').replace(/[^a-z0-9-]/g,'')},
    {label:'aLtErNaTiNg', run:s=>s.split('').map((c,i)=>i%2?c.toLowerCase():c.toUpperCase()).join('')},
    {label:'InVeRsE cAsE', run:s=>s.split('').map(c=>c===c.toUpperCase()?c.toLowerCase():c.toUpperCase()).join('')},
  ], info:'<h2>Case Converter</h2><p>Convert text instantly between ten case formats, covering developer formats (camelCase, snake_case, kebab-case) and writing formats (Title Case, Sentence case).</p>'},
{id:'remove-spaces', name:'Remove Extra Spaces', cat:'Text Tools', ab:'Rs', desc:'Clean whitespace and extra spaces from text', kind:'text',
  transforms:[
    {label:'Remove Extra Spaces', run:s=>s.trim().replace(/[ \t]+/g,' ').replace(/\n\s*\n/g,'\n\n')},
    {label:'Trim Only', run:s=>s.trim()},
    {label:'Remove Blank Lines', run:s=>s.split('\n').filter(l=>l.trim()).join('\n')},
    {label:'Remove ALL Spaces', run:s=>s.replace(/\s/g,'')},
  ], info:'<h2>Remove Extra Spaces</h2><p>Clean up whitespace left over from copy-pasting from PDFs, emails or scraped web pages.</p>'},
{id:'text-sorter', name:'Text Sorter', cat:'Text Tools', ab:'Ts', desc:'Sort lines alphabetically or reverse', kind:'text',
  transforms:[
    {label:'A to Z', run:s=>s.split('\n').sort((a,b)=>a.localeCompare(b)).join('\n')},
    {label:'Z to A', run:s=>s.split('\n').sort((a,b)=>b.localeCompare(a)).join('\n')},
    {label:'By Length', run:s=>s.split('\n').sort((a,b)=>a.length-b.length).join('\n')},
    {label:'Shuffle', run:s=>{const a=s.split('\n');for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('\n');}},
    {label:'Reverse Order', run:s=>s.split('\n').reverse().join('\n')},
  ], info:'<h2>Text Sorter</h2><p>Sort lines of text alphabetically, by length, or shuffle them randomly. One line per item.</p>'},
{id:'remove-duplicates', name:'Duplicate Line Remover', cat:'Text Tools', ab:'Dl', desc:'Remove duplicate lines from text instantly', kind:'text',
  transforms:[
    {label:'Remove Duplicates', run:s=>[...new Set(s.split('\n'))].join('\n')},
    {label:'Remove (Case-Insensitive)', run:s=>{const seen=new Set();return s.split('\n').filter(l=>{const k=l.toLowerCase();if(seen.has(k))return false;seen.add(k);return true;}).join('\n');}},
  ], info:'<h2>Duplicate Line Remover</h2><p>Paste a list and remove duplicate lines. Useful for cleaning CSV exports, email lists or any line-based data.</p>'},
{id:'random-word-generator', name:'Random Word Generator', cat:'Text Tools', ab:'Rw', desc:'Generate random placeholder words', kind:'calc',
  fields:[{id:'n',label:'How many words',type:'number',value:10,min:1,max:200}],
  compute:v=>{const n=Math.min(200,Math.max(1,parseInt(v.n)||10));const out=[];for(let i=0;i<n;i++)out.push(WORDLIST[Math.floor(Math.random()*WORDLIST.length)]);return `<div class="res-box">${out.join(' ')}</div>`;},
  info:'<h2>Random Word Generator</h2><p>Generates random English words - handy for naming things, word games or testing text fields.</p>'},
{id:'slug-generator', name:'Slug Generator', cat:'Text Tools', ab:'Sl', desc:'Convert text to URL-friendly slug', badge:'pop', kind:'text',
  transforms:[
    {label:'Generate Slug', run:s=>s.normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[^\w\s-]/g,'').trim().toLowerCase().replace(/[\s_]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'')},
  ], single:true, info:'<h2>URL Slug Generator</h2><p>A slug is the readable part of a URL. Good slugs are short, lowercase and use hyphens only.</p><h3>Good vs bad slugs</h3><ul><li>Good: /how-to-make-sourdough-bread</li><li>Bad: /post?id=123</li></ul>'},
{id:'text-reverser', name:'Text Reverser', cat:'Text Tools', ab:'Rv', desc:'Reverse any text or string', kind:'text',
  transforms:[
    {label:'Reverse Characters', run:s=>s.split('').reverse().join('')},
    {label:'Reverse Words', run:s=>s.split(/\s+/).reverse().join(' ')},
    {label:'Reverse Lines', run:s=>s.split('\n').reverse().join('\n')},
  ], info:'<h2>Text Reverser</h2><p>Reverse text by character, word or line order.</p>'},
{id:'lorem-ipsum', name:'Lorem Ipsum Generator', cat:'Text Tools', ab:'Li', desc:'Generate Lorem Ipsum placeholder text', badge:'pop', kind:'calc',
  fields:[{id:'n',label:'Amount',type:'number',value:3,min:1,max:50},{id:'type',label:'Type',type:'select',options:[['paras','Paragraphs'],['sentences','Sentences'],['words','Words']]}],
  compute:v=>{const n=Math.min(50,Math.max(1,parseInt(v.n)||3));const out=genLorem(n,v.type);return `<div class="fg"><label class="fl">Generated Text <button class="cpbtn" onclick="copyText(document.getElementById('loremOut').value,this)">Copy</button></label><textarea class="fc" id="loremOut" rows="10" readonly>${esc(out)}</textarea></div>`;},
  info:'<h2>Lorem Ipsum Generator</h2><p>Classic placeholder text for mockups and layouts, generated in paragraphs, sentences or words.</p>'},
{id:'find-replace', name:'Find and Replace', cat:'Text Tools', ab:'Fr', desc:'Find and replace text in bulk', kind:'custom', info:'<h2>Find and Replace</h2><p>Bulk find-and-replace across a block of text, with optional case-sensitive and whole-word matching, and regex support.</p>'},
{id:'line-counter', name:'Line Counter', cat:'Text Tools', ab:'Lc', desc:'Count lines in any text', kind:'text',
  transforms:[{label:'Count', run:t=>t}], extra:'linecount', info:'<h2>Line Counter</h2><p>Counts total lines, non-empty lines and blank lines in your text.</p>'},
{id:'text-compare', name:'Text Compare', cat:'Text Tools', ab:'Tc', desc:'Compare two texts side by side', kind:'compare', info:'<h2>Text Compare</h2><p>Compares two blocks of text line by line and highlights which lines differ.</p>'},
{id:'text-repeater', name:'Text Repeater', cat:'Text Tools', ab:'Tr', desc:'Repeat text multiple times', kind:'calc',
  fields:[{id:'txt',label:'Text to repeat',type:'text',value:'Hello'},{id:'n',label:'Times',type:'number',value:5,min:1,max:1000},{id:'sep',label:'Separator',type:'select',options:[['nl','New line'],['sp','Space'],['cm','Comma']]}],
  compute:v=>{const n=Math.min(1000,Math.max(1,parseInt(v.n)||1));const sep=v.sep==='nl'?'\n':v.sep==='cm'?', ':' ';const out=Array(n).fill(v.txt||'').join(sep);return `<div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('repOut').value,this)">Copy</button></label><textarea class="fc" id="repOut" rows="8" readonly>${esc(out)}</textarea></div>`;},
  info:'<h2>Text Repeater</h2><p>Repeat any word, phrase or symbol a set number of times.</p>'},
{id:'text-to-html', name:'Text to HTML', cat:'Text Tools', ab:'Th', desc:'Convert plain text to HTML format', kind:'text',
  transforms:[{label:'Convert to HTML', run:s=>s.split('\n\n').map(p=>'<p>'+esc(p).replace(/\n/g,'<br>')+'</p>').join('\n')}],
  single:true, mono:true, info:'<h2>Text to HTML</h2><p>Wraps paragraphs in <code>&lt;p&gt;</code> tags and line breaks in <code>&lt;br&gt;</code>, and escapes special characters, so plain text becomes safe HTML.</p>'},
{id:'html-encode', name:'HTML Entity Encoder/Decoder', cat:'Text Tools', ab:'He', desc:'Encode or decode HTML entities', kind:'text',
  transforms:[{label:'Encode', run:s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))},
    {label:'Decode', run:s=>{const t=document.createElement('textarea');t.innerHTML=s;return t.value;}}],
  info:'<h2>HTML Entity Encoder / Decoder</h2><p>Escape special characters for safe HTML embedding, or decode HTML entities back to plain text.</p>'},
{id:'word-frequency', name:'Word Frequency Counter', cat:'Text Tools', ab:'Wf', desc:'Count how often each word appears', kind:'custom', info:'<h2>Word Frequency Counter</h2><p>Shows how many times each word appears in a block of text, sorted by frequency.</p>'},
{id:'remove-line-breaks', name:'Remove Line Breaks', cat:'Text Tools', ab:'Lb', desc:'Join wrapped lines into one paragraph', kind:'text',
  transforms:[{label:'Remove Line Breaks', run:s=>s.replace(/\r?\n+/g,' ').replace(/\s+/g,' ').trim()},
    {label:'Replace with Space', run:s=>s.replace(/\r?\n/g,' ')}],
  info:'<h2>Remove Line Breaks</h2><p>Joins text that was wrapped across multiple lines (common when pasting from PDFs) back into continuous paragraphs.</p>'},
{id:'add-line-numbers', name:'Add Line Numbers', cat:'Text Tools', ab:'Ln', desc:'Prefix every line with its number', kind:'text',
  transforms:[{label:'Add Line Numbers', run:s=>s.split('\n').map((l,i)=>`${i+1}. ${l}`).join('\n')}], single:true, mono:true,
  info:'<h2>Add Line Numbers</h2><p>Numbers every line of a text block - useful for code snippets, scripts or lists.</p>'},
{id:'pig-latin', name:'Pig Latin Converter', cat:'Text Tools', ab:'Pl', desc:'Translate English text to Pig Latin', kind:'text',
  transforms:[{label:'Convert', run:s=>s.replace(/[a-zA-Z]+/g, w=>{
    const vowels='aeiouAEIOU'; if(vowels.includes(w[0])) return w+'way';
    let i=0; while(i<w.length && !vowels.includes(w[i])) i++;
    return w.slice(i)+w.slice(0,i)+'ay';
  })}], single:true, info:'<h2>Pig Latin Converter</h2><p>Translates English text into Pig Latin using the classic consonant-cluster-shift rule.</p>'},
{id:'rot13', name:'ROT13 Encoder/Decoder', cat:'Text Tools', ab:'R1', desc:'Encode or decode ROT13 cipher text', kind:'text',
  transforms:[{label:'ROT13', run:s=>s.replace(/[a-zA-Z]/g,c=>{const base=c<='Z'?65:97;return String.fromCharCode((c.charCodeAt(0)-base+13)%26+base);})}],
  single:true, mono:true, info:'<h2>ROT13 Encoder / Decoder</h2><p>ROT13 shifts every letter 13 places through the alphabet. Applying it twice returns the original text - the same button encodes and decodes.</p>'},
{id:'caesar-cipher', name:'Caesar Cipher', cat:'Text Tools', ab:'Cs', desc:'Shift letters by a chosen amount', kind:'custom', info:'<h2>Caesar Cipher</h2><p>A classic substitution cipher that shifts each letter by a fixed number of places in the alphabet.</p>'},
{id:'morse-code', name:'Morse Code Translator', cat:'Text Tools', ab:'Mc', desc:'Convert text to Morse code and back', kind:'custom', info:'<h2>Morse Code Translator</h2><p>Translate plain text to Morse code, or decode Morse code (dots, dashes, spaces) back to text.</p>'},
{id:'binary-text', name:'Text to Binary Converter', cat:'Text Tools', ab:'Bt', desc:'Convert text to binary and back', kind:'text',
  transforms:[
    {label:'Text to Binary', run:s=>s.split('').map(c=>c.charCodeAt(0).toString(2).padStart(8,'0')).join(' ')},
    {label:'Binary to Text', run:s=>s.trim().split(/\s+/).map(b=>String.fromCharCode(parseInt(b,2))).join('')},
  ], mono:true, info:'<h2>Text to Binary Converter</h2><p>Converts each character to its 8-bit binary (ASCII/UTF-16 code unit) representation, and back.</p>'},
{id:'nato-phonetic', name:'NATO Phonetic Alphabet', cat:'Text Tools', ab:'Np', desc:'Spell out text using the NATO alphabet', kind:'text',
  transforms:[{label:'Convert', run:s=>s.toUpperCase().split('').map(c=>NATO[c]||(c===' '?'/':c)).join(' ')}], single:true,
  info:'<h2>NATO Phonetic Alphabet</h2><p>Spells out each letter using the NATO phonetic alphabet (Alpha, Bravo, Charlie…) used by pilots, radio operators and the military.</p>'},
{id:'leetspeak', name:'Leetspeak Converter', cat:'Text Tools', ab:'1337', desc:'Convert text to 1337 speak', kind:'text',
  transforms:[{label:'Convert', run:s=>s.replace(/[aeiostlbgAEIOSTLBG]/g,c=>({a:'4',e:'3',i:'1',o:'0',s:'5',t:'7',l:'1',b:'8',g:'9',A:'4',E:'3',I:'1',O:'0',S:'5',T:'7',L:'1',B:'8',G:'9'}[c]))}],
  single:true, info:'<h2>Leetspeak Converter</h2><p>Replaces letters with lookalike numbers (A=4, E=3, I=1 …) for the classic "1337" internet style.</p>'},
{id:'palindrome-checker', name:'Palindrome Checker', cat:'Text Tools', ab:'Pc', desc:'Check if text reads the same backwards', kind:'calc',
  fields:[{id:'t',label:'Text',type:'text',value:'',placeholder:'e.g. A man a plan a canal Panama'}],
  compute:v=>{const clean=(v.t||'').toLowerCase().replace(/[^a-z0-9]/g,'');const rev=clean.split('').reverse().join('');const is=clean.length>0 && clean===rev;
    return `<div class="alert ${is?'alert-ok':'alert-err'}">${is?'Yes, this is a palindrome.':'Not a palindrome.'}</div>${clean?`<div class="res-box">Cleaned: ${clean}</div>`:''}`;},
  info:'<h2>Palindrome Checker</h2><p>Checks whether text reads the same forwards and backwards, ignoring spaces, punctuation and capitalisation.</p>'},
{id:'anagram-checker', name:'Anagram Checker', cat:'Text Tools', ab:'Ac', desc:'Check if two words are anagrams', kind:'compare', compareMode:'anagram', info:'<h2>Anagram Checker</h2><p>Checks whether two words or phrases are anagrams of each other (contain exactly the same letters).</p>'},
{id:'acronym-generator', name:'Acronym Generator', cat:'Text Tools', ab:'Ag', desc:'Generate an acronym from a phrase', kind:'calc',
  fields:[{id:'t',label:'Phrase',type:'text',value:'',placeholder:'e.g. As Soon As Possible'}],
  compute:v=>{const words=(v.t||'').trim().split(/\s+/).filter(Boolean);const ac=words.map(w=>w[0]?.toUpperCase()||'').join('');return `<div class="res-box">${ac||'-'}</div>`;},
  info:'<h2>Acronym Generator</h2><p>Builds an acronym from the first letter of each word in a phrase.</p>'},
{id:'string-length', name:'String Length Checker', cat:'Text Tools', ab:'Sl2', desc:'Check string length against social limits', kind:'text',
  transforms:[{label:'Check', run:t=>t}], extra:'strlen', info:'<h2>String Length Checker</h2><p>Shows character count against common limits: Twitter/X (280), SMS (160), meta description (160), title tag (60).</p>'},
{id:'syllable-counter', name:'Syllable Counter', cat:'Text Tools', ab:'Sy', desc:'Estimate syllables in text', kind:'text', transforms:[{label:'Count', run:t=>t}], extra:'syllable',
  info:'<h2>Syllable Counter</h2><p>Estimates the number of syllables per word using a vowel-group heuristic - handy for poetry, haiku, and readability checks.</p>'},

// ---------------- CALCULATOR TOOLS ----------------
{id:'age-calculator', name:'Age Calculator', cat:'Calculator Tools', ab:'Ag', desc:'Calculate exact age from birthdate', badge:'pop', kind:'dedicated'},
{id:'percentage-calculator', name:'Percentage Calculator', cat:'Calculator Tools', ab:'Pc', desc:'Calculate percentages easily', badge:'pop', kind:'custom', info:'<h2>Percentage Calculator</h2><p>Three common percentage calculations in one tool: find X% of Y, find what percentage X is of Y, and find the percentage change between two values.</p>'},
{id:'emi-calculator', name:'EMI Calculator', cat:'Calculator Tools', ab:'Em', desc:'Calculate monthly loan EMI', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:500000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:9,step:0.1},{id:'n',label:'Tenure (months)',type:'number',value:60}],
  compute:v=>{const P=+v.p,annR=+v.r,N=+v.n;if(!P||!N) return '';const r=annR/12/100;const emi=r===0?P/N:P*r*Math.pow(1+r,N)/(Math.pow(1+r,N)-1);const total=emi*N;const interest=total-P;
    return statBlock([['Monthly EMI',fmtMoney(emi)],['Total Interest',fmtMoney(interest)],['Total Payment',fmtMoney(total)]]);},
  info:'<h2>EMI Calculator</h2><p>Calculates your Equated Monthly Installment for a loan given the principal, annual interest rate, and tenure in months.</p><p><strong>Formula:</strong> EMI = P × r × (1+r)ⁿ ÷ ((1+r)ⁿ − 1)</p>'},
{id:'loan-calculator', name:'Loan Calculator', cat:'Calculator Tools', ab:'Ln', desc:'Calculate total loan repayments', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:200000},{id:'r',label:'Annual Rate (%)',type:'number',value:7.5,step:0.1},{id:'y',label:'Term (years)',type:'number',value:15}],
  compute:v=>{const P=+v.p,annR=+v.r,N=(+v.y)*12;if(!P||!N) return '';const r=annR/12/100;const emi=r===0?P/N:P*r*Math.pow(1+r,N)/(Math.pow(1+r,N)-1);const total=emi*N;
    return statBlock([['Monthly Payment',fmtMoney(emi)],['Total Interest',fmtMoney(total-P)],['Total Repaid',fmtMoney(total)]]);},
  info:'<h2>Loan Calculator</h2><p>Estimates monthly payment, total interest and total repayment for a fixed-rate loan.</p>'},
{id:'gst-calculator', name:'GST Calculator', cat:'Calculator Tools', ab:'Gs', desc:'Add or remove GST from any amount', kind:'calc',
  fields:[{id:'amt',label:'Amount',type:'number',value:1000},{id:'rate',label:'GST Rate (%)',type:'select',options:[['5','5%'],['12','12%'],['18','18%'],['28','28%']]},{id:'mode',label:'Mode',type:'select',options:[['add','Add GST'],['remove','Remove GST']]}],
  compute:v=>{const amt=+v.amt,rate=+v.rate;if(!amt)return'';let base,gst,total;
    if(v.mode==='add'){base=amt;gst=amt*rate/100;total=base+gst;} else {total=amt;base=amt/(1+rate/100);gst=total-base;}
    return statBlock([['Base Amount',fmtMoney(base)],['GST ('+rate+'%)',fmtMoney(gst)],['Total Amount',fmtMoney(total)]]);},
  info:'<h2>GST Calculator</h2><p>Add GST to a base price, or work backward to find the base price and GST portion of a GST-inclusive amount.</p>'},
{id:'discount-calculator', name:'Discount Calculator', cat:'Calculator Tools', ab:'Dc', desc:'Calculate discount and final price', kind:'calc',
  fields:[{id:'price',label:'Original Price',type:'number',value:1000},{id:'pct',label:'Discount (%)',type:'number',value:20}],
  compute:v=>{const p=+v.price,d=+v.pct;if(!p)return'';const saved=p*d/100;const final=p-saved;
    return statBlock([['You Save',fmtMoney(saved)],['Final Price',fmtMoney(final)],['Discount',d+'%']]);},
  info:'<h2>Discount Calculator</h2><p>Enter the original price and discount percentage to see the savings and final price.</p>'},
{id:'bmi-calculator', name:'BMI Calculator', cat:'Calculator Tools', ab:'Bm', desc:'Calculate Body Mass Index (BMI)', badge:'pop', kind:'dedicated'},
{id:'scientific-calculator', name:'Scientific Calculator', cat:'Calculator Tools', ab:'Sc', desc:'Full scientific calculator', kind:'custom', info:'<h2>Scientific Calculator</h2><p>A keyboard-friendly calculator supporting standard arithmetic plus trigonometric, logarithmic and power functions.</p>'},
{id:'simple-interest', name:'Simple Interest Calculator', cat:'Calculator Tools', ab:'Si', desc:'Calculate simple interest on loans', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:10000},{id:'r',label:'Annual Rate (%)',type:'number',value:6,step:0.1},{id:'t',label:'Time (years)',type:'number',value:3,step:0.1}],
  compute:v=>{const P=+v.p,R=+v.r,T=+v.t;if(!P)return'';const si=P*R*T/100;return statBlock([['Interest',fmtMoney(si)],['Total Amount',fmtMoney(P+si)]]);},
  info:'<h2>Simple Interest Calculator</h2><p><strong>Formula:</strong> SI = (P × R × T) ÷ 100</p>'},
{id:'compound-interest', name:'Compound Interest Calculator', cat:'Calculator Tools', ab:'Ci', desc:'Calculate compound interest', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:10000},{id:'r',label:'Annual Rate (%)',type:'number',value:6,step:0.1},{id:'t',label:'Time (years)',type:'number',value:5,step:0.1},{id:'n',label:'Compounds/year',type:'select',options:[['1','Annually'],['2','Semi-annually'],['4','Quarterly'],['12','Monthly'],['365','Daily']]}],
  compute:v=>{const P=+v.p,R=+v.r/100,T=+v.t,n=+v.n;if(!P)return'';const A=P*Math.pow(1+R/n,n*T);return statBlock([['Final Amount',fmtMoney(A)],['Interest Earned',fmtMoney(A-P)]]);},
  info:'<h2>Compound Interest Calculator</h2><p><strong>Formula:</strong> A = P(1 + r/n)^(nt)</p>'},
{id:'tip-calculator', name:'Tip Calculator', cat:'Calculator Tools', ab:'Tp', desc:'Calculate restaurant tips easily', kind:'calc',
  fields:[{id:'bill',label:'Bill Amount',type:'number',value:50},{id:'pct',label:'Tip %',type:'number',value:15},{id:'people',label:'Split Between',type:'number',value:1,min:1}],
  compute:v=>{const b=+v.bill,p=+v.pct,people=Math.max(1,+v.people||1);if(!b)return'';const tip=b*p/100;const total=b+tip;
    return statBlock([['Tip',fmtMoney(tip)],['Total',fmtMoney(total)],['Per Person',fmtMoney(total/people)]]);},
  info:'<h2>Tip Calculator</h2><p>Calculates tip amount, total bill, and amount per person when splitting.</p>'},
{id:'fuel-cost', name:'Fuel Cost Calculator', cat:'Calculator Tools', ab:'Fc', desc:'Calculate trip fuel costs', kind:'calc',
  fields:[{id:'dist',label:'Distance (km)',type:'number',value:300},{id:'eff',label:'Efficiency (km per liter)',type:'number',value:15},{id:'price',label:'Fuel Price per liter',type:'number',value:100}],
  compute:v=>{const d=+v.dist,e=+v.eff,p=+v.price;if(!d||!e)return'';const liters=d/e;return statBlock([['Fuel Needed',liters.toFixed(2)+' L'],['Total Cost',fmtMoney(liters*p)]]);},
  info:'<h2>Fuel Cost Calculator</h2><p>Estimates fuel needed and total cost for a trip based on distance and fuel efficiency.</p>'},
{id:'cgpa-calculator', name:'CGPA / GPA Calculator', cat:'Calculator Tools', ab:'Gp', desc:'Calculate GPA from grades and credits', kind:'custom', info:'<h2>CGPA / GPA Calculator</h2><p>Add each course\'s grade point and credit hours to calculate your weighted GPA.</p>'},
{id:'mean-median-mode-calculator', name:'Mean, Median & Mode Calculator', cat:'Calculator Tools', ab:'Av', desc:'Calculate mean, median, mode and standard deviation', kind:'calc',
  fields:[{id:'nums',label:'Numbers (comma or space separated)',type:'text',value:'4, 8, 6, 5, 3, 8, 9'}],
  compute:v=>{const nums=parseNums(v.nums);if(!nums.length)return'';const mean=nums.reduce((a,b)=>a+b,0)/nums.length;
    const sorted=[...nums].sort((a,b)=>a-b);const mid=Math.floor(sorted.length/2);const median=sorted.length%2?sorted[mid]:(sorted[mid-1]+sorted[mid])/2;
    const freq={};nums.forEach(n=>freq[n]=(freq[n]||0)+1);const maxF=Math.max(...Object.values(freq));const modes=Object.keys(freq).filter(k=>freq[k]===maxF);
    const variance=nums.reduce((a,b)=>a+(b-mean)**2,0)/nums.length;const stdev=Math.sqrt(variance);
    return statBlock([['Mean',round4(mean)],['Median',round4(median)],['Mode',maxF>1?modes.join(', '):'No mode'],['Std Deviation',round4(stdev)],['Range',round4(Math.max(...nums)-Math.min(...nums))],['Count',nums.length]]);},
  info:'<h2>Mean, Median &amp; Mode Calculator</h2><p>Computes mean, median, mode, standard deviation and range for a list of numbers.</p>'},
{id:'hourly-to-annual-salary', name:'Hourly to Annual Salary Calculator', cat:'Calculator Tools', ab:'Sa', desc:'Convert hourly, weekly, monthly and annual pay', kind:'calc',
  fields:[{id:'rate',label:'Hourly Rate',type:'number',value:25},{id:'hours',label:'Hours per week',type:'number',value:40}],
  compute:v=>{const r=+v.rate,h=+v.hours;if(!r||!h)return'';return statBlock([['Daily (8h)',fmtMoney(r*8)],['Weekly',fmtMoney(r*h)],['Monthly',fmtMoney(r*h*52/12)],['Annual',fmtMoney(r*h*52)]]);},
  info:'<h2>Hourly to Annual Salary Calculator</h2><p>Converts an hourly wage into daily, weekly, monthly and annual pay (52-week year).</p>'},
{id:'savings-goal', name:'Savings Goal Calculator', cat:'Calculator Tools', ab:'Sg', desc:'Find how much to save monthly for a goal', kind:'calc',
  fields:[{id:'goal',label:'Target Amount',type:'number',value:10000},{id:'have',label:'Already Saved',type:'number',value:1000},{id:'months',label:'Months to Save',type:'number',value:12}],
  compute:v=>{const goal=+v.goal,have=+v.have||0,m=+v.months;if(!goal||!m)return'';const need=Math.max(0,goal-have);
    return statBlock([['Remaining to Save',fmtMoney(need)],['Save per Month',fmtMoney(need/m)]]);},
  info:'<h2>Savings Goal Calculator</h2><p>Works out how much you need to set aside each month to reach a savings target by a given date.</p>'},
{id:'markup-calculator', name:'Markup & Margin Calculator', cat:'Calculator Tools', ab:'Mk', desc:'Calculate markup percentage and profit margin', kind:'calc',
  fields:[{id:'cost',label:'Cost Price',type:'number',value:50},{id:'sell',label:'Selling Price',type:'number',value:80}],
  compute:v=>{const c=+v.cost,s=+v.sell;if(!c||!s)return'';const profit=s-c;const markup=(profit/c)*100;const margin=(profit/s)*100;
    return statBlock([['Profit',fmtMoney(profit)],['Markup',round4(markup)+'%'],['Margin',round4(margin)+'%']]);},
  info:'<h2>Markup &amp; Margin Calculator</h2><p>Markup is profit as a percentage of cost; margin is profit as a percentage of the selling price. The two are often confused.</p>'},
{id:'break-even', name:'Break-Even Point Calculator', cat:'Calculator Tools', ab:'Be', desc:'Find your break-even sales volume', kind:'calc',
  fields:[{id:'fixed',label:'Fixed Costs',type:'number',value:5000},{id:'price',label:'Price per Unit',type:'number',value:25},{id:'cost',label:'Variable Cost per Unit',type:'number',value:10}],
  compute:v=>{const f=+v.fixed,p=+v.price,c=+v.cost;if(p<=c)return '<div class="alert alert-warn">Price must be higher than variable cost per unit.</div>';
    const units=f/(p-c);return statBlock([['Break-even Units',Math.ceil(units).toLocaleString()],['Break-even Revenue',fmtMoney(units*p)]]);},
  info:'<h2>Break-Even Point Calculator</h2><p>Finds the number of units you need to sell to cover your fixed costs.</p>'},
{id:'vat-calculator', name:'VAT Calculator', cat:'Calculator Tools', ab:'Vt', desc:'Add or remove VAT from a price', kind:'calc',
  fields:[{id:'amt',label:'Amount',type:'number',value:100},{id:'rate',label:'VAT Rate (%)',type:'number',value:20},{id:'mode',label:'Mode',type:'select',options:[['add','Add VAT'],['remove','Remove VAT']]}],
  compute:v=>{const amt=+v.amt,rate=+v.rate;if(!amt)return'';let base,vat,total;
    if(v.mode==='add'){base=amt;vat=amt*rate/100;total=base+vat;} else {total=amt;base=amt/(1+rate/100);vat=total-base;}
    return statBlock([['Net Amount',fmtMoney(base)],['VAT',fmtMoney(vat)],['Gross Amount',fmtMoney(total)]]);},
  info:'<h2>VAT Calculator</h2><p>Add VAT to a net price, or extract the VAT portion from a VAT-inclusive price.</p>'},
{id:'currency-converter', name:'Currency Converter', cat:'Calculator Tools', ab:'Cu', desc:'Convert between world currencies', kind:'custom', info:'<h2>Currency Converter</h2><p>Converts between major world currencies using indicative reference rates bundled in this page. For live, up-to-the-minute rates before a real transaction, check your bank or a live FX source.</p>'},
{id:'ratio-simplifier', name:'Ratio Simplifier', cat:'Calculator Tools', ab:'Rt', desc:'Simplify a ratio to its lowest terms', kind:'calc',
  fields:[{id:'a',label:'A',type:'number',value:12},{id:'b',label:'B',type:'number',value:18}],
  compute:v=>{const a=Math.round(+v.a),b=Math.round(+v.b);if(!a||!b)return'';const g=gcd(Math.abs(a),Math.abs(b));return statBlock([['Simplified Ratio',`${a/g} : ${b/g}`],['Decimal',round4(a/b)]]);},
  info:'<h2>Ratio Simplifier</h2><p>Reduces any ratio A:B to its simplest whole-number form.</p>'},

// ---------------- IMAGE TOOLS ----------------
{id:'image-resizer', name:'Image Resizer', cat:'Image Tools', ab:'Ir', desc:'Resize images to any dimension', badge:'pop', kind:'custom', info:'<h2>Image Resizer</h2><p>Resize any image to exact pixel dimensions or by percentage, right in your browser - nothing is uploaded anywhere.</p>'},
{id:'image-compressor', name:'Image Compressor', cat:'Image Tools', ab:'Ic', desc:'Compress images without a big quality loss', kind:'custom', info:'<h2>Image Compressor</h2><p>Re-encodes JPEG/WebP images at a chosen quality level to reduce file size, entirely in your browser.</p>'},
{id:'jpg-to-png', name:'JPG to PNG Converter', cat:'Image Tools', ab:'Jp', desc:'Convert JPG images to PNG format', kind:'custom', info:'<h2>JPG to PNG Converter</h2><p>Converts a JPG/JPEG image to PNG format locally in your browser.</p>'},
{id:'png-to-jpg', name:'PNG to JPG Converter', cat:'Image Tools', ab:'Pj', desc:'Convert PNG images to JPG format', kind:'custom', info:'<h2>PNG to JPG Converter</h2><p>Converts a PNG image to JPG format (flattened onto a white background), locally in your browser.</p>'},
{id:'image-crop', name:'Image Crop Tool', cat:'Image Tools', ab:'Cr', desc:'Crop images to custom dimensions', kind:'custom', info:'<h2>Image Crop Tool</h2><p>Drag to select a crop area on your image and export just that region.</p>'},
{id:'image-color-picker', name:'Image Color Picker', cat:'Image Tools', ab:'Cp', desc:'Pick colors from any image', kind:'custom', info:'<h2>Image Color Picker</h2><p>Click anywhere on an uploaded image to read off its exact HEX and RGB color value.</p>'},
{id:'image-to-base64', name:'Image to Base64', cat:'Image Tools', ab:'B6', desc:'Convert image to Base64 string', kind:'custom', info:'<h2>Image to Base64</h2><p>Converts an image file into a Base64-encoded data URI you can paste directly into HTML or CSS.</p>'},
{id:'base64-to-image', name:'Base64 to Image', cat:'Image Tools', ab:'B2i', desc:'Convert Base64 string back to image', kind:'custom', info:'<h2>Base64 to Image</h2><p>Paste a Base64 data URI (or raw Base64 string) and preview it as an image, with a download link.</p>'},
{id:'image-rotator', name:'Image Rotate & Flip', cat:'Image Tools', ab:'Rt2', desc:'Rotate or mirror an image', kind:'custom', info:'<h2>Image Rotate &amp; Flip</h2><p>Rotate an image in 90° steps, or flip it horizontally/vertically.</p>'},
{id:'favicon-generator', name:'Favicon Generator', cat:'Image Tools', ab:'Fv', desc:'Generate a favicon from any image', kind:'custom', info:'<h2>Favicon Generator</h2><p>Resizes an uploaded image down to the standard favicon sizes (16×16, 32×32, 48×48) for download.</p>'},

// ---------------- DEVELOPER TOOLS ----------------
{id:'json-formatter', name:'JSON Formatter', cat:'Developer Tools', ab:'{}', desc:'Format and validate JSON data', badge:'pop', kind:'dedicated'},
{id:'password-generator', name:'Password Generator', cat:'Developer Tools', ab:'Pw', desc:'Generate strong secure passwords', badge:'pop', kind:'dedicated'},
{id:'base64-encoder', name:'Base64 Encoder & Decoder', cat:'Developer Tools', ab:'B6', desc:'Encode text or data to Base64', kind:'text',
  transforms:[{label:'Encode', run:s=>btoa(unescape(encodeURIComponent(s)))},{label:'Decode', run:s=>decodeURIComponent(escape(atob(s)))}],
  mono:true, info:'<h2>Base64 Encoder &amp; Decoder</h2><p>Base64 encodes binary data as ASCII text, commonly used for embedding data in HTML/CSS/JSON or transmitting it over text-safe protocols.</p>'},
{id:'url-encoder', name:'URL Encoder & Decoder', cat:'Developer Tools', ab:'Ur', desc:'Encode URLs for safe transmission', kind:'text',
  transforms:[{label:'Encode', run:s=>encodeURIComponent(s)},{label:'Decode', run:s=>decodeURIComponent(s)}],
  mono:true, info:'<h2>URL Encoder &amp; Decoder</h2><p>Percent-encodes special characters for safe use in URLs, or decodes an encoded URL back to readable text.</p>'},
{id:'uuid-generator', name:'UUID Generator', cat:'Developer Tools', ab:'Id', desc:'Generate unique UUIDs (v4)', kind:'calc',
  fields:[{id:'n',label:'How many',type:'number',value:5,min:1,max:100},{id:'case',label:'Case',type:'select',options:[['lower','lowercase'],['upper','UPPERCASE']]}],
  compute:v=>{const n=Math.min(100,Math.max(1,parseInt(v.n)||1));const out=[];for(let i=0;i<n;i++){let u=crypto.randomUUID();if(v.case==='upper')u=u.toUpperCase();out.push(u);}
    return `<div class="fg"><label class="fl">Output <button class="cpbtn" onclick="copyText(document.getElementById('uuidOut').value,this)">Copy All</button></label><textarea class="fc mono" id="uuidOut" rows="${Math.min(12,n)}" readonly>${out.join('\n')}</textarea></div>`;},
  info:'<h2>UUID Generator</h2><p>Generates cryptographically random version-4 UUIDs using your browser\'s secure random number generator.</p>'},
{id:'md5-hash', name:'MD5 Hash Generator', cat:'Developer Tools', ab:'M5', desc:'Generate MD5 hash of any text', kind:'text',
  transforms:[{label:'Generate MD5', run:s=>SparkMD5.hash(s)}], single:true, mono:true, info:'<h2>MD5 Hash Generator</h2><p>Computes the MD5 hash of your text. MD5 is fast but cryptographically broken - do not use it for passwords or security-sensitive hashing. Use SHA-256 or better instead.</p>'},
{id:'hash-generator', name:'Hash Generator (SHA-1/256/384/512)', cat:'Developer Tools', ab:'Hg', desc:'Generate MD5, SHA1, SHA256 hashes', badge:'pop', kind:'custom', info:'<h2>Hash Generator</h2><p>Generates MD5, SHA-1, SHA-256, SHA-384 and SHA-512 hashes of your text using your browser\'s built-in Web Crypto engine.</p>'},
{id:'regex-tester', name:'Regex Tester', cat:'Developer Tools', ab:'Re', desc:'Test and debug regex patterns', kind:'custom', info:'<h2>Regex Tester</h2><p>Test a regular expression against sample text and see every match highlighted, with capture groups listed.</p>'},
{id:'color-converter', name:'Color Converter', cat:'Developer Tools', ab:'Co', desc:'Convert HEX, RGB, HSL colors', kind:'custom', info:'<h2>Color Converter</h2><p>Convert a color between HEX, RGB and HSL formats, with a live swatch preview.</p>'},
{id:'jwt-decoder', name:'JWT Decoder', cat:'Developer Tools', ab:'Jw', desc:'Decode and inspect JWT tokens', kind:'custom', info:'<h2>JWT Decoder</h2><p>Decodes a JSON Web Token\'s header and payload locally in your browser. This does not verify the signature - never paste a token from a system you don\'t trust into any website.</p>'},
{id:'markdown-html', name:'Markdown to HTML', cat:'Developer Tools', ab:'Md', desc:'Convert Markdown to HTML', kind:'custom', info:'<h2>Markdown to HTML</h2><p>Converts Markdown syntax (headings, bold, lists, links, code) into HTML markup.</p>'},
{id:'csv-json', name:'CSV to JSON Converter', cat:'Developer Tools', ab:'Cj', desc:'Convert CSV data to JSON', kind:'text',
  transforms:[{label:'CSV to JSON', run:s=>{const rows=parseCSV(s);if(!rows.length)return'';const [h,...body]=rows;return JSON.stringify(body.map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]??'']))),null,2);}},
  {label:'JSON to CSV', run:s=>{let data;try{data=JSON.parse(s);}catch(e){return 'Invalid JSON: '+e.message;}if(!Array.isArray(data)||!data.length)return 'Provide a JSON array of objects.';
    const headers=[...new Set(data.flatMap(o=>Object.keys(o)))];const esc=v=>{v=String(v??'');return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;};
    return [headers.join(','),...data.map(o=>headers.map(h=>esc(o[h])).join(','))].join('\n');}}],
  mono:true, info:'<h2>CSV and JSON Converter</h2><p>Converts CSV data (with a header row) to a JSON array of objects, or back from JSON to CSV.</p>'},
{id:'html-formatter', name:'HTML Formatter', cat:'Developer Tools', ab:'Hf', desc:'Format and indent HTML code', kind:'text', transforms:[{label:'Format', run:s=>formatHTML(s)}], single:true, mono:true,
  info:'<h2>HTML Formatter</h2><p>Adds consistent indentation to minified or messy HTML markup.</p>'},
{id:'css-minifier', name:'CSS Minifier', cat:'Developer Tools', ab:'Cm', desc:'Minify CSS by removing whitespace', kind:'text',
  transforms:[{label:'Minify', run:s=>s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{}:;,])\s*/g,'$1').replace(/;}/g,'}').trim()}],
  single:true, mono:true, info:'<h2>CSS Minifier</h2><p>Strips comments and unnecessary whitespace from CSS to reduce file size.</p>'},
{id:'js-minifier', name:'JS Whitespace Minifier', cat:'Developer Tools', ab:'Jm', desc:'Strip comments and extra whitespace from JS', kind:'text',
  transforms:[{label:'Minify', run:s=>s.replace(/\/\/.*$/gm,'').replace(/\/\*[\s\S]*?\*\//g,'').split('\n').map(l=>l.trim()).filter(Boolean).join('\n')}],
  single:true, mono:true, info:'<h2>JS Whitespace Minifier</h2><p>Removes comments, blank lines and leading whitespace from JavaScript. For production use, a proper minifier (e.g. Terser) is recommended for variable renaming and dead-code removal.</p>'},
{id:'cron-explainer', name:'Cron Expression Explainer', cat:'Developer Tools', ab:'Cx', desc:'Explain what a cron expression means', kind:'calc',
  fields:[{id:'c',label:'Cron Expression',type:'text',value:'*/15 9-17 * * 1-5'}],
  compute:v=>{try{return `<div class="res-box ok">${explainCron(v.c)}</div>`;}catch(e){return `<div class="res-box er">${e.message}</div>`;}},
  info:'<h2>Cron Expression Explainer</h2><p>Explains a standard 5-field cron expression (minute, hour, day-of-month, month, day-of-week) in plain English.</p>'},
{id:'number-base', name:'Number Base Converter', cat:'Developer Tools', ab:'Nb', desc:'Convert binary, decimal, hex, octal', kind:'base', info:'<h2>Number Base Converter</h2><p>Converts a number between binary, octal, decimal and hexadecimal.</p>'},
{id:'timestamp-converter', name:'Unix Timestamp Converter', cat:'Date & Time Tools', ab:'Ux', desc:'Convert Unix timestamps to dates', kind:'custom', info:'<h2>Unix Timestamp Converter</h2><p>Converts a Unix timestamp (seconds or milliseconds) to a readable date, or a date to its timestamp.</p>'},
{id:'json-validator', name:'JSON Validator', cat:'Developer Tools', ab:'Jv', desc:'Validate JSON and view structure stats', kind:'text', transforms:[{label:'Validate', run:t=>t}], extra:'jsonvalidate',
  info:'<h2>JSON Validator</h2><p>Validates JSON syntax and reports key count, nesting depth and value types.</p>'},
{id:'xml-formatter', name:'XML Formatter', cat:'Developer Tools', ab:'Xm', desc:'Format and indent XML', kind:'text', transforms:[{label:'Format', run:s=>formatHTML(s)}], single:true, mono:true,
  info:'<h2>XML Formatter</h2><p>Adds consistent indentation to XML markup.</p>'},

// ---------------- UNIT CONVERTERS ----------------
{id:'length-converter', name:'Length Converter', cat:'Unit Converters', ab:'Ln', desc:'Convert meters, feet, inches, miles', kind:'convert', table:'U_LENGTH', def:{amt:1,from:'m',to:'ft'}},
{id:'weight-converter', name:'Weight Converter', cat:'Unit Converters', ab:'Wt', desc:'Convert kg, lbs, grams, ounces', badge:'pop', kind:'convert', table:'U_WEIGHT', def:{amt:1,from:'kg',to:'lb'}},
{id:'temperature-converter', name:'Temperature Converter', cat:'Unit Converters', ab:'Tm', desc:'Convert Celsius, Fahrenheit, Kelvin', badge:'pop', kind:'custom', info:'<h2>Temperature Converter</h2><p>Converts between Celsius, Fahrenheit and Kelvin.</p>'},
{id:'speed-converter', name:'Speed Converter', cat:'Unit Converters', ab:'Sp', desc:'Convert km/h, mph, m/s, knots', kind:'convert', table:'U_SPEED', def:{amt:1,from:'kmh',to:'mph'}},
{id:'area-converter', name:'Area Converter', cat:'Unit Converters', ab:'Ar', desc:'Convert sq meters, acres, sq feet', kind:'convert', table:'U_AREA', def:{amt:1,from:'m2',to:'ft2'}},
{id:'volume-converter', name:'Volume Converter', cat:'Unit Converters', ab:'Vl', desc:'Convert liters, gallons, cups', kind:'convert', table:'U_VOLUME', def:{amt:1,from:'l',to:'gal'}},
{id:'time-unit-converter', name:'Time Unit Converter', cat:'Unit Converters', ab:'Tc2', desc:'Convert seconds, minutes, hours, days', kind:'convert', table:'U_TIME', def:{amt:1,from:'h',to:'min'}},
{id:'data-storage-converter', name:'Data Storage Converter', cat:'Unit Converters', ab:'Db', desc:'Convert bytes, KB, MB, GB, TB', kind:'convert', table:'U_DATA', def:{amt:1,from:'gb',to:'mb'}},
{id:'energy-converter', name:'Energy Converter', cat:'Unit Converters', ab:'En', desc:'Convert joules, calories, kWh', kind:'convert', table:'U_ENERGY', def:{amt:1,from:'kcal',to:'kj'}},
{id:'pressure-converter', name:'Pressure Converter', cat:'Unit Converters', ab:'Pr', desc:'Convert Pa, bar, psi, atm', kind:'convert', table:'U_PRESSURE', def:{amt:1,from:'bar',to:'psi'}},
{id:'power-converter', name:'Power Converter', cat:'Unit Converters', ab:'Pw2', desc:'Convert watts, kilowatts, horsepower', kind:'convert', table:'U_POWER', def:{amt:1,from:'hp',to:'w'}},
{id:'force-converter', name:'Force Converter', cat:'Unit Converters', ab:'Fo', desc:'Convert newtons, pound-force, kgf', kind:'convert', table:'U_FORCE', def:{amt:1,from:'n',to:'lbf'}},
{id:'angle-converter', name:'Angle Converter', cat:'Unit Converters', ab:'Ag2', desc:'Convert degrees, radians, gradians', kind:'convert', table:'U_ANGLE', def:{amt:180,from:'deg',to:'rad'}},
{id:'frequency-converter', name:'Frequency Converter', cat:'Unit Converters', ab:'Fr2', desc:'Convert Hz, kHz, MHz, GHz', kind:'convert', table:'U_FREQ', def:{amt:1,from:'ghz',to:'mhz'}},
{id:'fuel-economy', name:'Fuel Economy Converter', cat:'Unit Converters', ab:'Fe', desc:'Convert MPG, L/100km, km/L', kind:'custom', info:'<h2>Fuel Economy Converter</h2><p>Converts between miles per gallon (US/UK) and liters per 100km / kilometers per liter.</p>'},
{id:'shoe-size', name:'Shoe Size Converter', cat:'Unit Converters', ab:'Sh', desc:'Convert shoe sizes between regions', kind:'custom', info:'<h2>Shoe Size Converter</h2><p>Converts shoe sizes between US, UK and EU sizing systems (approximate - brands vary).</p>'},
{id:'cooking-converter', name:'Cooking Measurement Converter', cat:'Unit Converters', ab:'Ck', desc:'Convert cups, tablespoons, grams', kind:'convert', table:'U_VOLUME', def:{amt:1,from:'cup',to:'ml'}},

// ---------------- DATE & TIME TOOLS ----------------
{id:'date-difference', name:'Date Difference Calculator', cat:'Date & Time Tools', ab:'Dd', desc:'Calculate days between two dates', badge:'pop', kind:'custom', info:'<h2>Date Difference Calculator</h2><p>Calculates the exact number of years, months and days between two dates.</p>'},
{id:'timezone-converter', name:'Time Zone Converter', cat:'Date & Time Tools', ab:'Tz', desc:'Convert times across time zones', kind:'custom', info:'<h2>Time Zone Converter</h2><p>Shows the current time across major time zones around the world, side by side.</p>'},
{id:'days-until', name:'Days Until Date', cat:'Date & Time Tools', ab:'Du', desc:'Count days until any event', kind:'calc',
  fields:[{id:'d',label:'Target Date',type:'date',value:''}],
  compute:v=>{if(!v.d)return'';const target=new Date(v.d+'T00:00:00');const today=new Date();today.setHours(0,0,0,0);const diff=Math.round((target-today)/86400000);
    return statBlock([[diff>=0?'Days Remaining':'Days Ago',Math.abs(diff)],['Weeks',round4(Math.abs(diff)/7)]]);},
  info:'<h2>Days Until Date</h2><p>Counts the number of days until (or since) any date.</p>'},
{id:'week-number', name:'Week Number Calculator', cat:'Date & Time Tools', ab:'Wn', desc:'Find week number of any date', kind:'calc',
  fields:[{id:'d',label:'Date',type:'date',value:new Date().toISOString().slice(0,10)}],
  compute:v=>{if(!v.d)return'';const d=new Date(v.d+'T00:00:00');return statBlock([['ISO Week',getISOWeek(d)],['Year',d.getFullYear()],['Day of Year',getDayOfYear(d)]]);},
  info:'<h2>Week Number Calculator</h2><p>Finds the ISO 8601 week number and day-of-year for any date.</p>'},
{id:'unix-timestamp', name:'Unix Timestamp Now', cat:'Date & Time Tools', ab:'Ut2', desc:'Current Unix timestamp, live', kind:'custom', info:'<h2>Unix Timestamp</h2><p>Shows the current Unix timestamp, updating live.</p>'},
{id:'date-formatter', name:'Date Formatter', cat:'Date & Time Tools', ab:'Df', desc:'Format dates in any format', kind:'calc',
  fields:[{id:'d',label:'Date',type:'date',value:new Date().toISOString().slice(0,10)}],
  compute:v=>{if(!v.d)return'';const d=new Date(v.d+'T00:00:00');const pad=n=>String(n).padStart(2,'0');
    const formats=[['DD/MM/YYYY',`${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()}`],
      ['MM/DD/YYYY',`${pad(d.getMonth()+1)}/${pad(d.getDate())}/${d.getFullYear()}`],
      ['YYYY-MM-DD',`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`],
      ['Long',d.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})],
      ['Short',d.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'})]];
    return formats.map(([l,v])=>`<div class="trow"><span>${l}</span><strong class="mono">${v}</strong></div>`).join('');},
  info:'<h2>Date Formatter</h2><p>Displays a date in multiple common formats at once.</p>'},
{id:'business-days', name:'Business Days Calculator', cat:'Date & Time Tools', ab:'Bd', desc:'Calculate working days between dates', kind:'calc',
  fields:[{id:'a',label:'Start Date',type:'date',value:''},{id:'b',label:'End Date',type:'date',value:''}],
  compute:v=>{if(!v.a||!v.b)return'';let start=new Date(v.a+'T00:00:00'),end=new Date(v.b+'T00:00:00');if(start>end)[start,end]=[end,start];
    let days=0;const cur=new Date(start);while(cur<=end){const dow=cur.getDay();if(dow!==0&&dow!==6)days++;cur.setDate(cur.getDate()+1);}
    return statBlock([['Business Days',days],['Weekend Days',Math.round((end-start)/86400000)+1-days]]);},
  info:'<h2>Business Days Calculator</h2><p>Counts working days (Monday-Friday) between two dates, excluding weekends.</p>'},
{id:'stopwatch', name:'Stopwatch', cat:'Date & Time Tools', ab:'Sw', desc:'Online stopwatch with lap timer', kind:'custom', info:'<h2>Stopwatch</h2><p>A simple stopwatch with lap timing, running entirely in your browser tab.</p>'},
{id:'countdown-timer', name:'Countdown Timer', cat:'Date & Time Tools', ab:'Ct', desc:'Set a countdown to any date and time', kind:'custom', info:'<h2>Countdown Timer</h2><p>Set a target date and time and watch a live countdown.</p>'},
{id:'pomodoro-timer', name:'Pomodoro Timer', cat:'Date & Time Tools', ab:'Po', desc:'Focus timer using the Pomodoro technique', kind:'custom', info:'<h2>Pomodoro Timer</h2><p>A 25-minute focus / 5-minute break timer based on the Pomodoro productivity technique.</p>'},
{id:'leap-year', name:'Leap Year Checker', cat:'Date & Time Tools', ab:'Ly', desc:'Check if a year is a leap year', kind:'calc',
  fields:[{id:'y',label:'Year',type:'number',value:new Date().getFullYear()}],
  compute:v=>{const y=parseInt(v.y);if(!y)return'';const isLeap=(y%4===0 && y%100!==0) || y%400===0;
    return `<div class="alert ${isLeap?'alert-ok':'alert-info'}">${y} is ${isLeap?'':'not '}a leap year.</div>`;},
  info:'<h2>Leap Year Checker</h2><p>A year is a leap year if divisible by 4, except century years, which must be divisible by 400.</p>'},
{id:'world-clock', name:'World Clock', cat:'Date & Time Tools', ab:'Wc2', desc:'See the current time in major cities', kind:'custom', info:'<h2>World Clock</h2><p>Shows the current local time in major cities around the world, updating live.</p>'},
{id:'age-in-days', name:'Age in Days Calculator', cat:'Date & Time Tools', ab:'Ad', desc:'Find your exact age in total days', kind:'calc',
  fields:[{id:'d',label:'Date of Birth',type:'date',value:''}],
  compute:v=>{if(!v.d)return'';const dob=new Date(v.d+'T00:00:00');const today=new Date();today.setHours(0,0,0,0);const days=Math.floor((today-dob)/86400000);
    return statBlock([['Total Days',days.toLocaleString()],['Total Weeks',Math.floor(days/7).toLocaleString()],['Total Hours',(days*24).toLocaleString()]]);},
  info:'<h2>Age in Days Calculator</h2><p>Converts your age into total days, weeks and hours lived.</p>'},

// ---------------- UTILITY TOOLS ----------------
{id:'qr-generator', name:'QR Code Generator', cat:'Utility Tools', ab:'Qr', desc:'Generate QR codes instantly', badge:'pop', kind:'custom', info:'<h2>QR Code Generator</h2><p>Generates QR codes for URLs, text, email, phone, SMS and Wi-Fi - rendered locally in your browser with no data sent anywhere.</p>'},
{id:'ip-lookup', name:'My IP Address', cat:'Utility Tools', ab:'Ip', desc:'Find your public IP address', kind:'custom', info:'<h2>My IP Address</h2><p>Shows your current public IP address. This is the one tool on this site that contacts an external service (a public IP-echo API) to do its job - see our Privacy Policy for details.</p>'},
{id:'random-number', name:'Random Number Generator', cat:'Utility Tools', ab:'Rn', desc:'Generate random numbers in a range', kind:'calc',
  fields:[{id:'min',label:'Min',type:'number',value:1},{id:'max',label:'Max',type:'number',value:100},{id:'n',label:'How many',type:'number',value:1,min:1,max:50},{id:'uniq',label:'No duplicates',type:'checkbox'}],
  compute:v=>{let min=Math.round(+v.min),max=Math.round(+v.max);if(min>max)[min,max]=[max,min];const n=Math.min(50,Math.max(1,parseInt(v.n)||1));
    const range=max-min+1;if(v.uniq && n>range) return '<div class="alert alert-warn">Range too small for that many unique numbers.</div>';
    let out=[];if(v.uniq){const pool=[];for(let i=min;i<=max;i++)pool.push(i);for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}out=pool.slice(0,n);}
    else{for(let i=0;i<n;i++)out.push(Math.floor(Math.random()*range)+min);}
    return `<div class="res-box ok" style="font-size:20px;font-weight:700">${out.join(', ')}</div>`;},
  info:'<h2>Random Number Generator</h2><p>Generates random whole numbers within a range, with an option to disallow duplicates.</p>'},
{id:'coin-flip', name:'Coin Flip', cat:'Utility Tools', ab:'Cf', desc:'Virtual coin flip tool', kind:'custom', info:'<h2>Coin Flip</h2><p>Flips a virtual coin using your browser\'s random number generator.</p>'},
{id:'dice-roller', name:'Dice Roller', cat:'Utility Tools', ab:'Dr', desc:'Roll virtual dice online', kind:'custom', info:'<h2>Dice Roller</h2><p>Roll 1 to 10 dice with any number of sides (d4, d6, d8, d10, d12, d20…).</p>'},
{id:'reading-time', name:'Reading Time Calculator', cat:'Utility Tools', ab:'Rt3', desc:'Estimate article reading time', kind:'calc',
  fields:[{id:'words',label:'Word Count',type:'number',value:1000},{id:'wpm',label:'Reading Speed (WPM)',type:'number',value:200}],
  compute:v=>{const w=+v.words,wpm=+v.wpm||200;if(!w)return'';const min=w/wpm;return statBlock([['Reading Time',min<1?Math.round(min*60)+' sec':round4(min)+' min']]);},
  info:'<h2>Reading Time Calculator</h2><p>Estimates how long an article takes to read based on word count and reading speed (average adult reads ~200-250 WPM).</p>'},
{id:'number-to-words', name:'Number to Words', cat:'Utility Tools', ab:'Nw', desc:'Convert numbers to English words', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:12345}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n))return'';return `<div class="res-box ok">${numberToWords(n)}</div>`;},
  info:'<h2>Number to Words</h2><p>Spells out any whole number (up to trillions) in English words.</p>'},
{id:'text-to-speech', name:'Text to Speech', cat:'Utility Tools', ab:'Tts', desc:'Convert text to audio speech', kind:'custom', info:'<h2>Text to Speech</h2><p>Reads your text aloud using your browser\'s built-in speech synthesis - no audio leaves your device.</p>'},
{id:'password-passphrase', name:'Passphrase Generator', cat:'Utility Tools', ab:'Pp', desc:'Generate a memorable word-based passphrase', kind:'custom', info:'<h2>Passphrase Generator</h2><p>Generates a random multi-word passphrase from a curated word list - often easier to remember and type than a random character password, while still offering strong entropy.</p>'},
{id:'random-color', name:'Random Color Generator', cat:'Utility Tools', ab:'Rc', desc:'Generate random colors with codes', kind:'custom', info:'<h2>Random Color Generator</h2><p>Generates random colors with HEX, RGB and HSL values shown.</p>'},
{id:'name-picker', name:'Random Name Picker', cat:'Utility Tools', ab:'Np2', desc:'Pick a random name from a list', kind:'calc',
  fields:[{id:'list',label:'Names (one per line)',type:'textarea',value:'Alex\nJordan\nTaylor\nMorgan\nCasey'}],
  compute:v=>{const names=(v.list||'').split('\n').map(s=>s.trim()).filter(Boolean);if(!names.length)return'';const pick=names[Math.floor(Math.random()*names.length)];
    return `<div class="res-box ok" style="font-size:22px;font-weight:700;text-align:center">${esc(pick)}</div>`;},
  info:'<h2>Random Name Picker</h2><p>Paste a list of names (one per line) and pick a random winner - for raffles, team assignments, or deciding who goes first.</p>'},
{id:'spin-wheel', name:'Spin the Wheel', cat:'Utility Tools', ab:'Sw2', desc:'Spin a wheel to pick a random option', kind:'custom', info:'<h2>Spin the Wheel</h2><p>Enter options and spin an animated wheel to pick one at random.</p>'},
{id:'bmr-calculator', name:'BMR Calculator', cat:'Utility Tools', ab:'Br', desc:'Estimate basal metabolic rate', kind:'custom', info:'<h2>BMR Calculator</h2><p>Estimates basal metabolic rate (calories burned at rest) using the Mifflin-St Jeor formula. This is a general estimate, not medical advice - consult a professional for personalised guidance.</p>'},
{id:'water-intake', name:'Water Intake Calculator', cat:'Utility Tools', ab:'Wi', desc:'Estimate daily water intake', kind:'calc',
  fields:[{id:'w',label:'Body Weight (kg)',type:'number',value:70},{id:'activity',label:'Activity Level',type:'select',options:[['low','Low (little exercise)'],['mod','Moderate (3-5x/week)'],['high','High (daily intense)']]}],
  compute:v=>{const w=+v.w;if(!w)return'';const mult=v.activity==='high'?45:v.activity==='mod'?38:33;const ml=w*mult;
    return statBlock([['Suggested Daily Intake',(ml/1000).toFixed(1)+' L'],['In Cups (250ml)',Math.round(ml/250)]])+'<div class="alert alert-info">General wellness estimate only - not medical advice.</div>';},
  info:'<h2>Water Intake Calculator</h2><p>Gives a general daily water-intake estimate based on body weight and activity level. This is a general wellness guide, not medical advice.</p>'},
{id:'pace-calculator', name:'Running Pace Calculator', cat:'Utility Tools', ab:'Pc2', desc:'Calculate running pace, time or distance', kind:'custom', info:'<h2>Running Pace Calculator</h2><p>Calculates pace per km/mile, total time, or distance - given any two of the three.</p>'},
{id:'simple-tax-estimator', name:'Simple Tax Estimator', cat:'Utility Tools', ab:'Tx2', desc:'Estimate tax using custom bracket rates', kind:'custom', info:'<h2>Simple Tax Estimator</h2><p>Estimates tax owed using progressive brackets you define yourself. For an indicative, educational estimate only - not tax advice.</p>'},
{id:'electricity-cost', name:'Electricity Cost Calculator', cat:'Utility Tools', ab:'El', desc:'Estimate appliance running cost', kind:'calc',
  fields:[{id:'watts',label:'Appliance Power (Watts)',type:'number',value:1500},{id:'hours',label:'Hours per day',type:'number',value:2},{id:'rate',label:'Rate per kWh',type:'number',value:8}],
  compute:v=>{const w=+v.watts,h=+v.hours,r=+v.rate;if(!w)return'';const kwhDay=(w*h)/1000;
    return statBlock([['kWh per Day',round4(kwhDay)],['Cost per Day',fmtMoney(kwhDay*r)],['Cost per Month',fmtMoney(kwhDay*r*30)]]);},
  info:'<h2>Electricity Cost Calculator</h2><p>Estimates the running cost of an appliance based on its wattage, daily usage hours, and your electricity rate.</p>'},

// ---------------- SEO TOOLS ----------------
{id:'meta-tag-generator', name:'Meta Tag Generator', cat:'SEO Tools', ab:'Mt2', desc:'Generate SEO meta tags for any page', badge:'pop', kind:'custom', info:'<h2>Meta Tag Generator</h2><p>Generates title, description, keyword, and Open Graph meta tags ready to paste into your page\'s <code>&lt;head&gt;</code>.</p>'},
{id:'keyword-density', name:'Keyword Density Checker', cat:'SEO Tools', ab:'Kd', desc:'Analyze keyword density in content', kind:'custom', info:'<h2>Keyword Density Checker</h2><p>Analyzes how often each word and phrase appears in your content, as a percentage of total words.</p>'},
{id:'open-graph-generator', name:'Open Graph Tag Generator', cat:'SEO Tools', ab:'Og', desc:'Generate Open Graph social tags', kind:'custom', info:'<h2>Open Graph Tag Generator</h2><p>Generates Open Graph meta tags that control how your page looks when shared on social media.</p>'},
{id:'robots-txt-generator', name:'Robots.txt Generator', cat:'SEO Tools', ab:'Rb', desc:'Generate a robots.txt file', kind:'custom', info:'<h2>Robots.txt Generator</h2><p>Generates a robots.txt file to control which crawlers can access which parts of your site.</p>'},
{id:'schema-generator', name:'Schema Markup Generator', cat:'SEO Tools', ab:'Sg2', desc:'Generate JSON-LD schema markup', badge:'new', kind:'custom', info:'<h2>Schema Markup Generator</h2><p>Generates JSON-LD structured data for Article, Product, or FAQ page types, ready to paste into your page.</p>'},
{id:'title-analyzer', name:'Title Tag Analyzer', cat:'SEO Tools', ab:'Ta', desc:'Analyze and optimize title tags', kind:'text', transforms:[{label:'Analyze', run:t=>t}], extra:'titleanalyze',
  info:'<h2>Title Tag Analyzer</h2><p>Checks your page title\'s character length against Google\'s typical display limit (~60 characters / ~580px) and shows a search-result preview.</p>'},
{id:'meta-description-checker', name:'Meta Description Analyzer', cat:'SEO Tools', ab:'Mda', desc:'Check meta description length', kind:'text', transforms:[{label:'Analyze', run:t=>t}], extra:'metadescanalyze',
  info:'<h2>Meta Description Analyzer</h2><p>Checks your meta description length against Google\'s typical display limit (~155-160 characters) and previews it as a search snippet.</p>'},
{id:'utm-builder', name:'UTM Link Builder', cat:'SEO Tools', ab:'Um', desc:'Build UTM parameter tracking URLs', badge:'new', kind:'custom', info:'<h2>UTM Link Builder</h2><p>Builds a campaign-tracking URL with UTM source, medium, campaign, term and content parameters for use in Google Analytics.</p>'},
{id:'sitemap-generator', name:'Sitemap Generator', cat:'SEO Tools', ab:'Sm', desc:'Generate XML sitemaps for your site', kind:'custom', info:'<h2>Sitemap Generator</h2><p>Paste a list of URLs (one per line) and generate a valid sitemap.xml file.</p>'},
{id:'url-structure-checker', name:'URL Structure Checker', cat:'SEO Tools', ab:'Us', desc:'Check a URL for common SEO issues', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'urlcheck',
  info:'<h2>URL Structure Checker</h2><p>Flags common SEO issues in a URL: length, uppercase letters, underscores, special characters, and stop words.</p>'},
{id:'alt-text-checker', name:'Image Alt Text Checker', cat:'SEO Tools', ab:'At', desc:'Find images missing alt text in HTML', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'alttext',
  info:'<h2>Image Alt Text Checker</h2><p>Paste HTML and find every <code>&lt;img&gt;</code> tag missing an <code>alt</code> attribute - important for accessibility and image SEO.</p>'},
{id:'content-length-checker', name:'Content Length Checker', cat:'SEO Tools', ab:'Cl2', desc:'Check content length against SEO benchmarks', kind:'text', transforms:[{label:'Check', run:t=>t}], extra:'seolength',
  info:'<h2>Content Length Checker</h2><p>Checks word count against common SEO content-length benchmarks for blog posts and landing pages.</p>'},

// ---------------- SECURITY TOOLS ----------------
{id:'password-strength', name:'Password Strength Checker', cat:'Security Tools', ab:'Ps', desc:'Check password strength score', badge:'pop', kind:'custom', info:'<h2>Password Strength Checker</h2><p>Scores a password on length and character variety, and flags common weak patterns.</p>'},
{id:'token-generator', name:'Random Token Generator', cat:'Security Tools', ab:'Tk', desc:'Generate secure random tokens', kind:'calc',
  fields:[{id:'len',label:'Length',type:'number',value:32,min:8,max:128},{id:'fmt',label:'Format',type:'select',options:[['hex','Hex'],['b64','Base64']]}],
  compute:v=>{const len=Math.min(128,Math.max(8,parseInt(v.len)||32));const bytes=new Uint8Array(len);crypto.getRandomValues(bytes);
    const tok=v.fmt==='b64'?btoa(String.fromCharCode(...bytes)).replace(/=/g,''):[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
    return `<div class="res-box ok mono">${tok}</div>`;},
  info:'<h2>Random Token Generator</h2><p>Generates a cryptographically secure random token using your browser\'s secure random number generator - suitable as an API key seed or session secret.</p>'},
{id:'htpasswd', name:'HTPASSWD Generator', cat:'Security Tools', ab:'Hp', desc:'Generate .htpasswd password hashes', kind:'custom', info:'<h2>HTPASSWD Generator</h2><p>Generates a bcrypt-style htpasswd line for Apache/Nginx basic auth.</p>'},
{id:'fake-data-generator', name:'Fake Data Generator', cat:'Security Tools', ab:'Fd', desc:'Generate fake test data (names, emails)', kind:'custom', info:'<h2>Fake Data Generator</h2><p>Generates clearly-fake sample data - names, emails, phone numbers - for filling test forms and demos. Not real personal information.</p>'},
{id:'credit-card-check', name:'Credit Card Number Validator', cat:'Security Tools', ab:'Cc2', desc:'Validate a card number with the Luhn check', kind:'calc',
  fields:[{id:'n',label:'Card Number',type:'text',value:'4111 1111 1111 1111'}],
  compute:v=>{const digits=(v.n||'').replace(/\D/g,'');if(!digits)return'';const valid=luhnCheck(digits);const brand=detectCardBrand(digits);
    return `<div class="alert ${valid?'alert-ok':'alert-err'}">${valid?'Passes the Luhn checksum':'Fails the Luhn checksum, not a valid card number'}</div>${brand?`<div class="res-box">Likely network: ${brand}</div>`:''}<div class="alert alert-info">This only checks number format, it does not verify a real account. Never paste a real card number into any website unless you trust it completely.</div>`;},
  info:'<h2>Credit Card Number Validator</h2><p>Checks whether a card number passes the Luhn checksum algorithm used by all major card networks. This does not verify that the card is real, active, or valid for payment - it is a format check only.</p>'},
{id:'password-entropy', name:'Password Entropy Calculator', cat:'Security Tools', ab:'Pe', desc:'Estimate password entropy in bits', kind:'calc',
  fields:[{id:'p',label:'Password',type:'text',value:''}],
  compute:v=>{const p=v.p||'';if(!p)return'';let pool=0;if(/[a-z]/.test(p))pool+=26;if(/[A-Z]/.test(p))pool+=26;if(/[0-9]/.test(p))pool+=10;if(/[^a-zA-Z0-9]/.test(p))pool+=33;
    const entropy=p.length*Math.log2(pool||1);const crackTime=Math.pow(2,entropy)/1e10;
    return statBlock([['Entropy',round4(entropy)+' bits'],['Character Pool',pool],['Est. offline crack time (10B guesses/sec)',fmtDuration(crackTime)]]);},
  info:'<h2>Password Entropy Calculator</h2><p>Estimates password entropy in bits based on length and character pool, and a rough brute-force time estimate against a fast offline attack.</p>'},

// ---------------- MATH TOOLS ----------------
{id:'square-root', name:'Square & Cube Root Calculator', cat:'Math Tools', ab:'Sq', desc:'Calculate square and cube roots', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:144}],
  compute:v=>{const n=+v.n;if(isNaN(n))return'';return statBlock([['Square Root',n<0?'undefined (negative)':round4(Math.sqrt(n))],['Cube Root',round4(Math.cbrt(n))],['Square',round4(n*n)],['Cube',round4(n*n*n)]]);},
  info:'<h2>Square &amp; Cube Root Calculator</h2><p>Calculates the square root, cube root, square and cube of any number.</p>'},
{id:'prime-checker', name:'Prime Number Checker', cat:'Math Tools', ab:'Pn', desc:'Check if a number is prime', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:97}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n)||n<2)return '<div class="alert alert-info">Enter a whole number greater than 1.</div>';
    let isPrime=true;for(let i=2;i*i<=n;i++){if(n%i===0){isPrime=false;break;}}
    return `<div class="alert ${isPrime?'alert-ok':'alert-err'}">${n} is ${isPrime?'':'not '}a prime number.</div>`;},
  info:'<h2>Prime Number Checker</h2><p>Checks whether a number has exactly two distinct factors (1 and itself).</p>'},
{id:'fibonacci', name:'Fibonacci Sequence Generator', cat:'Math Tools', ab:'Fb', desc:'Generate Fibonacci number sequences', kind:'calc',
  fields:[{id:'n',label:'How many terms',type:'number',value:15,min:1,max:200}],
  compute:v=>{const n=Math.min(200,Math.max(1,parseInt(v.n)||1));const seq=[0,1];for(let i=2;i<n;i++)seq.push(seq[i-1]+seq[i-2]);
    return `<div class="res-box mono">${seq.slice(0,n).join(', ')}</div>`;},
  info:'<h2>Fibonacci Sequence Generator</h2><p>Generates the Fibonacci sequence, where each number is the sum of the two preceding ones.</p>'},
{id:'hcf-lcm', name:'HCF & LCM Calculator', cat:'Math Tools', ab:'Hl', desc:'Calculate HCF and LCM of numbers', kind:'calc',
  fields:[{id:'nums',label:'Numbers (comma separated)',type:'text',value:'12, 18, 24'}],
  compute:v=>{const nums=parseNums(v.nums).map(n=>Math.round(Math.abs(n))).filter(n=>n>0);if(nums.length<2)return'<div class="alert alert-info">Enter at least 2 positive numbers.</div>';
    const h=nums.reduce((a,b)=>gcd(a,b));const l=nums.reduce((a,b)=>a*b/gcd(a,b));
    return statBlock([['HCF (GCD)',h],['LCM',l]]);},
  info:'<h2>HCF &amp; LCM Calculator</h2><p>Calculates the Highest Common Factor and Lowest Common Multiple of a list of numbers.</p>'},
{id:'factorial', name:'Factorial Calculator', cat:'Math Tools', ab:'Ft', desc:'Calculate factorial of any number', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:10,min:0,max:170}],
  compute:v=>{const n=Math.round(+v.n);if(isNaN(n)||n<0)return'<div class="alert alert-info">Enter a whole number ≥ 0.</div>';if(n>170)return '<div class="alert alert-warn">Number too large (exceeds floating point range at 171!).</div>';
    let f=1n;for(let i=2;i<=n;i++)f*=BigInt(i);return `<div class="res-box mono" style="word-break:break-all">${n}! = ${f.toString()}</div>`;},
  info:'<h2>Factorial Calculator</h2><p>Calculates n! = n × (n-1) × (n-2) × ... × 1, using exact big-integer arithmetic.</p>'},
{id:'binary-converter', name:'Binary and Decimal Converter', cat:'Math Tools', ab:'Bn', desc:'Convert binary, decimal, hex, octal', kind:'base'},
{id:'roman-numerals', name:'Roman Numeral Converter', cat:'Math Tools', ab:'Rm', desc:'Convert between Arabic and Roman numerals', kind:'custom', info:'<h2>Roman Numeral Converter</h2><p>Converts between Arabic numbers (1-3999) and Roman numerals.</p>'},
{id:'quadratic-solver', name:'Quadratic Equation Solver', cat:'Math Tools', ab:'Qd', desc:'Solve ax² + bx + c = 0', kind:'calc',
  fields:[{id:'a',label:'a',type:'number',value:1},{id:'b',label:'b',type:'number',value:-3},{id:'c',label:'c',type:'number',value:2}],
  compute:v=>{const a=+v.a,b=+v.b,c=+v.c;if(!a)return '<div class="alert alert-info">Coefficient "a" must not be zero.</div>';
    const disc=b*b-4*a*c;
    if(disc>0){const x1=(-b+Math.sqrt(disc))/(2*a),x2=(-b-Math.sqrt(disc))/(2*a);return statBlock([['x₁',round4(x1)],['x₂',round4(x2)],['Discriminant',round4(disc)]]);}
    if(disc===0){const x=-b/(2*a);return statBlock([['x (double root)',round4(x)],['Discriminant',0]]);}
    const re=-b/(2*a),im=Math.sqrt(-disc)/(2*a);return statBlock([['x₁',`${round4(re)} + ${round4(im)}i`],['x₂',`${round4(re)} − ${round4(im)}i`],['Discriminant',round4(disc)]]);},
  info:'<h2>Quadratic Equation Solver</h2><p>Solves ax² + bx + c = 0 using the quadratic formula, including complex roots when the discriminant is negative.</p>'},
{id:'percent-error', name:'Percentage Error Calculator', cat:'Math Tools', ab:'Pe2', desc:'Calculate percentage error', kind:'calc',
  fields:[{id:'exp',label:'Expected (True) Value',type:'number',value:100},{id:'obs',label:'Observed (Measured) Value',type:'number',value:95}],
  compute:v=>{const exp=+v.exp,obs=+v.obs;if(!exp)return'';const err=Math.abs((obs-exp)/exp)*100;return statBlock([['Percentage Error',round4(err)+'%'],['Absolute Difference',round4(Math.abs(obs-exp))]]);},
  info:'<h2>Percentage Error Calculator</h2><p><strong>Formula:</strong> |Observed − Expected| ÷ Expected × 100</p>'},
{id:'permutation-combination', name:'Permutation & Combination Calculator', cat:'Math Tools', ab:'Pc3', desc:'Calculate nPr and nCr', kind:'calc',
  fields:[{id:'n',label:'n',type:'number',value:10,min:0},{id:'r',label:'r',type:'number',value:3,min:0}],
  compute:v=>{const n=Math.round(+v.n),r=Math.round(+v.r);if(isNaN(n)||isNaN(r)||r>n||n<0||r<0)return '<div class="alert alert-info">Require 0 ≤ r ≤ n.</div>';
    const fact=k=>{let f=1n;for(let i=2;i<=k;i++)f*=BigInt(i);return f;};
    const nPr=fact(n)/fact(n-r);const nCr=nPr/fact(r);
    return statBlock([['nPr (Permutations)',nPr.toString()],['nCr (Combinations)',nCr.toString()]]);},
  info:'<h2>Permutation &amp; Combination Calculator</h2><p>Calculates nPr (ordered arrangements) and nCr (unordered selections) for choosing r items from n.</p>'},
{id:'log-calculator', name:'Logarithm Calculator', cat:'Math Tools', ab:'Lg', desc:'Calculate log and antilog of a number', kind:'calc',
  fields:[{id:'n',label:'Number',type:'number',value:1000},{id:'base',label:'Base',type:'number',value:10}],
  compute:v=>{const n=+v.n,base=+v.base;if(n<=0||base<=0||base===1)return '<div class="alert alert-info">Number must be positive; base must be positive and ≠ 1.</div>';
    const result=Math.log(n)/Math.log(base);return statBlock([[`log base ${base} of ${n}`,round4(result)],['Natural log (ln)',round4(Math.log(n))],['log base 10',round4(Math.log10(n))],['log base 2',round4(Math.log2(n))]]);},
  info:'<h2>Logarithm Calculator</h2><p>Calculates the logarithm of a number to any base, plus natural log, log₁₀ and log₂.</p>'},
{id:'triangle-calculator', name:'Right Triangle Calculator', cat:'Math Tools', ab:'Tri', desc:'Solve a right triangle (Pythagoras)', kind:'calc',
  fields:[{id:'a',label:'Side a',type:'number',value:3},{id:'b',label:'Side b',type:'number',value:4}],
  compute:v=>{const a=+v.a,b=+v.b;if(!a||!b)return'';const c=Math.sqrt(a*a+b*b);const area=(a*b)/2;const angA=Math.atan(a/b)*180/Math.PI;const angB=90-angA;
    return statBlock([['Hypotenuse (c)',round4(c)],['Area',round4(area)],['Angle A',round4(angA)+'°'],['Angle B',round4(angB)+'°']]);},
  info:'<h2>Right Triangle Calculator</h2><p>Given the two legs of a right triangle, calculates the hypotenuse, area and both acute angles using the Pythagorean theorem.</p>'},
// ---- India finance calculators ----
{id:'sip-calculator', name:'SIP Calculator', cat:'Calculator Tools', ab:'Sp', badge:'new', desc:'Estimate the future value of a monthly SIP', kind:'calc',
  fields:[{id:'m',label:'Monthly Investment',type:'number',value:5000},{id:'r',label:'Expected Annual Return (%)',type:'number',value:12,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:10}],
  compute:v=>{const P=+v.m,R=+v.r,Y=+v.y;if(!(P>0)||!(Y>0)||R<0)return'';const n=Y*12,i=R/12/100;const fv=i===0?P*n:P*((Math.pow(1+i,n)-1)/i)*(1+i);const inv=P*n;
    return statBlock([['Invested Amount',fmtMoney(inv)],['Estimated Returns',fmtMoney(fv-inv)],['Total Value',fmtMoney(fv)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes a constant return and investment at the start of each month. Real market returns vary and are not guaranteed.</p>';},
  info:'<h2>SIP Calculator</h2><p>A Systematic Investment Plan (SIP) invests a fixed amount every month. This calculator estimates the future value using monthly compounding.</p><p><strong>Formula:</strong> FV = P x ((1+i)^n - 1) / i x (1+i), where i is the monthly rate and n is the number of months.</p>'},
{id:'fd-calculator', name:'FD / Lumpsum Calculator', cat:'Calculator Tools', ab:'Fd', badge:'new', desc:'Maturity value of a fixed deposit or lumpsum', kind:'calc',
  fields:[{id:'p',label:'Principal',type:'number',value:100000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:7,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:5,step:0.5},{id:'q',label:'Compounding',type:'select',options:[['4','Quarterly'],['12','Monthly'],['2','Half-yearly'],['1','Yearly']]}],
  compute:v=>{const P=+v.p,R=+v.r,Y=+v.y,q=+v.q||4;if(!(P>0)||!(Y>0)||R<0)return'';const m=P*Math.pow(1+R/100/q,q*Y);
    return statBlock([['Principal',fmtMoney(P)],['Interest Earned',fmtMoney(m-P)],['Maturity Value',fmtMoney(m)]]);},
  info:'<h2>FD / Lumpsum Calculator</h2><p>Calculates the maturity value of a one-time investment with compound interest. Most Indian banks compound fixed deposits quarterly.</p><p><strong>Formula:</strong> A = P x (1 + r/q)^(q x t)</p>'},
{id:'ppf-calculator', name:'PPF Calculator', cat:'Calculator Tools', ab:'Pf', badge:'new', desc:'Estimate Public Provident Fund maturity', kind:'calc',
  fields:[{id:'a',label:'Yearly Deposit (max 150000)',type:'number',value:150000},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:7.1,step:0.1},{id:'y',label:'Years (minimum 15)',type:'number',value:15}],
  compute:v=>{const A=Math.min(+v.a,150000),R=+v.r,Y=+v.y;if(!(A>0)||!(Y>=15)||R<0)return'<div class="alert alert-warn">PPF has a minimum tenure of 15 years. Enter 15 or more.</div>';const r=R/100;const fv=r===0?A*Y:A*((Math.pow(1+r,Y)-1)/r)*(1+r);const inv=A*Y;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Total Interest',fmtMoney(fv-inv)],['Maturity Value',fmtMoney(fv)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes the deposit is made before the 5th of April each year and the rate stays constant. The government revises the PPF rate every quarter, so check the current rate.</p>';},
  info:'<h2>PPF Calculator</h2><p>The Public Provident Fund is a 15-year government-backed savings scheme in India. Interest is compounded yearly and the yearly deposit is capped at 1,50,000.</p>'},
{id:'cagr-calculator', name:'CAGR Calculator', cat:'Calculator Tools', ab:'Cg', badge:'new', desc:'Compound annual growth rate of an investment', kind:'calc',
  fields:[{id:'s',label:'Starting Value',type:'number',value:100000},{id:'e',label:'Ending Value',type:'number',value:250000},{id:'y',label:'Years',type:'number',value:5,step:0.5}],
  compute:v=>{const S=+v.s,E=+v.e,Y=+v.y;if(!(S>0)||!(E>0)||!(Y>0))return'';const c=(Math.pow(E/S,1/Y)-1)*100;
    return statBlock([['CAGR',c.toFixed(2)+'%'],['Total Growth',((E/S-1)*100).toFixed(2)+'%'],['Absolute Gain',fmtMoney(E-S)]]);},
  info:'<h2>CAGR Calculator</h2><p>CAGR is the steady yearly growth rate that takes an investment from its starting value to its ending value.</p><p><strong>Formula:</strong> CAGR = (Ending / Starting)^(1 / years) - 1</p>'},
{id:'income-tax-india', name:'Income Tax Calculator (India)', cat:'Calculator Tools', ab:'It', badge:'new', desc:'Compare old and new tax regime, FY 2026-27', kind:'calc',
  fields:[{id:'inc',label:'Annual Gross Income',type:'number',value:1500000},{id:'sal',label:'Salaried?',type:'select',options:[['1','Yes (standard deduction applies)'],['0','No']]},{id:'ded',label:'Deductions for old regime (80C, 80D, HRA etc.)',type:'number',value:150000}],
  compute:v=>{const inc=+v.inc,sal=v.sal==='1',ded=Math.max(0,+v.ded||0);if(!(inc>=0))return'';
    const slab=(t,sl)=>{let tax=0,prev=0;for(const [lim,rt] of sl){if(t>prev)tax+=(Math.min(t,lim)-prev)*rt;prev=lim;}return tax;};
    const NEW=[[400000,0],[800000,.05],[1200000,.10],[1600000,.15],[2000000,.20],[2400000,.25],[Infinity,.30]];
    const OLD=[[250000,0],[500000,.05],[1000000,.20],[Infinity,.30]];
    let tn=Math.max(0,inc-(sal?75000:0)); let xn=slab(tn,NEW); if(tn<=1200000) xn=0; else xn=Math.min(xn,tn-1200000); const cn=xn*0.04;
    let to=Math.max(0,inc-(sal?50000:0)-ded); let xo=slab(to,OLD); if(to<=500000) xo=0; const co=xo*0.04;
    const totN=xn+cn,totO=xo+co; const better=totN<=totO?'New regime':'Old regime'; const save=Math.abs(totN-totO);
    return statBlock([['New Regime Tax',fmtMoney(totN)],['Old Regime Tax',fmtMoney(totO)],['Better Option',better]])
      +`<div class="alert alert-info">${better} saves about ${fmtMoney(save)} for this income.</div>`
      +`<p style="font-size:12px;color:var(--tm);margin-top:10px">Taxable income: ${fmtMoney(tn)} (new), ${fmtMoney(to)} (old). Includes 4% cess and Section 87A rebate. Excludes surcharge (applies above 50 lakh), other income types and capital gains. This is an estimate for individuals under 60. Confirm with the Income Tax Department or a chartered accountant before filing.</p>`;},
  info:'<h2>Income Tax Calculator (India)</h2><p>Compares tax under the new and old regime for an individual under 60 for FY 2026-27 (AY 2027-28).</p><p><strong>New regime:</strong> no tax up to 4 lakh, then 5%, 10%, 15%, 20%, 25% and 30% above 24 lakh. Standard deduction 75,000 and Section 87A rebate up to 60,000 for taxable income up to 12 lakh.</p><p><strong>Old regime:</strong> no tax up to 2.5 lakh, then 5%, 20% and 30% above 10 lakh. Standard deduction 50,000, rebate up to 12,500 for taxable income up to 5 lakh.</p>'},
// ---- PDF tools (run in the browser using pdf-lib, loaded on demand) ----
{id:'pdf-merge', name:'Merge PDF', cat:'PDF Tools', ab:'Mg', badge:'new', desc:'Combine several PDF files into one', kind:'custom', info:'<h2>Merge PDF</h2><p>Select two or more PDF files, put them in the order you want and download one combined PDF. Files are processed on your device and are never uploaded.</p>'},
{id:'pdf-split', name:'Split / Extract PDF Pages', cat:'PDF Tools', ab:'Sx', badge:'new', desc:'Extract chosen pages from a PDF', kind:'custom', info:'<h2>Split / Extract PDF Pages</h2><p>Enter the pages you want, such as 1-3,5,8-10, and download a new PDF containing only those pages. Processing happens on your device.</p>'},
{id:'images-to-pdf', name:'Images to PDF', cat:'PDF Tools', ab:'Ip', badge:'new', desc:'Turn JPG and PNG images into one PDF', kind:'custom', info:'<h2>Images to PDF</h2><p>Add JPG or PNG images, arrange them and download a single PDF with one image per page. Nothing is uploaded.</p>'},
{id:'pdf-rotate', name:'Rotate PDF', cat:'PDF Tools', ab:'Rp', badge:'new', desc:'Rotate every page of a PDF', kind:'custom', info:'<h2>Rotate PDF</h2><p>Rotate all pages of a PDF by 90, 180 or 270 degrees and download the result. Processing happens on your device.</p>'},
// ---- more India finance calculators ----
{id:'hra-calculator', name:'HRA Exemption Calculator', cat:'Calculator Tools', ab:'Hr', badge:'new', desc:'Work out the tax-exempt part of your HRA', kind:'calc',
  fields:[{id:'b',label:'Basic Salary + DA (monthly)',type:'number',value:50000},{id:'h',label:'HRA Received (monthly)',type:'number',value:20000},{id:'r',label:'Rent Paid (monthly)',type:'number',value:18000},{id:'m',label:'City',type:'select',options:[['0.5','Metro (Delhi, Mumbai, Kolkata, Chennai)'],['0.4','Non-metro']]}],
  compute:v=>{const b=+v.b,h=+v.h,r=+v.r,p=+v.m;if(!(b>0)||h<0||r<0)return'';const a=h,c=Math.max(0,r-0.1*b),d=p*b;const ex=Math.max(0,Math.min(a,c,d));
    return statBlock([['Exempt HRA (monthly)',fmtMoney(ex)],['Exempt HRA (yearly)',fmtMoney(ex*12)],['Taxable HRA (yearly)',fmtMoney((h-ex)*12)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Exemption is the lowest of: actual HRA (${fmtMoney(a)}), rent paid minus 10% of basic (${fmtMoney(c)}), and ${p*100}% of basic (${fmtMoney(d)}). HRA exemption is available only under the old tax regime.</p>`;},
  info:'<h2>HRA Exemption Calculator</h2><p>If you receive House Rent Allowance and pay rent, part of it can be exempt from income tax under the old regime. The exempt amount is the lowest of three figures: the HRA you actually receive, rent paid minus 10% of salary, and 50% (metro) or 40% (non-metro) of salary.</p>'},
{id:'gratuity-calculator', name:'Gratuity Calculator', cat:'Calculator Tools', ab:'Gr', badge:'new', desc:'Estimate gratuity payable on leaving a job', kind:'calc',
  fields:[{id:'s',label:'Last Drawn Basic + DA (monthly)',type:'number',value:60000},{id:'y',label:'Years of Service',type:'number',value:8},{id:'m',label:'Extra Months',type:'number',value:7}],
  compute:v=>{const S=+v.s,Y=Math.floor(+v.y),M=Math.floor(+v.m)||0;if(!(S>0)||!(Y>=0))return'';if(Y<5)return'<div class="alert alert-warn">Gratuity is generally payable only after 5 years of continuous service.</div>';const yrs=Y+(M>=6?1:0);const g=15/26*S*yrs;const cap=2000000;
    return statBlock([['Years Counted',String(yrs)],['Gratuity (formula)',fmtMoney(g)],['Payable (cap 20 lakh)',fmtMoney(Math.min(g,cap))]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Formula for employees covered by the Payment of Gratuity Act: last drawn salary x 15 / 26 x completed years, with 6 months or more rounded up. Your employer\'s policy may be more generous.</p>';},
  info:'<h2>Gratuity Calculator</h2><p>Gratuity is a lump sum paid by an employer after at least 5 years of service. For employees covered by the Payment of Gratuity Act it equals last drawn monthly basic plus DA, multiplied by 15/26, multiplied by completed years of service.</p>'},
{id:'swp-calculator', name:'SWP Calculator', cat:'Calculator Tools', ab:'Sw', badge:'new', desc:'See how long a corpus lasts with monthly withdrawals', kind:'calc',
  fields:[{id:'c',label:'Starting Corpus',type:'number',value:2000000},{id:'w',label:'Monthly Withdrawal',type:'number',value:15000},{id:'r',label:'Expected Annual Return (%)',type:'number',value:8,step:0.1},{id:'y',label:'Withdrawal Period (years)',type:'number',value:15}],
  compute:v=>{const C=+v.c,W=+v.w,R=+v.r,Y=+v.y;if(!(C>0)||!(W>0)||!(Y>0)||R<0)return'';const i=R/12/100;let bal=C,months=0,drawn=0;for(let k=1;k<=Y*12;k++){bal=bal*(1+i);const take=Math.min(W,bal);bal-=take;drawn+=take;months=k;if(bal<=0.005){bal=0;break;}}
    const lasted=bal<=0&&months<Y*12;return statBlock([['Total Withdrawn',fmtMoney(drawn)],['Final Balance',fmtMoney(bal)],['Lasts For',lasted?(Math.floor(months/12)+' yr '+(months%12)+' mo'):(Y+' yr (full period)')]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Assumes a constant return and withdrawals at the end of each month. Real returns vary, and taxes are not included.</p>';},
  info:'<h2>SWP Calculator</h2><p>A Systematic Withdrawal Plan takes a fixed amount from an investment every month. The calculator shows the balance left after your chosen period and how long the corpus lasts if you withdraw too much.</p>'},
{id:'stepup-sip-calculator', name:'Step-up SIP Calculator', cat:'Calculator Tools', ab:'Ss', badge:'new', desc:'SIP that grows by a fixed percentage every year', kind:'calc',
  fields:[{id:'m',label:'Starting Monthly Investment',type:'number',value:5000},{id:'s',label:'Yearly Step-up (%)',type:'number',value:10,step:0.5},{id:'r',label:'Expected Annual Return (%)',type:'number',value:12,step:0.1},{id:'y',label:'Time Period (years)',type:'number',value:10}],
  compute:v=>{const P=+v.m,S=+v.s,R=+v.r,Y=Math.floor(+v.y);if(!(P>0)||!(Y>0)||R<0||S<0)return'';const i=R/12/100;let bal=0,inv=0,cur=P;for(let k=0;k<Y*12;k++){if(k>0&&k%12===0)cur*=1+S/100;bal=(bal+cur)*(1+i);inv+=cur;}
    return statBlock([['Invested Amount',fmtMoney(inv)],['Estimated Returns',fmtMoney(bal-inv)],['Total Value',fmtMoney(bal)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Investment is assumed at the start of each month and the amount rises once a year. Market returns are not guaranteed.</p>';},
  info:'<h2>Step-up SIP Calculator</h2><p>A step-up SIP raises your monthly investment by a fixed percentage every year, usually in line with your salary. This usually builds a much larger corpus than a flat SIP over the same period.</p>'},
{id:'loan-prepayment-calculator', name:'Loan Prepayment Calculator', cat:'Calculator Tools', ab:'Lp', badge:'new', desc:'Interest saved by prepaying part of a loan', kind:'calc',
  fields:[{id:'p',label:'Loan Amount',type:'number',value:3000000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:8.5,step:0.05},{id:'n',label:'Tenure (months)',type:'number',value:240},{id:'k',label:'Prepay After Month',type:'number',value:24},{id:'a',label:'Prepayment Amount',type:'number',value:300000}],
  compute:v=>{const P=+v.p,R=+v.r,N=Math.floor(+v.n),K=Math.floor(+v.k),A=+v.a;if(!(P>0)||!(N>0)||R<0||!(K>=0)||A<0||K>=N)return'';const i=R/12/100;const emi=i===0?P/N:P*i*Math.pow(1+i,N)/(Math.pow(1+i,N)-1);const base=emi*N-P;
    let bal=P,int=0,m=0;while(bal>0.005&&m<N*2){const it=bal*i;int+=it;bal=bal+it-emi;m++;if(m===K){bal=Math.max(0,bal-A);}}if(bal<0)bal=0;const saved=base-int;
    return statBlock([['Monthly EMI',fmtMoney(emi)],['Interest Saved',fmtMoney(saved)],['Months Saved',String(N-m)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Without prepayment you pay ${fmtMoney(base)} interest over ${N} months. With it, the loan ends in ${m} months and costs ${fmtMoney(int)} interest. The EMI stays the same and the tenure shortens. Check your lender for prepayment charges.</p>`;},
  info:'<h2>Loan Prepayment Calculator</h2><p>Paying part of your loan early, while keeping the EMI the same, shortens the tenure and cuts the total interest. Enter your loan, the month you plan to prepay and the amount to see the saving.</p>'},
{id:'rd-calculator', name:'RD Calculator', cat:'Calculator Tools', ab:'Rd', badge:'new', desc:'Maturity value of a recurring deposit', kind:'calc',
  fields:[{id:'d',label:'Monthly Deposit',type:'number',value:5000},{id:'r',label:'Annual Interest Rate (%)',type:'number',value:6.5,step:0.1},{id:'n',label:'Tenure (months)',type:'number',value:60}],
  compute:v=>{const D=+v.d,R=+v.r,N=Math.floor(+v.n);if(!(D>0)||!(N>0)||R<0)return'';const q=R/400;let mat=0;for(let k=0;k<N;k++){mat+=D*Math.pow(1+q,(N-k)/3);}const inv=D*N;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Interest Earned',fmtMoney(mat-inv)],['Maturity Value',fmtMoney(mat)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Uses quarterly compounding, which most Indian banks follow. Your bank may round differently, so the final figure can vary slightly.</p>';},
  info:'<h2>RD Calculator</h2><p>A Recurring Deposit lets you save a fixed amount every month at a fixed interest rate. This calculator uses quarterly compounding, as most Indian banks do.</p>'},
// ---- more India finance calculators ----
{id:'nps-calculator', name:'NPS Calculator', cat:'Calculator Tools', ab:'Np', badge:'new', desc:'Estimate NPS corpus, lump sum and monthly pension', kind:'calc',
  fields:[{id:'m',label:'Monthly Contribution',type:'number',value:5000},{id:'a',label:'Current Age',type:'number',value:30},{id:'ra',label:'Retirement Age',type:'number',value:60},{id:'r',label:'Expected Annual Return (%)',type:'number',value:10,step:0.1},{id:'an',label:'Share of Corpus Used for Annuity (%)',type:'number',value:40,step:1},{id:'ar',label:'Annuity Rate (% p.a.)',type:'number',value:6,step:0.1}],
  compute:v=>{const M=+v.m,A=Math.floor(+v.a),RA=Math.floor(+v.ra),R=+v.r,AN=+v.an,AR=+v.ar;if(!(M>0)||!(RA>A)||!(A>=0)||R<0||!(AN>=0&&AN<=100)||AR<0)return'';const n=(RA-A)*12,i=R/12/100;const fv=i===0?M*n:M*((Math.pow(1+i,n)-1)/i)*(1+i);const inv=M*n;const ann=fv*AN/100,lump=fv-ann;const pen=ann*AR/100/12;
    return statBlock([['Total Corpus',fmtMoney(fv)],['Lump Sum at Retirement',fmtMoney(lump)],['Monthly Pension',fmtMoney(pen)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">You invest ${fmtMoney(inv)} in total over ${RA-A} years. Assumes a constant return and a deposit at the start of each month. The minimum annuity share and the tax treatment of the lump sum are set by PFRDA and the Income Tax Act and have changed in the past, so check the current rules.</p>`;},
  info:'<h2>NPS Calculator</h2><p>The National Pension System is a market-linked retirement scheme in India. This calculator projects your corpus from a monthly contribution, then splits it into a lump sum and an annuity that pays a monthly pension.</p><p>Returns are not guaranteed. Change the return and annuity inputs to see how sensitive the result is.</p>'},
{id:'epf-calculator', name:'EPF Calculator', cat:'Calculator Tools', ab:'Ep', badge:'new', desc:'Estimate your EPF balance at retirement', kind:'calc',
  fields:[{id:'b',label:'Monthly Basic + DA',type:'number',value:30000},{id:'a',label:'Current Age',type:'number',value:30},{id:'ra',label:'Retirement Age',type:'number',value:58},{id:'g',label:'Yearly Salary Growth (%)',type:'number',value:5,step:0.5},{id:'r',label:'EPF Interest Rate (% p.a.)',type:'number',value:8.25,step:0.05},{id:'cur',label:'Current EPF Balance',type:'number',value:0}],
  compute:v=>{let B=+v.b;const A=Math.floor(+v.a),RA=Math.floor(+v.ra),G=+v.g,R=+v.r;let bal=Math.max(0,+v.cur||0);if(!(B>0)||!(RA>A)||G<0||R<0)return'';let emp=0,er=0,intr=0;for(let y=0;y<RA-A;y++){let acc=0;for(let m=0;m<12;m++){const e=B*0.12;const eps=Math.min(0.0833*Math.min(B,15000),1250);const c=B*0.12-eps;acc+=bal*R/100/12;bal+=e+c;emp+=e;er+=c;}bal+=acc;intr+=acc;B*=1+G/100;}
    return statBlock([['Estimated Balance',fmtMoney(bal)],['Your Contribution',fmtMoney(emp)],['Employer Contribution',fmtMoney(er)]])+`<p style="font-size:12px;color:var(--tm);margin-top:10px">Interest earned: ${fmtMoney(intr)}. You contribute 12% of basic, and the employer puts 12% too, of which 8.33% of wages up to 15,000 (maximum 1,250 a month) goes to the pension scheme (EPS) and the rest to your EPF. Interest is worked out monthly and credited yearly. The EPF rate is declared every year, so treat this as an estimate.</p>`;},
  info:'<h2>EPF Calculator</h2><p>The Employees\' Provident Fund collects 12% of your basic pay from you and 12% from your employer. Part of the employer share goes to the Employees\' Pension Scheme, so only the remainder adds to your EPF balance.</p><p>Enter your basic pay plus dearness allowance, your expected salary growth and the interest rate to estimate the balance at retirement.</p>'},
{id:'home-loan-eligibility', name:'Home Loan Eligibility Calculator', cat:'Calculator Tools', ab:'He', badge:'new', desc:'How much home loan your income can support', kind:'calc',
  fields:[{id:'inc',label:'Monthly Net Income',type:'number',value:100000},{id:'emi',label:'Existing Monthly EMIs',type:'number',value:10000},{id:'f',label:'Share of Income Lenders Allow for EMIs (%)',type:'number',value:50,step:1},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:8.5,step:0.05},{id:'y',label:'Tenure (years)',type:'number',value:20}],
  compute:v=>{const I=+v.inc,E=Math.max(0,+v.emi||0),F=+v.f,R=+v.r,Y=+v.y;if(!(I>0)||!(F>0&&F<=100)||R<0||!(Y>0))return'';const cap=I*F/100-E;if(cap<=0)return'<div class="alert alert-warn">Your existing EMIs already use up the share of income lenders allow, so no new EMI fits.</div>';const n=Y*12,i=R/12/100;const loan=i===0?cap*n:cap*(1-Math.pow(1+i,-n))/i;const pay=cap*n;
    return statBlock([['Eligible Loan',fmtMoney(loan)],['Affordable EMI',fmtMoney(cap)],['Total Interest',fmtMoney(pay-loan)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">A rough guide only. Banks also look at your credit score, age, job type, property value and other debts, so the offer you get can be lower or higher.</p>';},
  info:'<h2>Home Loan Eligibility Calculator</h2><p>Lenders limit your total monthly EMIs to a share of your income, often around 40% to 55%. This calculator takes that share, subtracts your current EMIs and works out the loan that the remaining EMI can repay over your chosen tenure.</p>'},
{id:'ssy-calculator', name:'Sukanya Samriddhi Calculator', cat:'Calculator Tools', ab:'Sy', badge:'new', desc:'Estimate Sukanya Samriddhi Yojana maturity', kind:'calc',
  fields:[{id:'a',label:'Yearly Deposit (250 to 150000)',type:'number',value:150000},{id:'r',label:'Interest Rate (% p.a.)',type:'number',value:8.2,step:0.1}],
  compute:v=>{const A=+v.a,R=+v.r;if(!(A>=250)||A>150000||R<0)return'<div class="alert alert-warn">Enter a yearly deposit between 250 and 1,50,000.</div>';let bal=0;for(let y=1;y<=21;y++){if(y<=15)bal+=A;bal+=bal*R/100;}const inv=A*15;
    return statBlock([['Total Deposited',fmtMoney(inv)],['Total Interest',fmtMoney(bal-inv)],['Maturity Value (Year 21)',fmtMoney(bal)]])+'<p style="font-size:12px;color:var(--tm);margin-top:10px">Deposits are made for 15 years and the account matures in year 21. Assumes the full deposit is made before the 5th of April each year and a constant rate. The rate is reset by the government every quarter, so use the current rate.</p>';},
  info:'<h2>Sukanya Samriddhi Calculator</h2><p>Sukanya Samriddhi Yojana is a small savings scheme for the girl child in India. You deposit for 15 years and the account matures 21 years after opening. Interest is compounded yearly.</p>'},
{id:'inflation-calculator', name:'Inflation Calculator', cat:'Calculator Tools', ab:'If', badge:'new', desc:'See what today\'s money will cost or buy later', kind:'calc',
  fields:[{id:'c',label:'Amount Today',type:'number',value:100000},{id:'i',label:'Yearly Inflation (%)',type:'number',value:6,step:0.1},{id:'y',label:'Years',type:'number',value:10}],
  compute:v=>{const C=+v.c,I=+v.i,Y=+v.y;if(!(C>0)||I<0||!(Y>0))return'';const f=C*Math.pow(1+I/100,Y),p=C/Math.pow(1+I/100,Y);
    return statBlock([['Same Things Will Cost',fmtMoney(f)],['Today\'s Amount Will Buy Only',fmtMoney(p)],['Loss in Buying Power',((1-p/C)*100).toFixed(1)+'%']]);},
  info:'<h2>Inflation Calculator</h2><p>Inflation makes the same things cost more every year. Enter an amount, a yearly inflation rate and a number of years to see what the same basket of goods will cost, and how much of today\'s money\'s buying power is lost.</p><p><strong>Formula:</strong> Future cost = Amount x (1 + inflation)^years</p>'},
// ---- more image and PDF tools ----
{id:'webp-converter', name:'WebP Converter', cat:'Image Tools', ab:'Wp', badge:'new', desc:'Convert images to or from WebP', kind:'custom', info:'<h2>WebP Converter</h2><p>Convert JPG or PNG images to the smaller WebP format, or turn WebP back into JPG or PNG. Everything happens in your browser and nothing is uploaded.</p>'},
{id:'pdf-to-jpg', name:'PDF to JPG', cat:'PDF Tools', ab:'Pj', badge:'new', desc:'Turn each PDF page into an image', kind:'custom', info:'<h2>PDF to JPG</h2><p>Render every page of a PDF as a JPG image and download them one by one. The PDF stays on your device.</p>'},
{id:'pdf-delete-pages', name:'Delete PDF Pages', cat:'PDF Tools', ab:'Pd2', badge:'new', desc:'Remove unwanted pages from a PDF', kind:'custom', info:'<h2>Delete PDF Pages</h2><p>Enter the pages you want to remove, such as 2,4-6, and download the PDF without them.</p>'},
{id:'pdf-page-numbers', name:'Add Page Numbers to PDF', cat:'PDF Tools', ab:'Pn', badge:'new', desc:'Stamp page numbers on every page', kind:'custom', info:'<h2>Add Page Numbers to PDF</h2><p>Add "Page 1 of N" style numbers at the bottom of every page and download the new PDF.</p>'},

];
