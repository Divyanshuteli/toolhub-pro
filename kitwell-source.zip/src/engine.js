// ============================================================
// TOOLHUB PRO - Engine: navigation, rendering, search, templates
// ============================================================

// ---------- TOAST / COPY ----------
function toast(msg, type=''){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast on${type ? ' '+type+'-t' : ''}`;
  setTimeout(() => el.classList.remove('on'), 2600);
}
function copyText(text, btn){
  navigator.clipboard.writeText(text).then(() => {
    toast('Copied to clipboard', 'ok');
    if (btn) { const o=btn.textContent; btn.textContent='Copied'; btn.classList.add('copied'); setTimeout(()=>{btn.textContent=o;btn.classList.remove('copied')},1600); }
  }).catch(() => {
    const t = document.createElement('textarea');
    t.value = text; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t);
    toast('Copied', 'ok');
  });
}

// ---------- NAVIGATION ----------
const LANG = document.documentElement.lang==='hi' ? 'hi' : 'en';
const HOME = LANG==='hi' ? '/hi/' : '/';
const TOOLP = LANG==='hi' ? '/hi/tools/' : '/tools/';
let currentPage = 'home';
let navStack = [];
let currentView = 'home';
function navigate(page, opts){
  opts = opts || {};
  const view = page==='generic-tool' ? (opts.toolId||page) : page;
  if (!opts.back && !opts.noPush && currentView !== view) navStack.push(currentView);
  currentView = view;
  document.querySelectorAll('.page').forEach(p => { p.classList.remove('active'); p.style.display='none'; });
  const el = document.getElementById('pg-' + page);
  if (el) { el.classList.add('active'); el.style.display='block'; currentPage = page; }
  window.scrollTo(0,0); document.documentElement.scrollTop=0; document.body.scrollTop=0;
  closeMenu();
  document.querySelectorAll('.hnav a').forEach(a => a.classList.remove('act'));
  const na = document.getElementById('nav-' + page); if (na) na.classList.add('act');
  if (history && history.pushState && !opts.noHash) {
    const toolId = opts.toolId || page;
    const isTool = !!TOOLS.find(t=>t.id===toolId);
    if (USE_PATH) {
      const path = page==='home' ? HOME : (isTool ? TOOLP+toolId+'/' : '/'+page+'/');
      if (location.pathname !== path || location.hash) history.pushState({i:histIdx()+1},'', path);
    } else {
      const hash = page==='home' ? '' : (isTool ? '#tool='+toolId : '#page='+page);
      if (location.hash !== hash) history.pushState({i:histIdx()+1},'', location.pathname + hash);
    }
  }
  if (LANG==='hi') document.documentElement.lang = (page==='home' || TOOLS.find(x=>x.id===(opts.toolId||page))) ? 'hi' : 'en';
  updateMeta(page, opts.toolId);
  if (opts.toolId || TOOLS.find(t=>t.id===page)) { const id = opts.toolId || page; trackRecent(id); ensureActions(id); track('tool_open',{tool_id:id}); }
  const hs = document.getElementById('homeShelf'); if (hs && page==='home') renderShelf();
  fixLabels(document.querySelector('.page.active'));
}
const USE_PATH = /^https?:$/.test(location.protocol);
const PAGE_TITLES = {home: LANG==='hi' ? 'Kitwell | 150+ मुफ्त ऑनलाइन टूल्स' : 'Kitwell | 150+ Free Online Tools', about:'About Kitwell', contact:'Contact Kitwell', privacy:'Privacy Policy | Kitwell', terms:'Terms and Conditions | Kitwell', disclaimer:'Disclaimer | Kitwell'};
function updateLangLink(page, toolId){
  const a=document.getElementById('langBtn'); if(!a||!USE_PATH) return;
  const t=TOOLS.find(x=>x.id===(toolId||page)); const to = LANG==='hi' ? '' : '/hi';
  let href;
  if (t) href = to+'/tools/'+t.id+'/';
  else if (page==='home') { const m=location.pathname.match(/\/category\/([a-z-]+)\/?$/); href = m ? to+'/category/'+m[1]+'/' : (LANG==='hi' ? '/' : '/hi/'); }
  else href = LANG==='hi' ? '/' : '/hi/';
  a.setAttribute('href', href);
}
function addGuideLink(tool){
  const pg=document.querySelector('.page.active'); if(!pg||!tool) return;
  const hd=pg.querySelector('.tool-hd'); if(!hd) return;
  const old=hd.querySelector('.glink'); if(old) old.remove();
  const g=GUIDE_BY_TOOL[tool.id]; if(!g||LANG==='hi'||!USE_PATH) return;
  const a=document.createElement('a'); a.className='glink'; a.href='/guides/'+g.slug+'/'; a.textContent='Guide: '+g.title; hd.appendChild(a);
}
function hiTitles(tool){
  if (LANG!=='hi' || !tool) return;
  const pg=document.querySelector('.page.active'); if(!pg) return;
  const h=pg.querySelector('.tool-hd h1'), d=pg.querySelector('.tool-hd p');
  if (h) h.textContent = trN(tool); if (d) d.textContent = trD(tool);
  const bc=pg.querySelectorAll('.bc > a'); if (bc[0]) bc[0].textContent='वापस'; if (bc[1]) bc[1].textContent='होम';
}
function updateMeta(page, toolId){
  const t = TOOLS.find(x=>x.id===(toolId||page));
  document.title = t ? (LANG==='hi' ? `${trN(t)}: मुफ्त ऑनलाइन टूल | Kitwell` : `${t.name}: Free Online Tool | Kitwell`) : (PAGE_TITLES[page] || PAGE_TITLES.home);
  if (USE_PATH) { const c=document.querySelector('link[rel=canonical]'); if (c) c.href = location.origin + (t && /^\/embed\//.test(location.pathname) ? '/tools/'+t.id+'/' : location.pathname);
  updateLangLink(page, toolId); if (/^\/embed\//.test(location.pathname)) { const r=document.querySelector('meta[name=robots]'); if (r) r.content='noindex, follow'; } }
}
// ---------- FAVOURITES / RECENT (per-browser, localStorage) ----------
function lsGet(k){ try{ return JSON.parse(localStorage.getItem(k)||'[]'); }catch(e){ return []; } }
function lsSet(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function trackRecent(id){ const r = lsGet('th-recent').filter(x=>x!==id); r.unshift(id); lsSet('th-recent', r.slice(0,8)); }
function isFav(id){ return lsGet('th-fav').includes(id); }
function toggleFav(id){
  let f = lsGet('th-fav'); f = f.includes(id) ? f.filter(x=>x!==id) : [id].concat(f);
  lsSet('th-fav', f.slice(0,24)); ensureActions(id); toast(f.includes(id)?'Saved to your tools':'Removed from your tools');
}
function shareTool(id){
  const url = USE_PATH ? location.origin + TOOLP + id + '/' + (currentView===id ? location.search : '') : location.href;
  const t = TOOLS.find(x=>x.id===id);
  if (navigator.share) { navigator.share({title:t?t.name:'Kitwell', url}).catch(()=>{}); }
  else copyText(url);
}
function downloadOutput(id){
  const root = document.querySelector('.page.active');
  if (!root) return;
  const parts = [];
  root.querySelectorAll('textarea[readonly], .res-box, .sgrid, #gtBody textarea[id$="out"], #gtBody textarea[id*="output"], pre.out').forEach(el => { const v = (el.value!==undefined && el.tagName==='TEXTAREA') ? el.value : el.innerText; if (v && v.trim()) parts.push(v.trim()); });
  if (!parts.length) { toast('Nothing to download yet', 'err'); return; }
  const blob = new Blob([parts.join('\n\n')+'\n'], {type:'text/plain'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = id + '-result.txt';
  document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function ensureActions(id){
  const root = document.querySelector('.page.active'); if (!root) return;
  const bc = root.querySelector('.bc'); if (!bc) return;
  let box = bc.querySelector('.tact'); if (!box) { box = document.createElement('div'); box.className='tact'; bc.appendChild(box); }
  const fav = isFav(id);
  box.innerHTML = `<button type="button" class="tbtn${fav?' on':''}" onclick="toggleFav('${id}')" aria-pressed="${fav}">${svgIcon('star',15)}<span>${fav?'Saved':'Save'}</span></button>`
    + `<button type="button" class="tbtn" onclick="shareTool('${id}')">${svgIcon('share',15)}<span>Share</span></button>`
    + (USE_PATH ? `<button type="button" class="tbtn" onclick="showEmbed('${id}')">${svgIcon('code',15)}<span>Embed</span></button>` : '')
    + `<button type="button" class="tbtn" onclick="downloadOutput('${id}')">${svgIcon('ui_down',15)}<span>Download</span></button>`
    + ((TOOLS.find(x=>x.id===id)||{}).kind==='calc' ? `<button type="button" class="tbtn" onclick="saveResult('${id}')">${svgIcon('ui_check',15)}<span>${LANG==='hi'?'नतीजा सेव':'Save result'}</span></button><button type="button" class="tbtn" onclick="shareCard('${id}')">${svgIcon('image',15)}<span>${LANG==='hi'?'इमेज':'Image'}</span></button>` : '');
  if (typeof renderSaved==='function') renderSaved(id);
}
function showEmbed(id){
  const t = TOOLS.find(x=>x.id===id); if(!t) return;
  const src = location.origin + '/embed/' + id + '/';
  const code = `<iframe src="${src}" width="100%" height="620" style="border:1px solid #e2e8f0;border-radius:12px" loading="lazy" title="${t.name}"></iframe>`;
  let d = document.getElementById('embedDlg'); if (d) d.remove();
  d = document.createElement('div'); d.id='embedDlg'; d.className='dlg'; d.setAttribute('role','dialog'); d.setAttribute('aria-modal','true'); d.setAttribute('aria-label','Embed this tool');
  d.innerHTML = `<div class="dlg-ov" onclick="document.getElementById('embedDlg').remove()"></div><div class="dlg-bx"><div class="dlg-hd"><h3>Embed ${esc(t.name)}</h3><button type="button" class="mclose dlg-x" onclick="document.getElementById('embedDlg').remove()" aria-label="Close">${svgIcon('ui_close',18)}</button></div><p style="font-size:13px;color:var(--t2);margin-bottom:10px">Paste this on your website or blog. The tool runs inside the frame and links back to Kitwell.</p><textarea class="fc mono" id="embedCode" rows="4" readonly>${esc(code)}</textarea><div style="display:flex;gap:8px;margin-top:12px"><button type="button" class="btn btn-p btn-sm" onclick="copyText(document.getElementById('embedCode').value,this)">Copy code</button><a class="btn btn-s btn-sm" href="${src}" target="_blank" rel="noopener">Preview</a></div></div>`;
  document.body.appendChild(d); const ta=d.querySelector('textarea'); if(ta){ ta.focus(); ta.select(); }
}
function renderShelf(){
  const el = document.getElementById('homeShelf'); if (!el) return;
  const favs = lsGet('th-fav').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean);
  const rec = lsGet('th-recent').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean).filter(t=>!favs.includes(t)).slice(0,6);
  const chip = t => `<a class="shc" href="${USE_PATH?TOOLP+t.id+'/':'#tool='+t.id}" onclick="event.preventDefault();openTool('${t.id}')">${toolIconSvg(t,16)}<span>${esc(trN(t))}</span></a>`;
  let h='';
  if (favs.length) h += `<div class="shr"><div class="shl">${LANG==="hi"?"सेव किए":"Saved"}</div><div class="shg">${favs.map(chip).join('')}</div></div>`;
  if (rec.length) h += `<div class="shr"><div class="shl">${LANG==="hi"?"हाल में इस्तेमाल किए":"Recently used"}</div><div class="shg">${rec.map(chip).join('')}</div></div>`;
  el.innerHTML = h; el.style.display = h ? '' : 'none';
}
// ---------- THEME ----------
function openMenu(){ const m=document.getElementById('mnav'); if(!m) return; m.classList.add('on'); document.body.style.overflow='hidden'; const b=document.getElementById('mtog'); if(b) b.setAttribute('aria-expanded','true'); setTimeout(()=>{const c=m.querySelector('.mclose'); if(c) c.focus();},60); }
function closeMenu(){ const m=document.getElementById('mnav'); if(!m) return; m.classList.remove('on'); document.body.style.overflow=''; const b=document.getElementById('mtog'); if(b){ b.setAttribute('aria-expanded','false'); } }
document.addEventListener('keydown', e => { if (e.key==='Escape') closeMenu(); });
function setTheme(t){
  if (t==='dark') document.documentElement.setAttribute('data-theme','dark'); else document.documentElement.removeAttribute('data-theme');
  try{ localStorage.setItem('th-theme', t); }catch(e){}
  ['themeBtn','themeBtn2'].forEach((id,i)=>{ const b = document.getElementById(id); if (b) { b.innerHTML = svgIcon(t==='dark'?'ui_sun':'ui_moon',17) + (i?'<span>'+(t==='dark'?'Light theme':'Dark theme')+'</span>':''); b.setAttribute('aria-label', t==='dark'?'Switch to light theme':'Switch to dark theme'); } });
}
function toggleTheme(){ setTheme(document.documentElement.getAttribute('data-theme')==='dark' ? 'light' : 'dark'); }
function fixLabels(root){
  (root||document).querySelectorAll('label.fl').forEach(l=>{
    if (l.hasAttribute('for') || l.querySelector('input,select,textarea')) return;
    const c=l.parentElement && l.parentElement.querySelector('input:not([type=hidden]),select,textarea'); if(!c) return;
    if(!c.id) c.id='fld-'+Math.random().toString(36).slice(2,8); l.setAttribute('for', c.id);
  });
}
function histIdx(){ return (history.state && history.state.i) || 0; }
function goBack(){
  if (history && histIdx() > 0) { navStack.pop(); history.back(); return; }
  navStack = []; navigate('home');
}
function nav2(page){ navigate(page); }

function openTool(id, opts){
  try{
    const tool = TOOLS.find(t => t.id === id);
    if (!tool) return;
    if (tool.kind === 'dedicated') { navigate(id, opts); if (typeof setupToolPage === 'function') setupToolPage(id); hiTitles(tool); addGuideLink(tool); return; }
    renderGenericTool(tool, opts); hiTitles(tool); addGuideLink(tool);
  } catch(e){ console.error('openTool error:', e); }
}
function scrollToCat(id){ setTimeout(()=>{ const el=document.getElementById('cat-'+id); if (el) el.scrollIntoView({behavior:'smooth',block:'start'}); }, 80); }

// ---------- CATEGORY ICON ----------
function catIcon(cat, size){
  const cfg = CAT_CONFIG[cat] || {ab:'?',bg:'#64748B'};
  return `<div style="background:${cfg.bg};width:${size}px;height:${size}px;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0">${catIconSvg(cat, Math.round(size*0.55))}</div>`;
}

// ---------- HOME RENDER ----------
function trN(t){ return LANG==='hi' && HI_TOOLS[t.id] ? HI_TOOLS[t.id].n : t.name; }
function trD(t){ return LANG==='hi' && HI_TOOLS[t.id] ? HI_TOOLS[t.id].d : t.desc; }
function switchLang(e){ if(!USE_PATH) return false; return true; }
function renderHome(){
  const area = document.getElementById('toolsArea');
  if (!area) return;
  const cats = Object.keys(CAT_CONFIG);
  let html = '';
  cats.forEach(cat => {
    const cfg = CAT_CONFIG[cat];
    const catTools = TOOLS.filter(t => t.cat === cat);
    if (!catTools.length) return;
    html += `
      <section class="cat-sec" id="cat-${cfg.id}" data-cat="${cat}">
        <div class="cat-hd">
          ${catIcon(cat,38)}
          <div><h2>${LANG==='hi'?(HI_CAT[cat]||cat):cat}</h2><p>${LANG==='hi' ? catTools.length+' '+HI_UI.tools+': '+esc(HI_CAT_USE[cat]||'') : catTools.length+' tools for '+esc(CAT_USE[cat]||'everyday use')}</p></div>
        </div>
        <div class="tgrid">
          ${catTools.map(t => `
            <div class="tc" role="link" tabindex="0" onclick="openTool('${t.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openTool('${t.id}')}">
              <div class="tc-ic" style="background:${cfg.bg}">${toolIconSvg(t,20)}</div>
              <div class="tc-nm">${esc(trN(t))}</div>
              <div class="tc-ds">${esc(trD(t))}</div>
              ${t.badge ? `<span class="tc-bd ${t.badge==='pop'?'bd-pop':'bd-new'}">${LANG==='hi'?(t.badge==='pop'?'लोकप्रिय':'नया'):(t.badge==='pop'?'Popular':'New')}</span>` : ''}
            </div>
          `).join('')}
        </div>
      </section>`;
  });
  area.innerHTML = html;
}
function filterCat(cat, btn){
  document.querySelectorAll('.cb').forEach(b => b.classList.remove('act'));
  btn.classList.add('act');
  if (typeof USE_PATH!=='undefined' && USE_PATH && history.pushState){ const path = cat==='all' ? HOME : HOME+'category/'+catSlug(cat)+'/'; if (location.pathname!==path) history.pushState({i:histIdx()+1},'',path); document.title = cat==='all' ? PAGE_TITLES.home : (LANG==='hi' ? (HI_CAT[cat]||cat)+': मुफ्त ऑनलाइन टूल्स | Kitwell' : cat+': Free Online Tools | Kitwell'); }
  document.querySelectorAll('.cat-sec').forEach(s => { s.style.display = (cat==='all' || s.dataset.cat===cat) ? '' : 'none'; });
  updateLangLink('home');
}
function renderRelated(containerId, cat, currentName, limit=6){
  const el = document.getElementById(containerId);
  if (!el) return;
  const cur = TOOLS.find(t => t.name === currentName);
  let related = ((cur && RELATED[cur.id]) || []).map(id => TOOLS.find(t => t.id === id)).filter(Boolean);
  if (related.length < limit) {
    const have = new Set(related.map(t => t.id).concat(cur ? [cur.id] : []));
    related = related.concat(TOOLS.filter(t => t.cat === cat && !have.has(t.id) && t.name !== currentName).sort((x,y)=>x.id<y.id?-1:1));
  }
  related = related.slice(0, limit);
  el.innerHTML = related.map(t => `
    <div class="tc" role="link" tabindex="0" onclick="openTool('${t.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openTool('${t.id}')}">
      <div class="tc-ic" style="background:${CAT_CONFIG[t.cat].bg}">${toolIconSvg(t,20)}</div>
      <div class="tc-nm">${esc(trN(t))}</div>
      <div class="tc-ds">${esc(trD(t))}</div>
    </div>`).join('');
}

// ---------- SEARCH ----------
function lev1(a,b){ if(a===b) return true; if(Math.abs(a.length-b.length)>1) return false; let i=0,j=0,d=0; while(i<a.length&&j<b.length){ if(a[i]===b[j]){i++;j++;continue;} if(++d>1) return false; if(a.length>b.length) i++; else if(a.length<b.length) j++; else {i++;j++;} } return d + (a.length-i) + (b.length-j) <= 1; }
function searchTools(q, limit){
  q = q.trim().toLowerCase(); if (q.length<2) return [];
  const toks = q.split(/\s+/).filter(Boolean);
  const scored = [];
  TOOLS.forEach(t => {
    const hi = LANG==='hi' && HI_TOOLS[t.id] ? (HI_TOOLS[t.id].n+' '+HI_TOOLS[t.id].d).toLowerCase() : '';
    const name=t.name.toLowerCase(), hay=(name+' '+t.desc.toLowerCase()+' '+t.cat.toLowerCase()+' '+t.id.replace(/-/g,' ')+' '+hi);
    const words=hay.split(/[^a-z0-9\u0900-\u097f]+/).filter(Boolean);
    let score=0, all=true;
    toks.forEach(tok => {
      if (name.startsWith(tok)) score+=100; else if (name.includes(tok)) score+=60; else if (hay.includes(tok)) score+=30;
      else if (tok.length>=4 && words.some(w=>w.length>=4 && lev1(tok,w))) score+=15; else all=false;
    });
    if (all && score>0) scored.push([score + (t.badge==='pop'?5:0), t]);
  });
  return scored.sort((a,b)=>b[0]-a[0]).slice(0,limit||8).map(x=>x[1]);
}
function doSearch(q){
  const res = document.getElementById('sRes');
  q = q.trim().toLowerCase();
  if (q.length < 2) { res.classList.remove('on'); return; }
  const hits = searchTools(q, 8);
  res.innerHTML = hits.length
    ? hits.map(t => `<div class="sri" onclick="document.getElementById('sIn').value='';document.getElementById('sRes').classList.remove('on');openTool('${t.id}')"><span class="sri-ic" style="background:${CAT_CONFIG[t.cat].bg};color:#fff">${toolIconSvg(t,15)}</span><div style="flex:1"><div style="font-weight:600">${esc(trN(t))}</div><div style="font-size:11px;color:var(--tm)">${esc(trD(t))}</div></div><span class="sri-cat">${esc(t.cat.split(' ')[0])}</span></div>`).join('')
    : `<div class="sri" style="color:var(--tm)">${LANG==="hi"?"कोई टूल नहीं मिला":"No tools found for"} "${esc(q)}"</div>`;
  res.classList.add('on');
}
function renderMenuCats(){
  const el=document.getElementById('mCats'); if(!el) return;
  el.innerHTML = Object.keys(CAT_CONFIG).map(cat=>{ const c=CAT_CONFIG[cat]; return `<button type="button" class="mcat" onclick="closeMenu();navigate('home');scrollToCat('${c.id}')"><span class="ci" style="background:${c.bg}">${catIconSvg(cat,15)}</span>${esc(LANG==='hi' ? (HI_CAT_SHORT[cat]||cat) : cat.replace(' Tools','').replace('Calculator','Calculators'))}</button>`; }).join('');
}
function mobileSearch(q){
  const res = document.getElementById('mSRes');
  q = q.trim().toLowerCase();
  if (q.length < 2) { res.innerHTML=''; return; }
  const hits = searchTools(q, 6);
  res.innerHTML = hits.map(t => `<button class="mlink" onclick="closeMenu();openTool('${t.id}')">${esc(t.name)}</button>`).join('');
}
document.addEventListener('keydown', e => { const tg=(e.target.tagName||'').toLowerCase(); if (e.key==='/' && !e.ctrlKey && !e.metaKey && tg!=='input' && tg!=='textarea' && tg!=='select' && !e.target.isContentEditable){ const i=document.getElementById('sIn'); if(i && i.offsetParent!==null){ e.preventDefault(); i.focus(); i.select(); } } });
document.addEventListener('keydown', e => { if (e.key==='Enter' && e.target && e.target.id==='sIn'){ const h=searchTools(e.target.value,1); if(h[0]){ e.target.value=''; const r=document.getElementById('sRes'); if(r) r.classList.remove('on'); openTool(h[0].id); } } });
document.addEventListener('click', e => { if (!e.target.closest('.hdr-search')) { const r=document.getElementById('sRes'); if (r) r.classList.remove('on'); } });

// ============================================================
// GENERIC TOOL RENDERER - dispatches by tool.kind
// ============================================================
function renderGenericTool(tool, opts){
  document.getElementById('gtBc').innerHTML = `<a class="bc-back" href="#" onclick="goBack();return false">Back</a><a href="#" onclick="navigate('home');return false">Home</a><span class="bc-sep">›</span><span style="color:var(--tm)">${esc(tool.cat)}</span><span class="bc-sep">›</span><span class="bc-cur">${esc(tool.name)}</span>`;
  document.getElementById('gtTitle').textContent = tool.name;
  document.getElementById('gtDesc').textContent = tool.desc;
  document.getElementById('gtBoxTitle').textContent = tool.name;
  document.getElementById('gtSidebar').innerHTML = `<h3>About This Tool</h3><p style="font-size:13px;color:var(--t2);line-height:1.7">${esc(tool.desc)}</p>`;

  let bodyHtml = '', initFn = null;
  if (tool.kind === 'convert') { ({bodyHtml, initFn} = buildConvertTool(tool)); }
  else if (tool.kind === 'text') { ({bodyHtml, initFn} = buildTextTool(tool)); }
  else if (tool.kind === 'compare') { ({bodyHtml, initFn} = buildCompareTool(tool)); }
  else if (tool.kind === 'calc') { ({bodyHtml, initFn} = buildCalcTool(tool)); }
  else if (tool.kind === 'base') { ({bodyHtml, initFn} = buildBaseTool(tool)); }
  else if (tool.kind === 'custom') {
    const impl = (typeof TOOL_CUSTOM !== 'undefined') && TOOL_CUSTOM[tool.id];
    if (impl) { bodyHtml = impl.body(); initFn = impl.init; }
    else { bodyHtml = `<div class="alert alert-warn">This tool is being finished. Check back soon.</div>`; }
  }
  document.getElementById('gtBody').innerHTML = bodyHtml;
  document.getElementById('gtInfo').innerHTML = ctHtml(tool, esc);
  renderRelated('gt-related', tool.cat, tool.name);
  navigate('generic-tool', Object.assign({toolId: tool.id}, opts||{}));
  if (initFn) setTimeout(initFn, 0);
}
function clearGeneric(){
  document.querySelectorAll('#gtBody textarea, #gtBody input[type=text], #gtBody input[type=number], #gtBody input[type=email], #gtBody input[type=password]').forEach(el => el.value='');
}

// ---------- TEMPLATE: CONVERT ----------
function buildConvertTool(tool){
  const table = (new Function('return ' + tool.table))();
  const units = table.units;
  const keys = Object.keys(units);
  const def = tool.def || {amt:1, from:keys[0], to:keys[1]};
  const opts = keys.map(k => `<option value="${k}">${units[k].l} (${k})</option>`).join('');
  const bodyHtml = `
    <div class="fg"><label class="fl">Amount</label><input type="number" class="fc" id="cv-amt" value="${def.amt}" oninput="cvRun('${tool.id}')"></div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:end;margin-bottom:16px">
      <div class="fg" style="margin:0"><label class="fl">From</label><select class="fc" id="cv-from" onchange="cvRun('${tool.id}')">${opts}</select></div>
      <button class="btn btn-s btn-sm" style="margin-bottom:1px" onclick="cvSwap('${tool.id}')" title="Swap" aria-label="Swap">${svgIcon('ui_swap',16)}</button>
      <div class="fg" style="margin:0"><label class="fl">To</label><select class="fc" id="cv-to" onchange="cvRun('${tool.id}')">${opts}</select></div>
    </div>
    <div class="res-box ok" id="cv-result" style="font-size:20px;font-weight:700;text-align:center"></div>
    <div class="divider"></div>
    <div style="font-size:12px;font-weight:700;color:var(--tm);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px">All Conversions</div>
    <div id="cv-table"></div>`;
  const initFn = () => {
    document.getElementById('cv-from').value = def.from;
    document.getElementById('cv-to').value = def.to;
    const q = qsRead(); const uk = Object.keys(table.units);
    if (q.has('a')) document.getElementById('cv-amt').value = q.get('a');
    if (q.has('f') && uk.includes(q.get('f'))) document.getElementById('cv-from').value = q.get('f');
    if (q.has('t') && uk.includes(q.get('t'))) document.getElementById('cv-to').value = q.get('t');
    cvRun(tool.id);
  };
  return {bodyHtml, initFn};
}
function cvSwap(id){
  const f=document.getElementById('cv-from'), t=document.getElementById('cv-to');
  const tmp=f.value; f.value=t.value; t.value=tmp; cvRun(id);
}
function cvRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const table = (new Function('return ' + tool.table))();
  const amt = parseFloat(document.getElementById('cv-amt').value);
  const from = document.getElementById('cv-from').value;
  const to = document.getElementById('cv-to').value;
  const out = document.getElementById('cv-result');
  const tbl = document.getElementById('cv-table');
  qsWrite({a:document.getElementById('cv-amt').value, f:from, t:to});
  if (isNaN(amt)) { out.textContent = 'Enter a number'; tbl.innerHTML=''; return; }
  const baseVal = amt * table.units[from].f;
  const result = baseVal / table.units[to].f;
  out.innerHTML = `${amt} ${from} = <span style="color:var(--p)">${round4(result)} ${to}</span>`;
  tbl.innerHTML = Object.keys(table.units).map(k => {
    const v = baseVal / table.units[k].f;
    return `<div class="trow"><span>${esc(table.units[k].l)}</span><strong class="mono">${round4(v)} ${k}</strong></div>`;
  }).join('');
}

// ---------- TEMPLATE: TEXT (transform / analyzer) ----------
function buildTextTool(tool){
  const single = tool.single;
  const mono = tool.mono ? ' mono' : '';
  const btns = (tool.transforms||[]).map(tr => `<button class="btn ${tool.transforms.indexOf(tr)===0?'btn-p':'btn-s'} btn-sm" onclick="txRun('${tool.id}','${tool.transforms.indexOf(tr)}')">${esc(tr.label)}</button>`).join('');
  const liveAttr = tool.extra ? `oninput="txAnalyze('${tool.id}')"` : '';
  const bodyHtml = `
    <div class="fg"><label class="fl">Input</label><textarea class="fc${mono}" id="tx-in" rows="8" placeholder="Type or paste text here..." ${liveAttr}></textarea></div>
    ${btns ? `<div class="bgrp" style="margin-bottom:12px">${btns}</div>` : ''}
    ${tool.extra ? `<div id="tx-analysis"></div>` : `<div class="fg"><label class="fl">Output <button class="cpbtn" id="tx-cp" onclick="copyText(document.getElementById('tx-out').value,this)">Copy</button></label><textarea class="fc${mono}" id="tx-out" rows="8" readonly placeholder="Result will appear here..."></textarea></div>`}`;
  const initFn = () => { if (tool.extra) txAnalyze(tool.id); };
  return {bodyHtml, initFn};
}
function txRun(id, idx){
  const tool = TOOLS.find(t=>t.id===id);
  const tr = tool.transforms[+idx];
  const input = document.getElementById('tx-in').value;
  try { document.getElementById('tx-out').value = tr.run(input); }
  catch(e){ document.getElementById('tx-out').value = 'Error: '+e.message; }
}
function txAnalyze(id){
  const tool = TOOLS.find(t=>t.id===id);
  const text = document.getElementById('tx-in').value;
  const el = document.getElementById('tx-analysis');
  el.innerHTML = TEXT_ANALYZERS[tool.extra] ? TEXT_ANALYZERS[tool.extra](text) : '';
}

const TEXT_ANALYZERS = {
  charcount: t => {
    const bytes = new TextEncoder().encode(t).length;
    return statBlock([['Characters', t.length], ['No Spaces', t.replace(/\s/g,'').length], ['Bytes (UTF-8)', bytes]]);
  },
  linecount: t => {
    const lines = t.length ? t.split('\n') : [];
    const nonEmpty = lines.filter(l=>l.trim()).length;
    return statBlock([['Total Lines', lines.length], ['Non-empty', nonEmpty], ['Blank', lines.length-nonEmpty]]);
  },
  strlen: t => {
    const n = t.length;
    const limits = [['Tweet / X post',280],['SMS message',160],['Meta description',160],['Title tag',60]];
    return statBlock([['Length', n]]) + limits.map(([l,max]) => `<div class="trow"><span>${l} (${max})</span><strong style="color:${n>max?'var(--err)':'var(--ok)'}">${n}/${max} ${n>max?'over':'ok'}</strong></div>`).join('');
  },
  syllable: t => {
    const words = t.trim() ? t.trim().split(/\s+/) : [];
    let total = 0;
    words.forEach(w => { const m = w.toLowerCase().replace(/[^a-z]/g,'').match(/[aeiouy]+/g); total += Math.max(1, m ? m.length : 1); });
    return statBlock([['Words', words.length], ['Est. Syllables', total], ['Avg per Word', words.length?round4(total/words.length):0]]);
  },
  jsonvalidate: t => {
    if (!t.trim()) return '<div class="alert alert-warn">Paste some JSON first.</div>';
    try {
      const parsed = JSON.parse(t);
      let keys=0, depth=0, maxDepth=0;
      const walk = (o,d) => { maxDepth=Math.max(maxDepth,d); if (o && typeof o==='object') { Object.keys(o).forEach(k=>{keys++; walk(o[k],d+1);}); } };
      walk(parsed,0);
      return '<div class="alert alert-ok">Valid JSON</div>' + statBlock([['Keys/Items', keys], ['Max Depth', maxDepth], ['Type', Array.isArray(parsed)?'array':typeof parsed]]);
    } catch(e) { return `<div class="alert alert-err">Invalid JSON: ${esc(e.message)}</div>`; }
  },
  titleanalyze: t => {
    const n = t.length;
    const ok = n>=30 && n<=60;
    return `<div class="alert ${ok?'alert-ok':'alert-warn'}">${n} characters - ${ok?'good length for a title tag':(n<30?'a bit short; consider 30-60 characters':'may get truncated in search results; aim for 30-60 characters')}</div>
      <div class="res-box" style="margin-top:10px"><div style="color:#1a0dab;font-size:18px;line-height:1.3">${esc(t)||'Your Page Title'}</div><div style="color:#006621;font-size:13px;margin-top:2px">yoursite.com › page</div></div>`;
  },
  metadescanalyze: t => {
    const n = t.length;
    const ok = n>=120 && n<=160;
    return `<div class="alert ${ok?'alert-ok':'alert-warn'}">${n} characters - ${ok?'good length for a meta description':(n<120?'a bit short; aim for 120-160 characters':'may get truncated; aim for 120-160 characters')}</div>
      <div class="res-box" style="margin-top:10px;color:var(--t2)">${esc(t)||'Your meta description will appear here.'}</div>`;
  },
  urlcheck: t => {
    const issues = [];
    if (t.length > 75) issues.push('URL is longer than 75 characters');
    if (/[A-Z]/.test(t)) issues.push('Contains uppercase letters (use lowercase)');
    if (/_/.test(t)) issues.push('Contains underscores (use hyphens instead)');
    if (/[^a-zA-Z0-9\-\/:.?=&]/.test(t)) issues.push('Contains special characters that may need encoding');
    if (/\s/.test(t)) issues.push('Contains spaces');
    if (!t.trim()) return '<div class="alert alert-info">Paste a URL to check.</div>';
    return issues.length ? '<div class="alert alert-warn">'+issues.map(esc).join('<br>')+'</div>' : '<div class="alert alert-ok">No common issues found.</div>';
  },
  alttext: t => {
    const imgs = [...t.matchAll(/<img\b[^>]*>/gi)];
    if (!imgs.length) return '<div class="alert alert-info">Paste HTML containing &lt;img&gt; tags.</div>';
    const missing = imgs.filter(m => !/\balt\s*=/i.test(m[0]));
    return statBlock([['Total Images', imgs.length],['Missing Alt Text', missing.length]]) +
      (missing.length ? '<div class="res-box er" style="margin-top:10px">'+missing.map(m=>esc(m[0])).join('\n')+'</div>' : '<div class="alert alert-ok" style="margin-top:10px">All images have alt text.</div>');
  },
  seolength: t => {
    const words = t.trim() ? t.trim().split(/\s+/).length : 0;
    let note;
    if (words < 300) note = 'Thin content - consider 600+ words for a standard blog post.';
    else if (words < 600) note = 'On the shorter side for competitive SEO content.';
    else if (words < 2000) note = 'Solid length for most blog posts and articles.';
    else note = 'Long-form content - good for comprehensive guides.';
    return statBlock([['Word Count', words]]) + `<div class="alert alert-info">${note}</div>`;
  },
};

// ---------- TEMPLATE: COMPARE ----------
function buildCompareTool(tool){
  const bodyHtml = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="fg"><label class="fl">${tool.compareMode==='anagram'?'Word / Phrase A':'Text A'}</label><textarea class="fc" id="cmp-a" rows="8"></textarea></div>
      <div class="fg"><label class="fl">${tool.compareMode==='anagram'?'Word / Phrase B':'Text B'}</label><textarea class="fc" id="cmp-b" rows="8"></textarea></div>
    </div>
    <button class="btn btn-p" onclick="cmpRun('${tool.id}')">Compare</button>
    <div id="cmp-result" style="margin-top:14px"></div>`;
  return {bodyHtml, initFn: null};
}
function cmpRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const a = document.getElementById('cmp-a').value;
  const b = document.getElementById('cmp-b').value;
  const res = document.getElementById('cmp-result');
  if (tool.compareMode === 'anagram') {
    const clean = s => s.toLowerCase().replace(/[^a-z0-9]/g,'').split('').sort().join('');
    const ca = clean(a), cb = clean(b);
    const is = ca && ca === cb;
    res.innerHTML = `<div class="alert ${is?'alert-ok':'alert-err'}">${is?'These are anagrams of each other.':'These are not anagrams.'}</div>`;
    return;
  }
  const la = a.split('\n'), lb = b.split('\n');
  const max = Math.max(la.length, lb.length);
  let same=0, diff=0, rows='';
  for (let i=0;i<max;i++){
    const x=la[i]??'', y=lb[i]??'';
    const eq = x===y; if(eq) same++; else diff++;
    rows += `<div class="trow" style="background:${eq?'transparent':'var(--errbg)'}"><span class="mono" style="font-size:12px">${esc(x)||'&nbsp;'}</span><span class="mono" style="font-size:12px">${esc(y)||'&nbsp;'}</span></div>`;
  }
  res.innerHTML = statBlock([['Matching Lines',same],['Different Lines',diff]]) + `<div style="margin-top:10px;border:1px solid var(--bdr);border-radius:8px;overflow:hidden">${rows}</div>`;
}

// ---------- TEMPLATE: CALC ----------
function buildCalcTool(tool){
  const fieldHtml = tool.fields.map(f => {
    if (f.type==='select') return `<div class="fg"><label class="fl">${esc(f.label)}</label><select class="fc" id="cf-${f.id}" oninput="calcRun('${tool.id}')" onchange="calcRun('${tool.id}')">${f.options.map(([v,l])=>`<option value="${v}">${esc(l)}</option>`).join('')}</select></div>`;
    if (f.type==='checkbox') return `<label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:14px;cursor:pointer"><input type="checkbox" id="cf-${f.id}" oninput="calcRun('${tool.id}')" onchange="calcRun('${tool.id}')"> ${esc(f.label)}</label>`;
    if (f.type==='textarea') return `<div class="fg"><label class="fl">${esc(f.label)}</label><textarea class="fc" id="cf-${f.id}" rows="5" oninput="calcRun('${tool.id}')">${esc(f.value||'')}</textarea></div>`;
    return `<div class="fg"><label class="fl">${esc(f.label)}</label><input type="${f.type}" class="fc" id="cf-${f.id}" value="${esc(f.value??'')}" placeholder="${esc(f.placeholder||'')}" ${f.min!=null?`min="${f.min}"`:''} ${f.max!=null?`max="${f.max}"`:''} ${f.step!=null?`step="${f.step}"`:''} oninput="calcRun('${tool.id}')"></div>`;
  }).join('');
  const bodyHtml = `${fieldHtml}<div id="calc-result" style="margin-top:4px"></div>`;
  const initFn = () => { const q = qsRead(); tool.fields.forEach(f => { const el = document.getElementById('cf-'+f.id); if (el && q.has(f.id)) { if (f.type==='checkbox') el.checked = q.get(f.id)==='1'; else el.value = q.get(f.id); } }); calcRun(tool.id); };
  return {bodyHtml, initFn};
}
function qsRead(){ try{ return new URLSearchParams(location.search); }catch(e){ return new URLSearchParams(); } }
function qsWrite(obj){
  if (!USE_PATH || !history.replaceState) return;
  const p = new URLSearchParams(); Object.keys(obj).forEach(k => { if (obj[k] !== '' && obj[k] !== undefined && obj[k] !== false) p.set(k, obj[k]===true?'1':obj[k]); });
  const s = p.toString(); const url = location.pathname + (s ? '?'+s : '') + location.hash;
  if (url !== location.pathname + location.search + location.hash) history.replaceState(history.state,'',url);
}
function calcRun(id){
  const tool = TOOLS.find(t=>t.id===id);
  const values = {};
  tool.fields.forEach(f => {
    const el = document.getElementById('cf-'+f.id);
    if (!el) return;
    values[f.id] = f.type==='checkbox' ? el.checked : el.value;
  });
  const res = document.getElementById('calc-result');
  if (!window.__noQs) qsWrite(values);
  try { res.innerHTML = tool.compute(values) || ''; }
  catch(e){ res.innerHTML = `<div class="alert alert-err">${esc(e.message)}</div>`; }
}

// ---------- TEMPLATE: NUMBER BASE ----------
function buildBaseTool(tool){
  const bodyHtml = `
    <div class="fg"><label class="fl">Value</label><input type="text" class="fc mono" id="bs-val" value="255" oninput="bsRun()"></div>
    <div class="fg"><label class="fl">Input Base</label>
      <select class="fc" id="bs-from" onchange="bsRun()"><option value="2">Binary (2)</option><option value="8">Octal (8)</option><option value="10" selected>Decimal (10)</option><option value="16">Hexadecimal (16)</option></select>
    </div>
    <div id="bs-out"></div>`;
  return {bodyHtml, initFn: bsRun};
}
function bsRun(){
  const valEl = document.getElementById('bs-val'); if (!valEl) return;
  const base = parseInt(document.getElementById('bs-from').value);
  const raw = valEl.value.trim();
  const out = document.getElementById('bs-out');
  const n = parseInt(raw, base);
  if (isNaN(n)) { out.innerHTML = '<div class="alert alert-warn">Invalid number for that base.</div>'; return; }
  out.innerHTML = [['Binary',2],['Octal',8],['Decimal',10],['Hexadecimal',16]].map(([l,b]) => `<div class="trow"><span>${l}</span><strong class="mono">${n.toString(b).toUpperCase()}</strong></div>`).join('');
}

// ---------- CONTACT FORM ----------
function setSubject(btn, subject){
  document.querySelectorAll('.subj-btn').forEach(b => b.classList.remove('active-subj'));
  btn.classList.add('active-subj');
  document.getElementById('cf-subject').value = subject;
  document.getElementById('form-subject-hidden').value = 'Kitwell: ' + subject;
}
document.addEventListener('DOMContentLoaded', () => {
  const msg = document.getElementById('cf-msg');
  const cnt = document.getElementById('charCount');
  if (msg && cnt) {
    msg.addEventListener('input', () => {
      const len = msg.value.length;
      cnt.textContent = len + ' / 1000';
      cnt.style.color = len > 900 ? 'var(--err)' : 'var(--tm)';
      if (len > 1000) msg.value = msg.value.slice(0,1000);
    });
  }
});
async function handleFormSubmit(e){
  e.preventDefault();
  const btn = document.getElementById('cf-btn');
  const st = document.getElementById('cf-status');
  const form = document.getElementById('contactForm');
  btn.innerHTML = 'Sending…';
  btn.disabled = true;
  try {
    const res = await fetch(form.action, { method:'POST', body:new FormData(form), headers:{'Accept':'application/json'} });
    if (res.ok) {
      st.innerHTML = '<div class="alert alert-ok">Message sent. We will get back to you within 24 hours.</div>';
      form.reset();
      document.querySelectorAll('.subj-btn').forEach((b,i)=>{ b.classList.remove('active-subj'); if(i===0) b.classList.add('active-subj'); });
      document.getElementById('charCount').textContent = '0 / 1000';
    } else { st.innerHTML = '<div class="alert alert-warn">Something went wrong. Please try again.</div>'; }
  } catch(err){ st.innerHTML = '<div class="alert alert-warn">Connection error. Check your internet and try again.</div>'; }
  btn.innerHTML = 'Send Message';
  btn.disabled = false;
}

// ---------- DEDICATED TOOL PAGE SETUP ----------
function setupToolPage(id){
  (function(){ const t=TOOLS.find(x=>x.id===id); const info=document.querySelector('#pg-'+id+' .tool-info'); if(t && info && !info.dataset.x){ info.dataset.x='1'; info.insertAdjacentHTML('beforeend', ctHtml(Object.assign({},t,{info:''}), esc)); } })();
  if (id==='word-counter') { renderRelated('wc-related','Text Tools','Word Counter'); }
  else if (id==='password-generator') { genPG(); renderRelated('pg-related','Developer Tools','Password Generator'); }
  else if (id==='json-formatter') { renderRelated('json-related','Developer Tools','JSON Formatter'); }
  else if (id==='bmi-calculator') { renderRelated('bmi-related','Calculator Tools','BMI Calculator'); }
  else if (id==='age-calculator') { renderRelated('ac-related','Calculator Tools','Age Calculator'); }
}

// ---------- INIT ----------
function catSlug(cat){ return cat.toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
function initHashRoute(){
  const h = location.hash, p = location.pathname;
  let m = p.match(/\/tools\/([^\/]+)\/?$/);
  if (m && TOOLS.find(t=>t.id===m[1])) { openTool(m[1],{noPush:true,noHash:true}); return; }
  m = p.match(/\/embed\/([^\/]+)\/?$/);
  if (m && TOOLS.find(t=>t.id===m[1])) { openTool(m[1],{noPush:true,noHash:true}); return; }
  m = p.match(/\/category\/([a-z-]+)\/?$/);
  if (m) { const c=Object.keys(CAT_CONFIG).find(k=>catSlug(k)===m[1]); if (c) { navigate('home',{noPush:true,noHash:true}); const cfg=CAT_CONFIG[c]; const btn=[...document.querySelectorAll('.cb')].find(b=>(b.getAttribute('onclick')||'').includes("'"+c+"'")); if (btn) filterCat(c,btn); document.title = LANG==='hi' ? (HI_CAT[c]||c)+': मुफ्त ऑनलाइन टूल्स | Kitwell' : c+': Free Online Tools | Kitwell'; return; } }
  m = p.match(/\/(about|contact|privacy|terms|disclaimer)\/?$/);
  if (m && document.getElementById('pg-'+m[1])) { navigate(m[1],{noPush:true,noHash:true}); return; }
  if (h.startsWith('#tool=')) { const id = h.slice(6); if (TOOLS.find(t=>t.id===id)) { openTool(id,{noPush:true}); return; } }
  if (h.startsWith('#page=')) { const id = h.slice(6); if (document.getElementById('pg-'+id)) { navigate(id,{noPush:true}); return; } }
  navigate('home',{noPush:true,noHash:true});
}
document.getElementById('yr').textContent = new Date().getFullYear();
setTheme(document.documentElement.getAttribute('data-theme')==='dark'?'dark':'light');
(function(){const m={icSearch:['ui_search',16],icSearchM:['ui_search',16],icClose:['ui_close',20],icTb:['ui_arrow',14],icTb2:['ui_arrow',16],icF1:['shield',20],icF2:['ui_check',20],icF3:['star',20],icXA:['calc',16],icXB:['sip',16],icXC:['text',16],icBadge:['ui_check',14],icUp:['ui_up',14],icMHome:['grid',18],icMTools:['tool',18],icMAbout:['person',18],icMContact:['mail',18]};
  Object.keys(m).forEach(k=>{const e=document.getElementById(k); if(e) e.innerHTML=svgIcon(m[k][0],m[k][1]);});})();
function suggestTool(){ navigate('contact'); const b=document.querySelector('#subjectBtns .subj-btn'); if(b && typeof setSubject==='function') setSubject(b,'Suggest a New Tool'); }
function goToTools(e){
  if(e) e.preventDefault();
  const go=()=>{const el=document.getElementById('toolsArea'); if(el) el.scrollIntoView({behavior:'smooth',block:'start'});};
  if(currentPage!=='home'){ navigate('home'); setTimeout(go,60); } else go();
}
renderHome();
renderMenuCats();
document.querySelectorAll('.page').forEach(p => { p.style.display = p.classList.contains('active') ? 'block' : 'none'; });
const todayDate = new Date().toISOString().split('T')[0];
const dobEl = document.getElementById('ac-dob'); if (dobEl) dobEl.max = todayDate;
genPG();
initHashRoute();
window.addEventListener('popstate', initHashRoute);
if (USE_PATH && 'serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(()=>{}); }); }
