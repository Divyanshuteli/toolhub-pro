document.getElementById('statTotal').textContent = TOOLS.length;
const _sc=document.getElementById('statCats'); if(_sc) _sc.textContent = Object.keys(CAT_CONFIG).length;
const _sg=document.getElementById('statGuides'); if(_sg) _sg.textContent = GUIDES.length;
