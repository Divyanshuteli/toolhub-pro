// ---------- ANALYTICS (GA4 events only if gtag exists; no extra cookies set by us) ----------
function track(name, params){ try{ if (typeof gtag==='function') gtag('event', name, params||{}); }catch(e){} }

// ---------- DIALOG HELPERS ----------
let _dlgOpener = null;
function closeDlg(){ document.querySelectorAll('.dlg').forEach(d=>d.remove()); if (_dlgOpener && _dlgOpener.focus) { try{ _dlgOpener.focus(); }catch(e){} } _dlgOpener=null; }
function openDlg(id, label, html){
  _dlgOpener = document.activeElement;
  document.querySelectorAll('.dlg').forEach(d=>d.remove());
  const d=document.createElement('div'); d.id=id; d.className='dlg'; d.setAttribute('role','dialog'); d.setAttribute('aria-modal','true'); d.setAttribute('aria-label',label);
  d.innerHTML=`<div class="dlg-ov" onclick="closeDlg()"></div><div class="dlg-bx">${html}</div>`;
  document.body.appendChild(d); return d;
}

// ---------- COMMAND PALETTE (Ctrl/Cmd + K) ----------
let palSel = 0, palHits = [];
function palHtml(){
  return `<div class="pal"><input type="text" id="palIn" class="pal-in" placeholder="${LANG==='hi'?'टूल खोजें':'Search tools'}" aria-label="${LANG==='hi'?'टूल खोजें':'Search tools'}" role="combobox" aria-expanded="true" aria-controls="palList" aria-autocomplete="list" autocomplete="off"><ul id="palList" class="pal-list" role="listbox"></ul><div class="pal-ft"><span><kbd>↑</kbd><kbd>↓</kbd> ${LANG==='hi'?'चुनें':'move'}</span><span><kbd>Enter</kbd> ${LANG==='hi'?'खोलें':'open'}</span><span><kbd>Esc</kbd> ${LANG==='hi'?'बंद':'close'}</span></div></div>`;
}
function palRender(q){
  const list=document.getElementById('palList'); if(!list) return;
  q=(q||'').trim();
  if (q.length>=2) palHits = searchTools(q, 8);
  else { const rec=lsGet('th-recent').map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean); const pop=['word-counter','emi-calculator','sip-calculator','income-tax-india','pdf-merge','password-generator','qr-generator','image-compressor'].map(id=>TOOLS.find(t=>t.id===id)).filter(Boolean); const seen=new Set(); palHits=rec.concat(pop).filter(t=>!seen.has(t.id)&&seen.add(t.id)).slice(0,8); }
  palSel=0;
  list.innerHTML = palHits.length ? palHits.map((t,i)=>`<li id="pal-${i}" role="option" aria-selected="${i===0}" class="pal-it${i===0?' on':''}" data-i="${i}"><span class="sri-ic" style="background:${CAT_CONFIG[t.cat].bg};color:#fff">${toolIconSvg(t,16)}</span><span class="pal-tx"><b>${esc(trN(t))}</b><i>${esc(trD(t))}</i></span></li>`).join('') : `<li class="pal-empty">${LANG==='hi'?'कोई टूल नहीं मिला':'No tools found'}</li>`;
  const inp=document.getElementById('palIn'); if(inp) inp.setAttribute('aria-activedescendant', palHits.length?'pal-0':'');
}
function palMove(d){
  if(!palHits.length) return; palSel=(palSel+d+palHits.length)%palHits.length;
  document.querySelectorAll('#palList .pal-it').forEach((li,i)=>{ li.classList.toggle('on',i===palSel); li.setAttribute('aria-selected',i===palSel); if(i===palSel) li.scrollIntoView({block:'nearest'}); });
  const inp=document.getElementById('palIn'); if(inp) inp.setAttribute('aria-activedescendant','pal-'+palSel);
}
function palOpenSel(){ const t=palHits[palSel]; if(!t) return; closeDlg(); track('palette_open_tool',{tool_id:t.id}); openTool(t.id); }
function showPalette(){
  if (document.getElementById('palDlg')) { closeDlg(); return; }
  closeMenu(); const d=openDlg('palDlg', LANG==='hi'?'टूल खोजें':'Command palette', palHtml()); d.classList.add('dlg-top');
  const inp=d.querySelector('#palIn'); palRender(''); inp.focus(); track('palette_show');
  inp.addEventListener('input',()=>palRender(inp.value));
  inp.addEventListener('keydown',e=>{ if(e.key==='ArrowDown'){e.preventDefault();palMove(1);} else if(e.key==='ArrowUp'){e.preventDefault();palMove(-1);} else if(e.key==='Enter'){e.preventDefault();palOpenSel();} });
  d.querySelector('#palList').addEventListener('click',e=>{ const li=e.target.closest('.pal-it'); if(li){ palSel=+li.dataset.i; palOpenSel(); } });
}

// ---------- SHORTCUTS ----------
function showShortcuts(){
  const rows=[['/', LANG==='hi'?'हेडर में खोजें':'Focus the header search'],['Ctrl + K  or  Cmd + K', LANG==='hi'?'टूल पैलेट खोलें':'Open the tool palette'],['?', LANG==='hi'?'यह सूची खोलें':'Show this list'],['Esc', LANG==='hi'?'डायलॉग बंद करें':'Close a dialog or menu'],['Enter', LANG==='hi'?'खोज में पहले टूल को खोलें':'Open the top search result'],['Alt + ←', LANG==='hi'?'पिछले पेज पर जाएं':'Go back (browser)']];
  openDlg('shortDlg', LANG==='hi'?'कीबोर्ड शॉर्टकट':'Keyboard shortcuts', `<div class="dlg-hd"><h3>${LANG==='hi'?'कीबोर्ड शॉर्टकट':'Keyboard shortcuts'}</h3><button type="button" class="mclose dlg-x" onclick="closeDlg()" aria-label="Close">${svgIcon('ui_close',18)}</button></div><table class="sk-tbl"><tbody>${rows.map(r=>`<tr><td>${r[0].split('  or  ').map(k=>k.split(' + ').map(x=>`<kbd>${esc(x)}</kbd>`).join(' + ')).join(' <span class="sk-or">/</span> ')}</td><td>${esc(r[1])}</td></tr>`).join('')}</tbody></table>`).querySelector('.dlg-x').focus();
}
document.addEventListener('keydown', e => {
  const tg=(e.target.tagName||'').toLowerCase(); const typing = tg==='input'||tg==='textarea'||tg==='select'||e.target.isContentEditable;
  if ((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); showPalette(); return; }
  if (e.key==='Escape'){ if(document.querySelector('.dlg')) closeDlg(); return; }
  if (e.key==='?' && !typing && !e.ctrlKey && !e.metaKey){ e.preventDefault(); showShortcuts(); }
});

// ---------- SAVED RESULTS (this browser only) ----------
function resultPairs(){
  const pg=document.querySelector('.page.active'); if(!pg) return [];
  return [...pg.querySelectorAll('.sgrid .sc')].map(sc=>[(sc.querySelector('.sl')||{}).textContent||'', (sc.querySelector('.sn')||{}).textContent||'']).filter(p=>p[0]&&p[1]);
}
function getSaved(){ try{ return JSON.parse(localStorage.getItem('th-saved')||'[]'); }catch(e){ return []; } }
function putSaved(a){ try{ localStorage.setItem('th-saved', JSON.stringify(a.slice(0,40))); }catch(e){} }
function saveResult(id){
  const pairs=resultPairs(); if(!pairs.length){ toast(LANG==='hi'?'पहले कोई नतीजा निकालें':'Run the calculation first'); return; }
  const a=getSaved(); a.unshift({id, qs: USE_PATH ? location.search : '', t: Date.now(), p: pairs.slice(0,4)});
  putSaved(a); track('save_result',{tool_id:id}); renderSaved(id); toast(LANG==='hi'?'नतीजा सेव हुआ':'Result saved');
}
function deleteSaved(t){ putSaved(getSaved().filter(x=>x.t!==t)); const c=currentToolId(); if(c) renderSaved(c); }
function restoreSaved(t){
  const s=getSaved().find(x=>x.t===t); if(!s) return;
  if (USE_PATH) history.pushState({i:histIdx()+1}, '', TOOLP+s.id+'/'+(s.qs||''));
  openTool(s.id,{noPush:true,noHash:true});
}
function currentToolId(){ const m=location.pathname.match(/\/tools\/([^\/]+)\/?$/); if(m&&TOOLS.find(t=>t.id===m[1])) return m[1]; return (typeof currentView!=='undefined' && TOOLS.find(t=>t.id===currentView)) ? currentView : null; }
function renderSaved(id){
  const pg=document.querySelector('.page.active'); if(!pg) return;
  const t=TOOLS.find(x=>x.id===id); if(!t||t.kind!=='calc'){ const o=pg.querySelector('.svbox'); if(o) o.remove(); return; }
  let box=pg.querySelector('.svbox'); const list=getSaved().filter(x=>x.id===id).slice(0,8);
  if(!list.length){ if(box) box.remove(); return; }
  if(!box){ box=document.createElement('section'); box.className='svbox'; box.setAttribute('aria-label','Saved results'); const anchor=pg.querySelector('.tbox'); if(!anchor) return; anchor.insertAdjacentElement('afterend', box); }
  const fmt=ts=>new Date(ts).toLocaleDateString(undefined,{day:'numeric',month:'short'});
  box.innerHTML=`<h3>${LANG==='hi'?'सेव किए नतीजे':'Saved results'}</h3><ul>${list.map(x=>`<li><span class="sv-tx">${x.p.map(p=>`<b>${esc(p[1])}</b> ${esc(p[0])}`).join('<i>·</i>')}</span><span class="sv-dt">${fmt(x.t)}</span><button type="button" class="tbtn" onclick="restoreSaved(${x.t})">${LANG==='hi'?'वापस लाएं':'Restore'}</button><button type="button" class="tbtn" onclick="deleteSaved(${x.t})">${LANG==='hi'?'हटाएं':'Delete'}</button></li>`).join('')}</ul>`;
}

// ---------- SHARE CARD (PNG drawn in the browser) ----------
async function shareCard(id){
  const t=TOOLS.find(x=>x.id===id); const pairs=resultPairs().slice(0,3);
  if(!t||!pairs.length){ toast(LANG==='hi'?'पहले कोई नतीजा निकालें':'Run the calculation first'); return; }
  try{ await document.fonts.load('700 56px Inter'); await document.fonts.load('500 26px Inter'); }catch(e){}
  const W=1200,H=630,c=document.createElement('canvas'); c.width=W; c.height=H; const x=c.getContext('2d');
  x.fillStyle='#060B16'; x.fillRect(0,0,W,H);
  const glow=(cx,cy,r,col)=>{ const g=x.createRadialGradient(cx,cy,0,cx,cy,r); g.addColorStop(0,col); g.addColorStop(1,'rgba(0,0,0,0)'); x.fillStyle=g; x.fillRect(0,0,W,H); };
  glow(180,80,520,'rgba(36,81,224,.55)'); glow(1080,560,520,'rgba(8,145,178,.40)');
  const rr=(px,py,w,h,r)=>{ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); };
  rr(48,48,W-96,H-96,34); x.fillStyle='rgba(255,255,255,.07)'; x.fill(); x.strokeStyle='rgba(255,255,255,.22)'; x.lineWidth=2; x.stroke();
  x.fillStyle='#fff'; x.font='700 54px Inter, system-ui, sans-serif'; x.textBaseline='alphabetic'; x.fillText(t.name.length>34?t.name.slice(0,33)+'…':t.name, 96, 150);
  x.fillStyle='rgba(255,255,255,.6)'; x.font='500 26px Inter, system-ui, sans-serif'; x.fillText(t.cat, 96, 192);
  const n=pairs.length, gap=24, bw=(W-192-gap*(n-1))/n;
  pairs.forEach((p,i)=>{ const bx=96+i*(bw+gap), by=240; rr(bx,by,bw,210,24); x.fillStyle='rgba(255,255,255,.08)'; x.fill(); x.strokeStyle='rgba(255,255,255,.2)'; x.lineWidth=1.5; x.stroke();
    let fs=52; x.font=`700 ${fs}px Inter, system-ui, sans-serif`; while(x.measureText(p[1]).width>bw-48 && fs>22){ fs-=2; x.font=`700 ${fs}px Inter, system-ui, sans-serif`; }
    x.fillStyle='#fff'; x.fillText(p[1], bx+24, by+110);
    x.fillStyle='rgba(255,255,255,.62)'; x.font='500 24px Inter, system-ui, sans-serif'; x.fillText(p[0].length>26?p[0].slice(0,25)+'…':p[0], bx+24, by+160); });
  x.fillStyle='#fff'; x.font='700 34px Inter, system-ui, sans-serif'; x.fillText('Kitwell', 96, 540);
  x.fillStyle='rgba(255,255,255,.55)'; x.font='500 24px Inter, system-ui, sans-serif'; x.textAlign='right'; x.fillText((USE_PATH?location.host:'kitwell')+TOOLP.replace(/\/$/,'')+'/'+id, W-96, 540); x.textAlign='left';
  c.toBlob(async blob=>{
    if(!blob) return; track('share_card',{tool_id:id});
    const file=new File([blob], id+'-result.png', {type:'image/png'});
    try{ if(navigator.canShare && navigator.canShare({files:[file]})){ await navigator.share({files:[file], title:t.name}); return; } }catch(e){ if(e&&e.name==='AbortError') return; }
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=file.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(a.href),4000);
  },'image/png');
}
