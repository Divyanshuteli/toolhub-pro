// PDF tools: pdf-lib is loaded on demand from /vendor/pdf-lib.min.js (kept out of the main bundle).
let __pdfLibPromise = null;
function loadPdfLib(){
  if (window.PDFLib) return Promise.resolve(window.PDFLib);
  if (__pdfLibPromise) return __pdfLibPromise;
  __pdfLibPromise = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = (/^https?:$/.test(location.protocol) ? '/vendor/' : 'vendor/') + 'pdf-lib.min.js';
    s.onload = () => res(window.PDFLib);
    s.onerror = () => { __pdfLibPromise = null; rej(new Error('Could not load the PDF library')); };
    document.head.appendChild(s);
  });
  return __pdfLibPromise;
}
function pdfReadFile(f){ return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(new Uint8Array(r.result)); r.onerror = () => rej(new Error('Could not read ' + f.name)); r.readAsArrayBuffer(f); }); }
function pdfDownload(bytes, name){
  const blob = new Blob([bytes], {type:'application/pdf'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
}
function pdfMsg(id, html, kind){ const el = document.getElementById(id); if (el) el.innerHTML = `<div class="alert alert-${kind||'info'}">${html}</div>`; }
function pdfFileList(files, listId){
  const el = document.getElementById(listId); if (!el) return;
  el.innerHTML = files.map((f, i) => `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid var(--bdr);border-radius:8px;margin-bottom:6px;background:var(--bg2)"><span style="flex:1;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)} <span style="color:var(--tm)">(${Math.max(1,Math.round(f.size/1024))} KB)</span></span><button type="button" class="btn btn-s btn-sm" onclick="pdfMove('${listId}',${i},-1)" aria-label="Move up">${svgIcon('ui_up',14)}</button><button type="button" class="btn btn-s btn-sm" onclick="pdfMove('${listId}',${i},1)" aria-label="Move down" style="transform:rotate(180deg)">${svgIcon('ui_up',14)}</button><button type="button" class="btn btn-s btn-sm" onclick="pdfRemove('${listId}',${i})" aria-label="Remove">${svgIcon('ui_close',14)}</button></div>`).join('');
}
const __pdfState = {};
function pdfMove(listId, i, d){ const a = __pdfState[listId]; const j = i + d; if (!a || j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; pdfFileList(a, listId); }
function pdfRemove(listId, i){ const a = __pdfState[listId]; if (!a) return; a.splice(i, 1); pdfFileList(a, listId); }
function pdfPicker(inputId, listId, accept, multi){
  __pdfState[listId] = [];
  const inp = document.getElementById(inputId);
  inp.addEventListener('change', () => { const add = Array.from(inp.files).filter(f => accept.test(f.name) || accept.test(f.type)); if (multi) __pdfState[listId].push(...add); else __pdfState[listId] = add.slice(0, 1); inp.value = ''; pdfFileList(__pdfState[listId], listId); });
}
const PDF_UP = (id, lid, accept, multi, label) => `<div class="fg"><label class="fl" for="${id}">${label}</label><input type="file" class="fc" id="${id}" accept="${accept}" ${multi ? 'multiple' : ''}></div><div id="${lid}"></div>`;

TOOL_CUSTOM['pdf-merge'] = {
  body: () => PDF_UP('pm-in', 'pm-list', 'application/pdf,.pdf', true, 'Add PDF files') + `<button type="button" class="btn btn-p" id="pm-go">Merge and download</button><div id="pm-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pm-in', 'pm-list', /\.pdf$|application\/pdf/i, true);
    document.getElementById('pm-go').onclick = async () => {
      const files = __pdfState['pm-list']; if (!files || files.length < 2) return pdfMsg('pm-msg', 'Add at least two PDF files.', 'warn');
      try {
        pdfMsg('pm-msg', 'Merging...');
        const { PDFDocument } = await loadPdfLib(); const out = await PDFDocument.create();
        for (const f of files) { const src = await PDFDocument.load(await pdfReadFile(f)); const pages = await out.copyPages(src, src.getPageIndices()); pages.forEach(p => out.addPage(p)); }
        pdfDownload(await out.save(), 'merged.pdf'); pdfMsg('pm-msg', `Done. ${out.getPageCount()} pages merged.`, 'ok');
      } catch (e) { pdfMsg('pm-msg', 'Could not merge. One of the files may be damaged or password protected.', 'err'); }
    };
  }
};
function pdfParseRanges(str, max){
  const out = []; const seen = new Set();
  for (const part of str.split(',').map(s => s.trim()).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:\s*-\s*(\d+))?$/); if (!m) return null;
    let a = +m[1], b = m[2] ? +m[2] : a; if (a < 1 || b < 1 || a > max || b > max) return null;
    const step = a <= b ? 1 : -1; for (let i = a; step > 0 ? i <= b : i >= b; i += step) { if (!seen.has(i)) { seen.add(i); out.push(i - 1); } }
  }
  return out.length ? out : null;
}
TOOL_CUSTOM['pdf-split'] = {
  body: () => PDF_UP('ps-in', 'ps-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="ps-range">Pages to keep</label><input class="fc" id="ps-range" placeholder="e.g. 1-3,5,8-10"></div><button type="button" class="btn btn-p" id="ps-go">Extract and download</button><div id="ps-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('ps-in', 'ps-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('ps-go').onclick = async () => {
      const f = (__pdfState['ps-list'] || [])[0]; if (!f) return pdfMsg('ps-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument } = await loadPdfLib(); const src = await PDFDocument.load(await pdfReadFile(f)); const total = src.getPageCount();
        const idx = pdfParseRanges(document.getElementById('ps-range').value, total);
        if (!idx) return pdfMsg('ps-msg', `Enter valid pages between 1 and ${total}, like 1-3,5.`, 'warn');
        const out = await PDFDocument.create(); (await out.copyPages(src, idx)).forEach(p => out.addPage(p));
        pdfDownload(await out.save(), f.name.replace(/\.pdf$/i, '') + '-pages.pdf'); pdfMsg('ps-msg', `Done. ${idx.length} of ${total} pages extracted.`, 'ok');
      } catch (e) { pdfMsg('ps-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
TOOL_CUSTOM['images-to-pdf'] = {
  body: () => PDF_UP('ip-in', 'ip-list', 'image/jpeg,image/png,.jpg,.jpeg,.png', true, 'Add JPG or PNG images') + `<button type="button" class="btn btn-p" id="ip-go">Create PDF</button><div id="ip-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('ip-in', 'ip-list', /\.(jpe?g|png)$|image\/(jpeg|png)/i, true);
    document.getElementById('ip-go').onclick = async () => {
      const files = __pdfState['ip-list']; if (!files || !files.length) return pdfMsg('ip-msg', 'Add at least one image.', 'warn');
      try {
        pdfMsg('ip-msg', 'Creating PDF...');
        const { PDFDocument } = await loadPdfLib(); const out = await PDFDocument.create();
        for (const f of files) { const bytes = await pdfReadFile(f); const img = /png$/i.test(f.name) || f.type === 'image/png' ? await out.embedPng(bytes) : await out.embedJpg(bytes); const pg = out.addPage([img.width, img.height]); pg.drawImage(img, {x:0, y:0, width:img.width, height:img.height}); }
        pdfDownload(await out.save(), 'images.pdf'); pdfMsg('ip-msg', `Done. ${files.length} image${files.length > 1 ? 's' : ''} added.`, 'ok');
      } catch (e) { pdfMsg('ip-msg', 'Could not add one of the images. Use standard JPG or PNG files.', 'err'); }
    };
  }
};
TOOL_CUSTOM['pdf-rotate'] = {
  body: () => PDF_UP('pr-in', 'pr-list', 'application/pdf,.pdf', false, 'Choose a PDF file') + `<div class="fg"><label class="fl" for="pr-deg">Rotate pages by</label><select class="fc" id="pr-deg"><option value="90">90 degrees clockwise</option><option value="180">180 degrees</option><option value="270">90 degrees counter-clockwise</option></select></div><button type="button" class="btn btn-p" id="pr-go">Rotate and download</button><div id="pr-msg" style="margin-top:12px"></div>`,
  init: () => {
    pdfPicker('pr-in', 'pr-list', /\.pdf$|application\/pdf/i, false);
    document.getElementById('pr-go').onclick = async () => {
      const f = (__pdfState['pr-list'] || [])[0]; if (!f) return pdfMsg('pr-msg', 'Choose a PDF file first.', 'warn');
      try {
        const { PDFDocument, degrees } = await loadPdfLib(); const doc = await PDFDocument.load(await pdfReadFile(f)); const d = +document.getElementById('pr-deg').value;
        doc.getPages().forEach(p => p.setRotation(degrees((p.getRotation().angle + d) % 360)));
        pdfDownload(await doc.save(), f.name.replace(/\.pdf$/i, '') + '-rotated.pdf'); pdfMsg('pr-msg', 'Done. All pages rotated.', 'ok');
      } catch (e) { pdfMsg('pr-msg', 'Could not read this PDF. It may be damaged or password protected.', 'err'); }
    };
  }
};
