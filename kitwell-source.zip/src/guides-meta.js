// Guide metadata. Bodies live in guides.js (build time only). The first tool of each guide is its primary tool.
const GUIDES = [
  {slug:'how-emi-is-calculated', title:'How EMI Is Calculated, With a Worked Example', desc:'The EMI formula, a month-by-month breakdown of interest and principal, and how tenure changes what you pay.', tools:['emi-calculator','loan-prepayment-calculator','home-loan-eligibility']},
  {slug:'sip-vs-fd', title:'SIP vs FD: What Actually Differs', desc:'A SIP and a recurring deposit compared on the same monthly amount, with the risk that the headline numbers hide.', tools:['sip-calculator','rd-calculator','fd-calculator']},
  {slug:'old-vs-new-tax-regime', title:'Old vs New Tax Regime: How to Choose (FY 2026-27)', desc:'Slabs, deductions and the break-even point where the old regime starts to beat the new one.', tools:['income-tax-india','hra-calculator','ppf-calculator']},
  {slug:'sip-vs-lumpsum', title:'SIP vs Lumpsum: Same Money, Different Timing', desc:'What the maths says when you invest a sum all at once versus in monthly parts, and what it leaves out.', tools:['sip-calculator','fd-calculator','cagr-calculator']},
  {slug:'how-gst-is-calculated', title:'How GST Is Calculated: Adding and Removing It', desc:'The two formulas you need, with examples, and the mistake people make when removing GST from a total.', tools:['gst-calculator','percentage-calculator','discount-calculator']},
  {slug:'bmi-categories-explained', title:'BMI Categories Explained, and Where BMI Falls Short', desc:'How BMI is worked out, the WHO categories, why some guidelines use lower cut-offs for South Asians, and what BMI cannot tell you.', tools:['bmi-calculator','bmr-calculator','water-intake']},
  {slug:'how-compound-interest-works', title:'How Compound Interest Works', desc:'The formula, the difference from simple interest on real numbers, and the rule of 72.', tools:['compound-interest','simple-interest','inflation-calculator']},
  {slug:'ppf-vs-fd', title:'PPF vs FD: Tax, Lock-in and Real Returns', desc:'Why a lower headline rate can still win once tax is counted, and when a fixed deposit makes more sense.', tools:['ppf-calculator','fd-calculator','income-tax-india']},
  {slug:'strong-password-guide', title:'What Makes a Password Strong', desc:'Length versus complexity, how many bits of entropy you get from random characters or words, and what to do about reuse.', tools:['password-generator','password-passphrase','password-strength']},
  {slug:'merge-pdf-without-uploading', title:'How to Merge PDFs Without Uploading Them', desc:'How in-browser PDF tools work, what stays on your device, and where they hit their limits.', tools:['pdf-merge','pdf-split','pdf-delete-pages']}
];
const GUIDE_BY_TOOL = {};
GUIDES.forEach(g => g.tools.forEach(id => { if (!GUIDE_BY_TOOL[id]) GUIDE_BY_TOOL[id] = g; }));
