// Serves dist/ over http (so path routing is used) and checks real outputs, deep links, mobile, theme, a11y basics.
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'dist');
const mime = {'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/woff2','.xml':'application/xml','.txt':'text/plain'};
const srv = http.createServer((q, s) => {
  let p = decodeURIComponent(q.url.split('?')[0]); if (p.endsWith('/')) p += 'index.html';
  let f = path.join(root, p);
  if (!fs.existsSync(f)) { for (const r of (JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8')).rewrites || [])) { const pre = r.source.replace('/:path*', ''); if (p.startsWith(pre + '/')) { f = path.join(root, r.destination); break; } } }
  if (!f.startsWith(root) || !fs.existsSync(f)) { s.writeHead(404); return s.end('nf'); }
  s.writeHead(200, {'content-type': mime[path.extname(f)] || 'application/octet-stream'}); s.end(fs.readFileSync(f));
});
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port;
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 } });
  await ctx.route(/googletagmanager|frankfurter|ipify/, r => r.abort());
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  const text = sel => p.locator(sel).first().innerText();
  // deep links
  const tools = JSON.parse(await (async()=>{ await p.goto(base + '/'); return JSON.stringify(await p.evaluate(()=>TOOLS.map(t=>t.id))); })());
  let dl = 0;
  for (const id of tools) {
    await p.goto(base + '/tools/' + id + '/');
    const act = await p.evaluate(() => document.querySelector('.page.active').id);
    const title = await p.title();
    if (act === 'pg-home' || !title.includes('Kitwell') || title.startsWith('Kitwell |')) { dl++; console.log('deeplink fail', id, act, title); }
    const bc = await p.locator('.page.active .bc-back').count(); if (!bc) { dl++; console.log('no back', id); }
    const ld = await p.evaluate(() => [...document.querySelectorAll('script[type="application/ld+json"]')].length);
    if (ld < 4) { dl++; console.log('ld missing', id, ld); }
    const words = await p.evaluate(() => { const el = document.querySelector('.page.active .tool-info'); return el ? el.innerText.split(/\s+/).length : -1; });
    const isTop = await p.evaluate(i => typeof topOf === 'function' && !!topOf(TOOLS.find(t => t.id === i)), id);
    if (words !== -1 && words < (isTop ? 120 : 200)) { dl++; console.log('thin content', id, words); }
  }
  ok(dl === 0, 'deep links/back/ld/content: ' + dl + ' problems');
  // real output checks
  const setv = async (sel, v) => { await p.fill(sel, String(v)); };
  await p.goto(base + '/tools/weight-converter/'); await p.waitForTimeout(100);
  ok((await text('#cv-result')).includes('2.2046'), 'kg->lb');
  await p.goto(base + '/tools/length-converter/'); await p.selectOption('#cv-from', 'mi'); await p.selectOption('#cv-to', 'km');
  ok((await text('#cv-result')).includes('1.6093'), 'mi->km: ' + await text('#cv-result'));
  await p.goto(base + '/tools/emi-calculator/'); await p.waitForTimeout(100);
  ok((await text('#calc-result')).replace(/[,\s]/g, '').includes('10379'), 'EMI 500000@9%/60 ≈ 10379: ' + (await text('#calc-result')).slice(0,80));
  await p.goto(base + '/tools/percentage-calculator/'); await p.waitForTimeout(100);
  const pct = await text('#gtBody'); ok(await p.locator('#gtBody input').count() >= 2, 'percentage renders');
  await p.goto(base + '/tools/factorial/'); await p.waitForTimeout(100);
  const fid = await p.evaluate(() => document.querySelector('#gtBody input').id); await p.fill('#' + fid, '5');
  ok((await text('#calc-result')).includes('120'), 'factorial 5 = 120: ' + (await text('#calc-result')).slice(0,60));
  await p.goto(base + '/tools/prime-checker/'); const pid = await p.evaluate(() => document.querySelector('#gtBody input').id); await p.fill('#' + pid, '97');
  ok(/prime/i.test(await text('#calc-result')) && !/not/i.test((await text('#calc-result')).slice(0, 40)), 'prime 97: ' + (await text('#calc-result')).slice(0,60));
  await p.fill('#' + pid, '91'); ok(/not/i.test(await text('#calc-result')), '91 not prime');
  await p.goto(base + '/tools/palindrome-checker/'); await p.fill('#gtBody input', 'A man a plan a canal Panama'); ok(/Yes/.test(await text('#calc-result')), 'palindrome');
  await p.goto(base + '/tools/roman-numerals/'); await p.waitForTimeout(100);
  const ro = await p.evaluate(() => document.querySelector('#gtBody').innerText); ok(ro.length > 20, 'roman renders');
  await p.goto(base + '/tools/hcf-lcm/'); await p.waitForTimeout(100);
  await p.goto(base + '/tools/case-converter/'); await p.fill('#tx-in', 'hello world'); await p.getByRole('button', { name: /UPPER/i }).first().click();
  ok((await p.inputValue('#tx-out').catch(() => '')) === 'HELLO WORLD', 'upper case: ' + await p.inputValue('#tx-out').catch(()=>'?'));
  await p.goto(base + '/tools/text-reverser/'); await p.fill('#tx-in', 'abc'); await p.getByRole('button').filter({ hasText: /reverse/i }).first().click().catch(()=>{});
  await p.goto(base + '/tools/md5-hash/'); await p.waitForTimeout(100);
  await p.goto(base + '/tools/word-counter/'); await p.waitForTimeout(100);
  const wcIn = await p.evaluate(() => document.querySelector('#pg-word-counter textarea').id); await p.fill('#' + wcIn, 'one two three four five');
  ok((await p.evaluate(() => document.querySelector('#pg-word-counter').innerText)).includes('5'), 'word counter 5');
  await p.goto(base + '/tools/bmi-calculator/'); await p.waitForTimeout(100);
  await p.goto(base + '/tools/json-formatter/'); const jid = await p.evaluate(() => document.querySelector('#pg-json-formatter textarea').id); await p.fill('#' + jid, '{"a":1,"b":[1,2]}');
  await p.getByRole('button', { name: /format|beautify/i }).first().click();
  const jo = await p.evaluate(() => document.getElementById('jsonOut').innerText); ok(/\n\s+"a": 1/.test(jo), 'json pretty: ' + jo.slice(0,80));
  // favourites + recent + theme
  await p.goto(base + '/tools/emi-calculator/'); await p.click('.page.active .tbtn:has-text("Save")');
  await p.goto(base + '/'); ok((await p.locator('#homeShelf').innerText()).includes('EMI Calculator'), 'shelf shows saved');
  await p.click('#themeBtn'); ok(await p.evaluate(() => document.documentElement.getAttribute('data-theme')) === null, 'light on (default is dark)');
  await p.waitForTimeout(400); await p.screenshot({ path: '/tmp/dark-home.png' });
  await p.goto(base + '/tools/emi-calculator/'); ok(await p.evaluate(() => document.documentElement.getAttribute('data-theme')) === null, 'light persists');
  await p.screenshot({ path: '/tmp/dark-tool.png' });
  // navigation via UI pushes real paths and back works
  await p.goto(base + '/'); await p.evaluate(() => openTool('emi-calculator')); ok(new URL(p.url()).pathname === '/tools/emi-calculator/', 'pushState path');
  await p.click('.page.active .bc-back'); ok(new URL(p.url()).pathname === '/', 'back to /');
  await p.click('#tbLink'); await p.waitForTimeout(800); ok(await p.evaluate(() => scrollY) > 300, 'browse all scrolls');
  // download
  await p.goto(base + '/tools/emi-calculator/'); const [dlw] = await Promise.all([p.waitForEvent('download', { timeout: 3000 }).catch(() => null), p.click('.page.active .tbtn:has-text("Download")')]);
  ok(!!dlw, 'download output');
  // mobile overflow on a sample of pages
  const m = await b.newContext({ viewport: { width: 375, height: 800 }, isMobile: true }); await m.route(/googletagmanager|frankfurter|ipify/, r => r.abort());
  const mp = await m.newPage(); let ov = 0;
  for (const id of ['', 'tools/word-counter/', 'tools/emi-calculator/', 'tools/json-formatter/', 'tools/length-converter/', 'tools/qr-generator/', 'tools/password-generator/', 'tools/bmi-calculator/', 'tools/scientific-calculator/', 'tools/regex-tester/', 'tools/color-converter/', 'tools/image-resizer/', 'privacy/']) {
    await mp.goto(base + '/' + id); await mp.waitForTimeout(150);
    const w = await mp.evaluate(() => [document.documentElement.scrollWidth, innerWidth]);
    if (w[0] > w[1] + 1) { ov++; console.log('overflow', id, w); }
  }
  ok(ov === 0, 'mobile overflow pages: ' + ov);
  await mp.goto(base + '/'); await mp.screenshot({ path: '/tmp/m-home.png' });
  await mp.goto(base + '/tools/emi-calculator/'); await mp.screenshot({ path: '/tmp/m-tool.png' });
  // keyboard: tool card focusable & Enter opens
  await p.goto(base + '/'); await p.focus('.tc'); await p.keyboard.press('Enter');
  ok(await p.evaluate(() => document.querySelector('.page.active').id) !== 'pg-home', 'keyboard open');

  // ---- new features ----
  const { PDFDocument } = require('pdf-lib');
  const mk = async n => { const d = await PDFDocument.create(); for (let i = 0; i < n; i++) d.addPage([300, 400]); return Buffer.from(await d.save()); };
  const dlBytes = async (page, clickSel) => { const [d] = await Promise.all([page.waitForEvent('download', { timeout: 8000 }), page.click(clickSel)]); const pth = await d.path(); return fs.readFileSync(pth); };
  await p.goto(base + '/tools/pdf-merge/');
  await p.setInputFiles('#pm-in', [{ name: 'a.pdf', mimeType: 'application/pdf', buffer: await mk(2) }, { name: 'b.pdf', mimeType: 'application/pdf', buffer: await mk(3) }]);
  ok(await p.locator('#pm-list > div').count() === 2, 'merge list shows 2 files');
  let out = await PDFDocument.load(await dlBytes(p, '#pm-go')); ok(out.getPageCount() === 5, 'merge 2+3 = 5 pages, got ' + out.getPageCount());
  await p.goto(base + '/tools/pdf-split/');
  await p.setInputFiles('#ps-in', { name: 'c.pdf', mimeType: 'application/pdf', buffer: await mk(6) }); await p.fill('#ps-range', '1-2,5');
  out = await PDFDocument.load(await dlBytes(p, '#ps-go')); ok(out.getPageCount() === 3, 'split 1-2,5 = 3 pages, got ' + out.getPageCount());
  await p.fill('#ps-range', '9'); await p.click('#ps-go'); await p.waitForTimeout(400); ok((await text('#ps-msg')).includes('between 1 and 6'), 'split rejects out of range');
  await p.goto(base + '/tools/pdf-rotate/');
  await p.setInputFiles('#pr-in', { name: 'd.pdf', mimeType: 'application/pdf', buffer: await mk(2) });
  out = await PDFDocument.load(await dlBytes(p, '#pr-go')); ok(out.getPages().every(pg => pg.getRotation().angle === 90), 'rotate 90');
  await p.goto(base + '/tools/images-to-pdf/');
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  await p.setInputFiles('#ip-in', [{ name: 'x.png', mimeType: 'image/png', buffer: png }, { name: 'y.png', mimeType: 'image/png', buffer: png }]);
  out = await PDFDocument.load(await dlBytes(p, '#ip-go')); ok(out.getPageCount() === 2, 'images to pdf = 2 pages');
  // category pages
  await p.goto(base + '/category/pdf-tools/'); await p.waitForTimeout(200);
  const vis = await p.evaluate(() => [...document.querySelectorAll('.cat-sec')].filter(s => s.style.display !== 'none').map(s => s.dataset.cat));
  ok(vis.length === 1 && vis[0] === 'PDF Tools', 'category page filters: ' + vis);
  ok((await p.title()).startsWith('PDF Tools'), 'category title');
  const cr = await (await fetch(base + '/category/pdf-tools/')).text(); ok(cr.includes('CollectionPage') && cr.includes('/tools/pdf-merge/'), 'category static html has ld+links');
  // fuzzy search + slash shortcut
  await p.goto(base + '/'); await p.keyboard.press('/'); ok(await p.evaluate(() => document.activeElement.id) === 'sIn', 'slash focuses search');
  await p.keyboard.type('pasword'); await p.waitForTimeout(150); ok((await text('#sRes')).includes('Password Generator'), 'fuzzy: pasword -> Password Generator: ' + (await text('#sRes')).slice(0, 60));
  await p.fill('#sIn', 'sip'); await p.waitForTimeout(100); ok((await text('#sRes')).includes('SIP Calculator'), 'search sip');
  await p.fill('#sIn', 'merge pdf'); await p.waitForTimeout(100); await p.keyboard.press('Enter'); await p.waitForTimeout(200); ok(new URL(p.url()).pathname === '/tools/pdf-merge/', 'enter opens top hit: ' + p.url());

  // hindi
  await p.goto(base + '/hi/'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.documentElement.lang) === 'hi', 'hi lang');
  ok((await text('.hx h1')).includes('ब्राउज़र'), 'hi hero');
  ok((await text('#toolsArea')).includes('वर्ड काउंटर') && !(await text('#toolsArea')).includes('Word Counter'), 'hi cards translated');
  ok(await p.evaluate(() => document.querySelectorAll('.tc').length) === await p.evaluate(() => TOOLS.length), 'hi 178 cards');
  ok(await p.evaluate(() => document.getElementById('langBtn').getAttribute('href')) === '/', 'hi lang switch -> en');
  ok(await p.evaluate(() => !!document.querySelector('link[hreflang="hi"]') && !!document.querySelector('link[hreflang="x-default"]')), 'hreflang on hi');
  await p.click('.cb:nth-child(3)'); await p.waitForTimeout(150); ok(new URL(p.url()).pathname === '/hi/category/calculator-tools/', 'hi filter path: ' + p.url());
  await p.goto(base + '/hi/category/pdf-tools/'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => [...document.querySelectorAll('.cat-sec')].filter(s => s.style.display !== 'none').length) === 1, 'hi category page shows one section');
  await p.fill('#sIn', 'वर्ड'); await p.waitForTimeout(150); ok((await text('#sRes')).includes('वर्ड काउंटर'), 'hi search');
  await p.goto(base + '/'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.getElementById('langBtn').getAttribute('href')) === '/hi/', 'en lang switch -> hi');
  ok(await p.evaluate(() => document.querySelectorAll('.tc').length) === await p.evaluate(() => TOOLS.length), 'en 178 cards');
  ok((await fetch(base + '/sitemap.xml').then(r => r.text())).includes('/hi/category/'), 'sitemap has hi');
  // hindi tool pages
  for (const id of ['emi-calculator', 'word-counter', 'pdf-merge']) {
    await p.goto(base + '/hi/tools/' + id + '/'); await p.waitForTimeout(400);
    ok(await p.evaluate(() => document.documentElement.lang) === 'hi', 'hi tool lang ' + id);
    ok(await p.evaluate(i => document.querySelector('.page.active .tool-hd h1').textContent === HI_TOOLS[i].n, id), 'hi tool h1 ' + id);
    ok(await p.evaluate(() => document.getElementById('langBtn').getAttribute('href')) === '/tools/' + id + '/', 'hi tool lang link ' + id);
    ok(await p.evaluate(() => document.title.includes('मुफ्त ऑनलाइन टूल')), 'hi tool title ' + id);
  }
  await p.goto(base + '/tools/emi-calculator/'); await p.waitForTimeout(300); ok(await p.evaluate(() => document.getElementById('langBtn').getAttribute('href')) === '/hi/tools/emi-calculator/', 'en tool lang link');
  ok(await p.evaluate(() => !!document.querySelector('link[rel=alternate][hreflang=hi]')), 'en tool has hreflang');
  await p.goto(base + '/hi/'); await p.waitForTimeout(300); await p.evaluate(() => openTool('sip-calculator')); await p.waitForTimeout(200);
  ok(new URL(p.url()).pathname === '/hi/tools/sip-calculator/', 'hi open path ' + p.url());
  // command palette, shortcuts, saved results, share card
  await p.goto(base + '/'); await p.waitForTimeout(300);
  await p.keyboard.press('Control+k'); await p.waitForTimeout(150);
  ok(await p.evaluate(() => !!document.getElementById('palDlg') && document.activeElement.id === 'palIn'), 'palette opens focused');
  await p.keyboard.type('emi'); await p.waitForTimeout(150);
  ok(await p.evaluate(() => document.querySelectorAll('#palList .pal-it').length) > 0, 'palette results');
  await p.keyboard.press('ArrowDown'); await p.keyboard.press('ArrowUp'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  ok(new URL(p.url()).pathname.startsWith('/tools/') && !(await p.evaluate(() => !!document.getElementById('palDlg'))), 'palette Enter opens tool + closes: ' + p.url());
  await p.keyboard.press('Control+k'); await p.waitForTimeout(100); await p.keyboard.press('Escape'); ok(!(await p.evaluate(() => !!document.querySelector('.dlg'))), 'Esc closes palette');
  await p.keyboard.press('Shift+?'); await p.waitForTimeout(100); ok(await p.evaluate(() => !!document.getElementById('shortDlg')), '? opens shortcuts'); await p.keyboard.press('Escape');
  await p.goto(base + '/tools/sip-calculator/'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => !!document.querySelector('.glink')), 'guide link on sip');
  await p.evaluate(() => localStorage.removeItem('th-saved'));
  await p.click('.tact button[onclick^="saveResult"]'); await p.waitForTimeout(200);
  ok(await p.evaluate(() => !!document.querySelector('.svbox li')), 'saved result listed');
  await p.goto(base + '/tools/sip-calculator/?m=9999&r=10&y=5'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => !!document.querySelector('.svbox li')), 'saved persists after reload');
  await p.click('.svbox button:has-text("Restore")'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => document.getElementById('cf-m').value) !== '9999', 'restore resets inputs: ' + await p.evaluate(() => document.getElementById('cf-m').value));
  const [shareDl] = await Promise.all([p.waitForEvent('download', { timeout: 5000 }).catch(() => null), p.click('.tact button[onclick^="shareCard"]')]);
  ok(shareDl && shareDl.suggestedFilename() === 'sip-calculator-result.png', 'share card downloads png');
  await p.click('.svbox button:has-text("Delete")'); await p.waitForTimeout(150); ok(!(await p.evaluate(() => !!document.querySelector('.svbox'))), 'delete removes saved');
  // guides + all tools pages
  for (const g of ['how-emi-is-calculated', 'old-vs-new-tax-regime', 'strong-password-guide']) {
    await p.goto(base + '/guides/' + g + '/'); await p.waitForTimeout(150);
    ok(await p.evaluate(() => document.querySelectorAll('h1').length === 1 && document.querySelectorAll('.g-tools a').length >= 2 && document.querySelectorAll('script[type="application/ld+json"]').length >= 3), 'guide ok ' + g);
    ok(await p.evaluate(() => document.querySelector('link[rel=canonical]').href.includes('/guides/')), 'guide canonical ' + g);
  }
  await p.goto(base + '/tools/'); ok(await p.evaluate(() => document.querySelectorAll('.g-az a').length) === await (async () => (await (await fetch(base + '/sitemap.xml')).text()).match(/<loc>[^<]*?\/\/[^\/]+\/tools\/[a-z0-9-]+\/<\/loc>/g).length)(), 'A-Z lists every tool');
  await p.goto(base + '/guides/'); ok(await p.evaluate(() => document.querySelectorAll('.g-item').length) === 10, 'guides index 10');
  // embed
  await p.goto(base + '/embed/emi-calculator/'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => document.documentElement.hasAttribute('data-embed')), 'embed attr');
  ok(await p.evaluate(() => getComputedStyle(document.querySelector('.hdr')).display) === 'none', 'embed hides header');
  ok(await p.evaluate(() => getComputedStyle(document.getElementById('embedCredit')).display) !== 'none', 'embed credit visible');
  ok(await p.evaluate(() => document.querySelector('meta[name=robots]').content.includes('noindex')), 'embed noindex');
  // embed dialog + share params
  await p.goto(base + '/tools/emi-calculator/'); await p.waitForTimeout(400);
  ok((await p.evaluate(() => [...document.querySelectorAll('.tbtn')].map(b => b.textContent).join('|'))).includes('Embed'), 'embed button present');
  await p.evaluate(() => showEmbed('emi-calculator')); await p.waitForTimeout(150);
  ok((await p.evaluate(() => (document.querySelector('.dlg textarea, .dlg input, dialog textarea')||{}).value||'')).includes('/embed/emi-calculator/'), 'embed snippet');
  // new tools produce output
  for (const id of ['hra-calculator','gratuity-calculator','swp-calculator','stepup-sip-calculator','loan-prepayment-calculator','rd-calculator','income-tax-india','fd-calculator','ppf-calculator','cagr-calculator','nps-calculator','epf-calculator','home-loan-eligibility','ssy-calculator','inflation-calculator']) {
    await p.goto(base + '/tools/' + id + '/'); await p.waitForTimeout(300);
    const t = await p.evaluate(() => (document.querySelector('.page.active')||document.body).innerText);
    ok(/\d[\d,]{3,}/.test(t) && !/NaN|undefined|Infinity/.test(t), id + ' default output sane');
  }
  for (const id of ['pdf-to-jpg','pdf-delete-pages','pdf-page-numbers','webp-converter']) {
    await p.goto(base + '/tools/' + id + '/'); await p.waitForTimeout(300);
    ok((await p.evaluate(() => document.querySelector('.page.active input[type=file]') !== null)), id + ' has file input');
  }
  // old ids no longer served, renamed exist
  ok((await fetch(base + '/tools/json-validator/')).ok && (await fetch(base + '/tools/images-to-pdf/')).ok, 'renamed pages exist');
  // pwa / og
  const mf = await (await fetch(base + '/manifest.webmanifest')).json(); ok(mf.icons.length === 3, 'manifest');
  ok((await fetch(base + '/og-image.png')).ok && (await fetch(base + '/sw.js')).ok && (await fetch(base + '/vendor/pdf-lib.min.js')).ok, 'og/sw/vendor served');
  await p.goto(base + '/'); await p.waitForTimeout(800);
  ok(await p.evaluate(async () => !!(await navigator.serviceWorker.getRegistration())), 'service worker registered');
  ok(await p.evaluate(() => document.querySelector('meta[property="og:image"]').content.endsWith('/og-image.png')), 'og:image meta');
  ok(errs.length === 0, 'page errors: ' + errs.slice(0, 3).join(' | '));
  console.log(fails ? 'E2E FAILURES: ' + fails : 'E2E ALL PASS');
  await b.close(); srv.close(); process.exit(fails ? 1 : 0);
})();
