const { chromium } = require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..','dist-lite');
const cfg=JSON.parse(fs.readFileSync(path.join(root,'vercel.json'),'utf8'));
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/woff2','.png':'image/png','.xml':'application/xml','.json':'application/json'};
const srv=http.createServer((q,s)=>{let u=decodeURIComponent(q.url.split('?')[0]);let f=path.join(root,u);
 if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');
 if(!fs.existsSync(f)){for(const r of cfg.rewrites){const pre=r.source.replace('/:path*','');if(u===pre||u.startsWith(pre+'/')){f=path.join(root,r.destination);break}}}
 if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){s.writeHead(404);return s.end('404')}
 s.writeHead(200,{'content-type':mime[path.extname(f)]||'application/octet-stream'});s.end(fs.readFileSync(f))});
let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log('FAIL',m)}};
srv.listen(0,async()=>{const base='http://localhost:'+srv.address().port;
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 const act=()=>p.evaluate(()=>document.querySelector('.page.active')&&document.querySelector('.page.active').id);
 for(const id of ['emi-calculator','word-counter','pdf-merge','income-tax-india','qr-generator']){await p.goto(base+'/tools/'+id+'/');await p.waitForTimeout(300);ok((await act())!=='pg-home',id+' opens');ok((await p.title()).includes('Kitwell'),id+' title '+await p.title());ok(await p.evaluate(()=>document.querySelector('link[rel=canonical]').href.includes('/tools/')),id+' canonical');}
 await p.goto(base+'/category/pdf-tools/');await p.waitForTimeout(300);ok(await p.evaluate(()=>[...document.querySelectorAll('.cat-sec')].filter(s=>s.style.display!=='none').length)===1,'cat');
 await p.goto(base+'/hi/');await p.waitForTimeout(300);ok((await p.evaluate(()=>document.documentElement.lang))==='hi','hi');
 await p.goto(base+'/hi/category/pdf-tools/');await p.waitForTimeout(300);ok(await p.evaluate(()=>[...document.querySelectorAll('.cat-sec')].filter(s=>s.style.display!=='none').length)===1,'hi cat');
 await p.goto(base+'/embed/emi-calculator/');await p.waitForTimeout(300);ok(await p.evaluate(()=>document.documentElement.hasAttribute('data-embed')&&getComputedStyle(document.querySelector('.hdr')).display==='none'),'embed');
 for(const pg of ['about','contact','privacy','terms','disclaimer']){await p.goto(base+'/'+pg+'/');await p.waitForTimeout(200);ok((await act())==='pg-'+pg,pg)}
 await p.goto(base+'/');await p.waitForTimeout(300);await p.click('.tc');await p.waitForTimeout(300);ok(new URL(p.url()).pathname.startsWith('/tools/'),'click path');await p.goBack();await p.waitForTimeout(300);ok((await act())==='pg-home','back');
 ok(errs.length===0,'errors '+errs.slice(0,2));
 console.log(fails?'LITE FAILURES '+fails:'LITE ALL PASS');await b.close();srv.close();process.exit(fails?1:0)});
