// Known-answer tests: run each calc tool's compute() with defined inputs and check the text of the output.
const vm=require('vm'),fs=require('fs');const R=__dirname+'/../src/';
vm.runInThisContext(['icons','content-top','content','helpers','tools-data'].map(f=>fs.readFileSync(R+f+'.js','utf8')).join('\n')+';globalThis.TOOLS=TOOLS;');
const strip=h=>String(h).replace(/<[^>]+>/g,' ').replace(/,/g,'').replace(/\s+/g,' ');
let fails=0,n=0;
function run(id,over,...exp){
  const t=TOOLS.find(x=>x.id===id); const v={}; t.fields.forEach(f=>v[f.id]=f.value); Object.assign(v,over||{});
  let out; try{ out=strip(t.compute(v)); }catch(e){ out='THROW '+e.message; }
  exp.forEach(e=>{ n++; if(!out.includes(e)){ fails++; console.log('FAIL',id,JSON.stringify(over||{}),'expected',e,'got',out.slice(0,140)); } });
}
run('simple-interest',{p:10000,r:6,t:3},'1800','11800');
run('compound-interest',{p:10000,r:6,t:5,n:1},'13382.2');
run('discount-calculator',{price:1000,pct:20},'800','200');
run('tip-calculator',{bill:50,pct:15,people:1},'7.50','57.50');
run('tip-calculator',{bill:100,pct:20,people:4},'30');
run('mean-median-mode-calculator',{nums:'4, 8, 6, 5, 3, 8, 9'},'6.1429');
run('ratio-simplifier',{a:12,b:18},'2');
run('square-root',{n:144},'12');
run('hcf-lcm',{nums:'12, 18, 24'},'6','72');
run('percent-error',{exp:100,obs:95},'5');
run('break-even',{fixed:5000,price:25,cost:10},'334');
run('markup-calculator',{cost:50,sell:80},'60');
run('markup-calculator',{cost:50,sell:80},'37.5');
run('leap-year',{y:2024},'leap');
run('leap-year',{y:1900},'not');
run('leap-year',{y:2000},'leap');
run('quadratic-solver',{a:1,b:-3,c:2},'2','1');
run('triangle-calculator',{a:3,b:4},'5');
run('fuel-cost',{dist:300,eff:15,price:100},'2000');
run('emi-calculator',{p:500000,r:9,n:60},'10379.18','122750');
run('loan-calculator',{p:200000,r:7.5,y:15},'1854');
run('sip-calculator',{m:5000,r:12,y:10},'1161695','561695');
run('sip-calculator',{m:10000,r:0,y:1},'120000');
run('fd-calculator',{p:100000,r:7,y:5,q:'4'},'141477.82');
run('ppf-calculator',{a:150000,r:7.1,y:15},'4068209');
run('ppf-calculator',{a:150000,r:7.1,y:10},'minimum tenure');
run('cagr-calculator',{s:100000,e:250000,y:5},'20.11%');
run('income-tax-india',{inc:1275000,sal:'1',ded:0},'0.00 New Regime Tax','187200.00 Old Regime Tax');
run('income-tax-india',{inc:1500000,sal:'1',ded:150000},'97500.00 New Regime Tax');
run('income-tax-india',{inc:1200000,sal:'1',ded:0},'0.00 New Regime Tax');
run('income-tax-india',{inc:1300000,sal:'1',ded:0},'26000.00 New Regime Tax');
run('income-tax-india',{inc:550000,sal:'1',ded:0},'0.00 Old Regime Tax');
run('income-tax-india',{inc:800000,sal:'1',ded:150000},'33800.00 Old Regime Tax');
run('income-tax-india',{inc:2500000,sal:'1',ded:0},'319800.00 New Regime Tax','569400.00 Old Regime Tax');
// more India calculators (independent closed-form cross-checks)
run('hra-calculator',{b:50000,h:20000,r:18000,m:'0.5'},'13000.00 Exempt HRA (monthly)','156000.00 Exempt HRA (yearly)','84000.00 Taxable HRA');
run('hra-calculator',{b:50000,h:20000,r:2000,m:'0.5'},'0.00 Exempt HRA (monthly)');
run('gratuity-calculator',{s:60000,y:8,m:7},'311538.46','9 Years Counted');
run('gratuity-calculator',{s:60000,y:8,m:2},'8 Years Counted');
run('gratuity-calculator',{s:60000,y:3,m:0},'5 years');
{ const C=2000000,W=15000,i=0.08/12,n=180; const fb=C*Math.pow(1+i,n)-W*(Math.pow(1+i,n)-1)/i; run('swp-calculator',{c:C,w:W,r:8,y:15},fb.toFixed(2)); }
run('swp-calculator',{c:100000,w:20000,r:0,y:10},'0.00 Final Balance','0 yr 5 mo');
{ const P=5000,s=0.10,i=0.12/12,Y=10; let fv=0,inv=0; for(let j=0;j<Y;j++){const A=P*Math.pow(1+s,j); fv+=A*((Math.pow(1+i,12)-1)/i)*(1+i)*Math.pow(1+i,12*(Y-1-j)); inv+=A*12;} run('stepup-sip-calculator',{m:P,s:10,r:12,y:Y},fv.toFixed(2),inv.toFixed(2)); }
run('stepup-sip-calculator',{m:5000,s:0,r:12,y:10},'1161695');
run('loan-prepayment-calculator',{p:3000000,r:8.5,n:240,k:24,a:0},'0 Months Saved','0.00 Interest Saved');
run('loan-prepayment-calculator',{p:3000000,r:8.5,n:240,k:24,a:300000},'26034.70');
{ const r=run; }
{ const t=TOOLS.find(x=>x.id==='loan-prepayment-calculator'); const o=strip(t.compute({p:3000000,r:8.5,n:240,k:24,a:300000})); const ms=+o.match(/(\d+) Months Saved/)[1]; n++; if(!(ms>20&&ms<80)){fails++;console.log('FAIL prepay months saved',ms);} }
run('rd-calculator',{d:5000,r:0,n:60},'300000.00 Total Deposited','300000.00 Maturity');
{ const q=0.065/4,R=5000,nq=20; const m=R*(Math.pow(1+q,nq)-1)/(1-Math.pow(1+q,-1/3)); run('rd-calculator',{d:R,r:6.5,n:60},m.toFixed(2)); }

// ---- new India calculators (closed-form / loop checks written independently) ----
{ const i=0.1/12,n=360,fv=5000*((Math.pow(1+i,n)-1)/i)*(1+i); run('nps-calculator',{},fv.toFixed(2),(fv*0.6).toFixed(2),(fv*0.4*0.06/12).toFixed(2)); }
run('nps-calculator',{a:60,ra:60},'');
run('epf-calculator',{b:10000,a:57,ra:58,g:0,r:0,cur:0},'18804.00 Estimated','14400.00 Your','4404.00 Employer');
{ const i=0.085/12; let pv=0; for(let k=1;k<=240;k++) pv+=40000/Math.pow(1+i,k); run('home-loan-eligibility',{},pv.toFixed(2),'40000.00 Affordable'); }
run('home-loan-eligibility',{emi:60000},'no new EMI fits');
{ const r=0.082,A=150000,fv=A*((Math.pow(1+r,15)-1)/r)*(1+r)*Math.pow(1+r,6); run('ssy-calculator',{},fv.toFixed(2),'2250000.00 Total Deposited'); }
run('ssy-calculator',{a:100},'between 250');
run('inflation-calculator',{},'179084.77','55839.48','44.2%');
// text transforms
const tt=(id,label,inp,exp)=>{ const t=TOOLS.find(x=>x.id===id); const tr=t.transforms.find(x=>x.label===label); n++; let o; try{o=tr.run(inp);}catch(e){o='THROW '+e.message;} if(String(o)!==exp){fails++;console.log('FAIL',id,label,JSON.stringify(o),'expected',JSON.stringify(exp));} };
const labels=id=>TOOLS.find(x=>x.id===id).transforms.map(x=>x.label);
console.log('case-converter:',labels('case-converter').join(' | '));
console.log('text-sorter:',labels('text-sorter').join(' | '));
tt('text-sorter','A to Z','b\na\nc','a\nb\nc'); tt('text-sorter','Z to A','b\na\nc','c\nb\na');
tt('case-converter','UPPERCASE','hello world','HELLO WORLD');
tt('rot13','ROT13','Hello','Uryyb');
console.log(fails?`COMPUTE FAILURES: ${fails}/${n}`:`COMPUTE ALL PASS (${n} checks)`); process.exit(fails?1:0);
