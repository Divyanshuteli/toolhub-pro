const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage();
  const consoleErrors = [];
  const pageErrors = [];
  page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
  page.on('pageerror', err => pageErrors.push(err.message));

  const fileUrl = 'file://' + path.join(__dirname, '..', 'dist-single', 'index.html');
  await page.goto(fileUrl);
  await page.waitForTimeout(300);

  const tools = await page.evaluate(() => TOOLS.map(t => ({ id: t.id, kind: t.kind })));
  console.log('Total tools to test:', tools.length);

  const failures = [];
  for (const t of tools) {
    consoleErrors.length = 0;
    pageErrors.length = 0;
    try {
      await page.evaluate(id => { openTool(id); }, t.id);
      await page.waitForTimeout(40);
      // check the right page/body actually rendered something
      const ok = await page.evaluate((id) => {
        if (!document.querySelector('.page.active') || (document.querySelector('.page.active').id==='pg-home')) return false;
        const active = document.querySelector('.page.active');
        if (!active) return false;
        if (active.id === 'pg-generic-tool') {
          const body = document.getElementById('gtBody');
          return body && body.innerHTML.trim().length > 0;
        }
        return true;
      }, t.id);
      if (!ok) failures.push({ id: t.id, kind: t.kind, reason: 'empty body after render' });
      if (pageErrors.length) failures.push({ id: t.id, kind: t.kind, reason: 'pageerror: ' + pageErrors.join(' | ') });
    } catch (e) {
      failures.push({ id: t.id, kind: t.kind, reason: 'exception: ' + e.message });
    }
  }

  console.log('\n=== FAILURES:', failures.length, '===');
  failures.forEach(f => console.log(`[${f.kind}] ${f.id}: ${f.reason}`));

  // also test navigating every static page
  const staticPages = ['home','about','contact','privacy','terms','disclaimer'];
  for (const p of staticPages) {
    pageErrors.length = 0;
    await page.evaluate(id => navigate(id), p);
    await page.waitForTimeout(30);
    if (pageErrors.length) console.log('STATIC PAGE ERROR', p, pageErrors.join(' | '));
  }

  // back button checks
  const bk=[];
  for (const t of tools) {
    await page.evaluate(()=>navigate('home',{noPush:true}));
    await page.evaluate(id=>openTool(id),t.id);
    const has=await page.evaluate(()=>{const a=document.querySelector('.page.active .bc-back');if(!a)return false;a.click();return true;});await page.waitForTimeout(50);const r=has?await page.evaluate(()=>document.querySelector('.page.active').id):'nobtn';
    if(r!=='pg-home') bk.push(t.id+':'+r);
  }
  console.log('Back button failures:',bk.length,bk.slice(0,10));
  // tool -> tool via related keeps previous
  // test search
  await page.evaluate(() => doSearch('password'));
  const searchResults = await page.evaluate(() => document.getElementById('sRes').children.length);
  console.log('\nSearch "password" results:', searchResults);

  await browser.close();
  process.exit(failures.length ? 1 : 0);
})();
