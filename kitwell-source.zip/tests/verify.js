global.document = { getElementById: ()=>({}) };
global.window = global;
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname,'..');
const files = ['src/icons.js','src/content-top.js','src/content.js','src/helpers.js','src/wordlist.js','src/tools-data.js','src/custom-tools.js','src/pdf-tools.js','src/extra-tools.js'];
files.forEach(f => {
  const code = fs.readFileSync(path.join(root,f),'utf8');
  require('vm').runInThisContext(code, {filename:f});
});

const customIds = TOOLS.filter(t=>t.kind==='custom').map(t=>t.id);
const missing = customIds.filter(id => !TOOL_CUSTOM[id]);
console.log('Total tools:', TOOLS.length);
console.log('Total custom tools needed:', customIds.length);
console.log('Missing implementations:', missing.length ? missing.join(', ') : 'NONE - all implemented');
const extra = Object.keys(TOOL_CUSTOM).filter(id => !customIds.includes(id));
console.log('Unused TOOL_CUSTOM entries:', extra.length ? extra.join(', ') : 'none');

const ids = TOOLS.map(t=>t.id);
const dupes = ids.filter((id,i)=>ids.indexOf(id)!==i);
console.log('Duplicate ids:', dupes.length ? [...new Set(dupes)].join(', ') : 'none');

const convertMissingTable = TOOLS.filter(t=>t.kind==='convert' && typeof global[t.table]==='undefined');
console.log('Convert tools with missing table:', convertMissingTable.map(t=>t.id).join(', ')||'none');

const byKind = {}; TOOLS.forEach(t=>byKind[t.kind]=(byKind[t.kind]||0)+1);
console.log('By kind:', JSON.stringify(byKind));

const byCat = {}; TOOLS.forEach(t=>byCat[t.cat]=(byCat[t.cat]||0)+1);
console.log('By category:', JSON.stringify(byCat,null,0));

// Validate every calc tool's compute() runs without throwing, using default field values
let calcErrors = [];
TOOLS.filter(t=>t.kind==='calc').forEach(t => {
  const values = {};
  t.fields.forEach(f => { values[f.id] = f.type==='checkbox' ? false : (f.value ?? ''); });
  try { t.compute(values); } catch(e) { calcErrors.push(t.id+': '+e.message); }
});
console.log('Calc tools with runtime errors on default values:', calcErrors.length ? calcErrors.join(' | ') : 'none');

// Validate every text tool's transform fns run
let textErrors = [];
TOOLS.filter(t=>t.kind==='text' && t.transforms).forEach(t => {
  t.transforms.forEach(tr => { try { tr.run('Sample Text 123'); } catch(e){ textErrors.push(t.id+'/'+tr.label+': '+e.message); } });
});
console.log('Text tools with runtime errors:', textErrors.length ? textErrors.join(' | ') : 'none');

console.log('\nALL CHECKS DONE');
