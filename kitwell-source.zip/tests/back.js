const { chromium } = require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');const root=require('path').join(__dirname,'..','dist');
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/woff2','.png':'image/png'};
const srv=http.createServer((q,s)=>{let u=decodeURIComponent(q.url.split('?')[0]);let f=path.join(root,u);if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.existsSync(f)){s.writeHead(404);return s.end()}s.writeHead(200,{'content-type':mime[path.extname(f)]||'x'});s.end(fs.readFileSync(f))}).listen(0,async()=>{
const base='http://localhost:'+srv.address().port;const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});const p=await b.newPage();let f=0;const ok=(c,m)=>{if(!c){f++;console.log('FAIL',m)}};
const pth=()=>new URL(p.url()).pathname;const back=async()=>{await p.click('.page.active .bc-back');await p.waitForTimeout(250)};
await p.goto(base+'/');await p.waitForTimeout(300);
await p.evaluate(()=>openTool('emi-calculator'));await p.waitForTimeout(200);ok(pth()==='/tools/emi-calculator/','open');
await back();ok(pth()==='/','back to home '+pth());ok(await p.evaluate(()=>document.querySelector('.page.active').id)==='pg-home','home visible');
// tool -> tool -> back -> back
await p.evaluate(()=>openTool('emi-calculator'));await p.waitForTimeout(150);await p.evaluate(()=>openTool('sip-calculator'));await p.waitForTimeout(150);
await back();ok(pth()==='/tools/emi-calculator/','back to previous tool '+pth());await back();ok(pth()==='/','then home '+pth());
// category -> tool -> back returns to category
await p.goto(base+'/category/pdf-tools/');await p.waitForTimeout(300);await p.evaluate(()=>openTool('pdf-merge'));await p.waitForTimeout(150);await back();ok(pth()==='/category/pdf-tools/','back to category '+pth());
// deep link then Back -> home, stays on site
await p.goto(base+'/tools/pdf-split/');await p.waitForTimeout(300);await back();ok(pth()==='/','deep link back -> home '+pth());
// browser back
await p.evaluate(()=>openTool('word-counter'));await p.waitForTimeout(150);await p.goBack();await p.waitForTimeout(250);ok(pth()==='/','browser back '+pth());
// hindi
await p.goto(base+'/hi/');await p.waitForTimeout(300);await p.evaluate(()=>openTool('emi-calculator'));await p.waitForTimeout(150);await back();ok(pth()==='/hi/','hi back '+pth());
console.log(f?'BACK FAIL '+f:'BACK ALL PASS');await b.close();srv.close()});
