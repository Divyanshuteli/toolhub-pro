// Assembles the single-file dist/index.html from src/ pieces.
const fs = require('fs');
const path = require('path');
const root = __dirname;
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

const css = read('src/styles.css');
const vendor = read('src/vendor/qrcode.js') + '\n' + read('src/vendor/spark-md5.js');
const wordlist = read('src/wordlist.js');
const helpers = read('src/icons.js') + '\n' + read('src/i18n-hi.js') + '\n' + read('src/guides-meta.js') + '\n' + read('src/content-top.js') + '\n' + read('src/content.js') + '\n' + read('src/helpers.js');
const toolsData = read('src/tools-data.js');
const customTools = read('src/custom-tools.js') + '\n' + read('src/pdf-tools.js') + '\n' + read('src/extra-tools.js');
const dedicatedTools = read('src/dedicated-tools.js');
const engine = read('src/engine.js');
const crypto = require('crypto');
const bundleJs = [vendor, wordlist, helpers, toolsData, customTools, dedicatedTools, read('src/boot.js'), engine, read('src/features.js')].join('\n;\n');
const h10 = s => crypto.createHash('md5').update(s).digest('hex').slice(0, 10);
const JS_NAME = `app.${h10(bundleJs)}.js`, CSS_NAME = `app.${h10(css)}.css`;
// mode 'ext': external hashed assets (small pages). mode 'inline': one self-contained file (used for file:// tests).
function assemble(tpl, mode) {
  let html = tpl;
  html = html.replace('<!--__CSS__-->', () => mode === 'inline' ? `<style>\n${css}\n</style>` : `<link rel="stylesheet" href="/assets/${CSS_NAME}">`);
  html = html.replace('<!--__BUNDLE__-->', () => mode === 'inline' ? `<script>\n${bundleJs}\n</script>` : `<script src="/assets/${JS_NAME}"></script>`);
  return html;
}
const tplEn = read('src/template.html');
const SITE = (process.env.SITE_URL || 'https://yoursite.com').replace(/\/$/, '');


// load tool data for per-page metadata
const vm = require('vm');
vm.runInThisContext(read('src/icons.js') + '\n' + read('src/i18n-hi.js') + '\n' + read('src/guides-meta.js') + '\n' + read('src/content-top.js') + '\n' + read('src/content.js') + '\n' + read('src/tools-data.js') + '\n;globalThis.__T={TOOLS,ctFaq,ctText,ctSteps,CAT_CONFIG,HI_TOOLS,HI_CAT,HI_CAT_SHORT,HI_UI,GUIDES,toolIconSvg,catIconSvg,svgIcon};');
const { TOOLS, ctFaq, ctText, CAT_CONFIG, HI_TOOLS, HI_CAT, HI_CAT_SHORT, HI_UI, GUIDES, toolIconSvg, catIconSvg } = globalThis.__T;
const GUIDE_BODY = vm.runInThisContext('(function(){' + read('src/guides.js') + '\nreturn GUIDE_BODY;})()');


// ---------- HOME HERO TOKENS ----------
const _fmt = n => Math.round(n).toLocaleString('en-IN');
const _fmt2 = n => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const _emi = (() => { const i = 9 / 1200, n = 60; return 500000 * i * Math.pow(1 + i, n) / (Math.pow(1 + i, n) - 1); })();
const _sip = (() => { const i = 12 / 1200, n = 120; return 5000 * ((Math.pow(1 + i, n) - 1) / i) * (1 + i); })();
const _txt = 'Kitwell runs in your browser';
function heroTokens(lang) {
  const hi = lang === 'hi', T = id => TOOLS.find(t => t.id === id), nm = id => hi ? HI_TOOLS[id].n : T(id).name;
  const words = _txt.split(/\s+/).length, chars = _txt.length;
  const en = { BADGE: 'Free to use. No account needed.', H1: 'Free tools<br>that run in<br><span>your browser.</span>', P: 'Calculators, text tools, image and PDF tools, developer utilities and SEO helpers. Most tools never send your input anywhere.', CTA1: 'Browse all tools', CTA2: 'Search tools',
    F1T: 'Runs in your browser', F1D: 'Your input stays on your device', F2T: 'No login', F2D: 'Open a tool and use it', F3T: 'Free', F3D: 'No paywall, no limits',
    ST1: 'Free tools', ST2: 'Categories', ST3: 'Languages', ST4: 'Guides', EXAMPLE: 'Example',
    A_LBL: 'Monthly EMI', A_SUB: 'Loan of 5,00,000 at 9% for 60 months', B_LBL: 'Value after 10 years', B_SUB: '5,000 a month at 12% a year', C_WL: 'words', C_CL: 'characters' };
  const hin = { BADGE: HI_UI.badge, H1: 'मुफ्त टूल्स<br>जो चलते हैं<br><span>आपके ब्राउज़र में।</span>', P: 'कैलकुलेटर, टेक्स्ट, इमेज और PDF टूल्स, डेवलपर यूटिलिटी और SEO हेल्पर। ज़्यादातर टूल्स आपका इनपुट कहीं नहीं भेजते।', CTA1: HI_UI.browse, CTA2: 'टूल खोजें',
    F1T: 'ब्राउज़र में चलता है', F1D: 'आपका इनपुट आपके डिवाइस पर रहता है', F2T: 'लॉगिन नहीं', F2D: 'टूल खोलें और इस्तेमाल करें', F3T: 'मुफ्त', F3D: 'कोई पेवॉल या सीमा नहीं',
    ST1: 'मुफ्त टूल्स', ST2: 'श्रेणियां', ST3: 'भाषाएं', ST4: 'गाइड', EXAMPLE: 'उदाहरण',
    A_LBL: 'मासिक EMI', A_SUB: '9% पर 60 महीने के लिए 5,00,000 का लोन', B_LBL: '10 साल बाद मूल्य', B_SUB: '12% सालाना पर हर महीने 5,000', C_WL: 'शब्द', C_CL: 'अक्षर' };
  return Object.assign({}, hi ? hin : en, { A_NAME: nm('emi-calculator'), A_NUM: _fmt2(_emi), B_NAME: nm('sip-calculator'), B_NUM: _fmt(_sip), C_NAME: nm('word-counter'), C_TEXT: _txt, C_W: words, C_CH: chars });
}
function applyTokens(tpl, lang) { const t = heroTokens(lang); return tpl.replace(/\{\{([A-Z0-9_]+)\}\}/g, (m, k) => { if (!(k in t)) throw new Error('token ' + k); return t[k]; }); }

const base = assemble(applyTokens(tplEn, 'en'), 'ext').replace(/__SITE__/g, SITE);
const baseSingle = assemble(applyTokens(tplEn, 'en'), 'inline').replace(/__SITE__/g, SITE);
const dist = path.join(root, 'dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
fs.writeFileSync(path.join(dist, 'index.html'), base);
fs.mkdirSync(path.join(dist, 'assets'), { recursive: true });
fs.writeFileSync(path.join(dist, 'assets', JS_NAME), bundleJs);
fs.writeFileSync(path.join(dist, 'assets', CSS_NAME), css);
const distSingle = path.join(root, 'dist-single');
fs.rmSync(distSingle, { recursive: true, force: true }); fs.mkdirSync(distSingle, { recursive: true });
fs.writeFileSync(path.join(distSingle, 'index.html'), baseSingle);
fs.copyFileSync(path.join(root, 'favicon.svg'), path.join(dist, 'favicon.svg'));
fs.mkdirSync(path.join(dist, 'vendor'), { recursive: true });
['pdf-lib.min.js', 'pdf.min.js', 'pdf.worker.min.js'].forEach(f => fs.copyFileSync(path.join(root, 'src/vendor', f), path.join(dist, 'vendor', f)));
fs.cpSync(path.join(root, 'fonts'), path.join(dist, 'fonts'), { recursive: true });

['og-image.png', 'icon-192.png', 'icon-512.png'].forEach(f => fs.copyFileSync(path.join(root, 'public', f), path.join(dist, f)));
fs.writeFileSync(path.join(dist, 'manifest.webmanifest'), JSON.stringify({ name: 'Kitwell', short_name: 'Kitwell', description: 'Free online tools that run in your browser.', start_url: '/', scope: '/', display: 'standalone', background_color: '#0A1120', theme_color: '#0A1120', icons: [{ src: '/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: '/icon-512.png', sizes: '512x512', type: 'image/png' }, { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }] }));
fs.writeFileSync(path.join(dist, 'sw.js'), fs.readFileSync(path.join(root, 'src/sw.js'), 'utf8').replace('__VERSION__', String(Date.now())));
const attr = s => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const txt = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
function variant(url, title, desc, extraLd, noscript, b0, alts) {
  let h = b0 || base;
  if (alts) h = h.replace('</head>', () => alts + '\n</head>');
  h = h.replace(/<title>[^<]*<\/title>/, () => `<title>${txt(title)}</title>`);
  h = h.replace(/(<meta name="description" content=")[^"]*(")/, (m, a, b) => a + attr(desc) + b);
  h = h.replace(/(<meta property="og:title" content=")[^"]*(")/, (m, a, b) => a + attr(title) + b);
  h = h.replace(/(<meta property="og:description" content=")[^"]*(")/, (m, a, b) => a + attr(desc) + b);
  h = h.replace(/(<meta property="og:url" content=")[^"]*(")/, (m, a, b) => a + url + b);
  h = h.replace(/(<link rel="canonical" href=")[^"]*(")/, (m, a, b) => a + url + b);
  if (extraLd) h = h.replace('</head>', () => `<script type="application/ld+json">${JSON.stringify(extraLd)}</script>\n</head>`);
  if (noscript) h = h.replace('<body>', () => `<body>\n<noscript><div style="max-width:760px;margin:20px auto;padding:0 16px;font-family:system-ui,sans-serif">${noscript}</div></noscript>`);
  return h;
}
const today = new Date().toISOString().slice(0, 10);
const urls = [{ loc: SITE + '/', pri: '1.0' }];
const esch = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');

TOOLS.forEach(t => {
  const url = `${SITE}/tools/${t.id}/`;
  let desc = `${t.desc}. Free online ${t.name.toLowerCase()}: no login, no limits, runs in your browser.`;
  if (desc.length > 158) desc = `${t.desc}. Free, no login, runs in your browser.`;
  const faq = ctFaq(t);
  const ld = [
    { '@context': 'https://schema.org', '@type': 'SoftwareApplication', name: t.name, description: t.desc, url, applicationCategory: 'UtilitiesApplication', operatingSystem: 'Any', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
    { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: SITE + '/' },
      { '@type': 'ListItem', position: 2, name: t.cat },
      { '@type': 'ListItem', position: 3, name: t.name, item: url } ] },
    { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) },
  ];
  const ns = `<h1>${esch(t.name)}</h1><p>${esch(t.desc)}</p><p>${esch(ctText(t))}</p><p>This tool needs JavaScript enabled to run.</p>`;
  let h = variant(url, `${t.name}: Free Online Tool | Kitwell`, desc, null, ns);
  ld.forEach(o => { h = h.replace('</head>', () => `<script type="application/ld+json">${JSON.stringify(o)}</script>\n</head>`); });
  const dir = path.join(dist, 'tools', t.id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), h);
  urls.push({ loc: url, pri: ['word-counter', 'password-generator', 'json-formatter', 'bmi-calculator', 'age-calculator'].includes(t.id) ? '0.9' : '0.7' });
});

fs.writeFileSync(path.join(dist, 'vercel.json'), JSON.stringify({
  rewrites: [{ source: '/embed/:path*', destination: '/index.html' }],
  headers: [
    { source: '/assets/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    { source: '/fonts/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    { source: '/vendor/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    { source: '/sw.js', headers: [{ key: 'Cache-Control', value: 'no-cache' }] }
  ]
}, null, 1));
const PAGES = { about: ['About Kitwell', 'About Kitwell, a free collection of online tools that run in your browser.'],
  contact: ['Contact Kitwell', 'Contact Kitwell to suggest a tool or report a problem.'],
  privacy: ['Privacy Policy | Kitwell', 'How Kitwell handles your data, analytics and cookies.'],
  terms: ['Terms and Conditions | Kitwell', 'Terms and conditions for using Kitwell.'],
  disclaimer: ['Disclaimer | Kitwell', 'Disclaimer for the calculators and tools on Kitwell.'] };
Object.entries(PAGES).forEach(([k, [title, desc]]) => {
  const dir = path.join(dist, k);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), variant(`${SITE}/${k}/`, title, desc));
  urls.push({ loc: `${SITE}/${k}/`, pri: '0.4' });
});

const slug = c => c.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const CATS = {};
TOOLS.forEach(t => { (CATS[t.cat] = CATS[t.cat] || []).push(t); });
Object.entries(CATS).forEach(([cat, list]) => {
  const url = `${SITE}/category/${slug(cat)}/`;
  const title = `${cat}: ${list.length} Free Online Tools | Kitwell`;
  const desc = `${list.length} free ${cat.toLowerCase()}: ${list.slice(0, 4).map(t => t.name).join(', ')} and more. No login, runs in your browser.`.slice(0, 300);
  const ld = { '@context': 'https://schema.org', '@type': 'CollectionPage', name: cat, url, mainEntity: { '@type': 'ItemList', itemListElement: list.map((t, i) => ({ '@type': 'ListItem', position: i + 1, url: `${SITE}/tools/${t.id}/`, name: t.name })) } };
  const ns = `<h1>${esch(cat)}</h1><ul>${list.map(t => `<li><a href="/tools/${t.id}/">${esch(t.name)}</a>: ${esch(t.desc)}</li>`).join('')}</ul>`;
  const dir = path.join(dist, 'category', slug(cat));
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), variant(url, title, desc, ld, ns));
  urls.push({ loc: url, pri: '0.8' });
});


// ---------- HINDI (home + category pages) ----------
const HI_NEW = 'नए टूल्स';
function hiTemplate(t) {
  const R = (a, c) => { if (!t.includes(a)) throw new Error('hi template miss: ' + a.slice(0, 50)); t = t.split(a).join(c); };
  t = t.replace('<html lang="en">', '<html lang="hi">');
  R('<strong>150+ free tools.</strong> No login. Runs in your browser.', HI_UI.topbar);
  R('Browse all tools', HI_UI.browse);
  R('placeholder="Search 150+ tools"', `placeholder="${HI_UI.search}"`);
  R('id="nav-home">Home<', `id="nav-home">${HI_UI.navHome}<`);
  R('id="nav-tools">Tools<', `id="nav-tools">${HI_UI.navTools}<`);
  R('id="nav-about">About<', `id="nav-about">${HI_UI.navAbout}<`);
  R('id="nav-contact">Contact<', `id="nav-contact">${HI_UI.navContact}<`);
  R('</span>Home</a>', `</span>${HI_UI.navHome}</a>`);
  R('</span>All tools</a>', `</span>${HI_UI.all}</a>`);
  R('</span>About</a>', `</span>${HI_UI.navAbout}</a>`);
  R('</span>Contact</a>', `</span>${HI_UI.navContact}</a>`);
  R('<div class="mlabel">Categories</div>', `<div class="mlabel">${HI_UI.fCat}</div>`);
  R('Suggest a tool', HI_UI.reqBtn);
  R('>All Tools</button>', `>${HI_UI.all}</button>`);
  Object.keys(HI_CAT_SHORT).forEach(c => { const re = new RegExp(`(filterCat\\('${c.replace(/[&]/g, '&')}',this\\)">)[^<]*`); if (!re.test(t)) throw new Error('cat btn ' + c); t = t.replace(re, (m, a) => a + HI_CAT_SHORT[c]); });
  R('<h3>Popular Tools</h3>', `<h3>${HI_UI.popular}</h3>`);
  R('<h3>New Tools</h3>', `<h3>${HI_NEW}</h3>`);
  t = t.replace(/(class="ptl" onclick="openTool\('([a-z0-9-]+)'\)">(?:<span class="pr">\d+<\/span>)?)([^<]+)(<\/div>)/g, (m, a, id, n, z) => HI_TOOLS[id] ? a + HI_TOOLS[id].n + z : m);
  t = t.replace(/(openTool\('([a-z0-9-]+)'\);return false">)([^<]+)(<\/a>)/g, (m, a, id, n, z) => HI_TOOLS[id] ? a + HI_TOOLS[id].n + z : m);
  R("<h3>Can't find the tool you need?</h3><p>Tell us what is missing. New tools are added based on requests.</p>", `<h3>${HI_UI.reqH}</h3><p>${HI_UI.reqP}</p>`);
  R('>Request a tool</a>', `>${HI_UI.reqBtn}</a>`);
  // SEO block
  const i0 = t.indexOf('<h2 style="font-size:24px;font-weight:700;margin-bottom:14px');
  const i1 = t.indexOf('</div>\n    </div>\n  </section>', t.indexOf('<div class="feat-grid">', i0));
  if (i0 < 0 || i1 < 0) throw new Error('seo block');
  t = t.slice(0, i0) + `<h2 style="font-size:24px;font-weight:700;margin-bottom:14px;letter-spacing:-.01em">मुफ्त ऑनलाइन टूल्स, बिना लॉगिन, बिना सीमा</h2>
      <p style="color:var(--t2);line-height:1.8;margin-bottom:13px">Kitwell में टेक्स्ट एडिटिंग, कैलकुलेटर, यूनिट कन्वर्जन, PDF, डेवलपर यूटिलिटी और SEO जैसे ${TOOLS.length}+ मुफ्त ऑनलाइन टूल्स हैं।</p>
      <p style="color:var(--t2);line-height:1.8">ज़्यादातर टूल सीधे आपके ब्राउज़र में चलते हैं। अकाउंट या सब्सक्रिप्शन की ज़रूरत नहीं। हर टूल के पेज पर बताया गया है कि कौन-सा टूल बाहरी डेटा इस्तेमाल करता है, जैसे IP लुकअप और करेंसी रेट।</p>
      <div class="feat-grid">
        <div class="feat"><h3>ब्राउज़र में चलता है</h3><p>लगभग हर टूल आपका इनपुट लोकल में प्रोसेस करता है, सर्वर पर नहीं भेजता।</p></div>
        <div class="feat"><h3>अकाउंट नहीं चाहिए</h3><p>टूल खोलें और तुरंत इस्तेमाल करें। साइन-अप की ज़रूरत नहीं।</p></div>
        <div class="feat"><h3>मोबाइल पर आसान</h3><p>फोन, टैबलेट और डेस्कटॉप, तीनों पर चलने वाला लेआउट।</p></div>
        <div class="feat"><h3>हमेशा मुफ्त</h3><p>कोई सब्सक्रिप्शन या पेवॉल नहीं। हर टूल मुफ्त।</p></div>
      ` + t.slice(i1);
  // footer
  R('<p>150+ free online tools for text, numbers, images, code and SEO. No login. Most tools run entirely in your browser.</p>', `<p>${HI_UI.fTag}</p>`);
  R('<h4>Popular tools</h4>', `<h4>${HI_UI.fPop}</h4>`);
  R('<h4>Categories</h4>', `<h4>${HI_UI.fCat}</h4>`);
  R('<h4>Company</h4>', `<h4>${HI_UI.fCo}</h4>`);
  R(">About</a></li>", `>${HI_UI.fAbout}</a></li>`);
  R(">Contact</a></li>", `>${HI_UI.fContact}</a></li>`);
  R(">Privacy Policy</a></li>", `>${HI_UI.fPriv}</a></li>`);
  R(">Terms and Conditions</a></li>", `>${HI_UI.fTerms}</a></li>`);
  R(">Disclaimer</a></li>", `>${HI_UI.fDisc}</a></li>`);
  t = t.replace(/(scrollToCat\('[a-z]+'\);return false">)([^<]+)(<\/a>)/g, (m, a, n, z) => { const c = Object.keys(HI_CAT).find(k => k.replace(' Tools', '').replace('Calculator', 'Calculators') === n || k === n); return c ? a + HI_CAT[c] + z : m; });
  R('</span>Back to top</button>', `</span>${HI_UI.fTop}</button>`);
  R('Kitwell. All rights reserved.', 'Kitwell. ' + HI_UI.rights);
  R('href="/hi/" hreflang="hi" lang="hi" onclick="return switchLang(event)">हिन्दी</a>', 'href="/" hreflang="en" lang="en" onclick="return switchLang(event)">English</a>');
  // keep every internal link inside the Hindi tree
  t = t.replace(/href="\/tools\/(?=[a-z0-9])/g, 'href="/hi/tools/').replace(/href="\/category\//g, 'href="/hi/category/');
  t = t.split('<a class="logo" href="/" ').join('<a class="logo" href="/hi/" ').split('<a href="/" onclick="navigate(\'home\')').join('<a href="/hi/" onclick="navigate(\'home\')').split('<a class="mrow" href="/" ').join('<a class="mrow" href="/hi/" ');
  return t;
}
const baseHi = assemble(applyTokens(hiTemplate(tplEn), 'hi'), 'ext').replace(/__SITE__/g, SITE);
const alt = (en, hi) => `<link rel="alternate" hreflang="en" href="${en}">\n<link rel="alternate" hreflang="hi" href="${hi}">\n<link rel="alternate" hreflang="x-default" href="${en}">`;
{
  const url = SITE + '/hi/';
  const title = 'Kitwell | 150+ मुफ्त ऑनलाइन टूल्स';
  const desc = 'टेक्स्ट, कैलकुलेटर, इमेज, PDF, डेवलपर और SEO के 150+ मुफ्त ऑनलाइन टूल्स। लॉगिन नहीं, सब ब्राउज़र में चलता है।';
  const ns = `<h1>${esch(title)}</h1><p>${esch(desc)}</p>`;
  const dir = path.join(dist, 'hi'); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), variant(url, title, desc, null, ns, baseHi, alt(SITE + '/', url)));
  urls.push({ loc: url, pri: '0.8' });
  // add hreflang to English home
  const ip = path.join(dist, 'index.html');
  fs.writeFileSync(ip, fs.readFileSync(ip, 'utf8').replace('</head>', () => alt(SITE + '/', url) + '\n</head>'));
}


Object.entries(CATS).forEach(([cat, list]) => {
  const url = `${SITE}/hi/category/${slug(cat)}/`;
  const hc = HI_CAT[cat] || cat;
  const title = `${hc}: ${list.length} मुफ्त ऑनलाइन टूल्स | Kitwell`;
  const desc = `${hc}: ${list.slice(0, 4).map(t => (HI_TOOLS[t.id] || {}).n || t.name).join(', ')} और भी। लॉगिन नहीं, ब्राउज़र में चलता है।`;
  const ld = { '@context': 'https://schema.org', '@type': 'CollectionPage', name: hc, inLanguage: 'hi', url, mainEntity: { '@type': 'ItemList', itemListElement: list.map((t, i) => ({ '@type': 'ListItem', position: i + 1, url: `${SITE}/tools/${t.id}/`, name: (HI_TOOLS[t.id] || {}).n || t.name })) } };
  const ns = `<h1>${esch(hc)}</h1><ul>${list.map(t => `<li><a href="/tools/${t.id}/">${esch((HI_TOOLS[t.id] || {}).n || t.name)}</a>: ${esch((HI_TOOLS[t.id] || {}).d || t.desc)}</li>`).join('')}</ul>`;
  const dir = path.join(dist, 'hi', 'category', slug(cat));
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), variant(url, title, desc, ld, ns, baseHi, alt(`${SITE}/category/${slug(cat)}/`, url)));
  urls.push({ loc: url, pri: '0.6' });
  const ep = path.join(dist, 'category', slug(cat), 'index.html');
  fs.writeFileSync(ep, fs.readFileSync(ep, 'utf8').replace('</head>', () => alt(`${SITE}/category/${slug(cat)}/`, url) + '\n</head>'));
});


// Hindi tool pages (Hindi page chrome + title; the tool interface itself stays English)
TOOLS.forEach(t => {
  const hi = HI_TOOLS[t.id] || { n: t.name, d: t.desc };
  const url = `${SITE}/hi/tools/${t.id}/`, en = `${SITE}/tools/${t.id}/`;
  const title = `${hi.n}: मुफ्त ऑनलाइन टूल | Kitwell`;
  const desc = `${hi.d}। मुफ्त, लॉगिन नहीं, आपके ब्राउज़र में चलता है।`.slice(0, 200);
  const ld = { '@context': 'https://schema.org', '@type': 'SoftwareApplication', name: hi.n, description: hi.d, url, inLanguage: 'hi', applicationCategory: 'UtilitiesApplication', operatingSystem: 'Any', offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' } };
  const ns = `<h1>${esch(hi.n)}</h1><p>${esch(hi.d)}</p><p>यह टूल चलाने के लिए JavaScript चालू करें। टूल का इंटरफ़ेस अंग्रेज़ी में है।</p>`;
  const dir = path.join(dist, 'hi', 'tools', t.id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), variant(url, title, desc, ld, ns, baseHi, alt(en, url)));
  urls.push({ loc: url, pri: '0.5' });
  const ep = path.join(dist, 'tools', t.id, 'index.html');
  fs.writeFileSync(ep, fs.readFileSync(ep, 'utf8').replace('</head>', () => alt(en, url) + '\n</head>'));
});


// ---------- GUIDES + ALL TOOLS (static pages, no app JS) ----------
const logoSvg = (tplEn.match(/<svg class="logo-mark"[\s\S]*?<\/svg>/) || [''])[0];
const headPart = base.slice(0, base.indexOf('</head>') + 7);
const themeSvg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17" /><path d="M12 3.5a8.5 8.5 0 0 1 0 17z" fill="currentColor"/></svg>';
function staticShell(inner) {
  return `<body class="g-body">
<a class="skip" href="#main-content">Skip to content</a>
<header class="hdr"><div class="wrap"><div class="hdr-inner">
<a class="logo" href="/" aria-label="Kitwell home">${logoSvg}<span class="logo-tx">Kit<span>well</span></span></a>
<nav class="hnav g-nav" aria-label="Main"><a href="/">Home</a><a href="/tools/">All tools</a><a href="/guides/">Guides</a><a class="g-hide" href="/about/">About</a><span class="hsep g-hide" aria-hidden="true"></span><button type="button" class="hbtn" id="gTheme" aria-label="Switch between light and dark theme">${themeSvg}</button><a class="btn-h g-hide" href="/contact/">Contact</a></nav>
</div></div></header>
<main id="main-content" class="g-main">${inner}</main>
<footer class="g-foot"><div class="wrap"><nav aria-label="Footer"><a href="/">Home</a><a href="/tools/">All tools</a><a href="/guides/">Guides</a><a href="/about/">About</a><a href="/contact/">Contact</a><a href="/privacy/">Privacy Policy</a><a href="/terms/">Terms and Conditions</a><a href="/disclaimer/">Disclaimer</a></nav><p>&copy; ${new Date().getFullYear()} Kitwell. All rights reserved.</p></div></footer>
<script>document.getElementById('gTheme').addEventListener('click',function(){var d=document.documentElement,n=d.getAttribute('data-theme')==='dark'?'light':'dark';if(n==='dark')d.setAttribute('data-theme','dark');else d.removeAttribute('data-theme');try{localStorage.setItem('th-theme',n)}catch(e){}});</script>
</body></html>`;
}
const toolCard = t => `<a class="tc g-tc" href="/tools/${t.id}/"><div class="tc-ic" style="background:${CAT_CONFIG[t.cat].bg}">${toolIconSvg(t, 20)}</div><div class="tc-nm">${esch(t.name)}</div><div class="tc-ds">${esch(t.desc)}</div></a>`;
const crumbs = items => `<nav class="g-bc" aria-label="Breadcrumb">${items.map((it, i) => it[1] ? `<a href="${it[1]}">${esch(it[0])}</a>` : `<span aria-current="page">${esch(it[0])}</span>`).join('<span class="bc-sep" aria-hidden="true">&rsaquo;</span>')}</nav>`;
const crumbLd = items => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it[0], item: it[1] ? SITE + it[1] : undefined })) });
function writeStatic(rel, title, desc, inner, lds, pri) {
  const url = `${SITE}/${rel}`;
  let h = variant(url, title, desc, null, null, headPart + staticShell(inner));
  h = h.replace('</head>', () => lds.map(o => `<script type="application/ld+json">${JSON.stringify(o)}</script>`).join('\n') + '\n</head>');
  const dir = path.join(dist, rel); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), h);
  urls.push({ loc: url, pri });
}
GUIDES.forEach(g => {
  const toolsById = id => TOOLS.find(t => t.id === id);
  const related = GUIDES.filter(x => x.slug !== g.slug).slice(0, 3);
  const bc = [['Home', '/'], ['Guides', '/guides/'], [g.title, null]];
  const inner = `<div class="wrap-sm g-art">${crumbs(bc)}<h1>${esch(g.title)}</h1><p class="g-lead">${esch(g.desc)}</p>${GUIDE_BODY[g.slug]()}
<h2>Try the tools</h2><div class="g-tools">${g.tools.map(toolsById).filter(Boolean).map(toolCard).join('')}</div>
<h2>More guides</h2><ul class="g-more">${related.map(r => `<li><a href="/guides/${r.slug}/">${esch(r.title)}</a></li>`).join('')}</ul></div>`;
  const lds = [{ '@context': 'https://schema.org', '@type': 'Article', headline: g.title, description: g.desc, inLanguage: 'en', datePublished: today, dateModified: today, author: { '@type': 'Organization', name: 'Kitwell' }, publisher: { '@type': 'Organization', name: 'Kitwell' }, mainEntityOfPage: `${SITE}/guides/${g.slug}/` }, crumbLd(bc)];
  writeStatic(`guides/${g.slug}/`, `${g.title} | Kitwell`, g.desc, inner, lds, '0.7');
});
{
  const bc = [['Home', '/'], ['Guides', null]];
  const inner = `<div class="wrap-sm g-art">${crumbs(bc)}<h1>Guides</h1><p class="g-lead">Short, worked explanations that go with our calculators and tools. Every example figure is calculated, not guessed.</p><div class="g-list">${GUIDES.map(g => `<a class="g-item" href="/guides/${g.slug}/"><strong>${esch(g.title)}</strong><span>${esch(g.desc)}</span></a>`).join('')}</div></div>`;
  writeStatic('guides/', 'Guides: Calculators and Tools Explained | Kitwell', 'Worked guides on EMI, SIP, income tax, GST, BMI, passwords and PDFs, written to go with the Kitwell tools.', inner, [crumbLd(bc)], '0.8');
}
{
  const bc = [['Home', '/'], ['All tools', null]];
  const sections = Object.keys(CAT_CONFIG).map(cat => { const list = TOOLS.filter(t => t.cat === cat).sort((a, b) => a.name.localeCompare(b.name)); return list.length ? `<section><h2 id="${slug(cat)}">${esch(cat)} <span class="g-n">${list.length}</span></h2><ul class="g-az">${list.map(t => `<li><a href="/tools/${t.id}/">${esch(t.name)}</a><span>${esch(t.desc)}</span></li>`).join('')}</ul></section>` : ''; }).join('');
  const inner = `<div class="wrap g-art g-wide">${crumbs(bc)}<h1>All tools</h1><p class="g-lead">${TOOLS.length} free tools, listed by category. Everything runs in your browser.</p>${sections}</div>`;
  writeStatic('tools/', `All ${TOOLS.length} Free Online Tools, A to Z | Kitwell`, `Every Kitwell tool in one list, grouped by category: text, calculators, images, PDF, developer, SEO and more.`, inner, [crumbLd(bc)], '0.8');
}

fs.writeFileSync(path.join(dist, 'sitemap.xml'), '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
  urls.map(u => `  <url><loc>${u.loc}</loc><lastmod>${today}</lastmod><priority>${u.pri}</priority></url>`).join('\n') + '\n</urlset>\n');
fs.writeFileSync(path.join(dist, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml\n`);
console.log('Built', (base.length / 1024).toFixed(1) + ' KB base,', TOOLS.length, 'tool pages,', urls.length, 'sitemap URLs, SITE =', SITE);
