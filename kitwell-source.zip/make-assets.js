// One-off: renders og-image.png and PWA icons with Playwright. Run: node make-assets.js
const { chromium } = require('playwright'); const fs = require('fs');
const mark = (s) => `<svg width="${s}" height="${s}" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#2451E0"/><rect x="8.5" y="7" width="4.5" height="18" rx="1.6" fill="#fff"/><path d="M14.5 16.2L22.8 7.8" stroke="#fff" stroke-width="4.5" stroke-linecap="round"/><path d="M14.5 15.8L22.8 24.2" stroke="#7DD3FC" stroke-width="4.5" stroke-linecap="round"/></svg>`;
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const font = fs.readFileSync('fonts/inter.woff2').toString('base64');
  const css = `@font-face{font-family:I;src:url(data:font/woff2;base64,${font}) format('woff2');font-weight:100 900}*{margin:0;box-sizing:border-box}body{font-family:I,sans-serif}`;
  let p = await b.newPage({ viewport: { width: 1200, height: 630 } });
  await p.setContent(`<style>${css}body{width:1200px;height:630px;background:#0A1120;color:#fff;padding:80px;position:relative;overflow:hidden}
  .g{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px);background-size:48px 48px}
  .l{display:flex;align-items:center;gap:18px;font-size:34px;font-weight:700;position:relative}.l span b{color:#7DD3FC}
  h1{font-size:92px;line-height:1.02;letter-spacing:-.035em;margin-top:70px;position:relative}h1 em{font-style:normal;color:#7DD3FC}
  p{font-size:32px;color:#9AA7BD;margin-top:30px;position:relative}.bar{position:absolute;left:0;right:0;bottom:0;height:8px;background:#2451E0}</style>
  <div class="g"></div><div class="l">${mark(64)}<span>Kit<b>well</b></span></div><h1>150+ free <em>online tools</em></h1><p>Text, calculators, PDF, images, code and SEO. No login needed.</p><div class="bar"></div>`);
  await p.screenshot({ path: 'public/og-image.png' });
  for (const s of [192, 512]) {
    p = await b.newPage({ viewport: { width: s, height: s } });
    await p.setContent(`<style>*{margin:0}body{width:${s}px;height:${s}px;background:#2451E0}</style>${mark(s).replace('rx="8"', 'rx="0"')}`);
    await p.screenshot({ path: `public/icon-${s}.png` });
  }
  await b.close();
})();
